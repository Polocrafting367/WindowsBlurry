document.getElementById('helpBtn').addEventListener('click', () => {
    window.open('help.html', 'HelpWindow', 'width=400,height=300');
});
