   
let anchorCell = null;   // cellule d’ancrage
let anchorRow  = null;   // index de ligne de l’ancre

    // ✅ Nouveau modèle : palette par utilisateur (rétrocompatible)
    let utilisateurs = {
      A: { HQ: "#a8e3a2" },
      B: { HQ: "#ffcba4" }
    };
    let utilisateurEnEdition = null;      // pour le renommage rapide/HQ
    let userPaletteEnEdition = null;      // pour la modal 🎨
    let planningData = {};
let lastSelection = null;

    const jours = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"];
    let currentJourIndex = 0;
    let selectedCells = [];
    let isMouseDown = false;
    let lignesMachine = [];
    const parametresParJour = {};
    const blocsParJour = {};




// 🔑 Clés de stockage
const LS_KEYS = {
  CURRENT: 'planning_current_v1',
  HISTORY: 'planning_history_v1',
  HISTORY_PTR: 'planning_history_ptr_v1'
};

const HISTORY_LIMIT = 50;     // nombre max d'entrées dans l'historique
const AUTOSAVE_DELAY = 1200;  // debounce autosave (ms)

let autosaveTimer = null;

// 🧱 Construit un état sérialisable cohérent
function buildSerializableState() {
  // Assure-toi de capturer l’état courant de la journée
  if (typeof enregistrerEtatCourant === 'function') {
    try { enregistrerEtatCourant(); } catch(e) {}
  }

  // Normalise les palettes utilisateurs (HEX)
  const normUsers = (typeof normalizeUtilisateurs === 'function')
    ? normalizeUtilisateurs(utilisateurs || {})
    : (utilisateurs || {});

  return {
    meta: {
      savedAt: new Date().toISOString(),
      version: 1
    },
    parametres: parametresParJour || {},
    blocs: blocsParJour || {},
    machines: lignesMachine || [],
    utilisateurs: normUsers
  };
}






    // --- Helpers couleurs ---
    function hexToRgbObj(hex) {
      if (!hex || typeof hex !== "string") return {r: 204, g: 204, b: 204};
      const clean = hex.trim().startsWith("#") ? hex.trim().slice(1) : hex.trim();
      if (clean.length !== 6) return {r: 204, g: 204, b: 204};
      const num = parseInt(clean, 16);
      return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
    }
    function rgbStrToObj(rgbStr) {
      const m = /rgb\((\d+),\s*(\d+),\s*(\d+)\)/i.exec(rgbStr || "");
      if (!m) return {r: 204, g: 204, b: 204};
      return { r: +m[1], g: +m[2], b: +m[3] };
    }
    function textColorFor(colorStrOrHex) {
      const isStr = typeof colorStrOrHex === "string";
      const rgb = isStr && colorStrOrHex.startsWith("#") ? hexToRgbObj(colorStrOrHex) : rgbStrToObj(colorStrOrHex || "");
      const lum = 0.299*rgb.r + 0.587*rgb.g + 0.114*rgb.b;
      return lum < 128 ? "#fff" : "#000";
    }

    // Ton algorithme d’ajustement pour l’auto
    function ajusterCouleur(baseColor, frequence) {
      const adjustColor = (hex, amt) => {
        const num = parseInt(hex.slice(1), 16);
        let r = (num >> 16) + amt;
        let g = ((num >> 8) & 0x00FF) + amt;
        let b = (num & 0x0000FF) + amt;
        r = Math.max(0, Math.min(255, r));
        g = Math.max(0, Math.min(255, g));
        b = Math.max(0, Math.min(255, b));
        return { r, g, b, rgb: `rgb(${r}, ${g}, ${b})` };
      };
      let amt = 0;
      switch (frequence) {
        case "S1": amt = 40; break;
        case "S2": amt = -40; break;
        case "S3": amt = -80; break;
        case "S4": amt = -120; break;
        case "HQ":
        default: amt = 0;
      }
      const adjusted = adjustColor(baseColor, amt);
      const luminance = 0.299 * adjusted.r + 0.587 * adjusted.g + 0.114 * adjusted.b;
      const textColor = luminance < 128 ? "#fff" : "#000";
      return { backgroundColor: adjusted.rgb, textColor };
    }

    // Palette auto (à partir de HQ)
    function paletteAutoDepuisBase(baseHex) {
      return {
        HQ: baseHex,
        S1: ajusterCouleur(baseHex, "S1").backgroundColor,
        S2: ajusterCouleur(baseHex, "S2").backgroundColor,
        S3: ajusterCouleur(baseHex, "S3").backgroundColor,
        S4: ajusterCouleur(baseHex, "S4").backgroundColor
      };
    }

    // --- Normalisation & conversions (pour sauvegarde fiable) ---

    function normalizePalette(p) {
      if (!p) return { HQ:"#cccccc", S1:"#b3b3b3", S2:"#999999", S3:"#808080", S4:"#666666" };
      if (typeof p === "string") {
        const hq = rgbToHexStr(p);
        const auto = paletteAutoDepuisBase(hq);
        return {
          HQ: hq,
          S1: rgbToHexStr(auto.S1),
          S2: rgbToHexStr(auto.S2),
          S3: rgbToHexStr(auto.S3),
          S4: rgbToHexStr(auto.S4),
        };
      }
      const HQ = rgbToHexStr(p.HQ || p.base || "#cccccc");
      const auto = paletteAutoDepuisBase(HQ);
      return {
        HQ,
        S1: rgbToHexStr(p.S1 || auto.S1),
        S2: rgbToHexStr(p.S2 || auto.S2),
        S3: rgbToHexStr(p.S3 || auto.S3),
        S4: rgbToHexStr(p.S4 || auto.S4),
      };
    }
    function normalizeUtilisateurs(obj) {
      const out = {};
      for (const [nom, pal] of Object.entries(obj || {})) {
        out[nom] = normalizePalette(pal);
      }
      return out;
    }

    // Récupère la couleur pour user+fréquence (gère rétrocompat)
    function getUserFreqColor(user, freq) {
      const u = utilisateurs[user];
      if (!u) return "#ccc";
      if (typeof u === "string") {
        if (freq === "HQ" || freq === "none" || !freq) return u;
        return ajusterCouleur(u, freq).backgroundColor;
      }
      const base = u.HQ || u.base || "#ccc";
      if (freq === "HQ" || freq === "none" || !freq) return u.HQ || base;
      if (u[freq]) return u[freq];
      return ajusterCouleur(base, freq).backgroundColor;
    }

    // Chargement initial depuis le serveur
    fetch('charger.php')
      .then(res => res.json())
      .then(data => {
        Object.assign(parametresParJour, data.parametres || {});
        Object.assign(blocsParJour, data.blocs || {});
        lignesMachine = data.machines || [];
        if (data.utilisateurs) utilisateurs = normalizeUtilisateurs(data.utilisateurs); // ✅
        majListeUtilisateurs();
        chargerParametresJour();
      });

    // Souris / sélection
    document.body.addEventListener("mousedown", () => isMouseDown = true);
document.body.addEventListener("mouseup", () => {
  if (!isMouseDown) return;
  isMouseDown = false;

  // S’il y a une sélection, affichage/positionnement
  if (selectedCells.length > 0) {
    const overlay = document.getElementById("overlay");
    overlay.style.display = "block";     // pour mesurer
    positionOverlayForSelection();  
focusOverlayTexte({ selectAll: true }); // ← focus + sélection du texte
     // place et clamp par rapport à TOUTE la sélection
  }

  majCadreSelection(); // s’assure que le cadre est ok à la fin du drag
  anchorCell = null;
  anchorRow  = null;
});


    function fermerOverlay() {
      const overlay = document.getElementById("overlay");
      overlay.style.display = "none";
      selectedCells.forEach(cell => cell.classList.remove("selected"));
      selectedCells = [];
      document.getElementById("selectionBox").style.display = "none";

    }

    function changerJour(delta) {
      enregistrerEtatCourant();
      currentJourIndex = (currentJourIndex + delta + 7) % 7;
      document.getElementById("jourAffichage").textContent = jours[currentJourIndex];
      chargerParametresJour();
    }

    function enregistrerEtatCourant() {
      const jour = jours[currentJourIndex];
      parametresParJour[jour] = {
        startHour: parseFloat(document.getElementById("startHourInput").value),
        totalHours: parseFloat(document.getElementById("totalHoursInput").value),
        pauseStart: parseFloat(document.getElementById("pauseStartInput").value),
        pauseEnd: parseFloat(document.getElementById("pauseEndInput").value)
      };

      const blocs = [];
      document.querySelectorAll("#planningBody tr").forEach((tr, rowIndex) => {
        let colIndex = 0;
        tr.querySelectorAll("td:not(:first-child)").forEach(td => {
          if (!td.classList.contains("pause") && td.classList.contains("merged")) {
            let user = "";
            for (const nom in utilisateurs) {
              if (td.classList.contains(nom)) { user = nom; break; }
            }
            blocs.push({
              ligne: rowIndex,
              start: colIndex,
              end: colIndex + (td.colSpan || 1) - 1,
              texte: td.textContent,
              codeFiche: td.dataset.codeFiche || "",
              user: user,
              frequence: td.dataset.frequence || "none"
            });
          }
          colIndex += td.colSpan || 1;
        });
      });
      blocsParJour[jour] = blocs;
    }

    function enregistrerJSON() {
      enregistrerEtatCourant();
      const utilisateursToSave = normalizeUtilisateurs(utilisateurs); // ✅ toujours palettes HEX complètes
      const data = {
        parametres: parametresParJour,
        blocs: blocsParJour,
        machines: lignesMachine,
        utilisateurs: utilisateursToSave
      };

      fetch('sauver.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
      .then(res => {
        if (!res.ok) throw new Error("Erreur serveur");
        return res.text();
      })
      .then(msg => alert("✅ Sauvegarde réussie"))
      .catch(err => alert("❌ Échec de la sauvegarde : " + err.message));
    }

    function chargerDepuisJSON(event) {
      const file = event.target.files[0];
      const etat = document.getElementById("etatFichier");
      if (!file) {
        etat.textContent = "❌ Aucun fichier sélectionné.";
        etat.style.color = "red";
        return;
      }
      const reader = new FileReader();
      reader.onload = function(e) {
        try {
          const data = JSON.parse(e.target.result);
          Object.assign(parametresParJour, data.parametres || {});
          Object.assign(blocsParJour, data.blocs || {});
          lignesMachine = data.machines || [];
          if (data.utilisateurs) {
            utilisateurs = normalizeUtilisateurs(data.utilisateurs); // ✅
          }
          majListeUtilisateurs();
          chargerParametresJour();
          etat.textContent = `✅ Chargé : ${file.name}`;
          etat.style.color = "green";
        } catch (err) {
          etat.textContent = "❌ Erreur dans le fichier JSON.";
          etat.style.color = "red";
        }
      };
      reader.readAsText(file);
    }

    function chargerParametresJour() {
      const jour = jours[currentJourIndex];
      const params = parametresParJour[jour] || { startHour: 7, totalHours: 13, pauseStart: 0, pauseEnd: 0 };
      document.getElementById("startHourInput").value = params.startHour;
      document.getElementById("totalHoursInput").value = params.totalHours;
      document.getElementById("pauseStartInput").value = params.pauseStart;
      document.getElementById("pauseEndInput").value = params.pauseEnd;
      rebuildPlanning();
      majListeUtilisateurs();
    }

function rebuildPlanning(force = false) {
  const startHour = parseFloat(document.getElementById("startHourInput").value);
  const totalHours = parseFloat(document.getElementById("totalHoursInput").value);
  const pauseStart = parseFloat(document.getElementById("pauseStartInput").value);
  const pauseEnd = parseFloat(document.getElementById("pauseEndInput").value);
  generatePlanning(startHour, totalHours, pauseStart, pauseEnd);

  // ✅ autosave (optionnel)
  if (force === true) {
    scheduleAutosave('rebuildPlanning');

  }
}


    function generatePlanning(startHour, totalHours, pauseStart, pauseEnd) {
      const thead = document.getElementById("planningHead");
      const tbody = document.getElementById("planningBody");
      thead.innerHTML = "";
      tbody.innerHTML = "";
      selectedCells = [];

      const startOffset = startHour % 1;
      const fullStartHour = Math.floor(startHour);
      const nbQuarts = Math.ceil(totalHours * 4);

      // En-tête 2 lignes
      const headRow1 = document.createElement("tr");
      const headRow2 = document.createElement("tr");
      headRow1.innerHTML = '<th rowspan="2">Machine</th>';
      headRow2.innerHTML = '';

      for (let i = 0; i < Math.ceil(totalHours); i++) {
        const hour = Math.floor(startHour + i);
        const thHour = document.createElement("th");
        thHour.textContent = `${hour % 24}h`;
        thHour.colSpan = 4;
        headRow1.appendChild(thHour);
        for (let q = 0; q < 4; q++) {
          const thQ = document.createElement("th");
          thQ.textContent = "";
          headRow2.appendChild(thQ);
        }
      }
      thead.appendChild(headRow1);
      thead.appendChild(headRow2);

      const jour = jours[currentJourIndex];
      const blocs = blocsParJour[jour] || [];

      lignesMachine.forEach((nom, rowIndex) => {
        const tr = document.createElement("tr");
        const tdLabel = document.createElement("td");
tdLabel.innerHTML = `
  <span class="machine-label">${nom}</span>
  <button class="row-edit-btn" title="Éditer / Actions">✏️</button>
`;

tdLabel.querySelector(".machine-label").style.cursor = "default";

tdLabel.querySelector(".row-edit-btn").addEventListener("click", (e) => {
  e.stopPropagation();
  openRowOverlayFor(tdLabel, rowIndex);
});

        // Modifier le nom de la machine
        tdLabel.querySelector(".machine-label").addEventListener("click", () => {
          const nouveauNom = prompt("Modifier le nom de la machine :", nom);
          if (nouveauNom && nouveauNom.trim()) {
            lignesMachine[rowIndex] = nouveauNom.trim();
            rebuildPlanning();
            scheduleAutosave('renameMachine');

          }
        });



        tr.appendChild(tdLabel);

        let cursor = 0;
        while (cursor < nbQuarts) {
          const bloc = blocs.find(b => b.ligne === rowIndex && b.start === cursor);
          const td = document.createElement("td");
          const currentHour = fullStartHour + Math.floor(cursor / 4) + (cursor % 4) * 0.25;

          if (bloc) {
            bloc.frequence = bloc.frequence || "none";
            td.colSpan = bloc.end - bloc.start + 1;
            td.innerHTML = bloc.texte === " " ? "&nbsp;" : bloc.texte;
            td.dataset.codeFiche = bloc.codeFiche || "";
td.dataset.row = rowIndex;               // ✅ index de ligne
td.dataset.start = bloc.start;           // ✅ position en quarts (début)
td.dataset.end = bloc.end;               // ✅ position en quarts (fin)
td.dataset.user = bloc.user || "";       // ✅ pour info/overlay

            if (bloc.user) {
              td.classList.add(bloc.user);
              const bg = getUserFreqColor(bloc.user, bloc.frequence);
              td.style.backgroundColor = bg;
              td.style.color = textColorFor(bg);
            }

            td.classList.add("merged");
            td.addEventListener("click", () => {
              selectedCells.forEach(c => c.classList.remove("selected"));
              selectedCells = [td];
              td.classList.add("selected");
              td.id = "selectedCell";
            td.dataset.frequence = bloc.frequence || "none";
            // 📌 MàJ de l'ancre de sélection
lastSelection = {
  row: +td.dataset.row,
  start: +td.dataset.start,
  end: +td.dataset.end
};

const bgClick = getUserFreqColor(bloc.user, td.dataset.frequence);
td.style.backgroundColor = bgClick;
td.style.color = textColorFor(bgClick);

// 📝 Préremplissage overlay
document.getElementById("overlayTexte").value = td.textContent?.trim() || "";
document.getElementById("overlayFiche").value = td.dataset.codeFiche || "";
document.getElementById("overlayTech").value = bloc.user || Object.keys(utilisateurs)[0] || "";
document.getElementById("overlayFrequence").value = td.dataset.frequence;



              const rect = td.getBoundingClientRect();
              const overlay = document.getElementById("overlay");
              overlay.style.top = `${window.scrollY + rect.top - 90}px`;
              overlay.style.left = `${rect.left}px`;
              overlay.style.display = "block";
positionOverlayForSelection?.();     // si tu le fais ici
focusOverlayTexte({ selectAll: true }); // ← focus + sélection du texte


positionOverlayNearCell(overlay, rect, 12, 5, "top"); // "top" d’abord

            });

            if (cursor < startOffset * 4) {
              td.classList.add("hors-duree");
              //td.textContent = "";
            }
            cursor = bloc.end + 1;
          } else {
            if (currentHour >= pauseStart && currentHour < pauseEnd) {
              td.classList.add("pause");
              td.dataset.row = rowIndex;
            } else {
              td.classList.add("editable");
              td.dataset.row = rowIndex;
              td.addEventListener("mousedown", () => startSelection(td));
td.addEventListener("mouseenter", () => extendSelection(td)); // plus stable que mouseover
    }

            const maxQuarts = totalHours * 4;
            const isExtra = cursor >= maxQuarts;
            const isBeforeStart = cursor < startOffset * 4;
            if (isExtra || isBeforeStart) {
              td.classList.add("hors-duree");
            }
            cursor++;
          }
          tr.appendChild(td);
        }
        tbody.appendChild(tr);
      });
    }

function startSelection(td) {
  majCadreSelection(); 
  if (td.classList.contains("pause") || td.classList.contains("merged")) return;

  isMouseDown = true;
  anchorCell = td;
  anchorRow  = td.dataset.row;

  // reset + sélection de l’ancre
  selectedCells.forEach(c => c.classList.remove("selected"));
  selectedCells = [td];
  td.classList.add("selected");
}

function extendSelection(td) {
  majCadreSelection();
  if (!isMouseDown) return;
  if (td.classList.contains("pause") || td.classList.contains("merged")) return;
  if (td.dataset.row !== anchorRow) return;  // une seule ligne

  const row = td.parentElement;
  const allCells = Array.from(row.querySelectorAll("td:not(:first-child)"));
  const aIndex = allCells.indexOf(anchorCell);
  const tIndex = allCells.indexOf(td);
  if (aIndex < 0 || tIndex < 0) return;

  const min = Math.min(aIndex, tIndex);
  const max = Math.max(aIndex, tIndex);
  const range = allCells.slice(min, max + 1);

  // garde-fou : rien de fusionné/texte/pause dans l’intervalle (hors extrémités)
  for (let i = min + 1; i < max; i++) {
    const cell = allCells[i];
    if (
      cell.classList.contains("merged") ||
      cell.classList.contains("pause") ||
      cell.textContent.trim()
    ) {
      return; // on n’étend pas par-dessus un bloc
    }
  }

  // appliquer la sélection (symétrique gauche ↔ droite)
  selectedCells.forEach(c => c.classList.remove("selected"));
  selectedCells = range;
  selectedCells.forEach(c => c.classList.add("selected"));
}

    function applySelection() {
        commitNormalizeOverlayTexte(); // garantit normalisation même sans Enter/blur

      const tech = document.getElementById("overlayTech").value;
      const texteVisible = document.getElementById("overlayTexte").value;
      const ficheCode = document.getElementById("overlayFiche").value;
      const frequence = document.getElementById("overlayFrequence").value;
const startIdxForNew = getAbsoluteStartIndexForSelection(selectedCells);

      if (selectedCells.length === 0) return;

      const row = selectedCells[0].parentElement;
      const firstIndex = Array.from(row.children).indexOf(selectedCells[0]);

      const isMerged = selectedCells.length === 1 && selectedCells[0].classList.contains("merged");
      const colspan = isMerged ? (selectedCells[0].colSpan || 1) : selectedCells.length;

      selectedCells.forEach(cell => cell.remove());

      const merged = document.createElement("td");
      merged.colSpan = colspan;
      merged.textContent = texteVisible;
      merged.className = tech + " merged";
merged.dataset.row = selectedCells[0].dataset.row;
merged.dataset.start = startIdxForNew;
merged.dataset.end = startIdxForNew + colspan - 1;
merged.dataset.user = tech;
      merged.dataset.codeFiche = ficheCode;
      merged.dataset.frequence = frequence;
// 📌 Ancre la nouvelle sélection
lastSelection = {
  row: +merged.dataset.row,
  start: +merged.dataset.start,
  end: +merged.dataset.end
};

      const bg = getUserFreqColor(tech, frequence);
      merged.style.backgroundColor = bg;
      merged.style.color = textColorFor(bg);

      merged.addEventListener("click", () => {
        selectedCells.forEach(c => c.classList.remove("selected"));
        selectedCells = [merged];
        merged.classList.add("selected");

        const rect = merged.getBoundingClientRect();
        const overlay = document.getElementById("overlay");
        overlay.style.top = `${window.scrollY + rect.top - 90}px`;
        overlay.style.left = `${rect.left}px`;
overlay.style.display = "block";
positionOverlayForSelection?.();     // si tu le fais ici
focusOverlayTexte({ selectAll: true }); // ← focus + sélection du texte

positionOverlayNearCell(overlay, rect, 12, 5, "top"); // "top" d’abord

        document.getElementById("overlayTexte").value = merged.textContent;
        document.getElementById("overlayFiche").value = merged.dataset.codeFiche || "";
        document.getElementById("overlayTech").value = tech;
        document.getElementById("overlayFrequence").value = merged.dataset.frequence || "none";
      });

      row.insertBefore(merged, row.children[firstIndex] || null);
      document.getElementById("overlay").style.display = "none";
      resetOverlayFields();                // 🧼 vider les champs après application

      selectedCells = [];
      scheduleAutosave('applySelection');
    }

    function resetSelection() {
      if (selectedCells.length === 0) return;
      const row = selectedCells[0].parentElement;
      const startIndex = Array.from(row.children).indexOf(selectedCells[0]);
      const colspan = selectedCells[0].colSpan || 1;
      const rowIndex = selectedCells[0].dataset.row;

      row.removeChild(selectedCells[0]);

      for (let i = 0; i < colspan; i++) {
        const newTd = document.createElement("td");
        newTd.className = "editable";
        newTd.dataset.row = rowIndex;
      newTd.addEventListener("mousedown", () => startSelection(newTd));
newTd.addEventListener("mouseenter", () => extendSelection(newTd));
    row.insertBefore(newTd, row.children[startIndex + i] || null);
      }

      selectedCells = [];
      document.getElementById("overlay").style.display = "none";
      scheduleAutosave('resetSelection');

    }

    function ajouterLigneMachine() {
      const nom = prompt("Nom de la nouvelle ligne :");
      if (nom) {
        lignesMachine.push(nom);
        rebuildPlanning();
          scheduleAutosave('addMachine');

      }

    }

    // Export JSON (local) avec palettes normalisées
    function exporterPlanning() {
      enregistrerEtatCourant();
      const utilisateursToSave = normalizeUtilisateurs(utilisateurs); // ✅

      const data = {
        parametres: parametresParJour,
        blocs: blocsParJour,
        machines: lignesMachine,
        utilisateurs: utilisateursToSave
      };

      const date = new Date();
      const yyyy = date.getFullYear();
      const mm = String(date.getMonth() + 1).padStart(2, '0');
      const dd = String(date.getDate()).padStart(2, '0');
      const fileName = `Planning-${yyyy}-${mm}-${dd}.json`;

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = fileName;
      a.click();
    }

    function ouvrirGestionUtilisateurs() {
      const modal = document.getElementById("modalUtilisateurs");
      const ul = document.getElementById("listeUtilisateurs");
      ul.innerHTML = "";

      for (const nom in utilisateurs) {
        const li = document.createElement("li");
        li.innerHTML = `
          <span style="display:inline-block; width:12px; height:12px; background:${getUserFreqColor(nom,"HQ")}; margin-right:5px;"></span>
          <strong>${nom}</strong>
          <button onclick="remplirEditionUtilisateur('${nom}')" title="Renommer / Couleur HQ rapide">✏️</button>
          <button onclick="ouvrirModalCouleurs('${nom}')" title="Personnaliser HQ/S1–S4">🎨</button>
          <button onclick="supprimerUtilisateur('${nom}')" title="Supprimer">🗑</button>
        `;
        ul.appendChild(li);
      }

      document.getElementById("utilisateurBtn").textContent = "➕ Ajouter";
      utilisateurEnEdition = null;
      modal.style.display = "block";
    }

    function remplirEditionUtilisateur(nom) {
      document.getElementById("nouvelUtilisateur").value = nom;
      const pal = normalizePalette(utilisateurs[nom]); // ✅ recup HQ même si palette objet
      document.getElementById("couleurUtilisateur").value = pal.HQ;
      document.getElementById("utilisateurBtn").textContent = "✅ Valider";
      utilisateurEnEdition = nom;
    }

    function fermerModalUtilisateurs() {
      document.getElementById("modalUtilisateurs").style.display = "none";
    }

    function ajouterUtilisateur() {
      const nom = document.getElementById("nouvelUtilisateur").value.trim();
      const couleur = document.getElementById("couleurUtilisateur").value;

      if (!nom) {
        alert("⚠️ Entrez un nom.");
        return;
      }

      if (utilisateurEnEdition) {
        if (utilisateurEnEdition !== nom && utilisateurs[nom]) {
          alert("⚠️ Ce nom est déjà pris.");
          return;
        }
        const ancien = utilisateurs[utilisateurEnEdition];
        let palette;
        if (typeof ancien === "object") {
          palette = { ...ancien, HQ: couleur };
        } else {
          palette = { HQ: couleur };
        }
        delete utilisateurs[utilisateurEnEdition];
        utilisateurs[nom] = palette;
        utilisateurEnEdition = null;
        document.getElementById("utilisateurBtn").textContent = "➕ Ajouter";
      } else {
        if (utilisateurs[nom]) {
          alert("⚠️ Utilisateur déjà existant.");
          return;
        }
        utilisateurs[nom] = { HQ: couleur };
      }

      document.getElementById("nouvelUtilisateur").value = "";
      ouvrirGestionUtilisateurs();
      majListeUtilisateurs();
      rebuildPlanning(true);
      scheduleAutosave('addOrEditUser');

    }

    function supprimerUtilisateur(nom) {
      if (confirm(`Supprimer l'utilisateur "${nom}" ?`)) {
        delete utilisateurs[nom];
        ouvrirGestionUtilisateurs();
        majListeUtilisateurs();
      }
    scheduleAutosave('deleteUser');

    }

    function majListeUtilisateurs() {
      const select = document.getElementById("overlayTech");
      select.innerHTML = "";
      for (const nom in utilisateurs) {
        const opt = document.createElement("option");
        opt.value = nom;
        opt.textContent = nom;
        select.appendChild(opt);
      }

      const ul = document.getElementById("listeUtilisateurs");
      if (ul) {
        ul.innerHTML = "";
        for (const nom in utilisateurs) {
          const li = document.createElement("li");
          li.innerHTML = `
            <span style="display:inline-block; width:12px; height:12px; background:${getUserFreqColor(nom,"HQ")}; margin-right:5px;"></span>
            <strong>${nom}</strong>
            <button onclick="remplirEditionUtilisateur('${nom}')" title="Renommer / Couleur HQ rapide">✏️</button>
            <button onclick="ouvrirModalCouleurs('${nom}')" title="Personnaliser HQ/S1–S4">🎨</button>
            <button onclick="supprimerUtilisateur('${nom}')" title="Supprimer">🗑</button>
          `;
          ul.appendChild(li);
        }
      }
    }

    // ----- Export PNG -----
    let nbColonnesExport = null;
    let exportEndHourOrigine = null;
    let valeurInitialeExport = null;
    let defautstart = null;

    function ouvrirModalExportpng() {
      const startBase = parseFloat(document.getElementById("startHourInput").value);
      const total = parseFloat(document.getElementById("totalHoursInput").value);
      const endBase = startBase + total - 0.5;

      document.getElementById("exportStartHour").value = startBase - 0.5;
      document.getElementById("exportEndHour").value = endBase;

      exportEndHourOrigine = endBase;
      valeurInitialeExport = endBase - startBase - 0.5;
      defautstart = startBase;
      genererPreviewExport();
      document.getElementById("modalExportpng").style.display = "block";
    }

    function genererPreviewExport() {
      const start = parseFloat(document.getElementById("exportStartHour").value) - 4.75;
      const end = parseFloat(document.getElementById("exportEndHour").value) + (start - defautstart) + .75;
      if (isNaN(start) || isNaN(end) || start >= end) {
        alert("Plage horaire invalide.");
        return;
      }

      const baseStart = 0;
      const startIndex = Math.round((start - baseStart) * 4);
      const endIndex = Math.round((end - baseStart - start) * 4);

      const preview = document.getElementById("previewExport");
      preview.innerHTML = "";

      const sourceTable = document.getElementById("planningTable");
      const tableClone = sourceTable.cloneNode(true);
      tableClone.id = "planningTableExport";
      tableClone.style.marginBottom = "10px";
      tableClone.querySelectorAll("button").forEach(btn => btn.remove());

      const allRows = tableClone.querySelectorAll("tr");
      allRows.forEach((row) => {
        let colIndex = 0;
        const cells = Array.from(row.querySelectorAll("td, th"));
        cells.forEach(cell => {
          const span = cell.colSpan || 1;
          const isHorsPlage = colIndex + span <= startIndex || colIndex >= endIndex;
          if (cell.cellIndex > 0 && isHorsPlage) {
            cell.remove();
          }
          colIndex += span;
        });
      });

      const currentEnd = parseFloat(document.getElementById("exportEndHour").value);
      const currentStart = parseFloat(document.getElementById("exportStartHour").value);
      const referenceHeureFin = defautstart + 0.5 + valeurInitialeExport;

      if (valeurInitialeExport !== null && currentEnd !== referenceHeureFin && allRows.length >= 2) {
        const secondHeaderRow = allRows[1];
        const ths = secondHeaderRow.querySelectorAll("th");
        if (ths.length > 0) ths[ths.length - 1].remove();
      }

      const exportWrapper = document.createElement("div");
      exportWrapper.style.display = "flex";
      exportWrapper.style.flexDirection = "column";
      exportWrapper.style.alignItems = "center";
      exportWrapper.style.width = "fit-content";
      exportWrapper.style.margin = "0 auto";
      exportWrapper.appendChild(tableClone);

      const footerBar = document.createElement("div");
      footerBar.style.display = "flex";
      footerBar.style.justifyContent = "space-between";
      footerBar.style.alignItems = "center";
      footerBar.style.width = tableClone.offsetWidth + "px";
      footerBar.style.fontSize = "14px";
      footerBar.style.gap = "10px";
      setTimeout(() => { footerBar.style.width = tableClone.offsetWidth + "px"; }, 0);

      const legend = document.createElement("div");
      legend.style.display = "flex";
      legend.style.flexWrap = "wrap";
      legend.style.alignItems = "center";
      legend.style.gap = "12px";

      const users = utilisateurs || {};
      for (const [nom, palette] of Object.entries(users)) {
        if (String(nom).toUpperCase() === "PAUSE") continue;
        const item = document.createElement("div");
        item.style.display = "flex";
        item.style.alignItems = "center";
        item.style.gap = "5px";

        const colorBox = document.createElement("div");
        colorBox.style.width = "16px";
        colorBox.style.height = "16px";
        const hq = getUserFreqColor(nom, "HQ");
        colorBox.style.backgroundColor = hq;
        colorBox.style.border = "1px solid #000";

        const label = document.createElement("span");
        label.textContent = nom;

        item.appendChild(colorBox);
        item.appendChild(label);
        legend.appendChild(item);
      }

const frequences = ["S1", "S2", "S3", "S4"];
frequences.forEach(freq => {
  const sample = document.createElement("div");
  sample.style.display = "flex";
  sample.style.alignItems = "center";
  sample.style.gap = "5px";

  // récupérer les deux premiers utilisateurs (ex. A et B)
  const noms = Object.keys(utilisateurs);
  const user1 = noms[1] || null;
  const user2 = noms[2] || null;

  // couleur par user et fréquence
  const color1 = user1 ? getUserFreqColor(user1, freq) : "#aaa";
  const color2 = user2 ? getUserFreqColor(user2, freq) : "#ccc";

  // créer la boîte moitié-moitié
  const colorBox = document.createElement("div");
  colorBox.style.width = "30px";
  colorBox.style.height = "16px";
  colorBox.style.border = "1px solid #000";
  colorBox.style.display = "flex";

  const half1 = document.createElement("div");
  half1.style.flex = "1";
  half1.style.backgroundColor = color1;

  const half2 = document.createElement("div");
  half2.style.flex = "1";
  half2.style.backgroundColor = color2;

  colorBox.appendChild(half1);
  colorBox.appendChild(half2);

  // label "S1" etc.
  const label = document.createElement("span");
  label.textContent = freq;

  sample.appendChild(colorBox);
  sample.appendChild(label);
  legend.appendChild(sample);
});


      const titre = document.createElement("div");
      const jourNom = jours[currentJourIndex];
      titre.textContent = `Planning préventif - ${jourNom.toUpperCase()}`;
      titre.style.flex = "1";
      titre.style.textAlign = "center";

      const date = new Date();
      const dateStr = date.toLocaleDateString("fr-FR");
      const dateExport = document.createElement("div");
      dateExport.textContent = dateStr;
      dateExport.style.whiteSpace = "nowrap";

      footerBar.appendChild(legend);
      footerBar.appendChild(titre);
      footerBar.appendChild(dateExport);

      exportWrapper.appendChild(footerBar);
      preview.appendChild(exportWrapper);
    }




async function imprimerpng({
  orientation = "landscape", // "portrait" | "landscape"
  dpi = 300,                 // résolution finale du PNG
  marginMm = 5,             // marge tout autour (mm)
  align = "center"           // "left" | "center" (ancré en haut dans tous les cas)
} = {}) {
  const table = document.getElementById("planningTableExport");
  if (!table) { alert("❌ planningTableExport introuvable."); return; }

  // 👉 Cible = parent direct (table + footer)
  const wrapper = table.parentElement;
  if (!wrapper) { alert("❌ Conteneur parent de planningTableExport introuvable."); return; }

  // Attendre polices & images pour un rendu fidèle
  try { if (document.fonts?.ready) await document.fonts.ready; } catch {}
  await Promise.all(
    Array.from(wrapper.querySelectorAll("img"))
      .filter(img => !img.complete)
      .map(img => new Promise(res => { img.onload = img.onerror = res; }))
  );

  // Dimensions du contenu
  const rect = wrapper.getBoundingClientRect();
  const contentW = Math.ceil(Math.max(rect.width,  wrapper.scrollWidth  || 0));
  const contentH = Math.ceil(Math.max(rect.height, wrapper.scrollHeight || 0));

  // Capture high-DPI du contenu
  const RENDER_SCALE = 3; // ↑ si tu veux plus de piqué avant redimensionnement
  const canvasSrc = await html2canvas(wrapper, {
    backgroundColor: "#ffffff",
    scale: RENDER_SCALE,
    useCORS: true,
    allowTaint: true,
    width:  contentW + 4,   // marge anti-rognage
    height: contentH + 4,
    windowWidth:  contentW + 4,
    windowHeight: contentH + 4,
    scrollX: 0, scrollY: 0
  });

  // --- Page A4 en px au DPI demandé ---
  const mmToPx = (mm) => Math.round((mm / 25.4) * dpi);
  const A4 = orientation === "landscape"
    ? { wMm: 297, hMm: 210 }
    : { wMm: 210, hMm: 297 };

  const pageW = mmToPx(A4.wMm);
  const pageH = mmToPx(A4.hMm);
  const marginPx = mmToPx(marginMm);

  // Zone de contenu imprimable (après marges)
  const boxW = Math.max(10, pageW - marginPx * 2);
  const boxH = Math.max(10, pageH - marginPx * 2);

  // Dimensions de la capture
  const imgW = canvasSrc.width;
  const imgH = canvasSrc.height;

  // Scale "contain" dans la zone A4, puis ancrage en haut
  const scale = Math.min(boxW / imgW, boxH / imgH, 1); // jamais agrandir au-delà du box
  const drawW = Math.round(imgW * scale);
  const drawH = Math.round(imgH * scale);

  const dx = align === "left"
    ? marginPx
    : Math.round(marginPx + (boxW - drawW) / 2); // centré horizontalement
  const dy = marginPx; // ⇧ ancré en haut

  // Canvas final A4
  const canvasA4 = document.createElement("canvas");
  canvasA4.width = pageW;
  canvasA4.height = pageH;

  const ctx = canvasA4.getContext("2d");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, pageW, pageH);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";

  // Dessiner la capture en haut de page
  ctx.drawImage(canvasSrc, 0, 0, imgW, imgH, dx, dy, drawW, drawH);

  // Export PNG
  const blob = await new Promise(res => canvasA4.toBlob(res, "image/png", 1));
  if (!blob) { alert("❌ Échec de la génération PNG A4."); return; }
  const blobUrl = URL.createObjectURL(blob);

  // Nom de fichier
  const d = new Date();
  const JJ = String(d.getDate()).padStart(2,"0");
  const MM = String(d.getMonth()+1).padStart(2,"0");
  const AA = String(d.getFullYear()).slice(2);
  const jour = (document.getElementById("jourAffichageModal")?.textContent ||
                document.getElementById("jourAffichage")?.textContent || "JOUR").toUpperCase();
  const nomFichier = `Planning-Prev-A4-${orientation}-${jour}-${JJ}-${MM}-${AA}.png`;

  // Mini UI preview / download
  const overlay = document.createElement("div");
  overlay.style.position = "fixed";
  overlay.style.inset = "0";
  overlay.style.background = "rgba(0,0,0,0.95)";
  overlay.style.zIndex = "9999";
  overlay.style.display = "flex";
  overlay.style.flexDirection = "column";
  overlay.style.alignItems = "center";
  overlay.style.justifyContent = "center";
  overlay.style.padding = "20px";
  overlay.style.boxSizing = "border-box";

  const title = document.createElement("p");
  title.textContent = `Prévisualisation A4 (${orientation}, ${dpi} DPI) : ${nomFichier}`;
  title.style.color = "white";
  title.style.fontWeight = "bold";
  title.style.marginBottom = "10px";
  title.style.textAlign = "center";

  const img = document.createElement("img");
  img.src = blobUrl;
  img.alt = nomFichier;
  img.style.maxWidth = "90vw";
  img.style.maxHeight = "80vh";
  img.style.border = "2px solid white";
  img.style.marginBottom = "15px";

  const btns = document.createElement("div");
  btns.style.display = "flex";
  btns.style.gap = "10px";

  const dl = document.createElement("button");
  dl.textContent = "📥 Télécharger";
  dl.style.padding = "10px 20px";
  dl.onclick = () => {
    const a = document.createElement("a");
    a.href = blobUrl; a.download = nomFichier;
    document.body.appendChild(a); a.click();
    document.body.removeChild(a);
  };

  const close = document.createElement("button");
  close.textContent = "Fermer";
  close.style.padding = "10px 20px";
  close.onclick = () => {
    URL.revokeObjectURL(blobUrl);
    document.body.removeChild(overlay);
  };

  btns.appendChild(dl);
  btns.appendChild(close);
  overlay.appendChild(title);
  overlay.appendChild(img);
  overlay.appendChild(btns);
  document.body.appendChild(overlay);


}



    document.getElementById("exportStartHour").addEventListener("keydown", function(e) {
      if (e.key === "," || e.key === "." || e.key === "e") e.preventDefault();
    });
    document.getElementById("exportEndHour").addEventListener("keydown", function(e) {
      if (e.key === "," || e.key === "." || e.key === "e") e.preventDefault();
    });

    // --- Modal couleurs (🎨) ---
    function ouvrirModalCouleurs(nom) {
      userPaletteEnEdition = nom;
      document.getElementById("modalUserName").textContent = nom;

      const u = utilisateurs[nom];
      const base = (typeof u === "string") ? u : (u?.HQ || "#00aa00");
      const prop = paletteAutoDepuisBase(base);
      const palette = (typeof u === "object") ? u : { HQ: base };

      document.getElementById("color-HQ").value = palette.HQ || base;
      document.getElementById("color-S1").value = palette.S1 || colorToHex(prop.S1);
      document.getElementById("color-S2").value = palette.S2 || colorToHex(prop.S2);
      document.getElementById("color-S3").value = palette.S3 || colorToHex(prop.S3);
      document.getElementById("color-S4").value = palette.S4 || colorToHex(prop.S4);

      document.getElementById("modalCouleurs").style.display = "block";
    }
    function fermerModalCouleurs() {
      userPaletteEnEdition = null;
      document.getElementById("modalCouleurs").style.display = "none";
    }
    function autoPaletteCourante() {
      const hq = document.getElementById("color-HQ").value || "#00aa00";
      const p = paletteAutoDepuisBase(hq);
      document.getElementById("color-S1").value = colorToHex(p.S1);
      document.getElementById("color-S2").value = colorToHex(p.S2);
      document.getElementById("color-S3").value = colorToHex(p.S3);
      document.getElementById("color-S4").value = colorToHex(p.S4);
    }
    function reinitialiserPaletteCourante() {
      const hq = document.getElementById("color-HQ").value || "#00aa00";
      const p = paletteAutoDepuisBase(hq);
      document.getElementById("color-HQ").value = hq;
      document.getElementById("color-S1").value = colorToHex(p.S1);
      document.getElementById("color-S2").value = colorToHex(p.S2);
      document.getElementById("color-S3").value = colorToHex(p.S3);
      document.getElementById("color-S4").value = colorToHex(p.S4);
    }
    function validerCouleursPerso() {
      if (!userPaletteEnEdition) return;
      const nom = userPaletteEnEdition;
      utilisateurs[nom] = {
        HQ: document.getElementById("color-HQ").value || "#00aa00",
        S1: document.getElementById("color-S1").value,
        S2: document.getElementById("color-S2").value,
        S3: document.getElementById("color-S3").value,
        S4: document.getElementById("color-S4").value
      };
      majListeUtilisateurs();
      rebuildPlanning(true);
      fermerModalCouleurs();
      scheduleAutosave('paletteUser');

    }

    // Convertit "rgb(r,g,b)" -> "#rrggbb" pour inputs color
    function colorToHex(c) {
      if (!c) return "#cccccc";
      if (typeof c === "string" && c.startsWith("#")) return c;
      const {r,g,b} = rgbStrToObj(c);
      return "#" + [r,g,b].map(v => v.toString(16).padStart(2,"0")).join("");
    }

    // Démarrage
    chargerParametresJour();


    // Efface complètement le jour affiché (paramètres + blocs). Ne touche pas aux lignes machines ni aux utilisateurs.
function effacerJourActuel() {
  const jour = jours[currentJourIndex];

  const ok = confirm(
    `⚠️ Voulez-vous vraiment effacer TOUT le contenu du jour "${jour}" ?`

  );
  if (!ok) return;

  // Supprime les données du jour courant
  delete parametresParJour[jour];
  delete blocsParJour[jour];

  // Ferme l’overlay si ouvert
  try { document.getElementById("overlay").style.display = "none"; } catch(e){}

  // Recharge le jour → reconstruit le tableau avec les valeurs par défaut du jour
  chargerParametresJour();
  // (Optionnel) feedback
  // alert(`✅ Jour "${jour}" effacé.`);
  scheduleAutosave('clearDay');
}

// Efface tout le planning (tous les jours : paramètres + blocs). Ne touche pas aux lignes machines ni aux utilisateurs.
function effacerToutPlanning() {
  const ok1 = confirm(
    "⚠️ Voulez-vous vraiment effacer TOUT le planning (tous les jours) ?"

  );
  if (!ok1) return;

  // Double confirmation pour éviter l’erreur
  const ok2 = confirm("Dernière confirmation : effacer TOUT le planning ? Cette action est irréversible.");
  if (!ok2) return;

  // Vide proprement les structures tout en gardant les mêmes références objets
  for (const k in parametresParJour) delete parametresParJour[k];
  for (const k in blocsParJour) delete blocsParJour[k];

  // Ferme l’overlay si ouvert
  try { document.getElementById("overlay").style.display = "none"; } catch(e){}

  // Reconstruit la vue du jour courant avec les valeurs par défaut
  chargerParametresJour();
  // (Optionnel) feedback
  // alert("✅ Planning intégralement effacé.");
  scheduleAutosave('clearAll');

}

// ===== Helpers pour la grille du jour courant =====
function getGridContext() {
  const startHour = parseFloat(document.getElementById("startHourInput").value);
  const totalHours = parseFloat(document.getElementById("totalHoursInput").value);
  const pauseStart = parseFloat(document.getElementById("pauseStartInput").value);
  const pauseEnd   = parseFloat(document.getElementById("pauseEndInput").value);
  const fullStartHour = Math.floor(startHour);
  const nbQuarts = Math.ceil(totalHours * 4);
  return { startHour, totalHours, pauseStart, pauseEnd, fullStartHour, nbQuarts };
}
function indexToHour(i, fullStartHour) {
  return fullStartHour + Math.floor(i/4) + (i % 4) * 0.25;
}
function isRangeInPause(startIdx, endIdx, ctx) {
  for (let i = startIdx; i <= endIdx; i++) {
    const h = indexToHour(i, ctx.fullStartHour);
    if (h >= ctx.pauseStart && h < ctx.pauseEnd) return true;
  }
  return false;
}
function overlapsAny(startIdx, endIdx, rowBlocks, ignoreIndex = -1) {
  for (let k = 0; k < rowBlocks.length; k++) {
    if (k === ignoreIndex) continue;
    const b = rowBlocks[k];
    if (!(endIdx < b.start || startIdx > b.end)) return true;
  }
  return false;
}
function getCellStartIndexInRow(td) {
  const row = td.parentElement;
  const cells = Array.from(row.querySelectorAll("td:not(:first-child)"));
  let colIndex = 0;
  for (const c of cells) {
    if (c === td) return colIndex;
    colIndex += c.colSpan || 1;
  }
  return -1;
}
function indexToHour(i, fullStartHour) {
  // même calcul que generatePlanning()
  return fullStartHour + Math.floor(i/4) + (i % 4) * 0.25;
}
function isRangeInPause(startIdx, endIdx, ctx) {
  for (let i = startIdx; i <= endIdx; i++) {
    const h = indexToHour(i, ctx.fullStartHour);
    if (h >= ctx.pauseStart && h < ctx.pauseEnd) return true;
  }
  return false;
}
function overlapsAny(startIdx, endIdx, rowBlocks, ignoreIndex = -1) {
  // rowBlocks = liste [{start,end}, ...] **dans le même rang**
  for (let k = 0; k < rowBlocks.length; k++) {
    if (k === ignoreIndex) continue;
    const b = rowBlocks[k];
    if (!(endIdx < b.start || startIdx > b.end)) {
      return true;
    }
  }
  return false;
}

// ===== Décaler TOUT le jour courant de deltaQuarts (±1 = ±0,25h) =====
function shiftJourQuarts(deltaQuarts) {
  if (!deltaQuarts) return;

  const jour = jours[currentJourIndex];
  const ctx = getGridContext();
  const old = blocsParJour[jour] || [];
  if (old.length === 0) return;

  // Regrouper par ligne + garder les index origine
  const byRow = {};
  old.forEach((b, idx) => {
    (byRow[b.ligne] ||= []).push({ ...b, _idx: idx });
  });

  // Validation simultanée ligne par ligne
  for (const [row, list] of Object.entries(byRow)) {
    const moved = list.map(b => ({
      start: b.start + deltaQuarts,
      end:   b.end   + deltaQuarts,
      _idx:  b._idx
    }));

    for (const p of moved) {
      if (p.start < 0 || p.end >= ctx.nbQuarts) {
        alert("❌ Déplacement impossible : un bloc sortirait de la plage horaire.");
        return;
      }
      if (isRangeInPause(p.start, p.end, ctx)) {
        alert("❌ Déplacement impossible : un bloc entrerait dans la zone de pause.");
        return;
      }
    }

    moved.sort((a,b) => a.start - b.start);
    for (let i = 1; i < moved.length; i++) {
      if (moved[i-1].end >= moved[i].start) {
        alert("❌ Déplacement impossible : chevauchement entre blocs après décalage.");
        return;
      }
    }
  }

  // ✅ Appliquer réellement le décalage
  const updated = old.map(b => ({ ...b }));
  for (const list of Object.values(byRow)) {
    for (const b of list) {
      const i = b._idx;
      updated[i].start = b.start + deltaQuarts;
      updated[i].end   = b.end   + deltaQuarts;
    }
  }

  // Mémoriser le bloc sélectionné pour le re-sélectionner après redraw
  let target = null;
  if (selectedCells && selectedCells.length === 1 && selectedCells[0].classList.contains("merged")) {
    const td = selectedCells[0];
    target = {
      row: +td.dataset.row,
      start: +td.dataset.start + deltaQuarts,
      end: +td.dataset.end + deltaQuarts
    };
  }

  blocsParJour[jour] = updated;
  rebuildPlanning(true);
  reselectAfterRebuild(target);

  // autosave
  scheduleAutosave('shiftJour');
}

// ===== Récupérer l'index de départ (en quarts) du TD sélectionné dans sa ligne =====
function getCellStartIndexInRow(td) {
  const row = td.parentElement;
  const cells = Array.from(row.querySelectorAll("td:not(:first-child)"));
  let colIndex = 0;
  for (const c of cells) {
    if (c === td) return colIndex;
    colIndex += c.colSpan || 1;
  }
  return -1;
}

// ===== Déplacer le bloc SELECTIONNÉ de deltaQuarts (±1 = ±0,25h) =====
function moveSelectionByQuarts(deltaQuarts) {
  if (!deltaQuarts) return;
  if (!selectedCells || selectedCells.length !== 1 || !selectedCells[0].classList.contains("merged")) {
    alert("Sélectionnez d'abord un bloc à déplacer.");
    return;
  }
  const td = selectedCells[0];
  const rowIndex = +td.dataset.row;
  const startIdx = +td.dataset.start;
  const endIdx   = +td.dataset.end;

  const jour = jours[currentJourIndex];
  const ctx = getGridContext();
  const blocs = blocsParJour[jour] || [];

  const newStart = startIdx + deltaQuarts;
  const newEnd   = endIdx   + deltaQuarts;

  if (newStart < 0 || newEnd >= ctx.nbQuarts) {
    alert("❌ Déplacement impossible : le bloc sortirait de la plage horaire.");
    return;
  }
  if (isRangeInPause(newStart, newEnd, ctx)) {
    alert("❌ Déplacement impossible : le bloc entrerait dans la zone de pause.");
    return;
  }

  const rowBlocks = blocs.filter(b => b.ligne === rowIndex).map(b => ({start:b.start, end:b.end}));
  let ignoreIdx = -1;
  for (let i = 0; i < rowBlocks.length; i++) {
    if (rowBlocks[i].start === startIdx && rowBlocks[i].end === endIdx) { ignoreIdx = i; break; }
  }
  if (overlapsAny(newStart, newEnd, rowBlocks, ignoreIdx)) {
    alert("❌ Déplacement impossible : chevauchement avec un autre bloc.");
    return;
  }

  let found = false;
  for (const b of blocs) {
    if (b.ligne === rowIndex && b.start === startIdx && b.end === endIdx) {
      b.start = newStart;
      b.end   = newEnd;
      found = true;
      break;
    }
  }
  if (!found) { alert("⚠️ Bloc introuvable dans les données."); return; }

  // 🔁 Rebuild puis re-sélection
  const target = { row: rowIndex, start: newStart, end: newEnd };
  rebuildPlanning(true);
  reselectAfterRebuild(target);

  scheduleAutosave('moveSelection');
}


function resizeSelectionLeftByQuarts(deltaQuarts) {
  // deltaQuarts > 0 : étendre vers la gauche | deltaQuarts < 0 : réduire par la gauche
  if (!selectedCells || selectedCells.length !== 1 || !selectedCells[0].classList.contains("merged")) {
    alert("Sélectionnez d'abord un bloc.");
    return;
  }
  const td = selectedCells[0];
  const rowIndex = +td.dataset.row;
  const startIdx = +td.dataset.start;
  const endIdx   = +td.dataset.end;

  const jour = jours[currentJourIndex];
  const ctx = getGridContext();
  const blocs = blocsParJour[jour] || [];

  const newStart = startIdx - deltaQuarts; // attention au signe
  const newEnd   = endIdx;

  if (newStart < 0 || newStart > newEnd) { alert("❌ Taille invalide."); return; }
  if (isRangeInPause(newStart, newEnd, ctx)) { alert("❌ Le bloc toucherait la pause."); return; }

  const rowBlocks = blocs.filter(b => b.ligne === rowIndex).map(b => ({start:b.start, end:b.end}));
  for (let i = 0; i < rowBlocks.length; i++) {
    const b = rowBlocks[i];
    if (b.start === startIdx && b.end === endIdx) continue; // ignorer soi-même (remplacé par newStart/newEnd)
    if (!(newEnd < b.start || newStart > b.end)) { alert("❌ Chevauchement détecté."); return; }
  }

  let found = false;
  for (const b of blocs) {
    if (b.ligne === rowIndex && b.start === startIdx && b.end === endIdx) {
      b.start = newStart;
      found = true;
      break;
    }
  }
  if (!found) { alert("⚠️ Bloc introuvable dans les données."); return; }

  const target = { row: rowIndex, start: newStart, end: newEnd };
  rebuildPlanning(true);
  reselectAfterRebuild(target);
  scheduleAutosave('resizeLeft');

}


function resizeSelectionRightByQuarts(deltaQuarts) {
  // deltaQuarts > 0 : étendre à droite | deltaQuarts < 0 : réduire par la droite
  if (!selectedCells || selectedCells.length !== 1 || !selectedCells[0].classList.contains("merged")) {
    alert("Sélectionnez d'abord un bloc.");
    return;
  }
  const td = selectedCells[0];
  const rowIndex = +td.dataset.row;
  const startIdx = +td.dataset.start;
  const endIdx   = +td.dataset.end;

  const jour = jours[currentJourIndex];
  const ctx = getGridContext();
  const blocs = blocsParJour[jour] || [];

  const newStart = startIdx;
  const newEnd   = endIdx + deltaQuarts;

  if (newEnd >= ctx.nbQuarts || newEnd < newStart) { alert("❌ Taille invalide."); return; }
  if (isRangeInPause(newStart, newEnd, ctx)) { alert("❌ Le bloc toucherait la pause."); return; }

  const rowBlocks = blocs.filter(b => b.ligne === rowIndex).map(b => ({start:b.start, end:b.end}));
  for (let i = 0; i < rowBlocks.length; i++) {
    const b = rowBlocks[i];
    if (b.start === startIdx && b.end === endIdx) continue;
    if (!(newEnd < b.start || newStart > b.end)) { alert("❌ Chevauchement détecté."); return; }
  }

  let found = false;
  for (const b of blocs) {
    if (b.ligne === rowIndex && b.start === startIdx && b.end === endIdx) {
      b.end = newEnd;
      found = true;
      break;
    }
  }
  if (!found) { alert("⚠️ Bloc introuvable dans les données."); return; }

  const target = { row: rowIndex, start: newStart, end: newEnd };
  rebuildPlanning(true);
  reselectAfterRebuild(target);
  scheduleAutosave('resizeRight');

}


function reselectAfterRebuild(target) {
  if (!target) return;
  const tbody = document.getElementById("planningBody");
  const row = tbody.querySelectorAll("tr")[target.row];
  if (!row) return;
  const blocks = Array.from(row.querySelectorAll("td.merged"));
  for (const td of blocks) {
    if (+td.dataset.start === target.start && +td.dataset.end === target.end) {
      // utilise le handler existant (préremplissage + overlay)
      td.click();
      return;
    }
  }
}




/**
 * Positionne l'overlay près d'une cellule (td) puis le "clamp" dans l'écran.
 * @param {HTMLElement} overlay  - l'élément #overlay
 * @param {DOMRect} anchorRect   - rect de la cellule (getBoundingClientRect)
 * @param {number} offsetX       - décalage horizontal (px)
 * @param {number} offsetY       - décalage vertical (px)
 * @param {"right"|"left"|"top"|"bottom"} prefer - préférence d'ancrage
 */
function positionOverlayNearCell(overlay, anchorRect, offsetX = 12, offsetY = -12, prefer = "top") {
  const margin = 10; // marge intérieure au viewport

  // 1) S'assurer de connaître la taille de l'overlay (display:block mais invisible le temps de mesurer)
  const prevDisplay = overlay.style.display;
  const prevVis = overlay.style.visibility;

  overlay.style.visibility = "hidden";
overlay.style.display = "block";
focusOverlayTexte({ selectAll: true }); // ← focus + sélection du texte

  const ovW = overlay.offsetWidth;
  const ovH = overlay.offsetHeight;

  // 2) Position "cible" brute selon la préférence
  const pageLefts  = {
    right: window.scrollX + anchorRect.right + offsetX,
    left:  window.scrollX + anchorRect.left  - ovW - offsetX,
    top:   window.scrollX + anchorRect.left,
    bottom:window.scrollX + anchorRect.left
  };
  const pageTops   = {
    right: window.scrollY + anchorRect.top,
    left:  window.scrollY + anchorRect.top,
    top:   window.scrollY + anchorRect.top  - ovH - offsetY, // vers le haut
    bottom:window.scrollY + anchorRect.bottom + offsetY      // vers le bas
  };

  let left = pageLefts[prefer];
  let top  = pageTops[prefer];

  // 3) Si la préférence sort, on tente une alternative simple
  const vw = window.innerWidth;
  const vh = window.innerHeight;

  // helpers de dépassement
  const overflowRight  = () => (left + ovW) > (window.scrollX + vw - margin);
  const overflowLeft   = () => left < (window.scrollX + margin);
  const overflowBottom = () => (top + ovH) > (window.scrollY + vh - margin);
  const overflowTop    = () => top < (window.scrollY + margin);

  // Bascule simple si on sort du côté préféré
  if (prefer === "right" && overflowRight()) {
    left = pageLefts.left;  top = pageTops.left;
  } else if (prefer === "left" && overflowLeft()) {
    left = pageLefts.right; top = pageTops.right;
  } else if (prefer === "top" && overflowTop()) {
    left = pageLefts.bottom; top = pageTops.bottom;
  } else if (prefer === "bottom" && overflowBottom()) {
    left = pageLefts.top; top = pageTops.top;
  }

  // 4) Clamp final dans le viewport, quoi qu'il arrive
  const minLeft = window.scrollX + margin;
  const maxLeft = window.scrollX + vw - ovW - margin;
  const minTop  = window.scrollY + margin;
  const maxTop  = window.scrollY + vh - ovH - margin;

  left = Math.min(Math.max(left, minLeft), Math.max(minLeft, maxLeft));
  top  = Math.min(Math.max(top,  minTop ), Math.max(minTop,  maxTop));

  // 5) Appliquer puis rendre visible
  overlay.style.left = `${left}px`;
  overlay.style.top  = `${top}px`;
  overlay.style.visibility = prevVis || "visible";
  overlay.style.display = prevDisplay || "block";
}

// Renvoie le rectangle englobant de la sélection courante (en coordonnées page)
function getSelectionBBox() {
  const sel = document.querySelectorAll("td.selected");
  if (!sel.length) return null;

  let top = Infinity, left = Infinity, right = -Infinity, bottom = -Infinity;
  sel.forEach(td => {
    const r = td.getBoundingClientRect();
    if (r.top    < top)    top    = r.top;
    if (r.left   < left)   left   = r.left;
    if (r.right  > right)  right  = r.right;
    if (r.bottom > bottom) bottom = r.bottom;
  });

  const scrollX = window.scrollX || document.documentElement.scrollLeft;
  const scrollY = window.scrollY || document.documentElement.scrollTop;

  return {
    left:   scrollX + left,
    top:    scrollY + top,
    right:  scrollX + right,
    bottom: scrollY + bottom,
    width:  right - left,
    height: bottom - top
  };
}

// Met à jour/affiche le cadre rouge englobant
function majCadreSelection() {
  const box = document.getElementById("selectionBox");
  const bbox = getSelectionBBox();

  if (!bbox) {
    box.style.display = "none";
    return;
  }
  const pad = 2; // petit débord pour respirer

  box.style.left   = `${bbox.left - pad}px`;
  box.style.top    = `${bbox.top - pad}px`;
  box.style.width  = `${bbox.width + pad*2}px`;
  box.style.height = `${bbox.height + pad*2}px`;
  box.style.display = "block";
}

// Place l’overlay par rapport à la sélection courante (et le clamp dans l’écran)
function positionOverlayForSelection() {
  const overlay = document.getElementById("overlay");
  const bbox = getSelectionBBox();
  if (!bbox) { overlay.style.display = "none"; return; }

  // Position par défaut : au-dessus à gauche du rectangle sélectionné
  let left = bbox.left;
  let top  = bbox.top - overlay.offsetHeight - 8;

  // Si overlay pas encore mesuré, on force une mesure propre
  const prevDisplay = overlay.style.display;
  const prevVis = overlay.style.visibility;
  overlay.style.visibility = "hidden";
overlay.style.display = "block";
focusOverlayTexte({ selectAll: true }); // ← focus + sélection du texte
  const ow = overlay.offsetWidth;
  const oh = overlay.offsetHeight;

  // recalcul (au cas où oh n’était pas connu)
  top = bbox.top - oh - 8;

  // clamp dans le viewport
  const margin = 10;
  const vw = window.innerWidth;
  const vh = window.innerHeight;

  // si dépasse en haut → le mettre sous la sélection
  if (top < window.scrollY + margin) {
    top = bbox.bottom + 8;
  }
  // clamp horizontal
  if (left + ow > window.scrollX + vw - margin) {
    left = Math.max(window.scrollX + margin, window.scrollX + vw - ow - margin);
  }
  if (left < window.scrollX + margin) {
    left = window.scrollX + margin;
  }
  // clamp vertical
  if (top + oh > window.scrollY + vh - margin) {
    top = Math.max(window.scrollY + margin, window.scrollY + vh - oh - margin);
  }

  overlay.style.left = `${left}px`;
  overlay.style.top  = `${top}px`;

  // rendre visible
  overlay.style.visibility = prevVis || "visible";
  overlay.style.display = prevDisplay || "block";
}


// 💾 Sauvegarde l'état courant + pousse un snapshot en historique (optionnel)
function saveStateToLocal({ snapshot = true } = {}) {
  const state = buildSerializableState();

  // État courant (overwrite)
  try {
    localStorage.setItem(LS_KEYS.CURRENT, JSON.stringify(state));
  } catch (e) {
    console.warn('localStorage CURRENT plein / indisponible', e);
  }

  if (!snapshot) { updateUndoRedoButtons(); return; }

  // Historique + pointeur
  let arr = getHistoryArray();
  let ptr = getHistoryPtr();

  // Si on a fait des actions après un undo (ptr pas en fin), on coupe la branche "redo"
  if (ptr >= 0 && ptr < arr.length - 1) {
    arr = arr.slice(0, ptr + 1);
  }

  // Push snapshot
  arr.push(state);
  // FIFO limite
  while (arr.length > HISTORY_LIMIT) {
    arr.shift();
  }
  setHistoryArray(arr);

  // Pointeur = dernière entrée
  ptr = arr.length - 1;
  setHistoryPtr(ptr);

  // CURRENT = snapshot au pointeur (cohérence)
  try { localStorage.setItem(LS_KEYS.CURRENT, JSON.stringify(arr[ptr])); } catch {}

  updateUndoRedoButtons();
}


// ⏳ Debounce autosave
function scheduleAutosave(reason = '') {
  if (autosaveTimer) clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(() => {
    saveStateToLocal({ snapshot: true });
    // console.debug('autosave done', reason);
  }, AUTOSAVE_DELAY);
}



// 📥 Charge l'état depuis localStorage (courant) et reconstruit l'UI
function loadStateFromLocal() {
  try {
    const raw = localStorage.getItem(LS_KEYS.CURRENT);
    if (!raw) return false;

    const data = JSON.parse(raw);
    Object.assign(parametresParJour, data.parametres || {});
    Object.assign(blocsParJour, data.blocs || {});
    lignesMachine = data.machines || [];
    if (data.utilisateurs) {
      utilisateurs = (typeof normalizeUtilisateurs === 'function')
        ? normalizeUtilisateurs(data.utilisateurs)
        : data.utilisateurs;
    }

    if (typeof majListeUtilisateurs === 'function') majListeUtilisateurs();
    if (typeof chargerParametresJour === 'function') chargerParametresJour();
    else if (typeof rebuildPlanning === 'function') rebuildPlanning(true);

    return true;
  } catch (e) {
    console.warn('Échec de loadStateFromLocal', e);
    return false;
  }
}


// 📤 Exporte le JSON basé sur le snapshot courant en localStorage
function exporterPlanningDepuisLocal() {
  const raw = localStorage.getItem(LS_KEYS.CURRENT);
  if (!raw) {
    alert("❌ Aucun état dans le stockage local. Faites une action ou enregistrez d'abord.");
    return;
  }

  const date = new Date();
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  const fileName = `Planning-${yyyy}-${mm}-${dd}.json`;

  const blob = new Blob([raw], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = fileName;
  a.click();
}


// 🔎 Liste l'historique (tableau du plus ancien → plus récent)
function getHistoryList() {
  try {
    return JSON.parse(localStorage.getItem(LS_KEYS.HISTORY) || '[]');
  } catch {
    return [];
  }
}

// ♻️ Restaure un snapshot par index (0 = plus ancien, length-1 = plus récent)
function restoreFromHistory(index) {
  const arr = getHistoryList();
  if (!arr.length) { alert("Aucun historique."); return false; }
  if (index < 0 || index >= arr.length) { alert("Index d'historique invalide."); return false; }

  const snap = arr[index];

  // Écrase l'état courant
  try {
    localStorage.setItem(LS_KEYS.CURRENT, JSON.stringify(snap));
  } catch (e) {
    console.warn('Impossible d’écrire CURRENT lors de la restauration', e);
  }

  // Recharge en mémoire + UI
  Object.assign(parametresParJour, snap.parametres || {});
  Object.assign(blocsParJour, snap.blocs || {});
  lignesMachine = snap.machines || [];
  if (snap.utilisateurs) {
    utilisateurs = (typeof normalizeUtilisateurs === 'function')
      ? normalizeUtilisateurs(snap.utilisateurs)
      : snap.utilisateurs;
  }

  if (typeof majListeUtilisateurs === 'function') majListeUtilisateurs();
  if (typeof chargerParametresJour === 'function') chargerParametresJour();
  else if (typeof rebuildPlanning === 'function') rebuildPlanning(true);

  return true;
}



function getHistoryArray() {
  try { return JSON.parse(localStorage.getItem(LS_KEYS.HISTORY) || '[]'); }
  catch { return []; }
}
function setHistoryArray(arr) {
  try { localStorage.setItem(LS_KEYS.HISTORY, JSON.stringify(arr)); } catch {}
}
function getHistoryPtr() {
  const n = parseInt(localStorage.getItem(LS_KEYS.HISTORY_PTR), 10);
  return Number.isFinite(n) ? n : -1;
}
function setHistoryPtr(i) {
  try { localStorage.setItem(LS_KEYS.HISTORY_PTR, String(i)); } catch {}
}
function updateUndoRedoButtons() {
  const arr = getHistoryArray();
  const ptr = getHistoryPtr();
  const undoBtn = document.getElementById('btnUndo');
  const redoBtn = document.getElementById('btnRedo');
  if (!undoBtn || !redoBtn) return;
  undoBtn.disabled = !(ptr > 0);
  redoBtn.disabled = !(ptr >= 0 && ptr < arr.length - 1);
}

function applyStateToMemoryAndUI(snap) {
  Object.assign(parametresParJour, snap.parametres || {});
  Object.assign(blocsParJour,      snap.blocs      || {});
  lignesMachine = snap.machines || [];
  if (snap.utilisateurs) {
    utilisateurs = (typeof normalizeUtilisateurs === 'function')
      ? normalizeUtilisateurs(snap.utilisateurs)
      : snap.utilisateurs;
  }
  if (typeof majListeUtilisateurs === 'function') majListeUtilisateurs();
  if (typeof chargerParametresJour === 'function') chargerParametresJour();
  else if (typeof rebuildPlanning === 'function') rebuildPlanning(true);
}

function restoreByPointer(ptr) {
  const arr = getHistoryArray();
  if (!arr.length) { alert("Aucun historique disponible."); return false; }
  if (ptr < 0 || ptr >= arr.length) return false;

  const snap = arr[ptr];

  // CURRENT ← snapshot
  try { localStorage.setItem(LS_KEYS.CURRENT, JSON.stringify(snap)); } catch {}

  setHistoryPtr(ptr);
  applyStateToMemoryAndUI(snap);
  updateUndoRedoButtons();
  return true;
}

function undo() {
  const ptr = getHistoryPtr();
  if (ptr <= 0) return;
  restoreByPointer(ptr - 1);
}

function redo() {
  const arr = getHistoryArray();
  const ptr = getHistoryPtr();
  if (ptr < 0 || ptr >= arr.length - 1) return;
  restoreByPointer(ptr + 1);
}

document.getElementById('btnUndo')?.addEventListener('click', undo);
document.getElementById('btnRedo')?.addEventListener('click', redo);

// Raccourcis clavier : Ctrl+Z / Ctrl+Shift+Z
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
    e.preventDefault();
    if (e.shiftKey) redo(); else undo();
  }
});

function showStartupModal() {
  const modal = document.getElementById('startupModal');
  const hint  = document.getElementById('startupHint');
  const btnLocal  = document.getElementById('btnStartLocal');
  const btnServer = document.getElementById('btnStartServer');

  if (!modal || !btnLocal || !btnServer) return;

  // État du local
  const hasLocal = !!localStorage.getItem(LS_KEYS.CURRENT);
  btnLocal.disabled = !hasLocal;
  hint.textContent = hasLocal
    ? "Un snapshot local a été trouvé. Vous pouvez reprendre là où vous aviez laissé."
    : "Aucun snapshot local trouvé. Vous pouvez charger depuis le serveur.";

  modal.style.display = 'flex';

  btnLocal.onclick = () => {
    const ok = loadStateFromLocal();
    if (!ok) alert("Aucun état local valide.");
    modal.style.display = 'none';
    updateUndoRedoButtons();
  };

  btnServer.onclick = async () => {
    try {
      const res = await fetch('charger.php');
      const data = await res.json();

      // Appliquer en mémoire
      Object.assign(parametresParJour, data.parametres || {});
      Object.assign(blocsParJour,      data.blocs      || {});
      lignesMachine = data.machines || [];
      if (data.utilisateurs) {
        utilisateurs = (typeof normalizeUtilisateurs === 'function')
          ? normalizeUtilisateurs(data.utilisateurs)
          : data.utilisateurs;
      }

      // Reconstruire UI
      if (typeof majListeUtilisateurs === 'function') majListeUtilisateurs();
      if (typeof chargerParametresJour === 'function') chargerParametresJour();
      else if (typeof rebuildPlanning === 'function') rebuildPlanning(true);

      // Seed localStorage + historique (snapshot)
      saveStateToLocal({ snapshot: true });

      modal.style.display = 'none';
      updateUndoRedoButtons();
    } catch (e) {
      alert("❌ Échec du chargement serveur.");
    }
  };
}

document.addEventListener('DOMContentLoaded', () => {
  // Si tu veux forcer le choix à chaque fois :
  showStartupModal();

  // Si tu préfères reprendre auto si local existe, sinon demander :
  // if (!loadStateFromLocal()) showStartupModal(); else updateUndoRedoButtons();
});


// 🧹 Efface toutes les données liées au planning en localStorage
function clearLocalStorageData() {
  const ok = confirm("⚠️ Voulez-vous vraiment supprimer toutes les données locales (autosaves et historique) ?");
  if (!ok) return;

  // Supprimer les clés liées à ton système
  localStorage.removeItem(LS_KEYS.CURRENT);
  localStorage.removeItem(LS_KEYS.HISTORY);
  localStorage.removeItem(LS_KEYS.HISTORY_PTR);

  alert("✅ Données locales supprimées.\nLe planning repartira du serveur au prochain chargement.");

  // Optionnel : mise à jour UI
  updateUndoRedoButtons();
}

// 🔗 Brancher le bouton
document.getElementById("btnClearLocal")?.addEventListener("click", clearLocalStorageData);


  (function(){
    const root = document.documentElement;
    const bar  = document.getElementById('historyControls');

    function updateOffset(){
      const h = bar ? bar.offsetHeight : 0;
      root.style.setProperty('--history-offset', h + 'px');
    }

    // au chargement et quand la barre change de hauteur (responsive, wraps de boutons…)
    window.addEventListener('load', updateOffset);
    window.addEventListener('resize', updateOffset);

    // plus précis si dispo : observe les changements de taille de la barre
    if ('ResizeObserver' in window && bar){
      new ResizeObserver(updateOffset).observe(bar);
    }
  })();




// --- Dépendances légères (si pas déjà dans ta page) ---
function getPeriodCode(periode) {
  switch (periode) {
    case "10 Mois": return "10M";
    case "Bi Annuelle": return "BA";
    case "Tri Annuelle": return "TA";
    case "Quadri Annuelle": return "QA";
    case "Multi Annuelle": return "MA";
    default: return (periode || "").charAt(0).toUpperCase();
  }
}
function nettoyerFicheNumber(v) {
  return String(v || "").replace(/\[\d+\]$/, "").trim();
}

// --- Index fiche <-> code + Set de codes existants ---
const ficheToCode = new Map();
const codeToFiche = new Map();
let codeSet = new Set();        // ex: {"J5-2","J5-1","BA7-10", ...}
let periodCodes = [];           // ex: ["10M","BA","TA","QA","MA","J",...]

function buildCodeIndexes() {
  ficheToCode.clear(); codeToFiche.clear(); codeSet = new Set();

  // Construire la liste des codes périodes valides depuis l'arborescence
  const seen = new Set();
  for (const periode in arborescence) seen.add(getPeriodCode(periode));
  // On trie par longueur décroissante pour matcher en priorité "10M" avant "1" etc.
  periodCodes = Array.from(seen).sort((a,b) => b.length - a.length);

  for (const periode in arborescence) {
    const pCode = getPeriodCode(periode);
    const classeurs = arborescence[periode];
    for (const classeur in classeurs) {
      const mC = String(classeur).match(/\d+/);
      if (!mC) continue;
      const cNum = mC[0];

      const interventions = classeurs[classeur];
      for (const titre in interventions) {
        const mT = String(titre).match(/^\s*(\d+)/);
        if (!mT) continue;
        const tNum = mT[1];

        const itv = interventions[titre] || {};
        const fiche = nettoyerFicheNumber(itv["Numéro de fiche"]);
        if (!fiche) continue;

        const code = `${pCode}${cNum}-${tNum}`;
        ficheToCode.set(fiche, code);
        if (!codeToFiche.has(code)) codeToFiche.set(code, fiche);
        codeSet.add(code);
      }
    }
  }
}

// --- Normalisation d'une saisie "visible" (J5-2 / j52 / J52 / " j 5 _ 2 ") ---
function normalizeVisibleCodeInput(input) {
  if (!input) return null;

  // 1) Uppercase + supprimer espaces + normaliser séparateurs en "-"
  let s = String(input).toUpperCase().replace(/\s+/g, "");
  s = s.replace(/[_/–—−]+/g, "-"); // divers tirets
  // garder un seul "-"
  s = s.replace(/-+/g, "-");

  // 2) Trouver le code période valide en préfixe (10M, BA, J, ...)
  const pMatch = periodCodes.find(pc => s.startsWith(pc));
  if (!pMatch) return null;

  let rest = s.slice(pMatch.length); // ex: "5-2" ou "52" etc.
  if (!rest) return null;

  // 3) Cas avec tiret déjà présent → simple
  if (rest.includes("-")) {
    const [cNum, tNum] = rest.split("-").map(x => x.replace(/\D+/g,""));
    if (!cNum || !tNum) return null;
    const code = `${pMatch}${cNum}-${tNum}`;
    return { periodCode: pMatch, classeurNumber: cNum, titreNumber: tNum, code };
  }

  // 4) Cas condensé (ex: "52") → essayer toutes les découpes possibles en cherchant un code existant
  const digits = rest.replace(/\D+/g,"");
  if (digits.length < 2) return null;

  // essayer découpe à partir de la droite : cNum = début, tNum = fin
  for (let k = 1; k < digits.length; k++) {
    const cNum = digits.slice(0, digits.length - k);
    const tNum = digits.slice(digits.length - k);
    const candidate = `${pMatch}${cNum}-${tNum}`;
    if (codeSet.has(candidate)) {
      return { periodCode: pMatch, classeurNumber: cNum, titreNumber: tNum, code: candidate };
    }
  }

  // 5) Fallback : dernier chiffre = titre (comportement J52 → J5-2)
  const cNum = digits.slice(0, -1);
  const tNum = digits.slice(-1);
  const code = `${pMatch}${cNum}-${tNum}`;
  return { periodCode: pMatch, classeurNumber: cNum, titreNumber: tNum, code };
}

(function wireOverlayTolerance(){
  const inputTexte = document.getElementById("overlayTexte"); // ex: "J5-2"
  const inputFiche = document.getElementById("overlayFiche");
  if (!inputTexte || !inputFiche) return;

  buildCodeIndexes(); // (déjà dans ton code)

  // Normalise en LIVE si le champ ressemble uniquement à un code
  const looksLikePureCode = (s) => /^\s*[A-Za-z0-9/ _\-–—]*\s*$/.test(s);

  inputTexte.addEventListener("input", () => {
    const raw = inputTexte.value;
    if (!looksLikePureCode(raw)) return;             // ne touche pas aux phrases libres

    const norm = normalizeVisibleCodeInput(raw);     // ex: "j11" -> { code:"J1-1", ... }
    if (!norm) return;

    // Seulement si ce code existe vraiment dans l’arborescence
    if (codeSet.has(norm.code)) {
      // ⚠️ sauvegarder la position du curseur
      const hadFocus = document.activeElement === inputTexte;

      // Remplacer le contenu par la version normalisée
      inputTexte.value = norm.code;

      // Replacer le curseur en fin (comportement attendu pour "j11" → "J1-1")
      if (hadFocus) {
        const pos = inputTexte.value.length;
        try { inputTexte.setSelectionRange(pos, pos); } catch {}
      }

      // Renseigner la fiche si connue
      const fiche = codeToFiche.get(norm.code);
      if (fiche) inputFiche.value = fiche;
    }
    // sinon: on ne force rien → l’utilisateur peut continuer à taper
  });

  // Si on tape un numéro de fiche → on déduit le code (déjà présent chez toi)
  inputFiche.addEventListener("input", () => {
    const fiche = nettoyerFicheNumber(inputFiche.value);
    if (!fiche) return;
    const code = ficheToCode.get(fiche);
    if (code) inputTexte.value = code;
  });
})();


// --- helpers overlay ---
function resetOverlayFields() {
  const overlayTexte = document.getElementById("overlayTexte");
  const overlayFiche = document.getElementById("overlayFiche");
  const overlayTech  = document.getElementById("overlayTech");
  const overlayFreq  = document.getElementById("overlayFrequence");

  if (overlayTexte) overlayTexte.value = "";
  if (overlayFiche) overlayFiche.value = "";
  //if (overlayFreq)  overlayFreq.value  = "none";
  //if (overlayTech)  overlayTech.value  = Object.keys(utilisateurs || {})[0] || "";
}

// sélection composée uniquement de cellules vides (non merged, non pause, sans texte)
function isCurrentSelectionEmpty() {
  if (!selectedCells || selectedCells.length === 0) return false;
  return selectedCells.every(td =>
    !td.classList.contains("merged") &&
    !td.classList.contains("pause")  &&
    !td.textContent.trim()
  );
}


// --- 3) Clic en dehors de l’overlay ET en dehors du tableau → fermer ---
(function wireOutsideClickClose(){
  const overlay = document.getElementById("overlay");
  const table   = document.getElementById("planningTable");

  // Utilise 'pointerdown' pour réagir plus tôt et éviter des conflits
  document.addEventListener("pointerdown", (e) => {
    if (!overlay || overlay.style.display === "none") return;

    const clickInOverlay = overlay.contains(e.target);
    const clickInTable   = table ? table.contains(e.target) : false;

    if (!clickInOverlay && !clickInTable) {
      // ferme et nettoie la sélection
      try { fermerOverlay(); } catch {}
    }
  }, true);
})();

// --- Réinit overlay UNIQUEMENT si on clique une cellule vide du tableau ---
(function hookResetOnEmptyCellClick(){
  const overlay = document.getElementById("overlay");
  const table   = document.getElementById("planningTable");
  if (!overlay || !table) return;

  document.addEventListener("mouseup", (e) => {
    // overlay fermé → rien à faire
    if (overlay.style.display === "none") return;

    // clic à l'intérieur de l'overlay → ne pas effacer
    //if (overlay.contains(e.target)) return;

    // on ne traite que les clics dans le tableau
    const td = e.target.closest("#planningTable td");
    if (!td) return;

    // effacer SEULEMENT si la cellule est vide & éditable
    const isEmptyEditable =
      !td.classList.contains("merged") &&
      !td.classList.contains("pause")  &&
      !td.textContent.trim();

    if (isEmptyEditable) {
      resetOverlayFields();
    }
  }, true);
})();



async function exporterExcel7JoursModifiable() {
  if (typeof ExcelJS === "undefined") { alert("❌ ExcelJS non chargé."); return; }
  if (typeof saveAs  === "undefined") { alert("❌ FileSaver non chargé."); return; }
  if (!Array.isArray(jours))          { alert("❌ Tableau 'jours' manquant."); return; }

  // Helpers CSS → ExcelJS
  const rgbCssToARGB = (css) => {
    if (!css) return "FF000000";
    css = css.trim();
    let m = css.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (m) return "FF" + [m[1],m[2],m[3]].map(v=>Number(v).toString(16).padStart(2,"0")).join('').toUpperCase();
    m = css.match(/^#([0-9a-f]{6})$/i);
    if (m) return "FF" + m[1].toUpperCase();
    return "FF000000";
  };
  const isTransparent = (c) => !c || /^(transparent|rgba?\(0,\s*0,\s*0,\s*0\)|none)$/i.test(c);
  const pxToWch = (px) => Math.max(6, Math.round(px/7));
  const pxToPt  = (px) => Math.max(10, Math.round(px*0.75));
  const mapAlignH = (a) => ({left:'left',center:'center',right:'right',justify:'justify'})[a] || 'center';
  const mapAlignV = (a) => ({top:'top',middle:'middle',bottom:'bottom'})[a] || 'middle';
  const mapBorderStyle = (widthPx, styleCss) => {
    const s = (styleCss||'').toLowerCase();
    if (s === 'dotted') return 'dotted';
    if (s === 'dashed' || s === 'dash') return 'dashed';
    if (s === 'double') return 'double';
    if (widthPx >= 3) return 'thick';
    if (widthPx >= 2) return 'medium';
    if (widthPx > 0)  return 'thin';
    return undefined;
  };



function buildWorksheetFromTable(ws, tableEl) {
  const rows = Array.from(tableEl.rows);
  const grid = [];     // carte d'occupation pour gérer les fusions
  const merges = [];   // fusions à appliquer après remplissage

  let Rexcel = 1;      // index de ligne Excel (1-based)
  for (let r = 0; r < rows.length; r++, Rexcel++) {
    const tr = rows[r];
    grid[Rexcel] ||= [];
    let Cexcel = 1;    // index de colonne Excel (1-based)

    for (let ci = 0; ci < tr.cells.length; ci++) {
      // Aller à la 1re case libre (saute les zones déjà couvertes par fusion)
      while (grid[Rexcel][Cexcel]) Cexcel++;

      const td  = tr.cells[ci];
      const cs  = getComputedStyle(td);
      const rs  = td.rowSpan || 1;
      const csn = td.colSpan || 1;

      // Marquer l'occupation pour les cases couvertes par la fusion
      for (let rr = 0; rr < rs; rr++) {
        grid[Rexcel + rr] ||= [];
        for (let cc = 0; cc < csn; cc++) grid[Rexcel + rr][Cexcel + cc] = true;
      }

      // Texte (conserve les sauts de ligne visibles)
      const text = (td.innerText || td.textContent || "").replace(/\r\n/g, "\n");
      const cell = ws.getCell(Rexcel, Cexcel);

      // ---- Export ONLY : pas de déduction/import ici ----
      cell.value = text;

      // Font
      const fontColor  = rgbCssToARGB(cs.color);
      const fontSizePt = Math.max(8, Math.round(parseFloat(cs.fontSize || '12') * 0.75));
      const isBold     = (cs.fontWeight === 'bold') || (parseInt(cs.fontWeight,10) >= 600);
      const isItalic   = (cs.fontStyle || '').toLowerCase() === 'italic';
      cell.font = {
        name: 'Calibri',
        size: fontSizePt,
        color: { argb: fontColor },
        bold: isBold,
        italic: isItalic
      };

      // Alignements + wrap
      cell.alignment = {
        horizontal: mapAlignH((cs.textAlign||'').toLowerCase()),
        vertical:   mapAlignV((cs.verticalAlign||'').toLowerCase()),
        wrapText:   true
      };

      // Fond (si non transparent)
      if (!isTransparent(cs.backgroundColor)) {
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: rgbCssToARGB(cs.backgroundColor) }
        };
      }

      // Bordures
      const sides = [
        {k:'top',    w:parseFloat(cs.borderTopWidth)||0,    s:cs.borderTopStyle,    c:cs.borderTopColor},
        {k:'right',  w:parseFloat(cs.borderRightWidth)||0,  s:cs.borderRightStyle,  c:cs.borderRightColor},
        {k:'bottom', w:parseFloat(cs.borderBottomWidth)||0, s:cs.borderBottomStyle, c:cs.borderBottomColor},
        {k:'left',   w:parseFloat(cs.borderLeftWidth)||0,   s:cs.borderLeftStyle,   c:cs.borderLeftColor}
      ];
      const border = {};
      sides.forEach(({k,w,s,c}) => {
        const style = mapBorderStyle(w, s);
        if (style) border[k] = { style, color: { argb: rgbCssToARGB(c) } };
      });
      if (Object.keys(border).length) cell.border = border;

      // Fusion à appliquer plus tard
      if (rs > 1 || csn > 1) {
        merges.push({ s:{ r:Rexcel, c:Cexcel }, e:{ r:Rexcel+rs-1, c:Cexcel+csn-1 } });
      }

      Cexcel++;
    }

    // Hauteur de ligne (approx depuis le DOM)
    const rowHeightPx = tr.getBoundingClientRect().height || tr.offsetHeight || 0;
    if (rowHeightPx) ws.getRow(Rexcel).height = pxToPt(rowHeightPx);
  }

  // Appliquer les fusions
  merges.forEach(m => ws.mergeCells(m.s.r, m.s.c, m.e.r, m.e.c));

  // Largeurs de colonnes depuis une ligne “pleine” (la plus dense)
  const firstFullRow = rows.reduce((best, tr) => {
    const leafs = Array.from(tr.cells).reduce((a,c)=>a+(c.colSpan||1),0);
    return (!best || leafs > best.leafs) ? { tr, leafs } : best;
  }, null)?.tr;

  if (firstFullRow) {
    const widths = [];
    for (const cell of firstFullRow.cells) {
      const w    = cell.getBoundingClientRect().width || cell.offsetWidth || 0;
      const span = cell.colSpan || 1;
      const per  = Math.max(40, w/span);   // garde-fou min
      for (let i=0;i<span;i++) widths.push(pxToWch(per));
    }
    widths.forEach((wch, i) => ws.getColumn(i+1).width = wch);
  }

  // Figer entêtes (adapter selon ta table : 1ère colonne machine + 2 lignes d'entête)
  ws.views = [{ state: 'frozen', xSplit: 1, ySplit: 2 }];

  // Mise en page A3 paysage, Fit-to-page
  ws.pageSetup = {
    orientation: "landscape",
    fitToPage: true, fitToWidth: 1, fitToHeight: 1,
    paperSize: 8, // ~A3
    margins: { left:0.3, right:0.3, top:0.4, bottom:0.4, header:0.2, footer:0.2 }
  };
}

  // Classeur
  const wb = new ExcelJS.Workbook();
  wb.creator = "Planning";
  wb.created = new Date();

  // Sauver/restaurer l’index du jour courant
  const indexInitial = typeof currentJourIndex === "number" ? currentJourIndex : 0;

  // Pour chaque jour → reconstruire la table d’export, puis créer l’onglet
  for (const day of jours) {
    // basculer l’UI sur le jour
    const idx = jours.indexOf(day);
    if (idx >= 0 && typeof currentJourIndex === "number") currentJourIndex = idx;

    try { chargerParametresJour?.(); } catch {}
    try { genererPreviewExport?.(); } catch {}

    const tableEl = document.getElementById("planningTableExport");
    const sheetName = (day || "Jour").substring(0,31); // Excel max 31 chars
    const ws = wb.addWorksheet(sheetName);

    if (!tableEl) {
      // feuille vide si pas de table
      ws.addRow([`Aucune donnée pour ${day}`]);
      continue;
    }
    buildWorksheetFromTable(ws, tableEl);
  }

  // restaurer l’UI
  if (typeof currentJourIndex === "number") {
    currentJourIndex = indexInitial;
    try { chargerParametresJour?.(); } catch {}
    try { genererPreviewExport?.(); } catch {}
  }

  // Nom fichier
  const now = new Date();
  const JJ = String(now.getDate()).padStart(2,"0");
  const MM = String(now.getMonth()+1).padStart(2,"0");
  const AA = String(now.getFullYear()).slice(2);
  const fileName = `Planning-Prev-7J-${JJ}-${MM}-${AA}.xlsx`;

  // Télécharger
  const buf = await wb.xlsx.writeBuffer();
  saveAs(new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), fileName);
}


// Alias au cas où tu as tapé "shapfermerOverlay" quelque part
window.shapfermerOverlay = window.shapfermerOverlay || fermerOverlay;

function handleOverlayKeys(e) {
  if (e.isComposing) return;
  const overlay = document.getElementById("overlay");
  if (!overlay || overlay.style.display === "none") return;
  if (!overlay.contains(document.activeElement)) return;

  if (e.key === "Enter") {
    const tag = (e.target.tagName || "").toUpperCase();
    if (tag === "TEXTAREA" && e.shiftKey) return;
    if (tag === "SELECT") return;

    e.preventDefault();
    commitNormalizeOverlayTexte();  // ← normalise "J11" en "J1-1"
    try { applySelection(); } catch {}
    try { fermerOverlay(); } catch {}
    try { shapfermerOverlay(); } catch {}
    return;
  }

  if (e.key === "Escape") {
    e.preventDefault();
    try { fermerOverlay(); } catch {}
    try { shapfermerOverlay(); } catch {}
  }
}


// Écoute les touches tant que l’overlay est ouvert
document.addEventListener("keydown", handleOverlayKeys, true);

// Petit helper
function isVisible(el) {
  if (!el) return false;
  const s = getComputedStyle(el);
  return s.display !== "none" && s.visibility !== "hidden";
}

// RAF en cours (pour pouvoir l'annuler)
let _focusRaf = null;

// Appelle-la UNIQUEMENT lors de l’ouverture de l’overlay
function focusOverlayTexte({ selectAll = true, placeEnd = false, once = true } = {}) {
  const input   = document.getElementById("overlayTexte");
  const overlay = document.getElementById("overlay");
  if (!input || !overlay) return;

  // Annule une tentative précédente si elle existe
  if (_focusRaf) {
    cancelAnimationFrame(_focusRaf);
    _focusRaf = null;
  }

  _focusRaf = requestAnimationFrame(() => {
    _focusRaf = null;

    // Si l'overlay n'est plus visible → ne rien faire
    if (!isVisible(overlay)) return;

    // Si l’utilisateur a déjà un focus "valide" ailleurs, on respecte son choix
    const ae = document.activeElement;
    const userIsTypingAilleurs =
      ae &&
      ae !== document.body &&
      ae !== input &&
      (ae.matches?.("input, textarea, select, [contenteditable='true']") ||
       ae.closest?.("#overlay") !== overlay); // pas dans cet overlay

    if (userIsTypingAilleurs) return;

    // OK on peut donner le focus
    input.focus({ preventScroll: true });

    if (selectAll) {
      input.select();
    } else if (placeEnd) {
      const v = input.value || "";
      try { input.setSelectionRange(v.length, v.length); } catch {}
    }

    // Option: on désactive tout refocus automatique après ce coup
    if (once) {
      // Tu peux aussi décrocher tout écouteur qui relancerait cette fonction
      // ici si tu en as.
    }
  });
}

// BONUS : si l’utilisateur clique/touche ailleurs, on annule toute tentative de refocus
document.addEventListener("pointerdown", () => {
  if (_focusRaf) {
    cancelAnimationFrame(_focusRaf);
    _focusRaf = null;
  }
}, { capture: true });

// ✅ Normalise "overlayTexte" -> "J1-1" si on reconnaît un code (et remplit overlayFiche)
const NORMALIZE_VISIBLE_ON_COMMIT = true;
function commitNormalizeOverlayTexte() {
  if (!NORMALIZE_VISIBLE_ON_COMMIT) return;

  const inputTexte = document.getElementById("overlayTexte");
  const inputFiche = document.getElementById("overlayFiche");
  if (!inputTexte || !inputFiche) return;

  const raw  = inputTexte.value;
  const norm = normalizeVisibleCodeInput(raw); // ta fonction déjà définie
  if (!norm) return;

  // Seulement si ce code existe vraiment dans ton arbo
  if (codeSet.has(norm.code)) {
    // 1) écrire la version normalisée dans le champ visible
    inputTexte.value = norm.code;            // ex: "J11" → "J1-1"

    // 2) si on connaît la fiche correspondante, on la met aussi
    const fiche = codeToFiche.get(norm.code);
    if (fiche) inputFiche.value = fiche;
  }
}


function swap(arr, i, j) { const t = arr[i]; arr[i] = arr[j]; arr[j] = t; }

function deplacerLigne(rowIndex, delta) {
  const other = rowIndex + delta;
  if (other < 0 || other >= lignesMachine.length) return;

  // 0) swap des labels
  swap(lignesMachine, rowIndex, other);

  // 1) swap des index de ligne dans tous les blocs de tous les jours — SAFE
  for (const jour of jours) {
    const list = blocsParJour[jour];
    if (!Array.isArray(list)) continue;

    // Pass 1: tagger les blocs de rowIndex
    for (const b of list) {
      if (b.ligne === rowIndex) b.ligne = "__TMP__";
    }
    // Pass 2: those from 'other' -> rowIndex
    for (const b of list) {
      if (b.ligne === other) b.ligne = rowIndex;
    }
    // Pass 3: tmp -> other
    for (const b of list) {
      if (b.ligne === "__TMP__") b.ligne = other;
    }
  }

  // préserver la dernière sélection si possible
  let target = null;
  if (lastSelection) {
    if (lastSelection.row === rowIndex)      target = { ...lastSelection, row: other };
    else if (lastSelection.row === other)    target = { ...lastSelection, row: rowIndex };
    else                                     target = { ...lastSelection };
  }

  rebuildPlanning(true);
  reselectAfterRebuild(target);
  scheduleAutosave('moveRow');
}


/* Supprimer une ligne + recaler les index de blocs > rowIndex pour tous les jours */
function supprimerLigneEtRecaler(rowIndex) {
  if (rowIndex < 0 || rowIndex >= lignesMachine.length) return;
  const nom = lignesMachine[rowIndex];
  if (!confirm(`Supprimer la ligne "${nom}" ?`)) return;

  // retire la machine
  lignesMachine.splice(rowIndex, 1);

  // recale les blocs de tous les jours
  for (const jour of jours) {
    const list = blocsParJour[jour];
    if (!Array.isArray(list)) continue;
    // 1) supprimer ceux qui étaient sur cette ligne
    for (let i = list.length - 1; i >= 0; i--) {
      if (list[i].ligne === rowIndex) list.splice(i, 1);
    }
    // 2) décrémenter les lignes > rowIndex
    for (const b of list) {
      if (b.ligne > rowIndex) b.ligne -= 1;
    }
  }

  rebuildPlanning(true);
  scheduleAutosave('deleteRow');
}

/**
 * Déplace la ligne `rowIndex` d'un cran (delta = -1 vers le haut, +1 vers le bas),
 * et échange aussi les index de ligne dans TOUS les blocs de TOUS les jours.
 */
function deplacerLigne(rowIndex, delta) {
  const other = rowIndex + delta;
  if (other < 0 || other >= lignesMachine.length) return;

  // 1) swap dans le tableau des lignes
  swap(lignesMachine, rowIndex, other);

  // 2) swap des index de ligne dans tous les blocs de tous les jours
  for (const jour of jours) {
    const list = blocsParJour[jour];
    if (!Array.isArray(list)) continue;
    for (const b of list) {
      if (b.ligne === rowIndex) {
        b.ligne = other;
      } else if (b.ligne === other) {
        b.ligne = rowIndex;
      }
    }
  }

  // 3) préserver la sélection actuelle si possible
  let target = null;
  if (lastSelection) {
    if (lastSelection.row === rowIndex) {
      target = { ...lastSelection, row: other };
    } else if (lastSelection.row === other) {
      target = { ...lastSelection, row: rowIndex };
    } else {
      target = { ...lastSelection };
    }
  }

  // 4) Rebuild + reselect + autosave
  rebuildPlanning(true);
  reselectAfterRebuild(target);
  scheduleAutosave('moveRow');
}

let _rowOverlay = null;
let _rowOverlayCtx = { rowIndex: null, labelEl: null, inputEl: null, tdRect: null };

function ensureRowActionsOverlay(){
  if (_rowOverlay) return _rowOverlay;

  const wrap = document.createElement('div');
  wrap.id = 'rowActionsOverlay';

  // barre d’actions
  const actions = document.createElement('div');
  actions.className = 'actions';

  const btnUp    = document.createElement('button');   btnUp.textContent = '▲';
  const btnDown  = document.createElement('button');   btnDown.textContent = '▼';
  const btnDel   = document.createElement('button');   btnDel.textContent = '🗑';
  const btnClose = document.createElement('button');   btnClose.textContent = '✅';

  actions.appendChild(btnUp);
  actions.appendChild(btnDown);
  actions.appendChild(btnDel);
  actions.appendChild(btnClose);

  wrap.appendChild(actions);
  document.body.appendChild(wrap);

  // Handlers
  btnUp.onclick = (e) => {
    e.stopPropagation();
    if (_rowOverlayCtx.rowIndex == null) return;
    deplacerLigne(_rowOverlayCtx.rowIndex, -1);
    closeRowOverlay({ noRename: true });
  };
  btnDown.onclick = (e) => {
    e.stopPropagation();
    if (_rowOverlayCtx.rowIndex == null) return;
    deplacerLigne(_rowOverlayCtx.rowIndex, +1);
    closeRowOverlay({ noRename: true });
  };
  btnDel.onclick = (e) => {
    e.stopPropagation();
    if (_rowOverlayCtx.rowIndex == null) return;
    supprimerLigneEtRecaler(_rowOverlayCtx.rowIndex);
    closeRowOverlay({ noRename: true });
  };
  btnClose.onclick = (e) => {
    e.stopPropagation();
    closeRowOverlay();
  };

  // fermer si clic hors overlay
  document.addEventListener('pointerdown', (e) => {
    if (!wrap || wrap.style.display === 'none') return;
    const inside = wrap.contains(e.target) || (_rowOverlayCtx.labelEl && _rowOverlayCtx.labelEl.contains?.(e.target));
    if (!inside) closeRowOverlay();
  }, true);

  _rowOverlay = wrap;
  return _rowOverlay;
}

function openRowOverlayFor(tdLabelEl, rowIndex) {
  const overlay = ensureRowActionsOverlay();

  // remplace le libellé par un <input> (ou <textarea> si tu préfères)
  const span = tdLabelEl.querySelector('.machine-label');
  if (!span) return;

  // si déjà en saisie, ne pas recréer
  let input = tdLabelEl.querySelector('.machine-edit-input');
  if (!input) {
    input = document.createElement('input');
    input.type = 'text';
    input.className = 'machine-edit-input';
    input.value = span.textContent.trim();
    span.replaceWith(input);

    // Enter = valider, Escape = annuler
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); applyRowNameChange(); closeRowOverlay(); }
      if (e.key === 'Escape') { e.preventDefault(); closeRowOverlay({ cancelRename:true }); }
    });
    // blur = valider silencieusement
    input.addEventListener('blur', () => {
      // si l’overlay se ferme, closeRowOverlay gère déjà; sinon, on applique
      if (_rowOverlay && _rowOverlay.style.display !== 'none') return;
      applyRowNameChange();
    });
  }
  input.focus();
  input.select();

  // positionner l’overlay à droite du libellé
  const rect = tdLabelEl.getBoundingClientRect();
  const left = rect.right + 8 + window.scrollX;
  const top  = rect.top + window.scrollY;

  overlay.style.left = `${left}px`;
  overlay.style.top  = `${top}px`;
  overlay.style.display = 'block';

  // mémoriser le contexte
  _rowOverlayCtx = { rowIndex, labelEl: tdLabelEl, inputEl: input, tdRect: rect };
}

function applyRowNameChange() {
  if (!_rowOverlayCtx || _rowOverlayCtx.rowIndex == null) return;
  const idx = _rowOverlayCtx.rowIndex;
  const input = _rowOverlayCtx.inputEl;
  if (!input) return;

  const newName = (input.value || '').trim();
  if (!newName) return;

  // si le nom n’a pas changé, ne rien faire
  if (lignesMachine[idx] === newName) return;

  lignesMachine[idx] = newName;
  rebuildPlanning(true);
  scheduleAutosave('renameRow');
}

function closeRowOverlay({ cancelRename = false, noRename = false } = {}) {
  const overlay = ensureRowActionsOverlay();
  overlay.style.display = 'none';

  const { labelEl, inputEl } = _rowOverlayCtx || {};
  if (labelEl && inputEl && labelEl.contains(inputEl)) {
    // remettre un span machine-label
    const span = document.createElement('span');
    span.className = 'machine-label';
    span.textContent = cancelRename ? lignesMachine[_rowOverlayCtx.rowIndex] : (inputEl.value || '').trim() || lignesMachine[_rowOverlayCtx.rowIndex];
    inputEl.replaceWith(span);
  }

  if (!cancelRename && !noRename) applyRowNameChange();

  _rowOverlayCtx = { rowIndex: null, labelEl: null, inputEl: null, tdRect: null };
}

function getAbsoluteStartIndexForSelection(cells){
  const row = cells[0].parentElement;
  const all = Array.from(row.querySelectorAll("td:not(:first-child)"));
  let col = 0;
  for (const c of all) {
    if (c === cells[0]) return col;
    col += c.colSpan || 1;
  }
  return -1;
}

