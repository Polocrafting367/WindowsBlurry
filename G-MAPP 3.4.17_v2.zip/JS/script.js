// ------------------------------------------------------------
// PARTIE 1 : MODULE PIÈCES (CSV → JSON hiérarchique)
// ------------------------------------------------------------

// Éléments
const processBtn   = document.getElementById("processBtn");
const sendBtn      = document.getElementById("sendBtn");
const fileInput    = document.getElementById("csvFile");
const outputDiv    = document.getElementById("output");

// Modale pièces
const piecesModal  = document.getElementById("piecesModal");
const closePieces  = document.querySelector(".close-pieces");
const cancelPieces = document.getElementById("cancelPiecesBtn");
const previewPiecesBtn = document.getElementById("previewPiecesBtn");

const selId  = document.getElementById("piecesIdxId");
const selDes = document.getElementById("piecesIdxDesignation");
const selLoc = document.getElementById("piecesIdxLocation");
const selBar = document.getElementById("piecesIdxBarcode");

// État temporaire
let _pieces_lines  = null;
let _pieces_header = null;

function sortObject(obj) {
    // Si ce n'est pas un objet ou si c'est null, on retourne tel quel
    if (obj === null || typeof obj !== 'object' || Array.isArray(obj)) {
        return obj;
    }

    // Récupérer les clés et les trier de manière naturelle (01, 02, 10...)
    const sortedKeys = Object.keys(obj).sort((a, b) => {
        return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
    });

    const result = {};
    sortedKeys.forEach(key => {
        // Trier récursivement les sous-objets
        result[key] = sortObject(obj[key]);
    });
    return result;
}
// Helpers CSV simples
const splitRow = (row) =>
  row.split(";").map(c => c.replace(/^\uFEFF/, "").replace(/(^"|"$)/g, "").trim());

// Nettoyage
function cleanString(str) {
  return String(str ?? "")
    .replace(/½/g, "\u00BD")
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}
function extractLetter(seg) {
  if (!seg) return "";
  const m = String(seg).match(/([A-Z])/i);
  return m ? m[1].toUpperCase() : "";
}
function extractNumber(seg) {
  if (!seg) return "";
  const m = String(seg).match(/(\d+)/);
  return m ? String(parseInt(m[1], 10)) : "";
}
function extractBox(seg) {
  if (!seg) return "";
  const s = String(seg);
  const hasBis = /bis/i.test(s);
  const m = s.match(/(\d+)/);
  let n = m ? String(parseInt(m[1], 10)).padStart(2, "0") : "00";
  return n + (hasBis ? "BIS" : "");
}

function normalizeLocationToPlace(location) {
  if (!location) return { parts: [], place: "", hierarchyParts: [] };

  const parts = String(location)
    .split(/\s*\\+\s*/g)
    .map(s => s.replace(/(^"|"$)/g, "").trim())
    .filter(Boolean);

  const textLike = parts.length === 1 && /[a-zA-ZÀ-ÿ\s]/.test(parts[0]) && !/\d/.test(parts[0]);
  if (textLike) {
    return { parts: [], place: null, hierarchyParts: [parts[0]] };
  }

  let first = parts[0] || "";
  let L1;
  if (/^rangée\s+[A-Z]$/i.test(first)) {
    L1 = first.match(/([A-Z])$/i)[1].toUpperCase();
  } else {
    L1 = extractLetter(first);
  }

  const col = extractNumber(parts[1] || "");
  const L2  = extractLetter(parts[2] || "");
  const box = extractBox(parts[3] || "");

  const normParts = [L1, col, L2, box].filter(Boolean);
  const place = normParts.join("");

  const h0 = first || L1;
  const h1 = parts[1] || col;
  const h2 = parts[2] || L2;
  const h3 = parts[3] || box;
  const hierarchyParts = [h0, h1, h2, h3].filter(Boolean);

  return { parts: normParts, place, hierarchyParts };
}

// Modale
function openPiecesModal(headers) {
  function fillSelect(sel, headers, prefers) {
    sel.innerHTML = "";
    headers.forEach((h, i) => {
      const opt = document.createElement("option");
      opt.value = i;
      opt.textContent = `${i} — ${h}`;
      sel.appendChild(opt);
    });
    const idx = prefers
      .split("|")
      .map(s => s.trim())
      .map(key => headers.findIndex(h => h.toLowerCase().includes(key)))
      .find(i => i >= 0);
    sel.value = idx >= 0 ? String(idx) : "0";
  }

  fillSelect(selId,  headers, "référence interne|référence|ref interne|id");
  fillSelect(selDes, headers, "désignation|designation|libellé|libelle|desc");
  fillSelect(selLoc, headers, "emplacement (complet)|emplacement|localisation|lieu");
  fillSelect(selBar, headers, "code-barres|code barre|barcode|ean");

  piecesModal.style.display = "block";
}

// Clic “Prévisualier”
processBtn.addEventListener("click", () => {
  if (sendBtn) sendBtn.disabled = true;
  if (fileInput.files.length === 0) {
    outputDiv.textContent = "Veuillez sélectionner un fichier CSV.";
    return;
  }

  const file = fileInput.files[0];
  const reader = new FileReader();

  reader.onload = (event) => {
    let csvContent = "";
    try {
      csvContent = new TextDecoder("windows-1252").decode(event.target.result);
    } catch {
      csvContent = new TextDecoder().decode(event.target.result);
    }

    const lines = csvContent
      .split(/\r?\n/)
      .map(l => l.trim())
      .filter(l => l.length > 0);

    if (lines.length === 0) {
      outputDiv.textContent = "Fichier vide.";
      return;
    }

    _pieces_lines  = lines;
    _pieces_header = splitRow(lines[0]);

    openPiecesModal(_pieces_header);
  };

  reader.readAsArrayBuffer(file);
});

// Prévisualisation
if (previewPiecesBtn) {
    previewPiecesBtn.onclick = () => {

    if (!_pieces_lines || !_pieces_header) return;

    const idx = {
        id:          parseInt(selId.value, 10),
        designation: parseInt(selDes.value, 10),
        location:    parseInt(selLoc.value, 10),
        barcode:     parseInt(selBar.value, 10),
    };

    const dataLines = _pieces_lines.slice(1);

    dataLines.sort((a, b) => {
        const la = splitRow(a)[idx.location] ?? "";
        const lb = splitRow(b)[idx.location] ?? "";
        const locA = la.replace(/(^"|"$)/g, "").trim();
        const locB = lb.replace(/(^"|"$)/g, "").trim();
        const isAorRangeA = /^A\b/i.test(locA) || /rangée/i.test(locA);
        const isAorRangeB = /^A\b/i.test(locB) || /rangée/i.test(locB);
        if (isAorRangeA && !isAorRangeB) return -1;
        if (!isAorRangeA && isAorRangeB) return 1;
        return locA.localeCompare(locB, "fr", { sensitivity: "base", numeric: true });
    });

    const pieces = {};

    dataLines.forEach(line => {
        const cols = splitRow(line);
        const id = cols[idx.id] ?? "";
        const description = cols[idx.designation] ?? "";
        const location = cols[idx.location] ?? "";
        const barcode = cols[idx.barcode] ?? "";

        if (!location && !description) return;

        const { place: normalizedPlace, hierarchyParts } = normalizeLocationToPlace(location);
        let finalPlace = normalizedPlace;

        // --- CORRECTION 1 : Génération du 'place' par défaut avec des tirets ---
        if (!finalPlace) {
            // Remplace les espaces par "-", prend les 9 premiers caractères
            const base = String(description).substring(0, 9).replace(/\s+/g, "-");
            // Ne garde que les lettres, chiffres et tirets (supprime les underscores ou autres)
            finalPlace = base.replace(/[^\p{L}\p{N}-]/gu, "");
        }

        let current = pieces;
        hierarchyParts.forEach(key => {
            const k = cleanString(key);
            if (!current[k]) current[k] = {};
            current = current[k];
        });

        const cleanedDescription = cleanString(description).replace(/\s+bis$/i, "");

        // --- CORRECTION 2 : Séparateur ~ pour la clé unique ---
        const safeBarcode = barcode ? barcode.trim().replace(/\s+/g, "-") : "SANS_CB";
        
        // Structure : Nom ~ Place ~ CodeBarre
        const itemKey = `${cleanedDescription} ~ ${finalPlace} ~ ${safeBarcode}`;

        current[itemKey] = {
            id: id,
            barcode: barcode,
            place: finalPlace,
            designation: cleanedDescription
        };
    });

    outputDiv.textContent = JSON.stringify(pieces, null, 4);
    if (sendBtn) sendBtn.disabled = outputDiv.textContent.length === 0;
    if (piecesModal) piecesModal.style.display = "none";
};
}

// Envoi PHP
document.getElementById("sendBtn").addEventListener("click", () => {
  const jsonOutput = document.getElementById("output").textContent;
  if (!jsonOutput) {
    alert("Aucune donnée JSON à envoyer !");
    return;
  }

  const jsContent = `const pieces = ${jsonOutput};`;

  fetch("../PHP/savePieces.php", {
    method: "POST",
    headers: { "Content-Type": "application/javascript" },
    body: jsContent
  })
  .then(response => {
    if (response.ok) {
      alert("Fichier Pièces.js mis à jour avec succès !");
    } else {
      return response.text().then(text => { throw new Error(text); });
    }
  })
  .catch(error => {
    console.error("Erreur lors de l'import :", error.message);
    alert("Une erreur s'est produite lors de la mise à jour du fichier Pièces.js.");
  });
});

// Fermeture modale
if (closePieces)  closePieces.onclick  = () => { piecesModal.style.display = "none"; };
if (cancelPieces) cancelPieces.onclick = () => { piecesModal.style.display = "none"; };
window.addEventListener("click", (evt) => {
  if (evt.target === piecesModal) piecesModal.style.display = "none";
});


// ------------------------------------------------------------
// PARTIE 2 : DEV, UTILISATEURS, EXPORTS, INTERVENTIONS…
// ------------------------------------------------------------

(function(_0x3c9a92, _0x5cfc9a) {
    const _0x5e5c37 = _0x30ee, _0x731548 = _0x3c9a92();
    while (!![]) {
        try {
            const _0x5ab420 = parseInt(_0x5e5c37(0xe5)) / 1 * (-parseInt(_0x5e5c37(0xd1)) / 2)
            + -parseInt(_0x5e5c37(0xce)) / 3
            + parseInt(_0x5e5c37(0xc7)) / 4
            + -parseInt(_0x5e5c37(0xbc)) / 5 * (parseInt(_0x5e5c37(0xdc)) / 6)
            + -parseInt(_0x5e5c37(0x100)) / 7
            + -parseInt(_0x5e5c37(0xb8)) / 8
            + parseInt(_0x5e5c37(0xb3)) / 9 * (parseInt(_0x5e5c37(0xe6)) / 10);

            if (_0x5ab420 === _0x5cfc9a) break;
            else _0x731548.push(_0x731548.shift());
        } catch (_0x4b8023) {
            _0x731548.push(_0x731548.shift());
        }
    }
}(_0x5e77, 0x5ea9b));

window.DEV_FLAGS = { mode:false, heures:144, pieces:false, fastStart:false };

function refreshH2Titles() {
  const add = window.DEV_FLAGS.pieces ? " + Pièces" : "";
  const h2c = document.getElementById("h2Correctives");
  const h2p = document.getElementById("h2Prev");
  if (h2c) h2c.textContent = "Inter correctives" + add;
  if (h2p) h2p.textContent = "Fiches prèventives" + add;
}

function checkDateTimeInURL() {
    const urlParams = new URLSearchParams(window.location.search);
    const timeParam = urlParams.get('time');
    if (!timeParam) {
        alert('Erreur, merci de vous connecter.');
        window.location.href = window.location.origin + '/G-MAPP/index.html';
        return;
    }
    if (timeParam === "ok") return;

    const parts = timeParam.split('_');
    if (parts.length !== 2) {
        alert('Paramètre de date invalide.');
        window.location.href = window.location.origin + '/G-MAPP/index.html';
        return;
    }

    const datePart = parts[0];
    const timePart = parts[1];
    const dateComponents = datePart.split('-').map(Number);
    const timeComponents = timePart.split(':').map(Number);
    if (dateComponents.length !== 3 || timeComponents.length !== 3) {
        alert('Paramètre de date invalide.');
        window.location.href = window.location.origin + '/G-MAPP/index.html';
        return;
    }

    const parsedDate = new Date(
        dateComponents[0],
        dateComponents[1] - 1,
        dateComponents[2],
        timeComponents[0],
        timeComponents[1],
        timeComponents[2]
    );
    const now = new Date();
    const diffInMinutes = Math.abs(now - parsedDate) / (1000 * 60);
    if (diffInMinutes > 1) {
        alert('Temps expiré.');
        window.location.href = window.location.origin + '/G-MAPP/index.html';
    }
}

checkDateTimeInURL();

async function fetchUsers() {
    const _0x197a03 = _0x30ee;
    try {
        const _0x55772d = await fetch(_0x197a03(0xf9));
        const _0x3fcd7f = await _0x55772d.json();
        const _0x16ec5d = Object.keys(_0x3fcd7f).map(u => ({
            username: u,
            password: _0x3fcd7f[u]
        }));
        displayUsers(_0x16ec5d);
        populateUserSelect(_0x16ec5d);
    } catch (e) {
        console.error("Erreur:", e);
    }
}

// Chargement utilisateur
async function loadUserData(user, userDiv) {
    try {
        const [
            interventionsData,
            nonExportedCount,
            prevCSVData,
            nonExportedPrevCount
        ] = await Promise.all([
            fetchCSV(`../data/user/${user.username}_Work.csv`).catch(e => []),
            (async () => {
                let count = 0;
                try {
                    const r = await fetch(`../data/${user.username}_/Work_enregistrements.json`);
                    if (r.status === 404) count = 0;
                    else if (r.ok) {
                        const txt = await r.text();
                        count = (txt.match(/zoneTexte1/g) || []).length;
                    }
                } catch { count = 0; }
                return count;
            })(),
            fetchCSV(`../data/user/${user.username}_Priv.csv`).catch(e => []),
            (async () => {
                let count = 0;
                try {
                    const r = await fetch(`../data/${user.username}_/Priv_enregistrements.json`);
                    if (r.status === 404) count = 0;
                    else if (r.ok) {
                        const txt = await r.text();
                        count = (txt.match(/zoneTexte1/g) || []).length;
                    }
                } catch { count = 0; }
                return count;
            })()
        ]);

        const interventionsCount = interventionsData.length;
        const fichesPrevCount = prevCSVData.length;

        let message = `${interventionsCount} intervention(s) exportée(s)<br>${nonExportedCount} intervention(s) non exportée(s)<br><br>${fichesPrevCount} Fiches Prev. exportée(s)<br>${nonExportedPrevCount} Fiches Prev. non exportée(s)`;

        let buttonsHtml = "";
        if (interventionsCount > 0) {
            buttonsHtml += `<button onclick="toggleInterventions('${user.username}')">Voir interventions exportées</button>`;
        }
        if (nonExportedCount > 0) {
            buttonsHtml += `<button style="background-color: Teal;" onclick="window.location.href='../Ressources/index.html?&user=${user.username}&mode=Work&Export=true'">Voir interventions non exportées</button>`;
        }
        buttonsHtml += `<br>`;
        if (fichesPrevCount > 0) {
            buttonsHtml += `<button onclick="toggleInterventionsPrev('${user.username}')">Voir Fiches Prev exportées</button>`;
        }
        if (nonExportedPrevCount > 0) {
            buttonsHtml += `<button style="background-color: Teal;" onclick="window.location.href='../Ressouces/index.html?&user=${user.username}&mode=Priv&Export=true'">Voir Fiches Prev non exportées</button>`;
        }

        userDiv.innerHTML = `
            <h3>${user.username}</h3>
            <p>${message}</p>
            ${buttonsHtml}
            <div id="${user.username}-interventions" style="display:none;">
                ${generateInterventionTable(interventionsData)}
            </div>
            <div id="${user.username}-interventions-prev" style="display:none;">
                ${generateInterventionTablePrev(prevCSVData)}
            </div>
        `;
    } catch (error) {
        console.error(`Erreur pour ${user.username}:`, error);
        userDiv.innerHTML += `<p style="color:red;">Erreur lors du chargement des données.</p>`;
    }
}

// CSV générique
async function fetchCSV(url) {
    const r = await fetch(url);
    if (r.status === 404) return [];
    if (!r.ok) throw new Error("Erreur CSV");

    const contentType = r.headers.get('content-type');
    if (contentType && contentType.includes('text/html')) return [];

    const csvText = await r.text();
    if (csvText.trim().startsWith('<') ) return [];

    const lines = csvText.trim().split('\n');
    if (lines.length === 0) return [];

    const headers = lines[0].split(';').map(h => h.trim());
    return lines.slice(1).map(line => {
        const values = line.split(';').map(v => v.trim());
        const obj = {};
        headers.forEach((h,i)=> obj[h] = values[i]);
        return obj;
    });
}

async function displayUsers(users) {
    const userSection = document.getElementById('userSection');
    userSection.innerHTML = "";
    users.forEach(u => {
        if (u.username !== 'Gestion') {
            const d = document.createElement('div');
            d.className = 'user-info';
            d.innerHTML = `<h3>${u.username}</h3><p>Chargement...</p>`;
            userSection.appendChild(d);
            loadUserData(u, d);
        }
    });
}

// TABLEAU INTERVENTIONS
function generateInterventionTable(coreData, workData) {
  if ((!coreData || coreData.length === 0) && (!workData || workData.length === 0)) {
    return "<p>Aucune intervention trouvée.</p>";
  }

  const showPiecesCol = !!(window.DEV_FLAGS && window.DEV_FLAGS.pieces);

  const columns = [
    { idx: 1, label: "Date" },
    { idx: 2, label: "Désignation" },
    { idx: 3, label: "Type" },
    { idx: 4, label: "Cause" },
    { idx: 5, label: "Résumé" },
    ...(showPiecesCol ? [{ idx: 6, label: "Pièces" }] : []),
    { idx: 7, label: "Durée arrêt (h)" },
    { idx: 8, label: "Personnel" },
    { idx: 9, label: "Nombre d'heures" },
    { idx: 10, label: "Numéro d'intervention" }
  ];

  function getCells(row) {
    if (typeof row === 'string') return row.split(';').map(c => c.trim());
    if (Array.isArray(row)) return row;
    if (row && typeof row === 'object') return Object.values(row);
    return [];
  }

  let tableHTML = `
    <table class="intervention-table">
      <thead>
        <tr>${columns.map(col => `<th>${col.label}</th>`).join('')}</tr>
      </thead>
      <tbody>
  `;

  function processRows(data) {
    let out = "";
    data.forEach(row => {
      const c = getCells(row);
      out += "<tr>";
      columns.forEach(col => out += `<td>${c[col.idx] ?? ""}</td>`);
      out += "</tr>";
    });
    return out;
  }

  if (coreData) tableHTML += processRows(coreData);
  if (workData) tableHTML += processRows(workData);

  tableHTML += "</tbody></table>";
  return tableHTML;
}

function generateInterventionTablePrev(coreData, workData) {
  if ((!coreData || coreData.length === 0) && (!workData || workData.length === 0)) {
    return "<p>Aucune intervention trouvée.</p>";
  }

  const showPiecesCol = !!(window.DEV_FLAGS && window.DEV_FLAGS.pieces);

  const columns = [
    { idx: 1, label: "Date" },
    { idx: 2, label: "Numéro de fiche" },
    { idx: 5, label: "Résumé" },
    ...(showPiecesCol ? [{ idx: 6, label: "Pièces" }] : []),
    { idx: 7, label: "Durée arrêt (h)" },
    { idx: 8, label: "Personnel" },
    { idx: 9, label: "Nombre d'heures" },
    { idx: 10, label: "Numéro d'export" }
  ];

  function getCells(row) {
    if (typeof row === 'string') return row.split(';').map(c => c.trim());
    if (Array.isArray(row)) return row;
    if (row && typeof row === 'object') return Object.values(row);
    return [];
  }

  let tableHTML = `
    <table class="intervention-table">
      <thead><tr>${columns.map(col => `<th>${col.label}</th>`).join('')}</tr></thead>
      <tbody>
  `;

  function process(rows) {
    let o = "";
    rows.forEach(r => {
      const c = getCells(r);
      o += "<tr>";
      columns.forEach(col => o += `<td>${c[col.idx] ?? ""}</td>`);
      o += "</tr>";
    });
    return o;
  }

  if (coreData) tableHTML += process(coreData);
  if (workData) tableHTML += process(workData);

  return tableHTML + "</tbody></table>";
}

function toggleInterventions(u) {
    const _0x43851e = _0x30ee;
    const el = document.getElementById(u + _0x43851e(0xf6));
    el.style.display = el.style.display === 'none' ? 'block' : 'none';
}
function toggleInterventionsPrev(u) {
    const el = document.getElementById(u + '-interventions-prev');
    el.style.display = el.style.display === 'none' ? 'block' : 'none';
}

function _0x30ee(x,y){const a=_0x5e77();return _0x30ee=function(i,j){i=i-0xae;return a[i];},_0x30ee(x,y);}
function _0x5e77(){const a=['display','9RWFKgK','Échec de la communication avec le serveur','interventionsList','interventions','application/json','5317528iVPKsB','Temps de connextion dépassé. Veuillez vous reconnecter.','value','createElement','70235FxNTIR','feedback','Erreur lors de la modification','La mise à jour du serveur a échoué','</td>','getElementById','Vraiment supprimé ? cela n efface pas les dernière inter et les archives','style','userSelect','action','Erreur lors de la récupération des utilisateurs:','1855056eDAvaw','newUsername','../PHP/manageUsers.php','<p>Aucune intervention trouvée.</p>','</h2>\n                <p>','time','user-window','76389YiMbBW','success','split','698894yBtXSb','Erreur:','json','\n            <table class="intervention-table">\n                <thead>\n                    <tr>\n                        <th>Date intervention</th>\n                        <th>Désignation machine</th>\n                        <th>Type de panne</th>\n                        <th>Cause</th>\n                        <th>Résumé intervention</th>\n                        <th>Durée arrêt (h)</th>\n                        <th>Personnel</th>\n                        <th>Nombre d heures</th>\n                    </tr>\n                </thead>\n                <tbody>\n            ','get','confirm','block','-interventions" style="display:none;">\n                        ','forEach','error','Êtes-vous sûr de vouloir créer?','270CeWaMZ','appendChild','href','delete','keys','username','create','</tr>','Erreur lors de la création.','2iykRoT','23529250QBbDbE','textContent','Erreur lors de la récupération des interventions pour ','option',' interventions depuis le dernier export</p>\n                        <button onclick="toggleInterventions(\'','password','POST','../PHP/G-MAPPs.php','Utilisateur supprimé avec succès!','Erreur lors de la création de l’utilisateur: ','innerHTML','Content-Type','message','modify','trim','length','-interventions','<td>','Gestion','../XbGv89Lm.json','abs','Modifier le mot de passe ?','Erreur lors de la modification: ','Nouvel utilisateur créé !','../index.html','Erreur lors de la suppression de l’utilisateur: ','2854509PPOdkM','location','\n                <h2>','className','stringify'];return _0x5e77=function(){return a;},_0x5e77();}

function populateUserSelect(arr) {
    const sel = document.getElementById("userSelect");
    sel.innerHTML = "";
    arr.forEach(u => {
        if (u.username !== 'Gestion') {
            const opt = document.createElement("option");
            opt.value = u.username;
            opt.textContent = u.username;
            sel.appendChild(opt);
        }
    });
}
function modifierMotDePasse() {
    const username = document.getElementById('userSelect').value;
    const oldPassword = document.getElementById('oldPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    if (!username) {
        alert('Veuillez sélectionner un utilisateur.');
        return;
    }
    fetch('../PHP/manageUsers.php', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({ action:'modify', username, oldPassword, newPassword })
    }).then(r=>r.json()).then(res=>{
        document.getElementById('feedback').textContent =
          res.success ? 'Mot de passe modifié avec succès.' : `Erreur : ${res.error || 'Action impossible.'}`;
    }).catch(e=>console.error("Erreur:",e));
}
async function supprimerUtilisateur() {
    const username = document.getElementById('userSelect').value;
    const oldPassword = document.getElementById('oldPassword').value;
    if (!username) {
        alert('Veuillez sélectionner un utilisateur.');
        return;
    }
    if (!confirm(`Confirmer la suppression de l'utilisateur "${username}" ?`)) return;

    try {
        const r = await fetch('../PHP/manageUsers.php',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({ action:'delete', username, oldPassword })
        });
        const res = await r.json();
        document.getElementById('feedback').textContent =
          res.success ? 'Utilisateur supprimé avec succès.' : `Erreur : ${res.error || 'Action impossible.'}`;
    } catch(e){
        console.error("Erreur suppression:",e);
    }
}
async function creerUtilisateur() {
    if (!confirm('Êtes-vous sûr de vouloir créer?')) return;

    const username = document.getElementById('newUsername').value.trim();
    const password = document.getElementById('createPassword').value.trim();
    const fb = document.getElementById('feedback');

    if (!username) { fb.textContent = "Nom d’utilisateur requis."; return; }

    try {
        const r = await fetch('../PHP/manageUsers.php',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({ action:'create', username, password })
        });
        const res = await r.json();
        if (res.success) {
            fb.textContent = "Nouvel utilisateur créé !";
            fetchUsers();
        } else {
            fb.textContent = res.error || "La mise à jour du serveur a échoué";
        }
    } catch(e){
        fb.textContent = "Erreur : " + e.message;
    }
}

fetchUsers();

async function genererInterventions() {
  await ensureDevFlagsLoaded();
  try {
    const r = await fetch('../PHP/generate_interventions.php');
    if (!r.ok) throw new Error(await r.text() || 'Erreur interventions');
    const fname = getFilenameFromDisposition(r.headers.get('Content-Disposition'));
    downloadBlob(await r.blob(), fname);

    if (window.DEV_FLAGS?.pieces) {
      const rp = await fetch('../PHP/generate_pieces.php');
      if (!rp.ok) throw new Error(await rp.text() || 'Erreur pièces');
      const fp = getFilenameFromDisposition(rp.headers.get('Content-Disposition'));
      downloadBlob(await rp.blob(), fp);
    }

    const d = await fetch('../PHP/create_date_file.php',{
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({ date:new Date().toISOString().split('T')[0] })
    });
    if (!d.ok) throw new Error(await d.text());
    lancerScriptPHP('../PHP/sync_archives.php');
    alert("Fichiers générés avec succès !");
  } catch(e){
    console.error(e);
    alert("Erreur de génération");
  }
}

function lancerScriptPHP(url,msg='Script exécuté avec succès.',err="Erreur lors de l'exécution du script des archives.") {
  const overlay = document.createElement('div');
  overlay.style.position='fixed';
  overlay.style.inset='0';
  overlay.style.background='rgba(0,0,0,0.35)';
  overlay.style.display='flex';
  overlay.style.flexDirection='column';
  overlay.style.alignItems='center';
  overlay.style.justifyContent='center';
  overlay.style.zIndex=9999;

  const box=document.createElement('div');
  box.style.background='#fff';
  box.style.padding='18px 22px';
  box.style.borderRadius='10px';
  box.style.minWidth='360px';
  box.style.boxShadow='0 10px 30px rgba(0,0,0,0.2)';

  const title=document.createElement('div');
  title.textContent='Mise à jour des données…';
  title.style.fontSize='18px';
  title.style.marginBottom='10px';
  title.style.fontWeight='600';

  const barWrap=document.createElement('div');
  barWrap.style.height='10px';
  barWrap.style.background='#eee';
  barWrap.style.borderRadius='999px';
  barWrap.style.overflow='hidden';

  const bar=document.createElement('div');
  bar.style.height='100%';
  bar.style.width='0%';
  bar.style.background='#2ecc71';
  barWrap.appendChild(bar);

  const label=document.createElement('div');
  label.textContent='Préparation…';
  label.style.marginTop='8px';
  label.style.fontSize='12px';
  label.style.color='#555';

  box.appendChild(title);
  box.appendChild(barWrap);
  box.appendChild(label);
  overlay.appendChild(box);
  document.body.appendChild(overlay);

  let pollId=null;
  const update=(p)=>{
    const t=Math.max(1,p.total||0);
    const d=Math.min(t,p.done||0);
    const pct=Math.round((d/t)*100);
    bar.style.width=pct+"%";
    const ph=p.phase||"traitement";
    label.textContent=
      ph==="count"?"Comptage… "+pct+"%":
      ph==="lecture"?"Lecture… "+pct+"%":
      ph==="aggregate"?"Agrégation… "+pct+"%":
      ph==="done"?"Terminé":
      "Traitement… "+pct+"%";
  };

  const start=()=>{
    if (pollId) return;
    pollId=setInterval(async ()=>{
      try{
        const r=await fetch('../PHP/progress_sync_archives.php?ts='+Date.now(),{cache:'no-store'});
        if (!r.ok) return;
        const p=await r.json();
        update(p);
        if (p.phase==="done") { clearInterval(pollId); pollId=null; }
      } catch(e){}
    },250);
  };
  start();

  fetch(url,{method:'GET',cache:'no-store'})
    .then(r=>r.text())
    .then(t=>{ try{return JSON.parse(t);}catch{throw new Error(t||err);} })
    .then(()=>{
      bar.style.width='100%';
      label.textContent='Terminé';
      setTimeout(()=>{
        overlay.remove();
        window.location.href='Gest.html?time=ok';
      },400);
    })
    .catch(e=>{
      if (pollId) clearInterval(pollId);
      overlay.remove();
      console.error(e);
      alert(e.message||err);
    });
}

async function genererInterventionsZeb() {
  await ensureDevFlagsLoaded();
  try {
    const r = await fetch('../PHP/generate_interventionsZeb.php');
    if (!r.ok) throw new Error(await r.text());
    downloadBlob(await r.blob(), getFilenameFromDisposition(r.headers.get('Content-Disposition')));

    if (window.DEV_FLAGS?.pieces) {
      const rp = await fetch('../PHP/generate_piecesZeb.php');
      if (!rp.ok) throw new Error(await rp.text());
      downloadBlob(await rp.blob(), getFilenameFromDisposition(rp.headers.get('Content-Disposition')));
    }

    const d = await fetch('../PHP/create_date_file.php',{
      method:'POST', headers:{'Content-Type':'application/json'},
      body:JSON.stringify({ date:new Date().toISOString().split('T')[0] })
    });
    if (!d.ok) throw new Error(await d.text());
    lancerScriptPHP('../PHP/sync_archives.php');
    alert("Fichiers générés avec succès !");
  } catch(e){
    console.error(e);
    alert("Erreur de génération");
  }
}

function getFilenameFromDisposition(disposition,def='export.csv') {
  if (!disposition) return def;
  const m=/filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i.exec(disposition);
  return decodeURIComponent((m && (m[1]||m[2])) || def);
}
function downloadBlob(blob,filename) {
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');
  a.style.display='none';
  a.href=url;
  a.download=filename||'export.csv';
  document.body.appendChild(a);
  a.click();
  URL.revokeObjectURL(url);
}

async function ensureDevFlagsLoaded() {
  if (typeof window.DEV_FLAGS?.pieces === 'boolean') return;
  try {
    const res=await fetch("../Dev.txt",{cache:"no-store"});
    const txt=await res.text();
    const p=txt.trim().split(/\r?\n/);
    window.DEV_FLAGS={
      mode:(p[0]||'false').trim().toLowerCase()==='true',
      heures:parseInt(p[1],10)||144,
      pieces:(p[2]||'false').trim().toLowerCase()==='true',
      fastStart:(p[3]||'false').trim().toLowerCase()==='true'
    };
  } catch(e){}
}

function genererInterventionstestZeb() {
    fetch('../PHP/G-MAPPstestZeb.php')
        .then(r=>{
            if (!r.ok) throw new Error('Erreur génération test');
            return r.json();
        })
        .then(data=>{
            const b1=new Blob([data.interventions],{type:'text/csv;charset=utf-8;'});
            const u1=URL.createObjectURL(b1);
            const l1=document.createElement('a');
            l1.href=u1; l1.download='interventions_test.csv';
            document.body.appendChild(l1); l1.click();
            URL.revokeObjectURL(u1);

            const b2=new Blob([data.pieces],{type:'text/csv;charset=utf-8;'});
            const u2=URL.createObjectURL(b2);
            const l2=document.createElement('a');
            l2.href=u2; l2.download='pieces_test.csv';
            document.body.appendChild(l2); l2.click();
            URL.revokeObjectURL(u2);
        })
        .catch(e=>{console.error(e); alert('Erreur test');});
}

function genererInterventionsAll() {
  genererInterventions();
  genererInterventionsZeb();
}

document.addEventListener("DOMContentLoaded", async () => {
  try {
    const res = await fetch("../Dev.txt", { cache: "no-store" });
    const txt = await res.text();
    const parts = txt.trim().split(/\r?\n/);

    // Mise à jour des flags globaux
    window.DEV_FLAGS.mode      = (parts[0] || "false").trim().toLowerCase() === "true";
    window.DEV_FLAGS.heures    = parseInt(parts[1], 10) || 144;
    window.DEV_FLAGS.pieces    = (parts[2] || "false").trim().toLowerCase() === "true";
    window.DEV_FLAGS.fastStart = (parts[3] || "false").trim().toLowerCase() === "true";
    // Nouveau : Cooldown (5ème ligne)
    window.DEV_FLAGS.cooldown  = parseInt(parts[4], 10) || 60;

    const devToggle       = document.getElementById("devToggle");
    const heureInput      = document.getElementById("heureInput");
    const piecesToggle    = document.getElementById("piecesToggle");
    const fastStartToggle = document.getElementById("fastStartToggle");
    const cooldownInput   = document.getElementById("cooldownInput");

    if (devToggle) devToggle.checked = window.DEV_FLAGS.mode;
    if (heureInput) heureInput.value = window.DEV_FLAGS.heures;
    if (piecesToggle) piecesToggle.checked = window.DEV_FLAGS.pieces;
    if (fastStartToggle) fastStartToggle.checked = window.DEV_FLAGS.fastStart;
    
    // Affectation de la valeur au nouvel input
    if (cooldownInput) cooldownInput.value = window.DEV_FLAGS.cooldown;

    // Mise à jour de la variable globale utilisée par le script de recherche
    window.COOLDOWN_DURATION = window.DEV_FLAGS.cooldown * 1000;

    refreshH2Titles();
  } catch(e) { 
    console.error("Erreur Dev.txt", e); 
  }

  fetchUsers();
});

async function sauvegarderDevTxt() {
  const mode      = document.getElementById("devToggle").checked ? "true" : "false";
  const heures    = (document.getElementById("heureInput").value || "144").trim();
  const pieces    = document.getElementById("piecesToggle").checked ? "true" : "false";
  const fastStart = document.getElementById("fastStartToggle").checked ? "true" : "false";
  // On récupère la nouvelle valeur du cooldown
  const cooldown  = (document.getElementById("cooldownInput").value || "60").trim();

  // On construit le payload avec les 5 lignes (ordre respecté)
  const payload = `${mode}\n${heures}\n${pieces}\n${fastStart}\n${cooldown}`;
  const fd = new FormData();
  fd.append("content", payload);

  try {
    const r = await fetch("../PHP/saveDev.php", { method: "POST", body: fd });
    const txt = await r.text();
    if (!r.ok) throw new Error(txt || "Erreur");

    // Mise à jour de l'objet global
    window.DEV_FLAGS = {
      mode: mode === "true",
      heures: parseInt(heures, 10) || 144,
      pieces: pieces === "true",
      fastStart: fastStart === "true",
      cooldown: parseInt(cooldown, 10) || 60
    };
    
    // On met à jour la constante de temps pour le script de recherche
    window.COOLDOWN_DURATION = window.DEV_FLAGS.cooldown * 1000;

    refreshH2Titles();

    const sm = document.getElementById("statusMessage");
    sm.textContent = "Sauvegardé";
    setTimeout(() => sm.textContent = "", 3000);
  } catch(e) {
    console.error("Erreur save", e);
    document.getElementById("statusMessage").textContent = "Échec";
  }
}

function accesProtege() {

   window.location.href="../ZTH.php";

}
