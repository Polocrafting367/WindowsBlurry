// --- Utilitaires --- //
function sortTree(tree) {
  const entries = Object.entries(tree);
  entries.sort(([a], [b]) => a.localeCompare(b, 'fr', { sensitivity: 'base' }));
  const out = {};
  for (const [k, v] of entries) {
    out[k] = (v && typeof v === 'object') ? sortTree(v) : v;
  }
  return out;
}

function cleanString(str) {
  return (str ?? '')
    .replace(/^\uFEFF/, '')        // BOM éventuel
    .trim()
    .replace(/^"|"$/g, '')
    .replace(/ +/g, ' ');
}

function objectToFormattedString(obj) {
  // Contenu de Lieu.js : export d'une constante
  return `const arborescence = ${JSON.stringify(obj, null, 2)};`;
}

function downloadFile(filename, content) {
  const blob = new Blob([content], { type: 'application/javascript' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// --- Import CSV/Excel --- //
document.getElementById('importButton').addEventListener('click', () => {
  const fileInput = document.getElementById('csvFileInput');
  if (!fileInput.files.length) {
    alert('Veuillez sélectionner un fichier CSV ou Excel.');
    return;
  }

  const file = fileInput.files[0];
  const name = file.name.toLowerCase();

  if (name.endsWith('.csv')) {
    // Chemin CSV existant, en CP1252 par défaut FR
    const reader = new FileReader();
    reader.onload = function (event) {
      const csvData = event.target.result;
      handleRowsFromDelimited(csvData);
    };
    reader.readAsText(file, 'windows-1252'); // CP1252 > évite les �
    return;
  }

  if (name.endsWith('.xlsx') || name.endsWith('.xls') || name.endsWith('.xlsb')) {
    // Chemin Excel
    const reader = new FileReader();
    reader.onload = function (event) {
      const data = new Uint8Array(event.target.result);
      const wb = XLSX.read(data, { type: 'array' });

      // Première feuille non vide
      const sheetName = wb.SheetNames.find(n => {
        const sh = wb.Sheets[n];
        const r = XLSX.utils.decode_range(sh['!ref'] || 'A1:A1');
        return r.e.r >= r.s.r && r.e.c >= r.s.c;
      }) || wb.SheetNames[0];

      const sheet = wb.Sheets[sheetName];
      // On récupère un tableau brut [ [col1, col2, ...], ... ]
      const aoa = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true, defval: '' });

      if (!aoa.length) {
        alert('Feuille Excel vide.');
        return;
      }

      // Normalisation en lignes “CSV-like” pour réutiliser ton code d’assemblage
      const rawLines = aoa.map(row => row.map(cell => toFlat(cell)).join(';'));
      handleRowsAlreadySplit(rawLines);
    };
    reader.readAsArrayBuffer(file);
    return;
  }

  alert('Format non supporté. Utilisez .csv, .xlsx, .xls, ou .xlsb.');
});

// Convertit une cellule Excel en texte plat sans sauts de ligne parasites
function toFlat(v) {
  const s = String(v ?? '');
  // enlève BOM éventuel, trim, guillemets de bord, espaces multiples
  return s.replace(/^\uFEFF/, '')
          .replace(/\r\n|\n|\r/g, ' ')
          .trim()
          .replace(/^"|"$/g, '')
          .replace(/ +/g, ' ');
}

// Gestion CSV (chaîne brute) -> lignes
function handleRowsFromDelimited(csvData) {
  const rawLines = csvData.split(/\r?\n/).filter(l => l.trim() !== '');
  if (!rawLines.length) {
    alert('Fichier CSV vide.');
    return;
  }
  handleRowsAlreadySplit(rawLines);
}

// Entrée commune: tableau de lignes “col1;col2;...”
function handleRowsAlreadySplit(rawLines) {
  const headers = rawLines[0].split(';').map(h => cleanString(h));

  // tolérance sur les libellés d’en-têtes
  const norm = (s) => s.toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();

  const hmap = {};
  headers.forEach((h, i) => { hmap[norm(h)] = i; });

  const idxPath = hmap[norm('Secteur (complet)')] ?? hmap[norm('secteur complet')] ?? -1;
  const idxDesignation = hmap[norm('Désignation')] ?? hmap[norm('designation')] ?? hmap[norm('Secteur')] ?? -1;

  if (idxPath === -1 || idxDesignation === -1) {
    console.error('En-têtes trouvés :', headers);
    alert('Colonnes attendues introuvables (besoin de "Désignation" et "Secteur (complet)").');
    return;
  }

  const tree = {};

  for (let i = 1; i < rawLines.length; i++) {
    const line = rawLines[i];
    if (!line.trim()) continue;

    const cols = line.split(';').map(c => cleanString(c));
    const sectorPath = cols[idxPath];
    const designation = cols[idxDesignation];

    if (!sectorPath) {
      console.warn(`Ligne ${i + 1} : Secteur (complet) manquant. Ligne : ${line}`);
      continue;
    }
    if (!designation) {
      console.warn(`Ligne ${i + 1} : Désignation manquante. Ligne : ${line}`);
      continue;
    }

    const parts = sectorPath
      .split(/\s*\\+\s*/g)
      .map(p => cleanString(p))
      .filter(Boolean);

    let level = tree;
    for (const p of parts) {
      if (!level[p]) level[p] = {};
      level = level[p];
    }
    if (!level[designation]) level[designation] = {};
  }

  const sortedTree = sortTree(tree);
  const formattedContent = objectToFormattedString(sortedTree);

  const preview = document.getElementById('previewContent');
  if (preview) preview.textContent = formattedContent;

  const modal = document.getElementById('previewModal');
  if (modal) modal.style.display = 'block';

  const confirmBtn = document.getElementById('confirmButton');
  if (confirmBtn) {
    confirmBtn.onclick = function () {
      fetch('../PHP/saveLieu.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/javascript; charset=UTF-8' },
        body: formattedContent
      }).then(response => {
        if (response.ok) {
          return response.text().then(text => alert(text));
        } else {
          alert('Erreur lors de la mise à jour du fichier Lieu.js.');
        }
      }).finally(() => {
        if (modal) modal.style.display = 'none';
      });
    };
  }

  const exportBtn = document.getElementById('exportButton');
  if (exportBtn) {
    exportBtn.onclick = function () {
      downloadFile('Lieu.js', formattedContent);
    };
  }

  const cancelBtn = document.getElementById('cancelButton');
  if (cancelBtn) {
    cancelBtn.onclick = function () {
      if (modal) modal.style.display = 'none';
    };
  }
}


// Fermer la modale (croix)
const closeBtn = document.querySelector('.close');
if (closeBtn) {
  closeBtn.onclick = function () {
    const modal = document.getElementById('previewModal');
    if (modal) modal.style.display = 'none';
  };
}

// Fermer en cliquant en dehors
window.onclick = function (event) {
  const modal = document.getElementById('previewModal');
  if (event.target === modal) {
    modal.style.display = 'none';
  }
};
