document.getElementById('btnImportXlsx')?.addEventListener('click', () => {
  document.getElementById('inputImportXlsx').click();

});
document.getElementById('inputImportXlsx')?.addEventListener('change', handleSelectFile);

document.getElementById('btnAnnulerImport').onclick = () => {
  document.getElementById('modalOverlay').style.display = "none";
  document.getElementById('modalConfigImport').style.display = "none";
  excelBuffer = null; // Annule l’import
};


let excelBuffer = null;
let feuillesDetectees = [];

async function handleSelectFile(evt) {
  const file = evt.target.files?.[0];
  if (!file) return;

  if (typeof ExcelJS === "undefined") {
    alert("ExcelJS non disponible");
    return;
  }

  try {
    excelBuffer = await file.arrayBuffer();
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.load(excelBuffer);

    feuillesDetectees = wb.worksheets.map(ws => ws.name || "");
    afficherModalConfig(feuillesDetectees);
  document.getElementById('modalOverlay').style.display = "block";
document.getElementById('modalConfigImport').style.display = "block";

  } catch (e) {
    alert("Erreur de lecture: " + e.message);
  }
}

function afficherModalConfig(feuilles) {
  const jours = ["Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche"];

  const tbody = document.getElementById('tableFeuilles').querySelector('tbody');
  tbody.innerHTML = "";

  feuilles.forEach(nom => {
    const tr = document.createElement('tr');

    // Nom de la feuille
    const tdNom = document.createElement('td');
    tdNom.textContent = nom;
    tr.appendChild(tdNom);

    // Sélecteur de jour
    const tdJour = document.createElement('td');
    const select = document.createElement('select');
    select.dataset.sheet = nom;
    jours.forEach(j => {
      const opt = document.createElement('option');
      opt.value = j;
      opt.textContent = j;
      if (nom.toLowerCase().includes(j.toLowerCase().slice(0,3))) opt.selected = true;
      select.appendChild(opt);
    });
    tdJour.appendChild(select);
    tr.appendChild(tdJour);

    tbody.appendChild(tr);
  });

  // Charger couleurs utilisateurs
  const zoneCouleurs = document.getElementById('couleursUtilisateurs');
  zoneCouleurs.innerHTML = "";
  for (const user of Object.keys(utilisateurs || {})) {
    const div = document.createElement('div');
    div.textContent = user + ": ";
    for (const freq of ['HQ','S1','S2','S3','S4']) {
      const input = document.createElement('input');
      input.type = "color";
      input.dataset.user = user;
      input.dataset.freq = freq;
      input.value = anyColorToHex(getUserFreqColor(user, freq));
      div.appendChild(input);
    }
    zoneCouleurs.appendChild(div);
  }

  // Auto-détection lignes si buffer déjà chargé
  detecterLignesMachines(buf => {
    document.getElementById('ligneDebut').value = buf.debut;
    document.getElementById('ligneFin').value = buf.fin;
  });

  document.getElementById('modalOverlay').style.display = "block";
  document.getElementById('modalConfigImport').style.display = "block";

  document.getElementById('btnLancerImport').onclick = () => {
    lancerImportAvecConfig();
    document.getElementById('modalOverlay').style.display = "none";
    document.getElementById('modalConfigImport').style.display = "none";
  };
}

async function detecterLignesMachines(callback) {
  if (!excelBuffer) return;

  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(excelBuffer);

  const ws = wb.worksheets[0]; // test sur la 1ère feuille
  const maxRow = ws.actualRowCount || ws.rowCount || 2000;

  let ligneDebut = null;
  let ligneFin = null;

  for (let r = 1; r <= maxRow; r++) {
    const v = readText(ws.getRow(r).getCell(1));
    if (v) { ligneDebut = r; break; }
  }
  for (let r = maxRow; r >= 1; r--) {
    const v = readText(ws.getRow(r).getCell(1));
    if (v) { ligneFin = r; break; }
  }
  if (ligneDebut === null) ligneDebut = 2;
  if (ligneFin === null) ligneFin = 200;

  callback({ debut: ligneDebut, fin: ligneFin });
}

async function lancerImportAvecConfig() {
  const selects = document.querySelectorAll('#tableFeuilles select');
  const mappingFeuilleJour = {};
  selects.forEach(sel => {
    mappingFeuilleJour[sel.dataset.sheet] = sel.value;
  });

  const ligneDebut = parseInt(document.getElementById('ligneDebut').value, 10) || 2;
  const ligneFin = parseInt(document.getElementById('ligneFin').value, 10) || 999;

  const inputsCouleur = document.querySelectorAll('#couleursUtilisateurs input[type=color]');
  for (const inp of inputsCouleur) setUserFreqColor(inp.dataset.user, inp.dataset.freq, inp.value);

  await importerPlanningDepuisExcelBuffer(excelBuffer, {
    mappingFeuilleJour,
    ligneDebut,
    ligneFin
  });
}


function setUserFreqColor(user, freq, hex) {
  if (!utilisateurs[user]) utilisateurs[user] = {};
  utilisateurs[user][freq] = hex;
}

async function importerPlanningDepuisExcelBuffer(buf, opts = {}) {
  const mapping = opts.mappingFeuilleJour || {};
  const ligneDebut = opts.ligneDebut || 2;
  const ligneFin = opts.ligneFin || 9999;

  if (!buf) { alert("Aucun fichier Excel"); return; }
  if (typeof ExcelJS === "undefined") { alert("ExcelJS non disponible"); return; }

  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buf);

  const newMachines = [];
  const machinesIndex = new Map();
  const newParam = {};
  const newBlocs = {};

  for (const ws of wb.worksheets) {
    const nomFeuille = ws.name || "";
    const dayName = mapping[nomFeuille];
    if (!dayName) continue;

    const mergeMap = getMergeMap(ws);
    const dayBlocks = [];

function traiterBlocFusionne(machineName, lignesFusionnees) {
  const mIndex = getOrPushMachineIndex(machineName, newMachines, machinesIndex);
  let cursor = dayBlocks.filter(b => b.ligne === mIndex).length;

  // on mémorise les merges déjà traités: "r0,c0"
  const processedMerges = new Set();

  for (const row of lignesFusionnees) {
    const maxCol = Math.max(row.actualCellCount || 0, row.cellCount || 0, ws.columnCount || 0);

    for (let c = 2; c <= maxCol; ) {
      const r = row.number;

      // si la cellule est dans un merge, on pointe vers sa top-left
      const covering = getCoveringMergeTopLeft(mergeMap, r, c);
      if (covering) {
        const key = `${covering.r0},${covering.c0}`;
        if (processedMerges.has(key)) {
          // déjà traité ce merge → on saute juste cette cellule
          c += 1;
          continue;
        }
        // lire depuis la top-left
        const tlCell = ws.getRow(covering.r0).getCell(covering.c0);
        const texte = readText(tlCell);

        if (texte) {
          const hexBg = getCellFillHex(tlCell);
          const inferredColor = hexBg ? inferUserAndFreqFromColor(hexBg) : null;
          const freq = resolveFrequencyFromColorAndText(inferredColor, texte);
          const codes = expandSlashCodes(texte);

          for (const raw of codes) {
            const code = normalizeCode(raw);
            const fiche = codeToFicheSafe(code);
            dayBlocks.push({
              ligne: mIndex,
              start: cursor,
              end: cursor,
              texte: code,
              codeFiche: fiche || "",
              user: inferredColor?.user || "",
              frequence: freq
            });
            cursor++;
          }
        }
        processedMerges.add(key);

        // si on est sur la ligne top-left, on peut sauter tout le merge horizontal
        // sinon on avance d’une colonne pour ne pas rater d’autres top-left sur cette ligne
        if (covering.r0 === r) {
          c += Math.max(1, covering.colSpan);
        } else {
          c += 1;
        }
        continue;
      }

      // pas de merge → lecture simple
      const cell = row.getCell(c);
      const texte = readText(cell);
      if (texte) {
        const hexBg = getCellFillHex(cell);
        const inferredColor = hexBg ? inferUserAndFreqFromColor(hexBg) : null;
        const freq = resolveFrequencyFromColorAndText(inferredColor, texte);
        const codes = expandSlashCodes(texte);

        for (const raw of codes) {
          const code = normalizeCode(raw);
          const fiche = codeToFicheSafe(code);
          dayBlocks.push({
            ligne: mIndex,
            start: cursor,
            end: cursor,
            texte: code,
            codeFiche: fiche || "",
            user: inferredColor?.user || "",
            frequence: freq
          });
          cursor++;
        }
      }
      c += 1;
    }
  }
}


    const maxRowWs = Math.max(ws.actualRowCount || 0, ws.rowCount || 0, ws.lastRow?.number || 0);
    const lastRowToUse = Math.min(maxRowWs, ligneFin);

    // Parcours avec prise en compte des merges verticaux sur la colonne machine (col 1)
    for (let r = Math.max(1, ligneDebut); r <= lastRowToUse; r++) {
      const row = ws.getRow(r);

      // Détecter si (r,1) est top-left d’un merge vertical
      const mergeMachineTop = mergeMap.get(`${r},1`);
      if (mergeMachineTop && mergeMachineTop.rowSpan > 1) {
        const spanEnd = Math.min(lastRowToUse, r + mergeMachineTop.rowSpan - 1);
        const machineName = readText(row.getCell(1)).trim();
        if (!machineName) { r = spanEnd; continue; }

        const lignesFusionnees = [];
        for (let rr = r; rr <= spanEnd; rr++) lignesFusionnees.push(ws.getRow(rr));

        traiterBlocFusionne(machineName, lignesFusionnees);
        r = spanEnd; // sauter les lignes couvertes par le merge
        continue;
      }

      // Si ce n’est pas une top-left, vérifier si la cellule machine est vide car couverte par un merge provenant d’au-dessus
      if (isInsideMergeButNotTopLeft(ws, mergeMap, r, 1)) {
        // On ignore cette ligne, elle sera traitée quand on a vu la top-left au-dessus
        continue;
      }

      // Cas normal: pas de merge vertical sur la machine à cette ligne
      const machineName = readText(row.getCell(1)).trim();
      if (!machineName) continue;

      traiterBlocFusionne(machineName, [row]); // traite comme un bloc d’une seule ligne
    }

    newBlocs[dayName] = dayBlocks;
    newParam[dayName] = parametresParJour[dayName] || { startHour: 7, totalHours: 13, pauseStart: 0, pauseEnd: 0 };
  }

  if (newMachines.length) lignesMachine = newMachines;
  for (const j of (jours || [])) {
    if (newBlocs[j]) blocsParJour[j] = newBlocs[j];
    if (newParam[j]) parametresParJour[j] = newParam[j];
  }

  majListeUtilisateurs?.();
  chargerParametresJour?.();
  rebuildPlanning?.(true);
  scheduleAutosave?.("importConfigurable");
  alert("Import terminé");
}



// ExcelJS fgColor.argb ("FFRRGGBB") -> "#rrggbb"
function argbToHex(argb) {
  if (!argb) return null;
  let s = String(argb).replace(/^0x/i, '');
  if (s.length === 8) s = s.slice(2);      // drop alpha
  if (s.length !== 6) return null;
  return '#' + s.toLowerCase();
}

function hexToRgb(hex) {
  if (!hex) return null;
  const s = hex.replace('#','').trim();
  if (s.length !== 6) return null;
  const n = parseInt(s, 16);
  return { r: (n>>16)&255, g: (n>>8)&255, b: n&255 };
}

function rgbDist(a, b) {
  if (!a || !b) return Infinity;
  const dr = a.r - b.r, dg = a.g - b.g, db = a.b - b.b;
  return Math.sqrt(dr*dr + dg*dg + db*db);
}



// Applique tes règles : "J..." -> HQ, "H..." -> HQ, "Mensuel S..." -> S1
function inferFreqFromTextDesignation(txt) {
  if (!txt) return null;
  const s = String(txt).trim().toUpperCase();

  if (s.startsWith('J')) return 'HQ';
  if (s.startsWith('H')) return 'HQ';
  if (s.startsWith('MENSUEL S')) return 'S1';

  return null; // sinon: ne rien faire
}

// --- Indice via 1ʳᵉ lettre du texte --------------------
function firstLetterFreqHint(txt) {
  const s = String(txt || "").trim().toUpperCase();
  if (!s) return null;
  const c = s[0];
  if (c === 'M') return 'S1';      // "M..." => Semaine 1
  if (c === 'H' || c === 'J') return 'HQ'; // "H..." ou "J..." => Hebdo
  return null;
}

// Combine l’inférence couleur + indice 1ʳᵉ lettre
function resolveFrequencyFromColorAndText(inferredFromColor, txt) {
  const hint = firstLetterFreqHint(txt);                // M -> S1, H/J -> HQ
  // Base: ce qu’a dit la couleur (ou none)
  let freq = inferredFromColor?.frequence || "none";

  // Si on a un hint, on le **priorise** quand la couleur est absente ou ambiguë
  // (et même si elle renvoie HQ/S1, on laisse le hint corriger).
  if (hint) {
    if (!inferredFromColor) return hint;               // pas de couleur → on suit le hint
    if (freq === "HQ" || freq === "S1") return hint;   // conflit HQ↔S1 → on suit le hint
  }
  return freq;
}


  // ---------- Helpers ----------
  const readText = (cell) => {
    if (!cell) return "";
    const v = cell.value;
    if (v == null) return "";
    if (typeof v === "string")  return v.trim();
    if (typeof v === "number")  return String(v);
    if (typeof v === "boolean") return v ? "TRUE" : "FALSE";
    if (v instanceof Date)      return v.toISOString();
    if (typeof v === "object" && ("result" in v || "formula" in v)) {
      if (v.result != null)  return String(v.result).trim();
      if (v.formula != null) return String(v.formula).trim();
    }
    if (typeof v === "object" && Array.isArray(v.richText)) {
      return v.richText.map(rt => rt?.text || "").join("").trim();
    }
    try { return String(v).trim(); } catch { return ""; }
  };

  // "H2-11/12/13" -> ["H2-11","H2-12","H2-13"]; si pas de motif, on retourne le texte brut
  function expandSlashCodes(input) {
    if (!input) return [];
    const s = String(input).trim();
    // Cherche un préfixe "H2-xxx/yyy/zzz"
    const m = /^([A-Za-z0-9]+)-([0-9]+(?:\/[0-9]+)+)\b/.exec(s);
    if (m) {
      const prefix = m[1];
      const nums = m[2].split('/').filter(Boolean);
      return nums.map(n => `${prefix}-${n}`);
    }
    // Sinon : découpe simple par espaces/virgules ; sinon garde tel quel
    const trimmed = s.replace(/\s+/g, ' ');
    return [trimmed];
  }

  function normalizeCode(code) {
    try {
      if (typeof normalizeVisibleCodeInput === 'function') {
        const n = normalizeVisibleCodeInput(code);
        if (n && n.code) return n.code;
      }
    } catch {}
    return String(code || "").toUpperCase();
  }

  const codeToFicheSafe = (code) => {
    try {
      if (typeof codeToFiche !== "undefined" && codeToFiche.get) {
        return codeToFiche.get(code) || "";
      }
    } catch {}
    return "";
  };

  const getOrPushMachineIndex = (name, machines, indexMap) => {
    if (indexMap.has(name)) return indexMap.get(name);
    const idx = machines.length;
    machines.push(name);
    indexMap.set(name, idx);
    return idx;
  };

  // ----- Couleurs Excel -> hex -----
  const THEME_BASES = {
    0: '#000000', 1: '#ffffff', 2: '#44546a', 3: '#e7e6e6', 4: '#4472c4',
    5: '#ed7d31', 6: '#a5a5a5', 7: '#ffc000', 8: '#5b9bd5', 9: '#70ad47'
  };
  function argbToHex(argb) {
    if (!argb) return null;
    let s = String(argb).replace(/^0x/i, '');
    if (s.length === 8) s = s.slice(2);
    if (!/^[0-9A-Fa-f]{6}$/.test(s)) return null;
    return '#' + s.toLowerCase();
  }
  function hexToRgb(hex) {
    if (!hex) return null;
    const s = hex.replace('#', '').trim();
    if (s.length !== 6) return null;
    const n = parseInt(s, 16);
    return { r: (n>>16)&255, g: (n>>8)&255, b: n&255 };
  }
  function applyTint(baseHex, tint) {
    const rgb = hexToRgb(baseHex);
    if (!rgb || typeof tint !== 'number' || tint === 0) return baseHex;
    const f = (v) => tint > 0 ? Math.round(v + (255 - v) * tint) : Math.round(v * (1 + tint));
    const r = Math.max(0, Math.min(255, f(rgb.r)));
    const g = Math.max(0, Math.min(255, f(rgb.g)));
    const b = Math.max(0, Math.min(255, f(rgb.b)));
    return '#' + [r,g,b].map(v => v.toString(16).padStart(2, '0')).join('');
  }
  function getCellFillHex(cell) {
    const f = cell?.fill;
    if (!f) return null;
    if (f.type === 'pattern') {
      const c = f.fgColor || f.bgColor;
      if (!c) return null;
      if (c.argb) return argbToHex(c.argb);
      if (c.rgb) return '#' + String(c.rgb).slice(-6).toLowerCase();
      if (typeof c.theme === 'number') {
        const base = THEME_BASES[c.theme];
        if (!base) return null;
        return (typeof c.tint === 'number') ? applyTint(base, c.tint) : base;
      }
    }
    return null;
  }

  // ----- Couleur → user/frequence -----
  function rgbDist(a, b) {
    const dr = a.r - b.r, dg = a.g - b.g, db = a.b - b.b;
    return Math.sqrt(dr*dr + dg*dg + db*db);
  }

  function inferUserAndFreqFromHex(hexBg, tolerance = 45) {
    const target = hexToRgb(hexBg);
    if (!target) return null;
    const samples = [];
    for (const user of Object.keys(utilisateurs || {})) {
      for (const freq of ['HQ','S1','S2','S3','S4']) {
        const c = anyColorToHex(getUserFreqColor(user, freq));
        const rgb = hexToRgb(c);
        if (rgb) samples.push({ user, freq, rgb });
      }
    }
    let best = null, bestD = Infinity;
    for (const s of samples) {
      const d = rgbDist(target, s.rgb);
      if (d < bestD) { best = s; bestD = d; }
    }
    return (bestD <= tolerance) ? { user: best.user, frequence: best.freq } : null;
  }
  function inferFreqFromTextDesignation(txt) {
    const s = String(txt).trim().toUpperCase();
    if (s.startsWith('J') || s.startsWith('H')) return 'HQ';
    if (s.startsWith('MENSUEL S')) return 'S1';
    return null;
  }

  // ----- Merges helpers -----
  function colLetterToNumber(letters) {
    let n = 0;
    for (let i = 0; i < letters.length; i++) {
      const cc = letters.charCodeAt(i);
      if (cc >= 65 && cc <= 90) n = n * 26 + (cc - 64);
      else if (cc >= 97 && cc <= 122) n = n * 26 + (cc - 96);
    }
    return n;
  }
  function getMergeMap(ws) {
    const map = new Map(); // "r,c" -> {rowSpan,colSpan}
    let addrs = [];
    if (ws?.model?.merges && Array.isArray(ws.model.merges)) addrs = ws.model.merges;
    else if (ws?._merges) {
      if (typeof ws._merges.keys === 'function') addrs = Array.from(ws._merges.keys());
      else addrs = Object.keys(ws._merges);
    }
    addrs.forEach(addr => {
      const m = /^([A-Z]+)(\d+):([A-Z]+)(\d+)$/i.exec(addr);
      if (!m) return;
      const c1 = colLetterToNumber(m[1]);
      const r1 = parseInt(m[2], 10);
      const c2 = colLetterToNumber(m[3]);
      const r2 = parseInt(m[4], 10);
      map.set(`${r1},${c1}`, { rowSpan: r2 - r1 + 1, colSpan: c2 - c1 + 1 });
    });
    return map;
  }
  function isCoveredByMergeTopLeft(ws, mergeMap, r, c) {
    // vrai si (r,c) est une top-left d’un merge
    return mergeMap.has(`${r},${c}`);
  }
  function isInsideMergeButNotTopLeft(ws, mergeMap, r, c) {
    // si (r,c) est couvert par un merge dont la top-left est ailleurs
    for (const [key, span] of mergeMap.entries()) {
      const [r0, c0] = key.split(',').map(Number);
      if (r >= r0 && r < r0 + span.rowSpan && c >= c0 && c < c0 + span.colSpan) {
        return !(r === r0 && c === c0);
      }
    }
    return false;
  }


// Parse "rgb(...)" ou "#rrggbb" → "#rrggbb"
function rgbToHexStr(input) {
  if (!input) return null;
  if (typeof input === 'string' && input.startsWith('#')) {
    const s = input.trim();
    if (/^#([0-9a-fA-F]{6})$/.test(s)) return s.toLowerCase();
    if (/^#([0-9a-fA-F]{3})$/.test(s)) {
      const r = s[1], g = s[2], b = s[3];
      return ('#' + r + r + g + g + b + b).toLowerCase();
    }
  }
  if (typeof input === 'string' && input.startsWith('rgb')) {
    // rgb(12,34,56) | rgba(12,34,56,0.5)
    const m = input.match(/rgba?\s*\(\s*([0-9]+)\s*,\s*([0-9]+)\s*,\s*([0-9]+)\s*(?:,\s*[0-9.]+\s*)?\)/i);
    if (m) {
      const r = Math.max(0, Math.min(255, parseInt(m[1],10)));
      const g = Math.max(0, Math.min(255, parseInt(m[2],10)));
      const b = Math.max(0, Math.min(255, parseInt(m[3],10)));
      return '#' + [r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('');
    }
  }
  return null;
}

function anyColorToHex(c) {
  if (!c) return null;
  if (typeof c === 'string' && c.startsWith('#')) return rgbToHexStr(c);
  return rgbToHexStr(String(c));
}

// Retourne { user, frequence }  ← IMPORTANT: clé "frequence"
function inferUserAndFreqFromColor(hexBg) {
  const target = hexToRgb(hexBg);
  if (!target) return null;

  const samples = [];
  for (const user of Object.keys(utilisateurs || {})) {
    for (const freq of ['HQ','S1','S2','S3','S4']) {
      const c = anyColorToHex(getUserFreqColor(user, freq));
      const rgb = hexToRgb(c);
      if (rgb) samples.push({ user, freq, rgb });
    }
  }

  let best = null, bestD = Infinity;
  for (const s of samples) {
    const d = rgbDist(target, s.rgb);
    if (d < bestD) { best = s; bestD = d; }
  }
  return bestD <= 45 ? { user: best.user, frequence: best.freq } : null;
}


function getCoveringMergeTopLeft(mergeMap, r, c) {
  for (const [key, span] of mergeMap.entries()) {
    const [r0, c0] = key.split(',').map(Number);
    if (r >= r0 && r < r0 + span.rowSpan && c >= c0 && c < c0 + span.colSpan) {
      return { r0, c0, rowSpan: span.rowSpan, colSpan: span.colSpan };
    }
  }
  return null;
}
