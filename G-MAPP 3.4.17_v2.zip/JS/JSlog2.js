

const urlParams = new URLSearchParams(window.location.search);

/* -------------------- [CORRIGÉ] Redirection Gestion à Gest.html ------------------- */
function proceedGestionLogin(accessLevel, username) {
    const mode = "Gest";
    const targetBaseUrl = "../HTML/Gest.html"; 

    // Stockage dans sessionStorage (correct)
    sessionStorage.setItem("currentUser", username);
    sessionStorage.setItem("userRole", accessLevel);

    // 1. Définition des paramètres de base (user, mode, time)
    // Nous appelons directement nowTimeString pour l'heure.
    const extraParamsObj = { 
        user: username, 
        mode: mode, 
        time: nowTimeString() 
    };

    // 2. AJOUT DU PARAMÈTRE AVANCE (C'EST LA CLÉ)
    if (accessLevel === "AVANCE") {
        extraParamsObj.adv = "true";
    }

    // --- Suppression de la lecture des paramètres i et p de l'URL source si non critiques ---
    // (Si ces paramètres sont critiques pour Gest.html, vous devez les récupérer d'une autre source fiable)
    // --- Fin de la suppression ---

    // 3. Redirection
    const qp = new URLSearchParams(extraParamsObj);
    const targetUrl = `${targetBaseUrl}?${qp.toString()}`;
    
    console.log(`Redirection Gestion (${accessLevel}) vers : ${targetUrl}`);
    // Utiliser window.location.assign est parfois préférable pour le suivi de l'historique
    window.location.assign(targetUrl); 
}

/* ----------------------------- [NEW] Réseau ------------------------------ */
async function isConnected() {
  try {
    const res = await fetch('../Ressources/void.html', { cache: 'no-store' });
    return res.ok;
  } catch {
    return false;
  }
}

/* --------------------- [NEW] Mappage IndexedDB identique ------------------ */
const DB_CONFIG = {
  "Work":  { DB_NAME: "MyAppDB",      STORE_NAME: "files",      LAST_SAVE_KEY: "lastSaveTime" },
  "Priv":  { DB_NAME: "MyAppDBPrev",  STORE_NAME: "filesPrev",  LAST_SAVE_KEY: "lastSaveTimePrev" },
  "Story": { DB_NAME: "MyAppDBStory", STORE_NAME: "filesStory", LAST_SAVE_KEY: "lastSaveTimeStory" }
};

/* ------------------------ [NEW] Utilitaires IndexedDB --------------------- */
async function openDatabase(dbName, storeName) {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(dbName, 1);
    request.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(storeName)) {
        db.createObjectStore(storeName);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(`Erreur ouverture DB ${dbName}`);
  });
}

async function getStoredFile(db, storeName, key) {
  return new Promise(resolve => {
    const tx = db.transaction(storeName, "readonly");
    const store = tx.objectStore(storeName);
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror   = () => resolve(null);
  });
}

/* --------------------- [NEW] UI : écran d’erreur offline ------------------ */
function showOfflineErrorScreen() {
  const overlay = document.createElement('div');
  overlay.style.position = 'fixed';
  overlay.style.inset = '0';
  overlay.style.background = 'rgba(0,0,0,0.3)';
  overlay.style.display = 'flex';
  overlay.style.flexDirection = 'column';
  overlay.style.alignItems = 'center';
  overlay.style.justifyContent = 'center';
  overlay.style.zIndex = '9999';
  overlay.innerHTML = `
    <p style="color: white; font-size: 1.2em; margin-bottom: 20px;">⚠️ Connexion Internet insuffisante</p>
    <button id="retryOffline" style="padding: 10px 20px; font-size: 1em;">Réessayer</button>
  `;
  document.body.appendChild(overlay);
document.querySelectorAll('.window').forEach(w => w.style.display = 'none');

  document.getElementById('retryOffline').onclick = async () => {
    if (await isConnected()) {
      location.reload();
    }
  };
}

/* ----------- [NEW] Rendu direct de start.html depuis le cache ------------- */
async function renderStartFromCache(mode, paramsString) {
  try {
    const { DB_NAME, STORE_NAME } = DB_CONFIG[mode];
    const db = await openDatabase(DB_NAME, STORE_NAME);
    const startContent = await getStoredFile(db, STORE_NAME, "start.html");
    if (!startContent) return false;

    document.body.innerHTML = '';
    const iframe = document.createElement("iframe");
    iframe.id = "startIframe";
    Object.assign(iframe.style, {
      position: "fixed", top: "0", left: "0", width: "100%", height: "100%",
      border: "none", zIndex: "9999"
    });
    document.body.appendChild(iframe);

    // URL logique que "verra" la page dans l'iframe
    const baseUrl  = "start.html";
    const finalUrl = paramsString ? `${baseUrl}?${paramsString}` : baseUrl;

    setTimeout(() => {
      const docIframe = iframe.contentDocument || iframe.contentWindow.document;
      if (!docIframe) return;

      // IMPORTANT:
      // 1) <base> pour les chemins relatifs
      // 2) history.replaceState(...) AVANT le contenu pour que start.js trouve window.location.search
      // (Pas de requête réseau : on change l'URL "logique" du document déjà chargé en mémoire)
      docIframe.open();
      docIframe.write(
        `<!DOCTYPE html>
         <base href="${finalUrl}">
         <script>try{history.replaceState(null,'','${finalUrl}')}catch(e){}<\/script>
         ${startContent}`
      );
      docIframe.close();
    }, 30);

    return true;
  } catch (e) {
    console.error("renderStartFromCache error:", e);
    return false;
  }
}


/* ----------------------- [NEW] Lancement hors-ligne ----------------------- */
async function tryOfflineLaunch(mode, extraParamsObj = {}) {
  const qp = new URLSearchParams();
  for (const [k, v] of Object.entries(extraParamsObj)) {
    if (v != null && v !== "") qp.set(k, v);
  }
  const ok = await renderStartFromCache(mode, qp.toString());
  if (!ok) showOfflineErrorScreen();
  return ok;
}

/* -------------------------- DOMContentLoaded ------------------------------ */
document.addEventListener('DOMContentLoaded', async function() {
  try {
    const response = await fetch('../Update.txt');
    if (!response.ok) throw new Error('Erreur lors du chargement du fichier Update.txt');
    const data = await response.text();
    const creditsEl = document.getElementById('credits');
    if (creditsEl) creditsEl.innerHTML = data.replace(/\n/g, '<br>');
  } catch (error) {
    console.error(error);
  }

  const carousel = document.getElementById('verticalCarousel');
  if (!carousel) return;

  carousel.querySelectorAll('.user-card').forEach(card => {
    let pressTimer = null;

    // Souris
    card.addEventListener("mousedown", () => {
      pressTimer = setTimeout(() => {
        card.alreadyResetMode = true;
        showResetButton(card);
      }, 800);
    });
    card.addEventListener("mouseup",   () => clearTimeout(pressTimer));
    card.addEventListener("mouseleave",() => clearTimeout(pressTimer));

    // Tactile
    card.addEventListener("touchstart", () => {
      pressTimer = setTimeout(() => {
        card.alreadyResetMode = true;
        showResetButton(card);
      }, 800);
    }, { passive: true });
    card.addEventListener("touchend",   () => clearTimeout(pressTimer));
    card.addEventListener("touchcancel",() => clearTimeout(pressTimer));
  });

});

/* ------------------------------- Reset long-press -------------------------- */
function showResetButton(card) {
  // Mettre la carte en mode expanded
  document.querySelectorAll('.user-card').forEach(c => {
    c.classList.add("dimmed");
    let lo = c.querySelector(".login-options");
    if (lo) c.removeChild(lo);
  });

  card.classList.remove("dimmed");
  card.classList.add("expanded");
  card.style.backgroundImage = "";

  // Masquer boutons d’origine
  const buttons = card.querySelectorAll('.action-button');
  buttons.forEach(btn => btn.style.display = 'none');

  let resetBtn = card.querySelector('.reset-button');
  let cancelBtn = card.querySelector('.cancel-reset-button');

  if (!resetBtn) {
    resetBtn = document.createElement('button');
    resetBtn.textContent = 'Reset paramètres actifs';
    resetBtn.className = 'reset-button';
    resetBtn.style.bottom = '45px';
    resetBtn.onclick = () => {
      const username = card.getAttribute('data-username');
      if (!username) {
        alert('Nom utilisateur manquant.');
        return;
      }
      const dynamicKey = username + '_device_id';
      console.log(dynamicKey);

      removeUserDeviceId(username, dynamicKey, () => {
        alert('Paramètres supprimés.');
        resetBtn.remove();
        cancelBtn.remove();
        card.alreadyResetMode = false;
        // Rétablir les autres cartes
        document.querySelectorAll('.user-card').forEach(c => {
          c.classList.remove("dimmed");
          c.classList.remove("expanded");
          c.style.backgroundImage = "url('../IMG/user.png')";
        });
      });
    };

    card.appendChild(resetBtn);
  }

  if (!cancelBtn) {
    cancelBtn = document.createElement('button');
    cancelBtn.textContent = 'Annuler';
    cancelBtn.className = 'cancel-reset-button';
    cancelBtn.style.marginTop = '5px';
    cancelBtn.onclick = () => {
      // Réafficher boutons d’origine
      buttons.forEach(btn => btn.style.display = '');

      // Supprimer boutons reset et annuler
      resetBtn.remove();
      cancelBtn.remove();

      // Rétablir état normal
      card.alreadyResetMode = false;

      // Rétablir les autres cartes
      document.querySelectorAll('.user-card').forEach(c => {
        c.classList.remove("dimmed");
        c.classList.remove("expanded");
        c.style.backgroundImage = "url('../IMG/user.png')";
      });
    };
    card.appendChild(cancelBtn);
  }
}

function removeUserDeviceId(username, key, callback) {
  const dynamicuser = username + '_';

  fetch('../Ressources/PHP/removeData.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ username: dynamicuser, key: key })
  })
  .then(response => response.json())
  .then(data => {
    console.log(data);

    // Réinitialiser AUTOUSER
    localStorage.removeItem("AUTOUSER");

    // Ajouter les valeurs comme une connexion normale
    localStorage.setItem("rememberedUser", username);
    localStorage.setItem("AUTOUSER", username);
    localStorage.setItem(username + '_uver', "Work");

    // Construire URL finale
    const now = new Date();
    const timeStr = now.getFullYear() + '-' +
      (now.getMonth() + 1).toString().padStart(2, '0') + '-' +
      now.getDate().toString().padStart(2, '0') + '_' +
      now.getHours().toString().padStart(2, '0') + ':' +
      now.getMinutes().toString().padStart(2, '0') + ':' +
      now.getSeconds().toString().padStart(2, '0');
    const encodedTime = encodeURIComponent(timeStr);

    const url = '../Ressources/index.html?user=' + encodeURIComponent(username) + '&mode=Work' + '&reset=true' + '&time=' + encodedTime;
    window.location.href = url;

    callback();
  })
  .catch(error => {
    console.error(error);
    alert('Erreur suppression.');
    callback();
  });
}

/* -------------------------- Chargement des utilisateurs ------------------- */
let users = {};
fetch("../XbGv89Lm.json")
  .then(response => response.json())
  .then(data => {
    users = data;
    createUserCards();
  });

function createUserCards() {
  const carouselContainer = document.getElementById("verticalCarousel");
  const managerContainer  = document.getElementById("managerContainer");
  if (!carouselContainer || !managerContainer) return;

  carouselContainer.innerHTML = "";
  //managerContainer.innerHTML  = "";

  function isObj(v){ return v && typeof v === 'object'; }
  function isEnd(u){
    const v = users[u];
    return isObj(v) && v.end === true;
  }
  function isGestion(u){
    if (u !== "Gestion") return false;
    const v = users[u];
    // ancien format: chaîne du mot de passe
    return true;
  }
  function orderVal(u){
    const v = users[u];
    return isObj(v) && Number.isFinite(v.order) ? Number(v.order) : 0;
  }

  const all = Object.keys(users);

  // tri: Gestion d’abord, puis order asc, puis non-end, puis end, puis alpha
  const sorted = all.slice().sort((a, b) => {
    if (isGestion(a) && !isGestion(b)) return -1;
    if (!isGestion(a) && isGestion(b)) return 1;

    const oa = orderVal(a), ob = orderVal(b);
    if (oa !== ob) return oa - ob;

    const ea = isEnd(a), eb = isEnd(b);
    if (ea !== eb) return ea - eb; // false avant true

    return a.localeCompare(b, 'fr', { sensitivity: 'base' });
  });



  // Utilisateurs
  sorted.forEach(username => {
    if (username === "Gestion") return;

    const card = document.createElement("div");
    card.className = "user-card";
    card.setAttribute("data-username", username);
    card.style.backgroundImage    = "url('../IMG/user.png')";
    card.style.backgroundRepeat   = "no-repeat";
    card.style.backgroundPosition = "center";
    card.style.backgroundSize     = "cover";

    const title = document.createElement("h2");
    title.innerText = username;
    card.appendChild(title);

    card.alreadyResetMode   = false;
    card.longPressTriggered = false;

    // Click normal
    card.addEventListener("click", function(e) {
      if (card.longPressTriggered) return;
      e.stopPropagation();
      if (card.alreadyResetMode) return;

      if (card.classList.contains("expanded")) {
        card.classList.remove("expanded");
        let loginOptions = card.querySelector(".login-options");
        if (loginOptions) card.removeChild(loginOptions);
        card.style.backgroundImage = "url('../IMG/user.png')";
        document.querySelectorAll('.user-card').forEach(c => c.classList.remove("dimmed"));
      } else {
        document.querySelectorAll('.user-card').forEach(c => {
          c.style.backgroundImage = "url('../IMG/user.png')";
          c.classList.remove("expanded");
          c.classList.add("dimmed");
          let lo = c.querySelector(".login-options");
          if (lo) c.removeChild(lo);
        });

        card.classList.remove("dimmed");
        card.classList.add("expanded");
        card.style.backgroundImage = "";

        const loginOptions = document.createElement("div");
        loginOptions.className = "login-options";
        const buttons = [];

        const btnCorrectif = document.createElement("button");
        btnCorrectif.innerText = "Correctif";
        btnCorrectif.className = "action-button";
        btnCorrectif.addEventListener("click", function(ev) {
          ev.stopPropagation();
          loginUser(username);
        });
        buttons.push(btnCorrectif);

        const btnLoginPrev = document.createElement("button");
        btnLoginPrev.innerText = "Préventif";
        btnLoginPrev.className = "action-button";
        btnLoginPrev.addEventListener("click", function(ev) {
          ev.stopPropagation();
          loginUserPrev(username);
        });
        buttons.push(btnLoginPrev);

        const btnCintre = document.createElement("button");
        btnCintre.innerText = "Cintre";
        btnCintre.style.backgroundColor = "#06A0BC";
        btnCintre.className = "action-button";
        btnCintre.addEventListener("click", function(ev) {
          ev.stopPropagation();
          loginCintre(username);
        });
        buttons.push(btnCintre);

        buttons.forEach(button => {
          button.style.opacity = "0";
          loginOptions.appendChild(button);
        });

        card.appendChild(loginOptions);

        setTimeout(() => {
          buttons.forEach((button, index) => {
            setTimeout(() => {
              button.style.opacity = "1";
              button.style.transform = "translateY(0)";
              button.style.transition = "opacity 0.5s ease-out, transform 0.5s ease-out";
            }, index * 100);
          });
        }, 10);
      }
    });

    // Appui long pour reset
    let pressTimer = null;
    function startPress() {
      card.longPressTriggered = false;
      pressTimer = setTimeout(() => {
        card.longPressTriggered = true;
        card.alreadyResetMode = true;
        showResetButton(card);
      }, 800);
    }
    function cancelPress(){ clearTimeout(pressTimer); }

    card.addEventListener("mousedown", startPress);
    card.addEventListener("mouseup",   cancelPress);
    card.addEventListener("mouseleave",cancelPress);
    card.addEventListener("touchstart",startPress, { passive: true });
    card.addEventListener("touchend",  cancelPress);
    card.addEventListener("touchcancel", cancelPress);

    carouselContainer.appendChild(card);
  });

  adjustCarousel();
}


/* ----------------------------- Cintre (inchangé) -------------------------- */
function loginCintre(username) {
  localStorage.removeItem("rememberedUser");
  localStorage.removeItem("AUTOUSER");
  top.location.href = '../Cintres/index.html?user=' + encodeURIComponent(username)
}

/* --------------------- [NEW] utilitaire timestamp URL --------------------- */
function makeEncodedNow() {
  const now = new Date();
  const timeStr = now.getFullYear() + '-' +
    (now.getMonth() + 1).toString().padStart(2, '0') + '-' +
    now.getDate().toString().padStart(2, '0') + '_' +
    now.getHours().toString().padStart(2, '0') + ':' +
    now.getMinutes().toString().padStart(2, '0') + ':' +
    now.getSeconds().toString().padStart(2, '0');
  return encodeURIComponent(timeStr);
}

/* ------------------ [NEW] procédure commune de connexion ------------------ */
async function proceedLogin(mode, username) {
  localStorage.setItem("rememberedUser", username);
  localStorage.setItem("AUTOUSER", username);
  localStorage.setItem(username + '_uver', mode);

  // time "brut" (non encodé) pour l'objet params; on encodera via URLSearchParams
  const now = new Date();
  const timeStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}_` +
                  `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`;

  const currentUrl = new URL(window.location.href);
  const paramsIn   = new URLSearchParams(currentUrl.search);
  const interLieu  = paramsIn.get('i') || paramsIn.get('p');
  const paramType  = paramsIn.has('i') ? 'i' : (paramsIn.has('p') ? 'p' : null);

  // Paramètres à transmettre dans TOUS les cas (online/offline)
  const extraParamsObj = { user: username, mode, time: timeStr };
  if (interLieu && paramType) extraParamsObj[paramType] = interLieu;

  // En ligne : flux normal -> Ressources/index.html
  if (await isConnected()) {
    const qp = new URLSearchParams(extraParamsObj);
    const targetUrl = `../Ressources/index.html?${qp.toString()}`;
    window.location.href = targetUrl;
    return;
  }

  // Hors ligne : tentative directe depuis IndexedDB
  const launched = await tryOfflineLaunch(mode, extraParamsObj);
  if (!launched) {
    // l’écran "⚠️ Connexion Internet insuffisante" est déjà affiché
  }
}


/* ---------------------------- Connexion Correctif ------------------------- */
function loginUser(username, accessLevel) {
    if (username === "Gestion") {
        // Appeler la logique spécifique Gestion (BASIC/AVANCE)
        // proceedGestionLogin gère la redirection et le sessionStorage.
        proceedGestionLogin(accessLevel, username); 
    } else {
        // Flux normal pour les autres utilisateurs (Correction)
        // proceedLogin (qui utilise localStorage) est OK pour les autres utilisateurs.
        proceedLogin("Work", username); 
    }
}
/* ---------------------------- Connexion Préventif ------------------------- */
function loginUserPrev(username) {
  proceedLogin("Priv", username); // [NEW] bascule hors-ligne si nécessaire
}

/* --------------------------- Interface Gestion (UI) - CORRIGÉE POUR DEBUG ----------------------- */
function activateGestionLogin() {
    // ... (Code de manipulation du DOM, inchangé) ...

    const carouselContainer = document.getElementById("verticalCarousel");
    carouselContainer.style.height = "calc(100% - 230px)";

    const managerContainer = document.getElementById("managerContainer");
    managerContainer.style.height = "230px";

    const managerCard = managerContainer.querySelector(".manager-card");
    if (!managerCard) return;

    while (managerCard.childNodes.length > 1) {
        managerCard.removeChild(managerCard.lastChild);
    }

    const formContainer = document.createElement("div");
    formContainer.className = "gestion-login-form";

    const pwdInput = document.createElement("input");
    pwdInput.type = "password";
    pwdInput.id = "password-input";
    pwdInput.placeholder = "Entrez le mot de passe";
    pwdInput.className = "gestion-password-input";
    pwdInput.style.opacity = "0";
    formContainer.appendChild(pwdInput);

    const buttons = [];

    // --- LOGIQUE DE VÉRIFICATION COMMUNE ---
    function handleGestionLogin() {
        const passwordEntered = pwdInput.value.trim();

        if (passwordEntered !== "") {
            const gestionPasswords = users["Gestion"]; 
            
            // DÉBOGAGE 1: Vérifiez que le JSON est chargé et structuré
            if (!gestionPasswords || typeof gestionPasswords !== 'object' || !gestionPasswords["AVANCE"] || !gestionPasswords["BASIC"]) {
                console.error("DEBUG JSON: La structure 'users[\"Gestion\"]' est incorrecte ou non chargée.", gestionPasswords);
                alert("Erreur de configuration des mots de passe Gestion (JSON non structuré).");
                return;
            }
            
            let accessLevel = null;
            
            // 1. Vérification AVANCÉE
            if (passwordEntered === gestionPasswords["AVANCE"]) {
                accessLevel = "AVANCE";
                console.log("DEBUG LOGIN: Mot de passe reconnu: AVANCE");
            } 
            // 2. Vérification BASIC
            else if (passwordEntered === gestionPasswords["BASIC"]) {
                accessLevel = "BASIC";
                console.log("DEBUG LOGIN: Mot de passe reconnu: BASIC");
            }

            if (accessLevel) {
                // Connexion réussie, appelle loginUser avec le niveau d'accès
                loginUser("Gestion", accessLevel); 
            } else {
                console.log("DEBUG LOGIN: Mot de passe incorrect.");
                alert("Mot de passe incorrect.");
            }
        } else {
            alert("Veuillez saisir le mot de passe.");
        }
    }
    // --- FIN LOGIQUE DE VÉRIFICATION COMMUNE ---


    const connectBtn = document.createElement("button");
    connectBtn.innerText = "Se connecter";
    connectBtn.className = "gestion-connect-btn";
    connectBtn.style.opacity = "0";
    connectBtn.addEventListener("click", function(event) {
        event.stopPropagation();
        handleGestionLogin(); // Utilise la nouvelle fonction de vérification
    });
    buttons.push(connectBtn);

    const cancelBtn = document.createElement("button");
    cancelBtn.innerText = "Annuler";
    cancelBtn.className = "gestion-cancel-btn";
    cancelBtn.style.opacity = "0";
    cancelBtn.addEventListener("click", function(event) {
        event.stopPropagation();
        hideGestionLogin(managerCard, formContainer);
    });
    buttons.push(cancelBtn);

    formContainer.appendChild(pwdInput);
    buttons.forEach(button => formContainer.appendChild(button));
    managerCard.appendChild(formContainer);

    setTimeout(() => {
        formContainer.classList.add("show");
        setTimeout(() => {
            pwdInput.style.opacity = "1";
            pwdInput.style.transform = "translateY(0)";
            pwdInput.focus();
        }, 200);

        pwdInput.addEventListener("keydown", function(event) {
            if (event.key === "Enter") {
                event.preventDefault();
                handleGestionLogin(); // Utilise la nouvelle fonction de vérification
            }
        });

        buttons.forEach((button, index) => {
            setTimeout(() => {
                button.style.opacity = "1";
                button.style.transform = "translateY(0)";
            }, (index + 1) * 200);
        });
    }, 10);
}
function hideGestionLogin(managerCard, formContainer, carouselContainer, managerContainer) {
  formContainer.classList.add("hide");

  carouselContainer = document.getElementById("verticalCarousel");
  managerContainer = document.getElementById("managerContainer");
  carouselContainer.style.height = "calc(100% - 58px)";
  managerContainer.style.height = "58px";

  setTimeout(() => {
    if (formContainer.parentNode) {
      formContainer.parentNode.removeChild(formContainer);
    }

    const mBtn = document.createElement("button");
    mBtn.innerText = "Se connecter";
    mBtn.className = "gestion-reconnect-btn";
    mBtn.style.opacity = "0";
    mBtn.style.transform = "translateY(-10px)";
    managerCard.appendChild(mBtn);

    mBtn.addEventListener("click", function(event) {
      event.stopPropagation();
      activateGestionLogin();
    });

    setTimeout(() => {
      mBtn.style.opacity = "1";
      mBtn.style.transform = "translateY(0)";
      mBtn.style.transition = "opacity 0.4s ease-out, transform 0.4s ease-out";
    }, 50);
  }, 350);
}

/* ------------------------ Carousel (scale éventuel) ----------------------- */
function adjustCarousel() {
  const carousel = document.getElementById('verticalCarousel');
  if (!carousel) return;
  const carouselRect = carousel.getBoundingClientRect();
  const carouselCenter = carouselRect.top + carouselRect.height / 2;
  const cards = carousel.getElementsByClassName('user-card');
  for (let card of cards) {
    const cardRect = card.getBoundingClientRect();
    const cardCenter = cardRect.top + cardRect.height / 2;
    const distance = Math.abs(carouselCenter - cardCenter);
    // appliquer un scale si désiré
  }
}
document.getElementById('verticalCarousel')?.addEventListener('scroll', adjustCarousel);

/* ------------------------------ Tutoriel Modal ---------------------------- */
function openWebsite() {
  const m = document.getElementById("tutorialModal");
  if (m) m.style.display = "none";
}
function openmodal() {
  loadPageInIframe("../Ressources/tuto/index.html");
  const m = document.getElementById("tutorialModal");
  if (m) m.style.display = "block";
}
function loadPageInIframe(url) {
  const c = document.getElementById("iframeContainer");
  if (c) c.innerHTML = '<iframe id="TUTORIEL" src="' + url + '"></iframe>';
}

/* ===========================
   Message bus parent (offline/online)
   À coller dans JSlog2.js
   =========================== */

// -- helpers locaux pour relire les paramètres courants de l'iframe/start
function getCurrentStartParamsFromIframe() {
  const iframe = document.getElementById('startIframe');
  if (!iframe || !iframe.contentWindow) return null;
  try {
    // on a défini history.replaceState(..., finalUrl) à l'injection : on peut lire search ici
    const search = iframe.contentWindow.location.search || "";
    return new URLSearchParams(search);
  } catch {
    return null;
  }
}

function buildParamsString(obj) {
  const qp = new URLSearchParams();
  Object.entries(obj).forEach(([k, v]) => {
    if (v != null && v !== "") qp.set(k, v);
  });
  return qp.toString();
}

function nowTimeString() {
  const now = new Date();
  return (
    `${now.getFullYear()}-` +
    `${String(now.getMonth()+1).padStart(2,'0')}-` +
    `${String(now.getDate()).padStart(2,'0')}_` +
    `${String(now.getHours()).padStart(2,'0')}:` +
    `${String(now.getMinutes()).padStart(2,'0')}:` +
    `${String(now.getSeconds()).padStart(2,'0')}`
  );
}

// -- recharge "soft" du start actuel (pref: offline, sinon online)
async function reloadStartIframe() {
  const params = getCurrentStartParamsFromIframe();
  let user  = localStorage.getItem("AUTOUSER") || localStorage.getItem("rememberedUser") || (params && params.get('user')) || "default";
  let mode  = (params && params.get('mode')) || localStorage.getItem((user || "default") + "_uver") || "Work";
  let i     = params && params.get('i');
  let p     = params && params.get('p');
  let time  = nowTimeString(); // on rafraîchit le time pour rester dans ta règle 8h

  const extraParamsObj = { user, mode, time };
  if (i) extraParamsObj.i = i;
  if (p) extraParamsObj.p = p;

  if (await isConnected()) {
    const qs = buildParamsString(extraParamsObj);
    window.location.href = `../Ressources/index.html?${qs}`;
    return;
  }

  // offline -> tenter le rendu cache
  const ok = await tryOfflineLaunch(mode, extraParamsObj);
  if (!ok) {
    // tryOfflineLaunch a déjà affiché l’overlay erreur
  }
}

// -- bascule de mode (ex: { action:'changeStart', mode:'Priv' })
async function redirectToStartPage(newMode, deviceNameUnused) {
  const params = getCurrentStartParamsFromIframe();
  const user = localStorage.getItem("AUTOUSER") || localStorage.getItem("rememberedUser") || (params && params.get('user')) || "default";
  const i    = params && params.get('i');
  const p    = params && params.get('p');
  const time = nowTimeString();

  // stocker le choix
  localStorage.setItem(user + "_uver", newMode);

  const extraParamsObj = { user, mode: newMode, time };
  if (i) extraParamsObj.i = i;
  if (p) extraParamsObj.p = p;

  if (await isConnected()) {
    const qs = buildParamsString(extraParamsObj);
    window.location.href = `../Ressources/index.html?${qs}`;
    return;
  }

  const ok = await tryOfflineLaunch(newMode, extraParamsObj);
  if (!ok) {
    // overlay déjà affiché
  }
}

// -- deco = retour login
function deco() {
  localStorage.removeItem('AUTOUSER');
  window.location.assign('../HTML/Loggin.html');
}

// -- reload “autouser” (ré-ouvre le start de l’utilisateur courant)
async function reloadAutoUserIframe() {
  const autoUser = localStorage.getItem('AUTOUSER') || localStorage.getItem('rememberedUser');
  if (!autoUser) {
    deco();
    return;
  }
  const mode = localStorage.getItem(autoUser + '_uver') || "Work";
  const params = getCurrentStartParamsFromIframe();
  const i = params && params.get('i');
  const p = params && params.get('p');
  const time = nowTimeString();

  const extraParamsObj = { user: autoUser, mode, time };
  if (i) extraParamsObj.i = i;
  if (p) extraParamsObj.p = p;

  if (await isConnected()) {
    const qs = buildParamsString(extraParamsObj);
    window.location.href = `../Ressources/index.html?${qs}`;
    return;
  }

  // Retire l’iframe si présent pour un “vrai” refresh visuel
  const iframe = document.getElementById('startIframe');
  if (iframe && iframe.parentNode) iframe.parentNode.removeChild(iframe);

  const ok = await tryOfflineLaunch(mode, extraParamsObj);
  if (!ok) {
    // overlay déjà affiché
  }
}

// -- bus messages
window.addEventListener('message', async function(event) {
  const data = event.data;
  if (!data) return;

  if (data.type === 'reloadStartIframe') {
    console.log("🔄 Message reçu : reloadStartIframe");
    await reloadStartIframe();
  }

  if (data.type === 'decoParent') {
    console.log("🚪 Message reçu : decoParent");
    window.location.href = '../HTML/Loggin.html';
  }

  if (data.action === 'changeStart') {
    const { mode } = data || {};
    if (mode) {
      console.log("📥 Message reçu : changeStart ->", mode);
      await redirectToStartPage(mode);
    }
  }

  if (data.type === 'reloadParent') {
    console.log("🔄 Message reçu : reloadParent");
    window.location.reload();
  }

  if (data.type === 'deviceConflict') {
    const userChoice = confirm("Vous êtes déjà connecté sur un autre appareil !\nOK pour vous connecter ici");
    if (userChoice) {
      event.source && event.source.postMessage({ type: 'acceptConflict' }, '*');
    } else {
      event.source && event.source.postMessage({ type: 'rejectConflict' }, '*');
      deco();
    }
  }

  if (data.type === 'variHRActive') {
    deco(); // éventuellement afficher une UI spécifique
  }

  if (data.type === 'Reload') {
    console.log("🔄 Message reçu : Reload (autouser)");
    await reloadAutoUserIframe();
  }

  if (data.type === 'askForceSync') {
    const confirmForce = confirm("Vous êtes connecté sur un autre appareil.\nVoulez-vous transmettre vos données maintenant ?\n(Si oui, cela écrasera les données sur l'autre appareil.)");
    if (confirmForce) {
      window.parent.postMessage({ type: 'acceptForceSync' }, '*');
    } else {
      window.parent.postMessage({ type: 'rejectForceSync' }, '*');
    }
  }
});
