// Fonction asynchrone pour demander la date au serveur PHP
async function demanderDateFichier(nomDuFichier) {
    const urlScriptPHP = 'obtenir_date.php';

    // 1. Préparation des données à envoyer (format FormData pour POST)
    const formData = new FormData();
    formData.append('nom_fichier', nomDuFichier);

    try {
        // 2. Envoi de la requête POST
        const response = await fetch(urlScriptPHP, {
            method: 'POST',
            body: formData 
        });

        // 3. Vérification de la réponse HTTP
        if (!response.ok) {
            throw new Error(`Erreur HTTP! Statut: ${response.status}`);
        }

        // 4. Lecture et parsing de la réponse JSON
        const data = await response.json();

        // 5. Traitement de la réponse du script PHP
        if (data.succes) {
            console.log(`Le fichier "${nomDuFichier}" a été modifié le : ${data.date_modification}`);
            return data.date_modification;
        } else {
            console.error(`Erreur serveur PHP: ${data.message}`);
            return null;
        }

    } catch (error) {
        console.error('Erreur lors de la requête AJAX:', error);
        return null;
    }
}

// --- UTILISATION ---
document.addEventListener('DOMContentLoaded', () => {
    // ATTENTION : Pour tester, assurez-vous qu'un fichier avec ce nom existe
    // dans le même répertoire que obtenir_date.php !
    const nomFichierATester = 'image_149a23.png'; // Utilisons l'image mentionnée
    
    const elementAffichage = document.getElementById('resultat-date');

    demanderDateFichier(nomFichierATester)
        .then(date => {
            if (date) {
                if (elementAffichage) {
                    elementAffichage.textContent = `Date de modification de l'image : ${date}`;
                }
            } else {
                if (elementAffichage) {
                    elementAffichage.textContent = 'Impossible de récupérer la date.';
                }
            }
        });
});