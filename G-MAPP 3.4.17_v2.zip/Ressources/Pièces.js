const pieces = {
    "A": {
        "1 Colonne": {
            "A": {
                "1": {
                    "Bande verte lisse l=640 ~ A1A01 ~ 000338": {
                        "id": "201901310025",
                        "barcode": "000338",
                        "place": "A1A01",
                        "designation": "Bande verte lisse l=640"
                    }
                },
                "2": {
                    "Bande verte lisse l=1470 ~ A1A02 ~ 002484": {
                        "id": "202309290002",
                        "barcode": "002484",
                        "place": "A1A02",
                        "designation": "Bande verte lisse l=1470"
                    }
                },
                "3": {
                    "Bande verte lisse l=3680 ~ A1A03 ~ 000339": {
                        "id": "201901310026",
                        "barcode": "000339",
                        "place": "A1A03",
                        "designation": "Bande verte lisse l=3680"
                    }
                },
                "4": {
                    "Bande feutre perforée l=2850 ~ A1A04 ~ 000345": {
                        "id": "201901310032",
                        "barcode": "000345",
                        "place": "A1A04",
                        "designation": "Bande feutre perforée l=2850"
                    }
                },
                "5": {
                    "Bande feutre perforée l=3150 ~ A1A05 ~ 000346": {
                        "id": "201901310033",
                        "barcode": "000346",
                        "place": "A1A05",
                        "designation": "Bande feutre perforée l=3150"
                    }
                }
            },
            "B": {
                "1": {
                    "Bande noir granuleuse l=1570 ~ A1B01 ~ 000341": {
                        "id": "201901310028",
                        "barcode": "000341",
                        "place": "A1B01",
                        "designation": "Bande noir granuleuse l=1570"
                    }
                },
                "2": {
                    "Bande noir granuleuse l=1765 ~ A1B02 ~ 000342": {
                        "id": "201901310029",
                        "barcode": "000342",
                        "place": "A1B02",
                        "designation": "Bande noir granuleuse l=1765"
                    }
                },
                "3": {
                    "Bande noir granuleuse l=2375 ~ A1B03 ~ 000343": {
                        "id": "201901310030",
                        "barcode": "000343",
                        "place": "A1B03",
                        "designation": "Bande noir granuleuse l=2375"
                    }
                },
                "4": {
                    "Bande coupée pyra inversée rigide noir largeur 150mm l=4780 (ping ping) ~ A1B04 ~ 001836": {
                        "id": "202006150001",
                        "barcode": "001836",
                        "place": "A1B04",
                        "designation": "Bande coupée pyra inversée rigide noir largeur 150mm l=4780 (ping ping)"
                    }
                },
                "5": {
                    "Bande coupée ping pong verte largeur150mm l=6070 ~ A1B05 ~ 001782": {
                        "id": "202004020001",
                        "barcode": "001782",
                        "place": "A1B05",
                        "designation": "Bande coupée ping pong verte largeur150mm l=6070"
                    }
                }
            },
            "C": {
                "10": {
                    "Bande feutre largeur 120mm l=2365 ~ A1C10 ~ 001863": {
                        "id": "202008280001",
                        "barcode": "001863",
                        "place": "A1C10",
                        "designation": "Bande feutre largeur 120mm l=2365"
                    }
                },
                "11": {
                    "Bande feutre largeur 120mm l=2630 ~ A1C11 ~ 000364": {
                        "id": "201901310051",
                        "barcode": "000364",
                        "place": "A1C11",
                        "designation": "Bande feutre largeur 120mm l=2630"
                    }
                },
                "00": {
                    "Bande coton largeur 25mm l=3880 ~ A1C00 ~ 000356": {
                        "id": "201901310043",
                        "barcode": "000356",
                        "place": "A1C00",
                        "designation": "Bande coton largeur 25mm l=3880"
                    }
                },
                "01": {
                    "Bande coton largeur 25mm l=2840 ~ A1C01 ~ 000355": {
                        "id": "201901310042",
                        "barcode": "000355",
                        "place": "A1C01",
                        "designation": "Bande coton largeur 25mm l=2840"
                    }
                },
                "02": {
                    "Bande coton largeur 25mm l=2475 ~ A1C02 ~ 002009": {
                        "id": "202108110001",
                        "barcode": "002009",
                        "place": "A1C02",
                        "designation": "Bande coton largeur 25mm l=2475"
                    }
                },
                "03": {
                    "Bande coton largeur 25mm l=6050 ~ A1C03 ~ 000357": {
                        "id": "201901310044",
                        "barcode": "000357",
                        "place": "A1C03",
                        "designation": "Bande coton largeur 25mm l=6050"
                    }
                },
                "04": {
                    "Bande coton largeur 25mm l=6100 ~ A1C04 ~ 000358": {
                        "id": "201901310045",
                        "barcode": "000358",
                        "place": "A1C04",
                        "designation": "Bande coton largeur 25mm l=6100"
                    }
                },
                "05": {
                    "Bande blanche granuleuse larg 25 l=1510 ~ A1C05 ~ 000359": {
                        "id": "201901310046",
                        "barcode": "000359",
                        "place": "A1C05",
                        "designation": "Bande blanche granuleuse larg 25 l=1510"
                    }
                },
                "06": {
                    "Bande blanc rigide pira inversé largeur 25mm l=1510 ~ A1C06 ~ 000360": {
                        "id": "201901310047",
                        "barcode": "000360",
                        "place": "A1C06",
                        "designation": "Bande blanc rigide pira inversé largeur 25mm l=1510"
                    },
                    "Bande feutre largeur 25mm l=1510 (ne pas recommander ) ~ A1C06 ~ 002492": {
                        "id": "202310240002",
                        "barcode": "002492",
                        "place": "A1C06",
                        "designation": "Bande feutre largeur 25mm l=1510 (ne pas recommander )"
                    }
                },
                "07": {
                    "Bande blanche coton l=3960 ~ A1C07 ~ 002513": {
                        "id": "202312050003",
                        "barcode": "002513",
                        "place": "A1C07",
                        "designation": "Bande blanche coton l=3960"
                    }
                },
                "08": {
                    "Bande feutre largeur 35mm l=1745 ~ A1C08 ~ 000361": {
                        "id": "201901310048",
                        "barcode": "000361",
                        "place": "A1C08",
                        "designation": "Bande feutre largeur 35mm l=1745"
                    }
                },
                "09": {
                    "Bande feutre collée largeur 100mm l=1220 ~ A1C09 ~ 000363": {
                        "id": "201901310050",
                        "barcode": "000363",
                        "place": "A1C09",
                        "designation": "Bande feutre collée largeur 100mm l=1220"
                    },
                    "Bande feutre agraphe largeur 100mm l=1220 ~ A1C09 ~ 001845": {
                        "id": "202007200001",
                        "barcode": "001845",
                        "place": "A1C09",
                        "designation": "Bande feutre agraphe largeur 100mm l=1220"
                    }
                }
            },
            "D": {
                "10": {
                    "Bande feutre perforée l=1100 ~ A1D10 ~ 000344": {
                        "id": "201901310031",
                        "barcode": "000344",
                        "place": "A1D10",
                        "designation": "Bande feutre perforée l=1100"
                    }
                },
                "00": {
                    "Rouleau Centreur bande velcro ~ A1D00 ~ 001881": {
                        "id": "202011130006",
                        "barcode": "001881",
                        "place": "A1D00",
                        "designation": "Rouleau Centreur bande velcro"
                    }
                },
                "01": {
                    "Bande feutre l=530 ~ A1D01 ~ 002220": {
                        "id": "202204040001",
                        "barcode": "002220",
                        "place": "A1D01",
                        "designation": "Bande feutre l=530"
                    }
                },
                "02": {
                    "Bande feutre l=635 ~ A1D02 ~ 000347": {
                        "id": "201901310034",
                        "barcode": "000347",
                        "place": "A1D02",
                        "designation": "Bande feutre l=635"
                    }
                },
                "03": {
                    "Bande feutre l=705 ~ A1D03 ~ 000348": {
                        "id": "201901310035",
                        "barcode": "000348",
                        "place": "A1D03",
                        "designation": "Bande feutre l=705"
                    }
                },
                "04": {
                    "Bande feutre l=715 ~ A1D04 ~ 001819": {
                        "id": "202004140008",
                        "barcode": "001819",
                        "place": "A1D04",
                        "designation": "Bande feutre l=715"
                    }
                },
                "05": {
                    "Bande feutre l=5065 ~ A1D05 ~ 000349": {
                        "id": "201901310036",
                        "barcode": "000349",
                        "place": "A1D05",
                        "designation": "Bande feutre l=5065"
                    }
                },
                "06": {
                    "Bande feutre l=6660 ~ A1D06 ~ 000350": {
                        "id": "201901310037",
                        "barcode": "000350",
                        "place": "A1D06",
                        "designation": "Bande feutre l=6660"
                    }
                },
                "06 bis": {
                    "Bande blanche granuleuse largeur 50mm l=2380 ~ A1D06BIS ~ 001966": {
                        "id": "202105200003",
                        "barcode": "001966",
                        "place": "A1D06BIS",
                        "designation": "Bande blanche granuleuse largeur 50mm l=2380"
                    },
                    "Bande blanche caoutchoutée largeur50mm l=2380 (ne pas recommander) ~ A1D06BIS ~ 002335": {
                        "id": "202303010001",
                        "barcode": "002335",
                        "place": "A1D06BIS",
                        "designation": "Bande blanche caoutchoutée largeur50mm l=2380 (ne pas recommander)"
                    }
                },
                "07": {
                    "Bande élastique l=620 ~ A1D07 ~ 000352": {
                        "id": "201901310039",
                        "barcode": "000352",
                        "place": "A1D07",
                        "designation": "Bande élastique l=620"
                    }
                },
                "08": {
                    "Bande élastique l=640 ~ A1D08 ~ 000353": {
                        "id": "201901310040",
                        "barcode": "000353",
                        "place": "A1D08",
                        "designation": "Bande élastique l=640"
                    }
                },
                "09": {
                    "Bande élastique l=1120 ~ A1D09 ~ 000354": {
                        "id": "201901310041",
                        "barcode": "000354",
                        "place": "A1D09",
                        "designation": "Bande élastique l=1120"
                    }
                }
            },
            "E": {
                "10": {
                    "Bande coton caoutchoutée l=2020 ~ A1E10 ~ 000331": {
                        "id": "201901310018",
                        "barcode": "000331",
                        "place": "A1E10",
                        "designation": "Bande coton caoutchoutée l=2020"
                    }
                },
                "11": {
                    "Bande coton caoutchoutée l=1605 ~ A1E11 ~ 000329": {
                        "id": "201901310016",
                        "barcode": "000329",
                        "place": "A1E11",
                        "designation": "Bande coton caoutchoutée l=1605"
                    }
                },
                "12": {
                    "Bande coton caoutchoutée l=2620 ~ A1E12 ~ 001965": {
                        "id": "202105200002",
                        "barcode": "001965",
                        "place": "A1E12",
                        "designation": "Bande coton caoutchoutée l=2620"
                    }
                },
                "13": {
                    "Bande coton caoutchoutée l=2190 ~ A1E13 ~ 000332": {
                        "id": "201901310019",
                        "barcode": "000332",
                        "place": "A1E13",
                        "designation": "Bande coton caoutchoutée l=2190"
                    }
                },
                "14": {
                    "Bande coton caoutchoutée l=2700 ~ A1E14 ~ 000333": {
                        "id": "201901310020",
                        "barcode": "000333",
                        "place": "A1E14",
                        "designation": "Bande coton caoutchoutée l=2700"
                    }
                },
                "15": {
                    "Bande coton caoutchoutée l=3150 ~ A1E15 ~ 000335": {
                        "id": "201901310022",
                        "barcode": "000335",
                        "place": "A1E15",
                        "designation": "Bande coton caoutchoutée l=3150"
                    }
                },
                "16": {
                    "Bande coton caoutchoutée l=2780 ~ A1E16 ~ 000334": {
                        "id": "201901310021",
                        "barcode": "000334",
                        "place": "A1E16",
                        "designation": "Bande coton caoutchoutée l=2780"
                    }
                },
                "17": {
                    "Bande coton caoutchoutée l=5060 ~ A1E17 ~ 000336": {
                        "id": "201901310023",
                        "barcode": "000336",
                        "place": "A1E17",
                        "designation": "Bande coton caoutchoutée l=5060"
                    }
                },
                "18": {
                    "Bande coton caoutchoutée l=5725 ~ A1E18 ~ 001769": {
                        "id": "202003200001",
                        "barcode": "001769",
                        "place": "A1E18",
                        "designation": "Bande coton caoutchoutée l=5725"
                    }
                },
                "01": {
                    "Bande coton caoutchoutée l=475 ~ A1E01 ~ 000351": {
                        "id": "201901310038",
                        "barcode": "000351",
                        "place": "A1E01",
                        "designation": "Bande coton caoutchoutée l=475"
                    }
                },
                "02": {
                    "Bande coton caoutchoutée l=765 ~ A1E02 ~ 000326": {
                        "id": "201901310013",
                        "barcode": "000326",
                        "place": "A1E02",
                        "designation": "Bande coton caoutchoutée l=765"
                    }
                },
                "03": {
                    "Bande coton caoutchoutée l=680 ~ A1E03 ~ 000324": {
                        "id": "201901310011",
                        "barcode": "000324",
                        "place": "A1E03",
                        "designation": "Bande coton caoutchoutée l=680"
                    }
                },
                "04": {
                    "Bande coton caoutchoutée l=705 ~ A1E04 ~ 000325": {
                        "id": "201901310012",
                        "barcode": "000325",
                        "place": "A1E04",
                        "designation": "Bande coton caoutchoutée l=705"
                    }
                },
                "05": {
                    "Bande coton caoutchoutée l=775 ~ A1E05 ~ 001964": {
                        "id": "202105200001",
                        "barcode": "001964",
                        "place": "A1E05",
                        "designation": "Bande coton caoutchoutée l=775"
                    }
                },
                "05bis": {
                    "Bande coton caoutchoutée l=520 ~ A1E05BIS ~ 000322": {
                        "id": "201901310009",
                        "barcode": "000322",
                        "place": "A1E05BIS",
                        "designation": "Bande coton caoutchoutée l=520"
                    }
                },
                "06": {
                    "Bande coton caoutchoutée l=640 ~ A1E06 ~ 000323": {
                        "id": "201901310010",
                        "barcode": "000323",
                        "place": "A1E06",
                        "designation": "Bande coton caoutchoutée l=640"
                    }
                },
                "07": {
                    "Bande coton caoutchoutée l=1120 ~ A1E07 ~ 000327": {
                        "id": "201901310014",
                        "barcode": "000327",
                        "place": "A1E07",
                        "designation": "Bande coton caoutchoutée l=1120"
                    }
                },
                "08": {
                    "Bande coton caoutchoutée l=1580 ~ A1E08 ~ 000328": {
                        "id": "201901310015",
                        "barcode": "000328",
                        "place": "A1E08",
                        "designation": "Bande coton caoutchoutée l=1580"
                    }
                },
                "09": {
                    "Bande coton caoutchoutée l=1995 ~ A1E09 ~ 000330": {
                        "id": "201901310017",
                        "barcode": "000330",
                        "place": "A1E09",
                        "designation": "Bande coton caoutchoutée l=1995"
                    }
                }
            }
        },
        "2 Colonne": {
            "A": {
                "Tapis vert granulé MAXIMAT (bande supérieure) ~ A2A ~ 000367": {
                    "id": "201902010003",
                    "barcode": "000367",
                    "place": "A2A",
                    "designation": "Tapis vert granulé MAXIMAT (bande supérieure)"
                },
                "Tapis vert lisse entrée et sortie de la filmeuse 2940x215 ~ A2A ~ 000368": {
                    "id": "201902010004",
                    "barcode": "000368",
                    "place": "A2A",
                    "designation": "Tapis vert lisse entrée et sortie de la filmeuse 2940x215"
                },
                "Tapis blanc polyest ep2.5mm l=2365X425 maximat ~ A2A ~ 000370": {
                    "id": "201902010006",
                    "barcode": "000370",
                    "place": "A2A",
                    "designation": "Tapis blanc polyest ep2.5mm l=2365X425 maximat"
                },
                "Tapis à maille fermé (maxipress) (L=3735 / larg=1000) ~ A2A ~ 000751": {
                    "id": "201903130006",
                    "barcode": "000751",
                    "place": "A2A",
                    "designation": "Tapis à maille fermé (maxipress) (L=3735 / larg=1000)"
                },
                "Tapis navette kannegiesser neuf ~ A2A ~ 001768": {
                    "id": "202003170010",
                    "barcode": "001768",
                    "place": "A2A",
                    "designation": "Tapis navette kannegiesser neuf"
                },
                "Tapis vert lisse sous ampicker( tapis B ) ~ A2A ~ 001794": {
                    "id": "202004070004",
                    "barcode": "001794",
                    "place": "A2A",
                    "designation": "Tapis vert lisse sous ampicker( tapis B )"
                },
                "Tapis séchoir indus ~ A2A ~ 001996": {
                    "id": "202107300002",
                    "barcode": "001996",
                    "place": "A2A",
                    "designation": "Tapis séchoir indus"
                },
                "Tapis derriere alvéole 11 7480X780 ~ A2A ~ 001997": {
                    "id": "202107300003",
                    "barcode": "001997",
                    "place": "A2A",
                    "designation": "Tapis derriere alvéole 11 7480X780"
                },
                "Tapis derriere alvéole 12 1900X980 ~ A2A ~ 002332": {
                    "id": "202302230001",
                    "barcode": "002332",
                    "place": "A2A",
                    "designation": "Tapis derriere alvéole 12 1900X980"
                },
                "Tapis vert navette après séchoir industriel T5.2 5807X780 ~ A2A ~ 002501": {
                    "id": "202311160001",
                    "barcode": "002501",
                    "place": "A2A",
                    "designation": "Tapis vert navette après séchoir industriel T5.2 5807X780"
                },
                "Tapis blanc lisse entrée et sortie de la filmeuse 2940x215 avec agraphe ~ A2A ~ 002657": {
                    "id": "202503180003",
                    "barcode": "002657",
                    "place": "A2A",
                    "designation": "Tapis blanc lisse entrée et sortie de la filmeuse 2940x215 avec agraphe"
                },
                "Tapis blanc lisse entrée et sortie de la filmeuse 2940x215 sans agraphe (jonction 2 plis en digital simple ) ~ A2A ~ 002658": {
                    "id": "202503180004",
                    "barcode": "002658",
                    "place": "A2A",
                    "designation": "Tapis blanc lisse entrée et sortie de la filmeuse 2940x215 sans agraphe (jonction 2 plis en digital simple )"
                },
                "Tapis blanc lisse sortie plieuse couverture 2915x600 avec agraphe a fil plat inox G02 ~ A2A ~ 002659": {
                    "id": "202503180005",
                    "barcode": "002659",
                    "place": "A2A",
                    "designation": "Tapis blanc lisse sortie plieuse couverture 2915x600 avec agraphe a fil plat inox G02"
                }
            },
            "C": {
                "01": {
                    "Bande verte granuleuse largeur 120mm l=8600 ~ A2C01 ~ 001685": {
                        "id": "201905210001",
                        "barcode": "001685",
                        "place": "A2C01",
                        "designation": "Bande verte granuleuse largeur 120mm l=8600"
                    }
                },
                "02": {
                    "Bande de défripage GP ~ A2C02 ~ 000366": {
                        "id": "201902010002",
                        "barcode": "000366",
                        "place": "A2C02",
                        "designation": "Bande de défripage GP"
                    }
                },
                "03": {
                    "Bande de défripage PP ~ A2C03 ~ 000365": {
                        "id": "201902010001",
                        "barcode": "000365",
                        "place": "A2C03",
                        "designation": "Bande de défripage PP"
                    }
                }
            },
            "D": {
                "01": {
                    "Bande verte granuleuse l=5870 ~ A2D01 ~ 000319": {
                        "id": "201901310006",
                        "barcode": "000319",
                        "place": "A2D01",
                        "designation": "Bande verte granuleuse l=5870"
                    }
                },
                "02": {
                    "Bande verte granuleuse l=6590 ~ A2D02 ~ 001857": {
                        "id": "202008050001",
                        "barcode": "001857",
                        "place": "A2D02",
                        "designation": "Bande verte granuleuse l=6590"
                    }
                },
                "03": {
                    "Bande verte granuleuse l=7240 ~ A2D03 ~ 000320": {
                        "id": "201901310007",
                        "barcode": "000320",
                        "place": "A2D03",
                        "designation": "Bande verte granuleuse l=7240"
                    }
                },
                "04": {
                    "Bande verte granuleuse l=7400 ~ A2D04 ~ 000321": {
                        "id": "201901310008",
                        "barcode": "000321",
                        "place": "A2D04",
                        "designation": "Bande verte granuleuse l=7400"
                    }
                }
            },
            "E": {
                "01": {
                    "Bande verte granuleuse l=1830 ~ A2E01 ~ 000314": {
                        "id": "201901310001",
                        "barcode": "000314",
                        "place": "A2E01",
                        "designation": "Bande verte granuleuse l=1830"
                    }
                },
                "02": {
                    "Bande verte granuleuse l=2030 ~ A2E02 ~ 000315": {
                        "id": "201901310002",
                        "barcode": "000315",
                        "place": "A2E02",
                        "designation": "Bande verte granuleuse l=2030"
                    }
                },
                "03": {
                    "Bande verte granuleuse l=2170 ~ A2E03 ~ 000316": {
                        "id": "201901310003",
                        "barcode": "000316",
                        "place": "A2E03",
                        "designation": "Bande verte granuleuse l=2170"
                    }
                },
                "04": {
                    "Bande verte granuleuse l= 3300 ~ A2E04 ~ 000317": {
                        "id": "201901310004",
                        "barcode": "000317",
                        "place": "A2E04",
                        "designation": "Bande verte granuleuse l= 3300"
                    }
                },
                "05": {
                    "Bande verte granuleuse l=3340 ~ A2E05 ~ 001969": {
                        "id": "202105210001",
                        "barcode": "001969",
                        "place": "A2E05",
                        "designation": "Bande verte granuleuse l=3340"
                    }
                },
                "06": {
                    "Bande verte granuleuse l=3630 ~ A2E06 ~ 000318": {
                        "id": "201901310005",
                        "barcode": "000318",
                        "place": "A2E06",
                        "designation": "Bande verte granuleuse l=3630"
                    }
                },
                "07": {
                    "Bande verte granuleuse l=5550 ~ A2E07 ~ 001783": {
                        "id": "202004020002",
                        "barcode": "001783",
                        "place": "A2E07",
                        "designation": "Bande verte granuleuse l=5550"
                    }
                },
                "08": {
                    "Centreur bande ~ A2E08 ~ 001805": {
                        "id": "202004090001",
                        "barcode": "001805",
                        "place": "A2E08",
                        "designation": "Centreur bande"
                    }
                }
            }
        },
        "3 Colonne": {
            "A": {
                "01": {
                    "Bande coton l=6200 ~ A3A01 ~ 000309": {
                        "id": "201901300028",
                        "barcode": "000309",
                        "place": "A3A01",
                        "designation": "Bande coton l=6200"
                    }
                },
                "02": {
                    "Bande coton l=6250 ~ A3A02 ~ 000310": {
                        "id": "201901300029",
                        "barcode": "000310",
                        "place": "A3A02",
                        "designation": "Bande coton l=6250"
                    },
                    "Bande coton largeur 25mm l=6250 ~ A3A02 ~ 002520": {
                        "id": "202312280002",
                        "barcode": "002520",
                        "place": "A3A02",
                        "designation": "Bande coton largeur 25mm l=6250"
                    }
                },
                "04": {
                    "Bande coton l=8350 ~ A3A04 ~ 000312": {
                        "id": "201901300031",
                        "barcode": "000312",
                        "place": "A3A04",
                        "designation": "Bande coton l=8350"
                    }
                },
                "05": {
                    "Bande coton l=10745 ~ A3A05 ~ 000313": {
                        "id": "201901300032",
                        "barcode": "000313",
                        "place": "A3A05",
                        "designation": "Bande coton l=10745"
                    }
                }
            },
            "B": {
                "01": {
                    "Bande coton l=3750 ~ A3B01 ~ 000302": {
                        "id": "201901300021",
                        "barcode": "000302",
                        "place": "A3B01",
                        "designation": "Bande coton l=3750"
                    }
                },
                "02": {
                    "Bande coton l=3820 ~ A3B02 ~ 000303": {
                        "id": "201901300022",
                        "barcode": "000303",
                        "place": "A3B02",
                        "designation": "Bande coton l=3820"
                    }
                },
                "03": {
                    "Bande coton l=4010 ~ A3B03 ~ 000304": {
                        "id": "201901300023",
                        "barcode": "000304",
                        "place": "A3B03",
                        "designation": "Bande coton l=4010"
                    }
                },
                "04": {
                    "Bande coton l=4490 ~ A3B04 ~ 000305": {
                        "id": "201901300024",
                        "barcode": "000305",
                        "place": "A3B04",
                        "designation": "Bande coton l=4490"
                    }
                },
                "05": {
                    "Bande coton l=5500 ~ A3B05 ~ 000306": {
                        "id": "201901300025",
                        "barcode": "000306",
                        "place": "A3B05",
                        "designation": "Bande coton l=5500"
                    },
                    "Bande coton largeur 25mm l=5500 ~ A3B05 ~ 002545": {
                        "id": "202402060001",
                        "barcode": "002545",
                        "place": "A3B05",
                        "designation": "Bande coton largeur 25mm l=5500"
                    }
                },
                "07": {
                    "Bande coton l=5800 ~ A3B07 ~ 000107": {
                        "id": "201801250066",
                        "barcode": "000107",
                        "place": "A3B07",
                        "designation": "Bande coton l=5800"
                    },
                    "Bande coton caoutchoutée l=5800 (2 sur convoyeur de sortie) ~ A3B07 ~ 002582": {
                        "id": "202405310001",
                        "barcode": "002582",
                        "place": "A3B07",
                        "designation": "Bande coton caoutchoutée l=5800 (2 sur convoyeur de sortie)"
                    }
                },
                "08": {
                    "Bande coton l=6100 ~ A3B08 ~ 000308": {
                        "id": "201901300027",
                        "barcode": "000308",
                        "place": "A3B08",
                        "designation": "Bande coton l=6100"
                    }
                }
            },
            "C": {
                "01": {
                    "Bande coton l=2840 ~ A3C01 ~ 000295": {
                        "id": "201901300014",
                        "barcode": "000295",
                        "place": "A3C01",
                        "designation": "Bande coton l=2840"
                    }
                },
                "02": {
                    "Bande coton l=2900 ~ A3C02 ~ 000296": {
                        "id": "201901300015",
                        "barcode": "000296",
                        "place": "A3C02",
                        "designation": "Bande coton l=2900"
                    }
                },
                "03": {
                    "Bande coton l=3240 ~ A3C03 ~ 000297": {
                        "id": "201901300016",
                        "barcode": "000297",
                        "place": "A3C03",
                        "designation": "Bande coton l=3240"
                    }
                },
                "04": {
                    "Bande coton l=3360 ~ A3C04 ~ 000299": {
                        "id": "201901300018",
                        "barcode": "000299",
                        "place": "A3C04",
                        "designation": "Bande coton l=3360"
                    }
                },
                "05": {
                    "Bande coton largeur 25mm l=3490 ~ A3C05 ~ 000298": {
                        "id": "201901300017",
                        "barcode": "000298",
                        "place": "A3C05",
                        "designation": "Bande coton largeur 25mm l=3490"
                    },
                    "Bande coton caoutchoutée l=3490 ~ A3C05 ~ 002275": {
                        "id": "202210170001",
                        "barcode": "002275",
                        "place": "A3C05",
                        "designation": "Bande coton caoutchoutée l=3490"
                    },
                    "Bande coton l=3490 ~ A3C05 ~ 002490": {
                        "id": "202310040001",
                        "barcode": "002490",
                        "place": "A3C05",
                        "designation": "Bande coton l=3490"
                    }
                },
                "06": {
                    "Bande coton l=3600 roll on ~ A3C06 ~ 000300": {
                        "id": "201901300019",
                        "barcode": "000300",
                        "place": "A3C06",
                        "designation": "Bande coton l=3600 roll on"
                    }
                },
                "07": {
                    "Bande coton l=3630 ~ A3C07 ~ 000301": {
                        "id": "201901300020",
                        "barcode": "000301",
                        "place": "A3C07",
                        "designation": "Bande coton l=3630"
                    }
                }
            },
            "D": {
                "01": {
                    "Bande coton l=2215 ~ A3D01 ~ 000291": {
                        "id": "201901300010",
                        "barcode": "000291",
                        "place": "A3D01",
                        "designation": "Bande coton l=2215"
                    }
                },
                "02": {
                    "Bande coton l=2475 ~ A3D02 ~ 000292": {
                        "id": "201901300011",
                        "barcode": "000292",
                        "place": "A3D02",
                        "designation": "Bande coton l=2475"
                    }
                },
                "03": {
                    "Bande coton l=2780 ~ A3D03 ~ 000294": {
                        "id": "201901300013",
                        "barcode": "000294",
                        "place": "A3D03",
                        "designation": "Bande coton l=2780"
                    }
                },
                "04": {
                    "Bande coton l=2495 ~ A3D04 ~ 002519": {
                        "id": "202312280001",
                        "barcode": "002519",
                        "place": "A3D04",
                        "designation": "Bande coton l=2495"
                    }
                }
            },
            "E": {
                "10": {
                    "Bande coton l=960 ~ A3E10 ~ 000286": {
                        "id": "201901300005",
                        "barcode": "000286",
                        "place": "A3E10",
                        "designation": "Bande coton l=960"
                    }
                },
                "11": {
                    "Bande coton l=1610 ~ A3E11 ~ 000287": {
                        "id": "201901300006",
                        "barcode": "000287",
                        "place": "A3E11",
                        "designation": "Bande coton l=1610"
                    }
                },
                "12": {
                    "Bande coton l=1950 ~ A3E12 ~ 000288": {
                        "id": "201901300007",
                        "barcode": "000288",
                        "place": "A3E12",
                        "designation": "Bande coton l=1950"
                    }
                },
                "13": {
                    "Bande coton l=1985 ~ A3E13 ~ 000289": {
                        "id": "201901300008",
                        "barcode": "000289",
                        "place": "A3E13",
                        "designation": "Bande coton l=1985"
                    }
                },
                "15": {
                    "Bande coton l=2050 ~ A3E15 ~ 001971": {
                        "id": "202105310002",
                        "barcode": "001971",
                        "place": "A3E15",
                        "designation": "Bande coton l=2050"
                    }
                },
                "01": {
                    "Bande coton l=515 ~ A3E01 ~ 001818": {
                        "id": "202004140007",
                        "barcode": "001818",
                        "place": "A3E01",
                        "designation": "Bande coton l=515"
                    }
                },
                "02": {
                    "Bande coton l=625 ~ A3E02 ~ 001774": {
                        "id": "202003300001",
                        "barcode": "001774",
                        "place": "A3E02",
                        "designation": "Bande coton l=625"
                    }
                },
                "03": {
                    "Bande coton l=640 ~ A3E03 ~ 000282": {
                        "id": "201901300001",
                        "barcode": "000282",
                        "place": "A3E03",
                        "designation": "Bande coton l=640"
                    }
                },
                "04": {
                    "Bande coton l=655 ~ A3E04 ~ 001775": {
                        "id": "202003300002",
                        "barcode": "001775",
                        "place": "A3E04",
                        "designation": "Bande coton l=655"
                    }
                },
                "05": {
                    "Bande coton l=680 ~ A3E05 ~ 000283": {
                        "id": "201901300002",
                        "barcode": "000283",
                        "place": "A3E05",
                        "designation": "Bande coton l=680"
                    }
                },
                "06": {
                    "Bande coton l=705 ~ A3E06 ~ 001822": {
                        "id": "202004150002",
                        "barcode": "001822",
                        "place": "A3E06",
                        "designation": "Bande coton l=705"
                    }
                },
                "07": {
                    "Bande coton l=710 ~ A3E07 ~ 001970": {
                        "id": "202105310001",
                        "barcode": "001970",
                        "place": "A3E07",
                        "designation": "Bande coton l=710"
                    }
                },
                "08": {
                    "Bande coton l=730 ~ A3E08 ~ 000284": {
                        "id": "201901300003",
                        "barcode": "000284",
                        "place": "A3E08",
                        "designation": "Bande coton l=730"
                    }
                },
                "09": {
                    "Bande coton l=860 ~ A3E09 ~ 000285": {
                        "id": "201901300004",
                        "barcode": "000285",
                        "place": "A3E09",
                        "designation": "Bande coton l=860"
                    }
                }
            },
            "F": {
                "Rouleau de bande coton de largeur 50mm ~ A3F ~ 000311": {
                    "id": "201901300030",
                    "barcode": "000311",
                    "place": "A3F",
                    "designation": "Rouleau de bande coton de largeur 50mm"
                },
                "Tapis vert navette Kanne occasion ~ A3F ~ 002248": {
                    "id": "202209090001",
                    "barcode": "002248",
                    "place": "A3F",
                    "designation": "Tapis vert navette Kanne occasion"
                },
                "Aimant en bande pour navette EHF sortie tunnel lavatec ~ A3F ~ 002605": {
                    "id": "202409040002",
                    "barcode": "002605",
                    "place": "A3F",
                    "designation": "Aimant en bande pour navette EHF sortie tunnel lavatec"
                },
                "Tapis vert en dessous des pinces ampicker (lisse voir si besoin avec raynure ) ~ A3F ~ 002615": {
                    "id": "202410150002",
                    "barcode": "002615",
                    "place": "A3F",
                    "designation": "Tapis vert en dessous des pinces ampicker (lisse voir si besoin avec raynure )"
                }
            }
        }
    },
    "Rangée B": {
        "1 Colonne": {
            "A": {
                "01": {
                    "Buse Orifice Jet Plat Laiton ~ B1A01 ~ 000758": {
                        "id": "201903130013",
                        "barcode": "000758",
                        "place": "B1A01",
                        "designation": "Buse Orifice Jet Plat Laiton"
                    },
                    "Buse Orifice Jet Plat Laiton ~ B1A01 ~ 000759": {
                        "id": "201903130014",
                        "barcode": "000759",
                        "place": "B1A01",
                        "designation": "Buse Orifice Jet Plat Laiton"
                    },
                    "Union nu écrou de buses ~ B1A01 ~ 000760": {
                        "id": "201903130015",
                        "barcode": "000760",
                        "place": "B1A01",
                        "designation": "Union nu écrou de buses"
                    }
                },
                "02": {
                    "Accouplement limiteur de couple ~ B1A02 ~ 000763": {
                        "id": "201903130018",
                        "barcode": "000763",
                        "place": "B1A02",
                        "designation": "Accouplement limiteur de couple"
                    }
                },
                "03": {
                    "Pistolet et buses de desinfection ~ B1A03 ~ 002621": {
                        "id": "202411150001",
                        "barcode": "002621",
                        "place": "B1A03",
                        "designation": "Pistolet et buses de desinfection"
                    }
                },
                "04": {
                    "Sonde t° thermocouple thermocolleuse ~ B1A04 ~ 000764": {
                        "id": "201903130019",
                        "barcode": "000764",
                        "place": "B1A04",
                        "designation": "Sonde t° thermocouple thermocolleuse"
                    },
                    "Sonde de température PRESSE DUPLEX AUTO MINI PLA ~ B1A04 ~ 000765": {
                        "id": "201903130020",
                        "barcode": "000765",
                        "place": "B1A04",
                        "designation": "Sonde de température PRESSE DUPLEX AUTO MINI PLA"
                    },
                    "Pressostat thermocolleuse Mammouth ~ B1A04 ~ 002665": {
                        "id": "202503240003",
                        "barcode": "002665",
                        "place": "B1A04",
                        "designation": "Pressostat thermocolleuse Mammouth"
                    },
                    "Sonde t° thermocouple thermocolleuse NL15R/fox new ~ B1A04 ~ 002744": {
                        "id": "202601190001",
                        "barcode": "002744",
                        "place": "B1A04",
                        "designation": "Sonde t° thermocouple thermocolleuse NL15R/fox new"
                    }
                },
                "05": {
                    "Plateau inférieur thermocolleuse PL4 ~ B1A05 ~ 000766": {
                        "id": "201903130021",
                        "barcode": "000766",
                        "place": "B1A05",
                        "designation": "Plateau inférieur thermocolleuse PL4"
                    },
                    "Petit plateau inférieur thermocolleuse ~ B1A05 ~ 000767": {
                        "id": "201903130022",
                        "barcode": "000767",
                        "place": "B1A05",
                        "designation": "Petit plateau inférieur thermocolleuse"
                    }
                },
                "06": {
                    "Colle silicone pour mousse ~ B1A06 ~ 000768": {
                        "id": "201903130023",
                        "barcode": "000768",
                        "place": "B1A06",
                        "designation": "Colle silicone pour mousse"
                    }
                },
                "06 Bis": {
                    "Filtre charbon table a détacher ~ B1A06BIS ~ 002209": {
                        "id": "202203110002",
                        "barcode": "002209",
                        "place": "B1A06BIS",
                        "designation": "Filtre charbon table a détacher"
                    }
                },
                "07": {
                    "Sandows Elastique bleu diam 8 mm 8ml rappel de porte automatique ~ B1A07 ~ 000770": {
                        "id": "201903130025",
                        "barcode": "000770",
                        "place": "B1A07",
                        "designation": "Sandows Elastique bleu diam 8 mm 8ml rappel de porte automatique"
                    },
                    "Guide inférieur de porte automatique Ditec recollé ( occasion ) ~ B1A07 ~ 000772": {
                        "id": "201903130027",
                        "barcode": "000772",
                        "place": "B1A07",
                        "designation": "Guide inférieur de porte automatique Ditec recollé ( occasion )"
                    }
                },
                "08": {
                    "Mecanisme ouverture porte ascenseur de l'entrée ~ B1A08 ~ 000771": {
                        "id": "201903130026",
                        "barcode": "000771",
                        "place": "B1A08",
                        "designation": "Mecanisme ouverture porte ascenseur de l'entrée"
                    }
                }
            },
            "B": {
                "01": {
                    "Flexible vapeur grosse machine a laver embout male 1-1/4 l:1000mm ~ B1B01 ~ 002196": {
                        "id": "202203010001",
                        "barcode": "002196",
                        "place": "B1B01",
                        "designation": "Flexible vapeur grosse machine a laver embout male 1-1/4 l:1000mm"
                    }
                },
                "02": {
                    "Coude union 3 pieces M/F 3/4 gaz INOX ~ B1B02 ~ 002240": {
                        "id": "202208030001",
                        "barcode": "002240",
                        "place": "B1B02",
                        "designation": "Coude union 3 pieces M/F 3/4 gaz INOX"
                    },
                    "Raccord union M/F 3/4 INOX ~ B1B02 ~ 002241": {
                        "id": "202208030002",
                        "barcode": "002241",
                        "place": "B1B02",
                        "designation": "Raccord union M/F 3/4 INOX"
                    },
                    "Crochet d'indexation chargement M a Laver 25kg ~ B1B02 ~ 002538": {
                        "id": "202401050004",
                        "barcode": "002538",
                        "place": "B1B02",
                        "designation": "Crochet d'indexation chargement M a Laver 25kg"
                    },
                    "Joint torique diametre 3 ~ B1B02 ~ 002633": {
                        "id": "202501130001",
                        "barcode": "002633",
                        "place": "B1B02",
                        "designation": "Joint torique diametre 3"
                    },
                    "Joint torique viton ~ B1B02 ~ 002634": {
                        "id": "202501130002",
                        "barcode": "002634",
                        "place": "B1B02",
                        "designation": "Joint torique viton"
                    },
                    "Bague d'étanchéité R:BEL CP 50*65*8 ~ B1B02 ~ 002635": {
                        "id": "202501130003",
                        "barcode": "002635",
                        "place": "B1B02",
                        "designation": "Bague d'étanchéité R:BEL CP 50*65*8"
                    },
                    "Roulement a galet ~ B1B02 ~ 002636": {
                        "id": "202501130004",
                        "barcode": "002636",
                        "place": "B1B02",
                        "designation": "Roulement a galet"
                    }
                },
                "03": {
                    "Flexible caoutchouc de vidange ~ B1B03 ~ 001739": {
                        "id": "202002050003",
                        "barcode": "001739",
                        "place": "B1B03",
                        "designation": "Flexible caoutchouc de vidange"
                    },
                    "Ressort porte du bas côté chargement laveuse 35 kg ~ B1B03 ~ 001740": {
                        "id": "202002050004",
                        "barcode": "001740",
                        "place": "B1B03",
                        "designation": "Ressort porte du bas côté chargement laveuse 35 kg"
                    },
                    "Ressort droit porte du bas côté chargement laveuse 35 kg ~ B1B03 ~ 001741": {
                        "id": "202002050005",
                        "barcode": "001741",
                        "place": "B1B03",
                        "designation": "Ressort droit porte du bas côté chargement laveuse 35 kg"
                    },
                    "Ressort droit porte du bas côté chargement laveuse 25 kg ~ B1B03 ~ 001828": {
                        "id": "202005070001",
                        "barcode": "001828",
                        "place": "B1B03",
                        "designation": "Ressort droit porte du bas côté chargement laveuse 25 kg"
                    },
                    "Moteur de vidange laveuse 25 kg ~ B1B03 ~ 001829": {
                        "id": "202005070002",
                        "barcode": "001829",
                        "place": "B1B03",
                        "designation": "Moteur de vidange laveuse 25 kg"
                    },
                    "Flexible vapeur petite machine a laver 3/4 l:650mm ~ B1B03 ~ 002172": {
                        "id": "202112070001",
                        "barcode": "002172",
                        "place": "B1B03",
                        "designation": "Flexible vapeur petite machine a laver 3/4 l:650mm"
                    },
                    "Laveuse 35 kg Ressort rappel butée porte ~ B1B03 ~ 002494": {
                        "id": "202310300001",
                        "barcode": "002494",
                        "place": "B1B03",
                        "designation": "Laveuse 35 kg Ressort rappel butée porte"
                    },
                    "Laveuse Ressort gaz 800N ~ B1B03 ~ 002495": {
                        "id": "202310300002",
                        "barcode": "002495",
                        "place": "B1B03",
                        "designation": "Laveuse Ressort gaz 800N"
                    },
                    "Laveuse Ressort de rappel butée de porte ~ B1B03 ~ 002496": {
                        "id": "202311060001",
                        "barcode": "002496",
                        "place": "B1B03",
                        "designation": "Laveuse Ressort de rappel butée de porte"
                    },
                    "Joint silicone de porte ~ B1B03 ~ 002537": {
                        "id": "202401050003",
                        "barcode": "002537",
                        "place": "B1B03",
                        "designation": "Joint silicone de porte"
                    }
                },
                "04": {
                    "Soufflets tuyaux ~ B1B04 ~ 002467": {
                        "id": "202308240007",
                        "barcode": "002467",
                        "place": "B1B04",
                        "designation": "Soufflets tuyaux"
                    }
                },
                "05": {
                    "Cable métallique ~ B1B05 ~ 002250": {
                        "id": "202209130001",
                        "barcode": "002250",
                        "place": "B1B05",
                        "designation": "Cable métallique"
                    },
                    "Joint feutre de porte (1/4) ~ B1B05 ~ 002251": {
                        "id": "202209130002",
                        "barcode": "002251",
                        "place": "B1B05",
                        "designation": "Joint feutre de porte (1/4)"
                    },
                    "Electrode d 'allumage ~ B1B05 ~ 002407": {
                        "id": "202307260003",
                        "barcode": "002407",
                        "place": "B1B05",
                        "designation": "Electrode d 'allumage"
                    },
                    "Cable d'allumage ~ B1B05 ~ 002408": {
                        "id": "202307260004",
                        "barcode": "002408",
                        "place": "B1B05",
                        "designation": "Cable d'allumage"
                    },
                    "Sonde de ionisation ~ B1B05 ~ 002409": {
                        "id": "202307260005",
                        "barcode": "002409",
                        "place": "B1B05",
                        "designation": "Sonde de ionisation"
                    },
                    "Cable d'allumage pour sonde ~ B1B05 ~ 002410": {
                        "id": "202307260006",
                        "barcode": "002410",
                        "place": "B1B05",
                        "designation": "Cable d'allumage pour sonde"
                    },
                    "Sécurité de porte (disjoncteur magnétique ) ~ B1B05 ~ 002483": {
                        "id": "202309290001",
                        "barcode": "002483",
                        "place": "B1B05",
                        "designation": "Sécurité de porte (disjoncteur magnétique )"
                    }
                },
                "06": {
                    "Barre de sécurité de tambour machine a laver ~ B1B06 ~ 002539": {
                        "id": "202401050005",
                        "barcode": "002539",
                        "place": "B1B06",
                        "designation": "Barre de sécurité de tambour machine a laver"
                    }
                },
                "07": {
                    "Sonde 50KO 8M d5mm pour groupe froid ~ B1B07 ~ 002244": {
                        "id": "202208040003",
                        "barcode": "002244",
                        "place": "B1B07",
                        "designation": "Sonde 50KO 8M d5mm pour groupe froid"
                    },
                    "Contact pour fluide groupe froid ~ B1B07 ~ 002469": {
                        "id": "202308240009",
                        "barcode": "002469",
                        "place": "B1B07",
                        "designation": "Contact pour fluide groupe froid"
                    },
                    "Kit groupe froid gleitringdichtung ~ B1B07 ~ 002470": {
                        "id": "202308240010",
                        "barcode": "002470",
                        "place": "B1B07",
                        "designation": "Kit groupe froid gleitringdichtung"
                    }
                },
                "08": {
                    "Carte electronique connect 2 fr-uk-d-es groupe froid gleitringdichtung ~ B1B08 ~ 002325": {
                        "id": "202301200006",
                        "barcode": "002325",
                        "place": "B1B08",
                        "designation": "Carte electronique connect 2 fr-uk-d-es groupe froid gleitringdichtung"
                    }
                }
            },
            "C": {
                "10": {
                    "Vérin à gaz ~ B1C10 ~ 000756": {
                        "id": "201903130011",
                        "barcode": "000756",
                        "place": "B1C10",
                        "designation": "Vérin à gaz"
                    }
                },
                "11": {
                    "Roulette guide plieuse éponge ~ B1C11 ~ 000757": {
                        "id": "201903130012",
                        "barcode": "000757",
                        "place": "B1C11",
                        "designation": "Roulette guide plieuse éponge"
                    }
                },
                "12": {
                    "Tuyau diamètre 4 spiralé ~ B1C12 ~ 002699": {
                        "id": "202510010005",
                        "barcode": "002699",
                        "place": "B1C12",
                        "designation": "Tuyau diamètre 4 spiralé"
                    }
                },
                "01": {
                    "Guide chaine L=176.5 ~ B1C01 ~ 000518": {
                        "id": "201903060033",
                        "barcode": "000518",
                        "place": "B1C01",
                        "designation": "Guide chaine L=176.5"
                    },
                    "Guide vert l=210mm pour chaine L=176.5 ~ B1C01 ~ 002365": {
                        "id": "202305040001",
                        "barcode": "002365",
                        "place": "B1C01",
                        "designation": "Guide vert l=210mm pour chaine L=176.5"
                    }
                },
                "02": {
                    "Guide chaine L=350 ~ B1C02 ~ 000519": {
                        "id": "201903060034",
                        "barcode": "000519",
                        "place": "B1C02",
                        "designation": "Guide chaine L=350"
                    }
                },
                "03": {
                    "Guide chariot par chaine ~ B1C03 ~ 001711": {
                        "id": "201910010005",
                        "barcode": "001711",
                        "place": "B1C03",
                        "designation": "Guide chariot par chaine"
                    },
                    "Rouleau chaine 1/2\" L=1079 ~ B1C03 ~ 001891": {
                        "id": "202012180002",
                        "barcode": "001891",
                        "place": "B1C03",
                        "designation": "Rouleau chaine 1/2\" L=1079"
                    }
                },
                "04": {
                    "ROULEAU du milieu a etage d=49/35mm L=0485mm ~ B1C04 ~ 002267": {
                        "id": "202209190002",
                        "barcode": "002267",
                        "place": "B1C04",
                        "designation": "ROULEAU du milieu a etage d=49/35mm L=0485mm"
                    }
                },
                "05": {
                    "Support empileur maximat occasion ~ B1C05 ~ 000516": {
                        "id": "201903060031",
                        "barcode": "000516",
                        "place": "B1C05",
                        "designation": "Support empileur maximat occasion"
                    }
                },
                "06": {
                    "Chariot maximat type lobster occasion ~ B1C06 ~ 000515": {
                        "id": "201903060030",
                        "barcode": "000515",
                        "place": "B1C06",
                        "designation": "Chariot maximat type lobster occasion"
                    }
                },
                "07": {
                    "Guide vert 3/4X5/16\"\" WER \"\"S\"\" ~ B1C07 ~ 000517": {
                        "id": "201903060032",
                        "barcode": "000517",
                        "place": "B1C07",
                        "designation": "Guide vert 3/4X5/16\"\" WER \"\"S\"\""
                    }
                }
            },
            "D": {
                "10": {
                    "Galet tendeur D=40mm L=45 ~ B1D10 ~ 000529": {
                        "id": "201903060044",
                        "barcode": "000529",
                        "place": "B1D10",
                        "designation": "Galet tendeur D=40mm L=45"
                    }
                },
                "11": {
                    "Palier D=45/11 ~ B1D11 ~ 000530": {
                        "id": "201903060045",
                        "barcode": "000530",
                        "place": "B1D11",
                        "designation": "Palier D=45/11"
                    }
                },
                "12": {
                    "Plaque demi lune ~ B1D12 ~ 000531": {
                        "id": "201903060046",
                        "barcode": "000531",
                        "place": "B1D12",
                        "designation": "Plaque demi lune"
                    }
                },
                "13": {
                    "Disque de friction ~ B1D13 ~ 000532": {
                        "id": "201903060047",
                        "barcode": "000532",
                        "place": "B1D13",
                        "designation": "Disque de friction"
                    }
                },
                "14": {
                    "Axe ~ B1D14 ~ 000533": {
                        "id": "201903060048",
                        "barcode": "000533",
                        "place": "B1D14",
                        "designation": "Axe"
                    }
                },
                "15": {
                    "BEARINGEND S,U,SXA L=90 ~ B1D15 ~ 000534": {
                        "id": "201903060049",
                        "barcode": "000534",
                        "place": "B1D15",
                        "designation": "BEARINGEND S,U,SXA L=90"
                    }
                },
                "16": {
                    "Guide ~ B1D16 ~ 000176": {
                        "id": "201901140011",
                        "barcode": "000176",
                        "place": "B1D16",
                        "designation": "Guide"
                    }
                },
                "17": {
                    "Guide pour N-2-004-2 ~ B1D17 ~ 000535": {
                        "id": "201903060050",
                        "barcode": "000535",
                        "place": "B1D17",
                        "designation": "Guide pour N-2-004-2"
                    }
                },
                "18": {
                    "Bras ARM DIA:4-5 ~ B1D18 ~ 000536": {
                        "id": "201903060051",
                        "barcode": "000536",
                        "place": "B1D18",
                        "designation": "Bras ARM DIA:4-5"
                    }
                },
                "19": {
                    "Plaque teflon ~ B1D19 ~ 000537": {
                        "id": "201903060052",
                        "barcode": "000537",
                        "place": "B1D19",
                        "designation": "Plaque teflon"
                    }
                },
                "20": {
                    "Ouvreur ~ B1D20 ~ 000538": {
                        "id": "201903060053",
                        "barcode": "000538",
                        "place": "B1D20",
                        "designation": "Ouvreur"
                    }
                },
                "21": {
                    "Plaque complete ~ B1D21 ~ 000541": {
                        "id": "201903060056",
                        "barcode": "000541",
                        "place": "B1D21",
                        "designation": "Plaque complete"
                    },
                    "PIECE DE LIAISON ~ B1D21 ~ 000542": {
                        "id": "201903060057",
                        "barcode": "000542",
                        "place": "B1D21",
                        "designation": "PIECE DE LIAISON"
                    }
                },
                "22": {
                    "Rondelle MAXIMAT D=30mm L=15.5mm ~ B1D22 ~ 000178": {
                        "id": "201901140013",
                        "barcode": "000178",
                        "place": "B1D22",
                        "designation": "Rondelle MAXIMAT D=30mm L=15.5mm"
                    }
                },
                "23": {
                    "Raccord de courroie ~ B1D23 ~ 000539": {
                        "id": "201903060054",
                        "barcode": "000539",
                        "place": "B1D23",
                        "designation": "Raccord de courroie"
                    },
                    "RESSORT D=10/1,4x47mm ~ B1D23 ~ 000540": {
                        "id": "201903060055",
                        "barcode": "000540",
                        "place": "B1D23",
                        "designation": "RESSORT D=10/1,4x47mm"
                    }
                },
                "24": {
                    "Guide ~ B1D24 ~ 000177": {
                        "id": "201901140012",
                        "barcode": "000177",
                        "place": "B1D24",
                        "designation": "Guide"
                    }
                },
                "25": {
                    "Ressort de tension ~ B1D25 ~ 000543": {
                        "id": "201903060058",
                        "barcode": "000543",
                        "place": "B1D25",
                        "designation": "Ressort de tension"
                    }
                },
                "26": {
                    "Marteau ~ B1D26 ~ 000544": {
                        "id": "201903060059",
                        "barcode": "000544",
                        "place": "B1D26",
                        "designation": "Marteau"
                    }
                },
                "27": {
                    "Levier maintien cintre attention !! nouvelle pièce (repère 11 doc) ~ B1D27 ~ 001668": {
                        "id": "201905110001",
                        "barcode": "001668",
                        "place": "B1D27",
                        "designation": "Levier maintien cintre attention !! nouvelle pièce (repère 11 doc)"
                    }
                },
                "28": {
                    "Poulie ALU PULLEY Ø45MM / Ø24MM ~ B1D28 ~ 001893": {
                        "id": "202012290001",
                        "barcode": "001893",
                        "place": "B1D28",
                        "designation": "Poulie ALU PULLEY Ø45MM / Ø24MM"
                    }
                },
                "29": {
                    "Poulie ALU PULLEY Ø43MM / Ø24MM ~ B1D29 ~ 001898": {
                        "id": "202012310001",
                        "barcode": "001898",
                        "place": "B1D29",
                        "designation": "Poulie ALU PULLEY Ø43MM / Ø24MM"
                    }
                },
                "30": {
                    "Pince ~ B1D30 ~ 001750": {
                        "id": "202002260005",
                        "barcode": "001750",
                        "place": "B1D30",
                        "designation": "Pince"
                    }
                },
                "31": {
                    "GUIDING TUBE L=117mm = 40762021 ~ B1D31 ~ 001894": {
                        "id": "202012290002",
                        "barcode": "001894",
                        "place": "B1D31",
                        "designation": "GUIDING TUBE L=117mm = 40762021"
                    },
                    "Douille a bille LBBS 20-2LS ~ B1D31 ~ 001895": {
                        "id": "202012290003",
                        "barcode": "001895",
                        "place": "B1D31",
                        "designation": "Douille a bille LBBS 20-2LS"
                    },
                    "Joints spi LS 20-28.4 ~ B1D31 ~ 001896": {
                        "id": "202012290004",
                        "barcode": "001896",
                        "place": "B1D31",
                        "designation": "Joints spi LS 20-28.4"
                    }
                },
                "32": {
                    "Arbre pour strocket ~ B1D32 ~ 001897": {
                        "id": "202012290005",
                        "barcode": "001897",
                        "place": "B1D32",
                        "designation": "Arbre pour strocket"
                    }
                },
                "33": {
                    "Guide préséparateur ~ B1D33 ~ 000616": {
                        "id": "201903080001",
                        "barcode": "000616",
                        "place": "B1D33",
                        "designation": "Guide préséparateur"
                    }
                },
                "34": {
                    "Support cintre attention nouvelle pièce!!!!(repère 7 doc) ~ B1D34 ~ 001920": {
                        "id": "202102100001",
                        "barcode": "001920",
                        "place": "B1D34",
                        "designation": "Support cintre attention nouvelle pièce!!!!(repère 7 doc)"
                    }
                },
                "35": {
                    "Guide ~ B1D35 ~ 000545": {
                        "id": "201903060060",
                        "barcode": "000545",
                        "place": "B1D35",
                        "designation": "Guide"
                    }
                },
                "01": {
                    "Étrier ( HANDLE WEDGE ) (Cintre Angle Rouge) ~ B1D01 ~ 000521": {
                        "id": "201903060036",
                        "barcode": "000521",
                        "place": "B1D01",
                        "designation": "Étrier ( HANDLE WEDGE ) (Cintre Angle Rouge)"
                    }
                },
                "02": {
                    "Tendeur ~ B1D02 ~ 000520": {
                        "id": "201903060035",
                        "barcode": "000520",
                        "place": "B1D02",
                        "designation": "Tendeur"
                    }
                },
                "03": {
                    "Sangle orange l=25mm L=1120mm ~ B1D03 ~ 000522": {
                        "id": "201903060037",
                        "barcode": "000522",
                        "place": "B1D03",
                        "designation": "Sangle orange l=25mm L=1120mm"
                    }
                },
                "04": {
                    "Poulie moteur D=70 H=45 AL=14 ~ B1D04 ~ 000523": {
                        "id": "201903060038",
                        "barcode": "000523",
                        "place": "B1D04",
                        "designation": "Poulie moteur D=70 H=45 AL=14"
                    }
                },
                "05": {
                    "Chariot a billes ~ B1D05 ~ 000524": {
                        "id": "201903060039",
                        "barcode": "000524",
                        "place": "B1D05",
                        "designation": "Chariot a billes"
                    }
                },
                "06": {
                    "Chaine clips duplex 5/8 ~ B1D06 ~ 000525": {
                        "id": "201903060040",
                        "barcode": "000525",
                        "place": "B1D06",
                        "designation": "Chaine clips duplex 5/8"
                    }
                },
                "07": {
                    "Chaine clips pour N-221-005 ~ B1D07 ~ 000526": {
                        "id": "201903060041",
                        "barcode": "000526",
                        "place": "B1D07",
                        "designation": "Chaine clips pour N-221-005"
                    }
                },
                "08": {
                    "Levier ~ B1D08 ~ 000527": {
                        "id": "201903060042",
                        "barcode": "000527",
                        "place": "B1D08",
                        "designation": "Levier"
                    }
                },
                "09": {
                    "Plaque t=5mm ~ B1D09 ~ 000528": {
                        "id": "201903060043",
                        "barcode": "000528",
                        "place": "B1D09",
                        "designation": "Plaque t=5mm"
                    }
                }
            },
            "E": {
                "01": {
                    "Silentbloc 30X30X8 avec 2 taraudages M8 ~ B1E01 ~ 000577": {
                        "id": "201903070032",
                        "barcode": "000577",
                        "place": "B1E01",
                        "designation": "Silentbloc 30X30X8 avec 2 taraudages M8"
                    }
                },
                "02": {
                    "Tige métallique pour switch JENFORM ~ B1E02 ~ 000578": {
                        "id": "201903070033",
                        "barcode": "000578",
                        "place": "B1E02",
                        "designation": "Tige métallique pour switch JENFORM"
                    },
                    "Plaque de serrage ~ B1E02 ~ 000579": {
                        "id": "201903070034",
                        "barcode": "000579",
                        "place": "B1E02",
                        "designation": "Plaque de serrage"
                    },
                    "Poulie pour racleur ~ B1E02 ~ 000580": {
                        "id": "201903070035",
                        "barcode": "000580",
                        "place": "B1E02",
                        "designation": "Poulie pour racleur"
                    },
                    "Morceau chaine Inox tunnel de finition ~ B1E02 ~ 001683": {
                        "id": "201905200001",
                        "barcode": "001683",
                        "place": "B1E02",
                        "designation": "Morceau chaine Inox tunnel de finition"
                    },
                    "Attache rapide en 1/2' inox pour tunnel finition ~ B1E02 ~ 002656": {
                        "id": "202503180002",
                        "barcode": "002656",
                        "place": "B1E02",
                        "designation": "Attache rapide en 1/2' inox pour tunnel finition"
                    }
                },
                "03": {
                    "Thermostat IS-350 avec RESET ~ B1E03 ~ 000581": {
                        "id": "201903070036",
                        "barcode": "000581",
                        "place": "B1E03",
                        "designation": "Thermostat IS-350 avec RESET"
                    },
                    "Transformateur d'allumage ~ B1E03 ~ 000582": {
                        "id": "201903070037",
                        "barcode": "000582",
                        "place": "B1E03",
                        "designation": "Transformateur d'allumage"
                    }
                },
                "04": {
                    "Crochet tunnel de finition ~ B1E04 ~ 000583": {
                        "id": "201903070038",
                        "barcode": "000583",
                        "place": "B1E04",
                        "designation": "Crochet tunnel de finition"
                    }
                },
                "05": {
                    "Entretoise de chaine (crochet tunnel de finition) ~ B1E05 ~ 002669": {
                        "id": "202503270001",
                        "barcode": "002669",
                        "place": "B1E05",
                        "designation": "Entretoise de chaine (crochet tunnel de finition)"
                    }
                },
                "06": {
                    "Multibloc GAZ ~ B1E06 ~ 000584": {
                        "id": "201903070039",
                        "barcode": "000584",
                        "place": "B1E06",
                        "designation": "Multibloc GAZ"
                    }
                }
            },
            "F": {
                "Adaptateur pour joint gonflable ~ B1F ~ 000755": {
                    "id": "201903130010",
                    "barcode": "000755",
                    "place": "B1F",
                    "designation": "Adaptateur pour joint gonflable"
                }
            }
        },
        "2 Colonne": {
            "A": {
                "Chaine Metric au pas de 177 monté avec doigts de perroquet (4 boites) ~ B2A ~ 002005": {
                    "id": "202108090001",
                    "barcode": "002005",
                    "place": "B2A",
                    "designation": "Chaine Metric au pas de 177 monté avec doigts de perroquet (4 boites)"
                }
            },
            "B": {
                "10": {
                    "Equerre oblong ~ B2B10 ~ 000594": {
                        "id": "201903070049",
                        "barcode": "000594",
                        "place": "B2B10",
                        "designation": "Equerre oblong"
                    }
                },
                "11": {
                    "Petite bride en U ~ B2B11 ~ 000595": {
                        "id": "201903070050",
                        "barcode": "000595",
                        "place": "B2B11",
                        "designation": "Petite bride en U"
                    }
                },
                "12": {
                    "Bride moyen en U ~ B2B12 ~ 000596": {
                        "id": "201903070051",
                        "barcode": "000596",
                        "place": "B2B12",
                        "designation": "Bride moyen en U"
                    }
                },
                "13": {
                    "Bride longue en U ~ B2B13 ~ 000597": {
                        "id": "201903070052",
                        "barcode": "000597",
                        "place": "B2B13",
                        "designation": "Bride longue en U"
                    }
                },
                "14": {
                    "Bride extra longue en U ~ B2B14 ~ 000598": {
                        "id": "201903070053",
                        "barcode": "000598",
                        "place": "B2B14",
                        "designation": "Bride extra longue en U"
                    }
                },
                "15": {
                    "Fixation diverse ~ B2B15 ~ 000599": {
                        "id": "201903070054",
                        "barcode": "000599",
                        "place": "B2B15",
                        "designation": "Fixation diverse"
                    }
                },
                "16": {
                    "Bride trippelnut FMX ~ B2B16 ~ 000613": {
                        "id": "201903070068",
                        "barcode": "000613",
                        "place": "B2B16",
                        "designation": "Bride trippelnut FMX"
                    },
                    "Support motorattachment FMXNE ~ B2B16 ~ 000614": {
                        "id": "201903070069",
                        "barcode": "000614",
                        "place": "B2B16",
                        "designation": "Support motorattachment FMXNE"
                    },
                    "Tige et écrou tension moteur Métric ~ B2B16 ~ 000615": {
                        "id": "201903070070",
                        "barcode": "000615",
                        "place": "B2B16",
                        "designation": "Tige et écrou tension moteur Métric"
                    }
                },
                "01": {
                    "Tube carré 20X20 ~ B2B01 ~ 000586": {
                        "id": "201903070041",
                        "barcode": "000586",
                        "place": "B2B01",
                        "designation": "Tube carré 20X20"
                    }
                },
                "02": {
                    "Fixation carré ~ B2B02 ~ 000587": {
                        "id": "201903070042",
                        "barcode": "000587",
                        "place": "B2B02",
                        "designation": "Fixation carré"
                    }
                },
                "03": {
                    "Double fixation 20X20 ~ B2B03 ~ 000588": {
                        "id": "201903070043",
                        "barcode": "000588",
                        "place": "B2B03",
                        "designation": "Double fixation 20X20"
                    }
                },
                "04": {
                    "Double fixation sur rail 20X20 ~ B2B04 ~ 002004": {
                        "id": "202108040001",
                        "barcode": "002004",
                        "place": "B2B04",
                        "designation": "Double fixation sur rail 20X20"
                    }
                },
                "05": {
                    "Fixation 20X20 ~ B2B05 ~ 000589": {
                        "id": "201903070044",
                        "barcode": "000589",
                        "place": "B2B05",
                        "designation": "Fixation 20X20"
                    }
                },
                "06": {
                    "Fixation simple 20X20 ~ B2B06 ~ 000590": {
                        "id": "201903070045",
                        "barcode": "000590",
                        "place": "B2B06",
                        "designation": "Fixation simple 20X20"
                    }
                },
                "07": {
                    "Croisillon 20X20 ~ B2B07 ~ 000591": {
                        "id": "201903070046",
                        "barcode": "000591",
                        "place": "B2B07",
                        "designation": "Croisillon 20X20"
                    }
                },
                "08": {
                    "Equerre de porte ~ B2B08 ~ 000593": {
                        "id": "201903070048",
                        "barcode": "000593",
                        "place": "B2B08",
                        "designation": "Equerre de porte"
                    }
                },
                "09": {
                    "Profilé attache X ~ B2B09 ~ 000592": {
                        "id": "201903070047",
                        "barcode": "000592",
                        "place": "B2B09",
                        "designation": "Profilé attache X"
                    }
                }
            },
            "C": {
                "10": {
                    "Guide noir de stockage Métric ~ B2C10 ~ 000605": {
                        "id": "201903070060",
                        "barcode": "000605",
                        "place": "B2C10",
                        "designation": "Guide noir de stockage Métric"
                    }
                },
                "11": {
                    "Morceau de chaine Metric au pas de 203 ~ B2C11 ~ 002360": {
                        "id": "202305020001",
                        "barcode": "002360",
                        "place": "B2C11",
                        "designation": "Morceau de chaine Metric au pas de 203"
                    }
                },
                "12": {
                    "Morceau de chaine Metric au pas de 254 ~ B2C12 ~ 002361": {
                        "id": "202305020002",
                        "barcode": "002361",
                        "place": "B2C12",
                        "designation": "Morceau de chaine Metric au pas de 254"
                    }
                },
                "13": {
                    "Morceau de chaine Metric au pas de 305 ~ B2C13 ~ 002363": {
                        "id": "202305020004",
                        "barcode": "002363",
                        "place": "B2C13",
                        "designation": "Morceau de chaine Metric au pas de 305"
                    }
                },
                "14": {
                    "Morceau de chaine Metric au pas de 381 ~ B2C14 ~ 002362": {
                        "id": "202305020003",
                        "barcode": "002362",
                        "place": "B2C14",
                        "designation": "Morceau de chaine Metric au pas de 381"
                    }
                },
                "15": {
                    "Chaine Metric au pas de 177 ~ B2C15 ~ 000985": {
                        "id": "201903200014",
                        "barcode": "000985",
                        "place": "B2C15",
                        "designation": "Chaine Metric au pas de 177"
                    }
                },
                "16": {
                    "Chaine Metric au pas de 254 ~ B2C16 ~ 002364": {
                        "id": "202305020005",
                        "barcode": "002364",
                        "place": "B2C16",
                        "designation": "Chaine Metric au pas de 254"
                    }
                },
                "17": {
                    "Chaine en 1/2' ~ B2C17 ~ 002061": {
                        "id": "202110250001",
                        "barcode": "002061",
                        "place": "B2C17",
                        "designation": "Chaine en 1/2'"
                    }
                },
                "01": {
                    "Rail remontant ( fmx17°) pour l'entrée M6 ( départ des taquets ) ~ B2C01 ~ 001811": {
                        "id": "202004090007",
                        "barcode": "001811",
                        "place": "B2C01",
                        "designation": "Rail remontant ( fmx17°) pour l'entrée M6 ( départ des taquets )"
                    }
                },
                "02": {
                    "Attache vérin sur support ~ B2C02 ~ 000610": {
                        "id": "201903070065",
                        "barcode": "000610",
                        "place": "B2C02",
                        "designation": "Attache vérin sur support"
                    },
                    "Doigt extensible sur le verin M6 pour rail 30147-01 right ~ B2C02 ~ 000611": {
                        "id": "201903070066",
                        "barcode": "000611",
                        "place": "B2C02",
                        "designation": "Doigt extensible sur le verin M6 pour rail 30147-01 right"
                    },
                    "Raccord X pour profile compl ~ B2C02 ~ 000612": {
                        "id": "201903070067",
                        "barcode": "000612",
                        "place": "B2C02",
                        "designation": "Raccord X pour profile compl"
                    },
                    "Axe pour doigt Pousseur pour rail entrée M6 ~ B2C02 ~ 001844": {
                        "id": "202007080002",
                        "barcode": "001844",
                        "place": "B2C02",
                        "designation": "Axe pour doigt Pousseur pour rail entrée M6"
                    },
                    "Circlips d'axe pour doigt Pousseur rail entrée M6 ~ B2C02 ~ 001846": {
                        "id": "202007220001",
                        "barcode": "001846",
                        "place": "B2C02",
                        "designation": "Circlips d'axe pour doigt Pousseur rail entrée M6"
                    },
                    "Vérin iso 10X60 pour M6 ~ B2C02 ~ 001882": {
                        "id": "202011130007",
                        "barcode": "001882",
                        "place": "B2C02",
                        "designation": "Vérin iso 10X60 pour M6"
                    },
                    "Circlips extérieur de 4 d'axe pour doigt Pousseur pour rail entrée M6 ~ B2C02 ~ 001888": {
                        "id": "202012110001",
                        "barcode": "001888",
                        "place": "B2C02",
                        "designation": "Circlips extérieur de 4 d'axe pour doigt Pousseur pour rail entrée M6"
                    }
                },
                "03": {
                    "Axe METRIC ~ B2C03 ~ 000502": {
                        "id": "201903060017",
                        "barcode": "000502",
                        "place": "B2C03",
                        "designation": "Axe METRIC"
                    }
                },
                "04": {
                    "Pièce axe fileté M4 METRIC ~ B2C04 ~ 000506": {
                        "id": "201903060021",
                        "barcode": "000506",
                        "place": "B2C04",
                        "designation": "Pièce axe fileté M4 METRIC"
                    }
                },
                "05": {
                    "Aiguillage Metric joint /SXA switch ~ B2C05 ~ 000505": {
                        "id": "201903060020",
                        "barcode": "000505",
                        "place": "B2C05",
                        "designation": "Aiguillage Metric joint /SXA switch"
                    }
                },
                "06": {
                    "Palette blanche Metric ~ B2C06 ~ 000504": {
                        "id": "201903060019",
                        "barcode": "000504",
                        "place": "B2C06",
                        "designation": "Palette blanche Metric"
                    }
                },
                "07": {
                    "Guide blanc de Métric ~ B2C07 ~ 000606": {
                        "id": "201903070061",
                        "barcode": "000606",
                        "place": "B2C07",
                        "designation": "Guide blanc de Métric"
                    }
                },
                "08": {
                    "Guide blanc de Métric loading profile R/Loading ~ B2C08 ~ 002340": {
                        "id": "202303070005",
                        "barcode": "002340",
                        "place": "B2C08",
                        "designation": "Guide blanc de Métric loading profile R/Loading"
                    }
                },
                "09": {
                    "Guide noir d'entrée rail de stockage Métric ~ B2C09 ~ 002358": {
                        "id": "202304280001",
                        "barcode": "002358",
                        "place": "B2C09",
                        "designation": "Guide noir d'entrée rail de stockage Métric"
                    }
                }
            },
            "D": {
                "10": {
                    "Support de doigts sur chaine avec 2 côtés ~ B2D10 ~ 000495": {
                        "id": "201903060010",
                        "barcode": "000495",
                        "place": "B2D10",
                        "designation": "Support de doigts sur chaine avec 2 côtés"
                    }
                },
                "11": {
                    "Support de doigt montage rapide ~ B2D11 ~ 000494": {
                        "id": "201903060009",
                        "barcode": "000494",
                        "place": "B2D11",
                        "designation": "Support de doigt montage rapide"
                    }
                },
                "12": {
                    "Rivets femelle ~ B2D12 ~ 000488": {
                        "id": "201903060003",
                        "barcode": "000488",
                        "place": "B2D12",
                        "designation": "Rivets femelle"
                    }
                },
                "13": {
                    "Rivets mâles ~ B2D13 ~ 000489": {
                        "id": "201903060004",
                        "barcode": "000489",
                        "place": "B2D13",
                        "designation": "Rivets mâles"
                    }
                },
                "14": {
                    "Doigt de perroquet vert silencieux ~ B2D14 ~ 000491": {
                        "id": "201903060006",
                        "barcode": "000491",
                        "place": "B2D14",
                        "designation": "Doigt de perroquet vert silencieux"
                    }
                },
                "15": {
                    "Doigt Perroquet METRICON bleu mettre avec ou sans fente (identique) taquet ~ B2D15 ~ 000490": {
                        "id": "201903060005",
                        "barcode": "000490",
                        "place": "B2D15",
                        "designation": "Doigt Perroquet METRICON bleu mettre avec ou sans fente (identique) taquet"
                    }
                },
                "16": {
                    "Circlips de 9 mm pour Metric ~ B2D16 ~ 000501": {
                        "id": "201903060016",
                        "barcode": "000501",
                        "place": "B2D16",
                        "designation": "Circlips de 9 mm pour Metric"
                    }
                },
                "17": {
                    "Descente noir METRIC ~ B2D17 ~ 000503": {
                        "id": "201903060018",
                        "barcode": "000503",
                        "place": "B2D17",
                        "designation": "Descente noir METRIC"
                    }
                },
                "18": {
                    "Joint S complet ~ B2D18 ~ 000508": {
                        "id": "201903060023",
                        "barcode": "000508",
                        "place": "B2D18",
                        "designation": "Joint S complet"
                    }
                },
                "19": {
                    "Joint U complet ~ B2D19 ~ 000507": {
                        "id": "201903060022",
                        "barcode": "000507",
                        "place": "B2D19",
                        "designation": "Joint U complet"
                    }
                },
                "20": {
                    "Insert rectangle M6X12 19.5/13.5 ~ B2D20 ~ 000510": {
                        "id": "201903060025",
                        "barcode": "000510",
                        "place": "B2D20",
                        "designation": "Insert rectangle M6X12 19.5/13.5"
                    }
                },
                "21": {
                    "Profil attachement XSX ~ B2D21 ~ 000509": {
                        "id": "201903060024",
                        "barcode": "000509",
                        "place": "B2D21",
                        "designation": "Profil attachement XSX"
                    }
                },
                "22": {
                    "Insert carré M6X15 19.5/19.5 ~ B2D22 ~ 000511": {
                        "id": "201903060026",
                        "barcode": "000511",
                        "place": "B2D22",
                        "designation": "Insert carré M6X15 19.5/19.5"
                    }
                },
                "23": {
                    "Vérin gaz R-19,60 BAR 25mm tendeur Kaller pour le M18 ~ B2D23 ~ 001883": {
                        "id": "202011240001",
                        "barcode": "001883",
                        "place": "B2D23",
                        "designation": "Vérin gaz R-19,60 BAR 25mm tendeur Kaller pour le M18"
                    },
                    "Bague pour le M18 ~ B2D23 ~ 002253": {
                        "id": "202209140002",
                        "barcode": "002253",
                        "place": "B2D23",
                        "designation": "Bague pour le M18"
                    }
                },
                "24": {
                    "Insert rectangle bisoté M6X16 ~ B2D24 ~ 000512": {
                        "id": "201903060027",
                        "barcode": "000512",
                        "place": "B2D24",
                        "designation": "Insert rectangle bisoté M6X16"
                    }
                },
                "25": {
                    "Support cintre poste engagement ~ B2D25 ~ 002063": {
                        "id": "202110250003",
                        "barcode": "002063",
                        "place": "B2D25",
                        "designation": "Support cintre poste engagement"
                    }
                },
                "01": {
                    "Circlips de 3.2 mm pour axes de doigts Metric ~ B2D01 ~ 000500": {
                        "id": "201903060015",
                        "barcode": "000500",
                        "place": "B2D01",
                        "designation": "Circlips de 3.2 mm pour axes de doigts Metric"
                    }
                },
                "02": {
                    "Axe long metric ~ B2D02 ~ 000487": {
                        "id": "201903060002",
                        "barcode": "000487",
                        "place": "B2D02",
                        "designation": "Axe long metric"
                    }
                },
                "03": {
                    "Doigt carré Métric ~ B2D03 ~ 000493": {
                        "id": "201903060008",
                        "barcode": "000493",
                        "place": "B2D03",
                        "designation": "Doigt carré Métric"
                    }
                },
                "04": {
                    "Petit axe pour doigt FMX Metric ~ B2D04 ~ 000486": {
                        "id": "201903060001",
                        "barcode": "000486",
                        "place": "B2D04",
                        "designation": "Petit axe pour doigt FMX Metric"
                    }
                },
                "05": {
                    "Doigt FMX triangle Metric ~ B2D05 ~ 000492": {
                        "id": "201903060007",
                        "barcode": "000492",
                        "place": "B2D05",
                        "designation": "Doigt FMX triangle Metric"
                    }
                },
                "06": {
                    "Clips 1/2'd'attache rapide chaîne Métric ~ B2D06 ~ 000497": {
                        "id": "201903060012",
                        "barcode": "000497",
                        "place": "B2D06",
                        "designation": "Clips 1/2'd'attache rapide chaîne Métric"
                    }
                },
                "07": {
                    "Rondelles 1/2' d'attache rapide pour chaine Métric ~ B2D07 ~ 000499": {
                        "id": "201903060014",
                        "barcode": "000499",
                        "place": "B2D07",
                        "designation": "Rondelles 1/2' d'attache rapide pour chaine Métric"
                    }
                },
                "08": {
                    "Maillon 1/2' attache rapide chaine Metric ~ B2D08 ~ 000498": {
                        "id": "201903060013",
                        "barcode": "000498",
                        "place": "B2D08",
                        "designation": "Maillon 1/2' attache rapide chaine Metric"
                    }
                },
                "09": {
                    "Support de doigts chaine 1 côtés ~ B2D09 ~ 000496": {
                        "id": "201903060011",
                        "barcode": "000496",
                        "place": "B2D09",
                        "designation": "Support de doigts chaine 1 côtés"
                    }
                }
            },
            "E": {
                "01": {
                    "Protection de scanner Métric ~ B2E01 ~ 000607": {
                        "id": "201903070062",
                        "barcode": "000607",
                        "place": "B2E01",
                        "designation": "Protection de scanner Métric"
                    }
                },
                "02": {
                    "Divers morceau rail Métric ~ B2E02 ~ 002142": {
                        "id": "202111160015",
                        "barcode": "002142",
                        "place": "B2E02",
                        "designation": "Divers morceau rail Métric"
                    }
                },
                "03": {
                    "Profile FMX DECHARGEMENT A DROITE 20° ~ B2E03 ~ 002141": {
                        "id": "202111160014",
                        "barcode": "002141",
                        "place": "B2E03",
                        "designation": "Profile FMX DECHARGEMENT A DROITE 20°"
                    }
                },
                "05": {
                    "Horizontalkurvauenke ~ B2E05 ~ 000448": {
                        "id": "201903050007",
                        "barcode": "000448",
                        "place": "B2E05",
                        "designation": "Horizontalkurvauenke"
                    }
                },
                "06": {
                    "Courbe 30° R490 ~ B2E06 ~ 000446": {
                        "id": "201903050005",
                        "barcode": "000446",
                        "place": "B2E06",
                        "designation": "Courbe 30° R490"
                    }
                },
                "07": {
                    "Courbe extérieure line M7C7 down 20° R350 180° ~ B2E07 ~ 000445": {
                        "id": "201903050004",
                        "barcode": "000445",
                        "place": "B2E07",
                        "designation": "Courbe extérieure line M7C7 down 20° R350 180°"
                    }
                },
                "08": {
                    "Courbe U R490 45° simple pour M3 ~ B2E08 ~ 002339": {
                        "id": "202303070004",
                        "barcode": "002339",
                        "place": "B2E08",
                        "designation": "Courbe U R490 45° simple pour M3"
                    }
                }
            },
            "F": {
                "Guide chaine gris ~ B2F ~ 000451": {
                    "id": "201903050010",
                    "barcode": "000451",
                    "place": "B2F",
                    "designation": "Guide chaine gris"
                },
                "Brosse PP 600X8X20 ~ B2F ~ 000608": {
                    "id": "201903070063",
                    "barcode": "000608",
                    "place": "B2F",
                    "designation": "Brosse PP 600X8X20"
                }
            }
        },
        "3 Colonne": {
            "B": {
                "01": {
                    "Étiqueteuse A4+/300P a verifier ~ B3B01 ~ 000669": {
                        "id": "201903110037",
                        "barcode": "000669",
                        "place": "B3B01",
                        "designation": "Étiqueteuse A4+/300P a verifier"
                    }
                },
                "03": {
                    "Rouleau déviateur RR4 ~ B3B03 ~ 000191": {
                        "id": "201901150013",
                        "barcode": "000191",
                        "place": "B3B03",
                        "designation": "Rouleau déviateur RR4"
                    },
                    "Rouleau d'impression DR4 ~ B3B03 ~ 000192": {
                        "id": "201901150014",
                        "barcode": "000192",
                        "place": "B3B03",
                        "designation": "Rouleau d'impression DR4"
                    },
                    "Roue crantée 42-TR ~ B3B03 ~ 000193": {
                        "id": "201901150015",
                        "barcode": "000193",
                        "place": "B3B03",
                        "designation": "Roue crantée 42-TR"
                    },
                    "Embrayage enrouleur ruban ~ B3B03 ~ 000194": {
                        "id": "201901150016",
                        "barcode": "000194",
                        "place": "B3B03",
                        "designation": "Embrayage enrouleur ruban"
                    },
                    "Embrayage enrouleur interne ~ B3B03 ~ 000195": {
                        "id": "201901150017",
                        "barcode": "000195",
                        "place": "B3B03",
                        "designation": "Embrayage enrouleur interne"
                    },
                    "Roue dentée référence : 29 ~ B3B03 ~ 000196": {
                        "id": "201901150018",
                        "barcode": "000196",
                        "place": "B3B03",
                        "designation": "Roue dentée référence : 29"
                    },
                    "Bague plastique D=8 B=10 ~ B3B03 ~ 000197": {
                        "id": "201901150019",
                        "barcode": "000197",
                        "place": "B3B03",
                        "designation": "Bague plastique D=8 B=10"
                    },
                    "Courroie 120MXL037 ~ B3B03 ~ 000200": {
                        "id": "201901150022",
                        "barcode": "000200",
                        "place": "B3B03",
                        "designation": "Courroie 120MXL037"
                    },
                    "Circlips din 4716-A6 ~ B3B03 ~ 000204": {
                        "id": "201901150026",
                        "barcode": "000204",
                        "place": "B3B03",
                        "designation": "Circlips din 4716-A6"
                    },
                    "Frein ~ B3B03 ~ 000670": {
                        "id": "201903120001",
                        "barcode": "000670",
                        "place": "B3B03",
                        "designation": "Frein"
                    },
                    "Ressort ~ B3B03 ~ 000671": {
                        "id": "201903120002",
                        "barcode": "000671",
                        "place": "B3B03",
                        "designation": "Ressort"
                    },
                    "Tête d'impression (occasion) ~ B3B03 ~ 000672": {
                        "id": "201903120003",
                        "barcode": "000672",
                        "place": "B3B03",
                        "designation": "Tête d'impression (occasion)"
                    },
                    "Arbre rouleau repere 141 ~ B3B03 ~ 000673": {
                        "id": "201903120004",
                        "barcode": "000673",
                        "place": "B3B03",
                        "designation": "Arbre rouleau repere 141"
                    },
                    "Tampon 90X90 ~ B3B03 ~ 001806": {
                        "id": "202004090002",
                        "barcode": "001806",
                        "place": "B3B03",
                        "designation": "Tampon 90X90"
                    },
                    "Lingette de nettoyage de la tête d'impression ~ B3B03 ~ 001808": {
                        "id": "202004090004",
                        "barcode": "001808",
                        "place": "B3B03",
                        "designation": "Lingette de nettoyage de la tête d'impression"
                    },
                    "Courroie 300MXL037 ~ B3B03 ~ 002006": {
                        "id": "202108090002",
                        "barcode": "002006",
                        "place": "B3B03",
                        "designation": "Courroie 300MXL037"
                    },
                    "Ecrou de serrage repere 135 ~ B3B03 ~ 002266": {
                        "id": "202209190001",
                        "barcode": "002266",
                        "place": "B3B03",
                        "designation": "Ecrou de serrage repere 135"
                    },
                    "Arbre de rebut Wickelwelle ~ B3B03 ~ 002589": {
                        "id": "202406260001",
                        "barcode": "002589",
                        "place": "B3B03",
                        "designation": "Arbre de rebut Wickelwelle"
                    },
                    "Vis de bout d'arbre M4*10 ~ B3B03 ~ 002590": {
                        "id": "202406260002",
                        "barcode": "002590",
                        "place": "B3B03",
                        "designation": "Vis de bout d'arbre M4*10"
                    },
                    "Rondelle pour vis de bout d'arbre M4*10 ~ B3B03 ~ 002591": {
                        "id": "202406260003",
                        "barcode": "002591",
                        "place": "B3B03",
                        "designation": "Rondelle pour vis de bout d'arbre M4*10"
                    },
                    "Cône de serrage pour Arbre de rebut ~ B3B03 ~ 002592": {
                        "id": "202406260004",
                        "barcode": "002592",
                        "place": "B3B03",
                        "designation": "Cône de serrage pour Arbre de rebut"
                    },
                    "Alimentation HQ SQUIX ~ B3B03 ~ 002593": {
                        "id": "202406260005",
                        "barcode": "002593",
                        "place": "B3B03",
                        "designation": "Alimentation HQ SQUIX"
                    },
                    "Flasque maintien de rouleau ~ B3B03 ~ 002639": {
                        "id": "202501230001",
                        "barcode": "002639",
                        "place": "B3B03",
                        "designation": "Flasque maintien de rouleau"
                    }
                }
            },
            "B Bis": {
                "01": {
                    "Aiguillage tridirectionnel ~ B3B01 ~ 002007": {
                        "id": "202108090003",
                        "barcode": "002007",
                        "place": "B3B01",
                        "designation": "Aiguillage tridirectionnel"
                    }
                },
                "02": {
                    "Aiguillage bidirectionnel ~ B3B02 ~ 000650": {
                        "id": "201903110018",
                        "barcode": "000650",
                        "place": "B3B02",
                        "designation": "Aiguillage bidirectionnel"
                    }
                }
            },
            "C": {
                "10": {
                    "Fermeture eclair de slings ~ B3C10 ~ 001850": {
                        "id": "202007290001",
                        "barcode": "001850",
                        "place": "B3C10",
                        "designation": "Fermeture eclair de slings"
                    }
                },
                "11": {
                    "Frein ficelle complet sling ~ B3C11 ~ 000663": {
                        "id": "201903110031",
                        "barcode": "000663",
                        "place": "B3C11",
                        "designation": "Frein ficelle complet sling"
                    },
                    "Levier frein ficelle sling ~ B3C11 ~ 000664": {
                        "id": "201903110032",
                        "barcode": "000664",
                        "place": "B3C11",
                        "designation": "Levier frein ficelle sling"
                    }
                },
                "12": {
                    "Anneaux pour sling ~ B3C12 ~ 000661": {
                        "id": "201903110029",
                        "barcode": "000661",
                        "place": "B3C12",
                        "designation": "Anneaux pour sling"
                    }
                },
                "13": {
                    "Séparateur de trolley complet ~ B3C13 ~ 000665": {
                        "id": "201903110033",
                        "barcode": "000665",
                        "place": "B3C13",
                        "designation": "Séparateur de trolley complet"
                    }
                },
                "14": {
                    "Roulette trolley accrochage ~ B3C14 ~ 000632": {
                        "id": "201903080017",
                        "barcode": "000632",
                        "place": "B3C14",
                        "designation": "Roulette trolley accrochage"
                    }
                },
                "02": {
                    "Roue alvéole industriel (grand diamètre ) ~ B3C02 ~ 000653": {
                        "id": "201903110021",
                        "barcode": "000653",
                        "place": "B3C02",
                        "designation": "Roue alvéole industriel (grand diamètre )"
                    },
                    "Bague pour roue alvéole industriel ~ B3C02 ~ 001855": {
                        "id": "202007300003",
                        "barcode": "001855",
                        "place": "B3C02",
                        "designation": "Bague pour roue alvéole industriel"
                    },
                    "Roue alvéole industriel ( diamètre standart linge sale ) ~ B3C02 ~ 001858": {
                        "id": "202008240001",
                        "barcode": "001858",
                        "place": "B3C02",
                        "designation": "Roue alvéole industriel ( diamètre standart linge sale )"
                    }
                },
                "03": {
                    "Roulement trolley MP Supertrack Maxipress ~ B3C03 ~ 002054": {
                        "id": "202110050001",
                        "barcode": "002054",
                        "place": "B3C03",
                        "designation": "Roulement trolley MP Supertrack Maxipress"
                    },
                    "Trolley MK-1de sling axe long 131mm ~ B3C03 ~ 002055": {
                        "id": "202110050002",
                        "barcode": "002055",
                        "place": "B3C03",
                        "designation": "Trolley MK-1de sling axe long 131mm"
                    },
                    "Kit de pieces de détachées (2 rlts+2 roulettes+circlips ) Maxipress ~ B3C03 ~ 002544": {
                        "id": "202402050001",
                        "barcode": "002544",
                        "place": "B3C03",
                        "designation": "Kit de pieces de détachées (2 rlts+2 roulettes+circlips ) Maxipress"
                    },
                    "Trolley MK-1de sling axe court ~ B3C03 ~ 002587": {
                        "id": "202406240001",
                        "barcode": "002587",
                        "place": "B3C03",
                        "designation": "Trolley MK-1de sling axe court"
                    }
                },
                "04": {
                    "Roulement a aiguilles roulette sling ~ B3C04 ~ 001708": {
                        "id": "201910010002",
                        "barcode": "001708",
                        "place": "B3C04",
                        "designation": "Roulement a aiguilles roulette sling"
                    },
                    "Rondelles pour roulement a aiguilles roulette sling ~ B3C04 ~ 002521": {
                        "id": "202312280003",
                        "barcode": "002521",
                        "place": "B3C04",
                        "designation": "Rondelles pour roulement a aiguilles roulette sling"
                    }
                },
                "05": {
                    "Roulette Jensen POUR TROLLEY de sling ~ B3C05 ~ 000654": {
                        "id": "201903110022",
                        "barcode": "000654",
                        "place": "B3C05",
                        "designation": "Roulette Jensen POUR TROLLEY de sling"
                    },
                    "Cache roulette ~ B3C05 ~ 000655": {
                        "id": "201903110023",
                        "barcode": "000655",
                        "place": "B3C05",
                        "designation": "Cache roulette"
                    },
                    "Circlips bleu pour roulette sling ~ B3C05 ~ 000656": {
                        "id": "201903110024",
                        "barcode": "000656",
                        "place": "B3C05",
                        "designation": "Circlips bleu pour roulette sling"
                    }
                },
                "06": {
                    "Anneaux saisissage ~ B3C06 ~ 000657": {
                        "id": "201903110025",
                        "barcode": "000657",
                        "place": "B3C06",
                        "designation": "Anneaux saisissage"
                    }
                },
                "07": {
                    "Maillon rapide zingué Chaubeyre 8mm pour Sling (manille) ~ B3C07 ~ 000658": {
                        "id": "201903110026",
                        "barcode": "000658",
                        "place": "B3C07",
                        "designation": "Maillon rapide zingué Chaubeyre 8mm pour Sling (manille)"
                    }
                },
                "08": {
                    "Contre poids ~ B3C08 ~ 000659": {
                        "id": "201903110027",
                        "barcode": "000659",
                        "place": "B3C08",
                        "designation": "Contre poids"
                    }
                },
                "09": {
                    "Rondelle auto bloquante pour axe de 8 de trolley Maxipress ~ B3C09 ~ 000660": {
                        "id": "201903110028",
                        "barcode": "000660",
                        "place": "B3C09",
                        "designation": "Rondelle auto bloquante pour axe de 8 de trolley Maxipress"
                    }
                }
            },
            "D": {
                "10": {
                    "Taquet de retenu (anti retour) ~ B3D10 ~ 000642": {
                        "id": "201903110010",
                        "barcode": "000642",
                        "place": "B3D10",
                        "designation": "Taquet de retenu (anti retour)"
                    }
                },
                "11": {
                    "Guide taquet ~ B3D11 ~ 000643": {
                        "id": "201903110011",
                        "barcode": "000643",
                        "place": "B3D11",
                        "designation": "Guide taquet"
                    }
                },
                "12": {
                    "Système amortisseur linge sale artisanale ~ B3D12 ~ 000644": {
                        "id": "201903110012",
                        "barcode": "000644",
                        "place": "B3D12",
                        "designation": "Système amortisseur linge sale artisanale"
                    }
                },
                "13": {
                    "Guide rail orientable ~ B3D13 ~ 001714": {
                        "id": "201910020002",
                        "barcode": "001714",
                        "place": "B3D13",
                        "designation": "Guide rail orientable"
                    }
                },
                "14": {
                    "Tige filetée ascenceur sling linge sale fait par bih ~ B3D14 ~ 000645": {
                        "id": "201903110013",
                        "barcode": "000645",
                        "place": "B3D14",
                        "designation": "Tige filetée ascenceur sling linge sale fait par bih"
                    }
                },
                "15": {
                    "Butee rail futurail N°2 2020-04186 ~ B3D15 ~ 000647": {
                        "id": "201903110015",
                        "barcode": "000647",
                        "place": "B3D15",
                        "designation": "Butee rail futurail N°2 2020-04186"
                    }
                },
                "16": {
                    "Rondelle élastique belleville 28X14.2X1.25mm linge sale ~ B3D16 ~ 001947": {
                        "id": "202104080001",
                        "barcode": "001947",
                        "place": "B3D16",
                        "designation": "Rondelle élastique belleville 28X14.2X1.25mm linge sale"
                    }
                },
                "17": {
                    "Plaque teflon ~ B3D17 ~ 000648": {
                        "id": "201903110016",
                        "barcode": "000648",
                        "place": "B3D17",
                        "designation": "Plaque teflon"
                    }
                },
                "18": {
                    "Vérin pousseur course 250mm pour élévateur ~ B3D18 ~ 000649": {
                        "id": "201903110017",
                        "barcode": "000649",
                        "place": "B3D18",
                        "designation": "Vérin pousseur course 250mm pour élévateur"
                    }
                },
                "19": {
                    "Partie fixe décroche sacs fabrication maison ~ B3D19 ~ 000631": {
                        "id": "201903080016",
                        "barcode": "000631",
                        "place": "B3D19",
                        "designation": "Partie fixe décroche sacs fabrication maison"
                    }
                },
                "00": {
                    "Afficheur BAUMER PA418 ~ B3D00 ~ 002352": {
                        "id": "202304110002",
                        "barcode": "002352",
                        "place": "B3D00",
                        "designation": "Afficheur BAUMER PA418"
                    }
                },
                "01": {
                    "Afficheur noritake alvéole résident ~ B3D01 ~ 000633": {
                        "id": "201903110001",
                        "barcode": "000633",
                        "place": "B3D01",
                        "designation": "Afficheur noritake alvéole résident"
                    }
                },
                "02": {
                    "Guide avec 2 roulettes linge sale ascenceur ~ B3D02 ~ 000634": {
                        "id": "201903110002",
                        "barcode": "000634",
                        "place": "B3D02",
                        "designation": "Guide avec 2 roulettes linge sale ascenceur"
                    }
                },
                "03": {
                    "Peson alvéoles linge sale ~ B3D03 ~ 000635": {
                        "id": "201903110003",
                        "barcode": "000635",
                        "place": "B3D03",
                        "designation": "Peson alvéoles linge sale"
                    }
                },
                "04": {
                    "Guide reglable avec 1 roulette ascenceur ~ B3D04 ~ 000636": {
                        "id": "201903110004",
                        "barcode": "000636",
                        "place": "B3D04",
                        "designation": "Guide reglable avec 1 roulette ascenceur"
                    }
                },
                "05": {
                    "Guide avec 1 roulette ascenceur ~ B3D05 ~ 000637": {
                        "id": "201903110005",
                        "barcode": "000637",
                        "place": "B3D05",
                        "designation": "Guide avec 1 roulette ascenceur"
                    }
                },
                "06": {
                    "Roue codeuse crouzet 0 à 9 pour linge sale ~ B3D06 ~ 000638": {
                        "id": "201903110006",
                        "barcode": "000638",
                        "place": "B3D06",
                        "designation": "Roue codeuse crouzet 0 à 9 pour linge sale"
                    }
                },
                "07": {
                    "Taquet pour butée séparatrice (fait bih) ~ B3D07 ~ 000639": {
                        "id": "201903110007",
                        "barcode": "000639",
                        "place": "B3D07",
                        "designation": "Taquet pour butée séparatrice (fait bih)"
                    }
                },
                "08": {
                    "Plaque longue pour taquet de retenue ~ B3D08 ~ 000640": {
                        "id": "201903110008",
                        "barcode": "000640",
                        "place": "B3D08",
                        "designation": "Plaque longue pour taquet de retenue"
                    },
                    "Plaque courte pour taquet de retenue ~ B3D08 ~ 001702": {
                        "id": "201908220001",
                        "barcode": "001702",
                        "place": "B3D08",
                        "designation": "Plaque courte pour taquet de retenue"
                    }
                },
                "09": {
                    "Jonction rail futurail ~ B3D09 ~ 000641": {
                        "id": "201903110009",
                        "barcode": "000641",
                        "place": "B3D09",
                        "designation": "Jonction rail futurail"
                    }
                }
            },
            "E": {
                "10": {
                    "Jonction de rail ~ B3E10 ~ 000652": {
                        "id": "201903110020",
                        "barcode": "000652",
                        "place": "B3E10",
                        "designation": "Jonction de rail"
                    }
                },
                "11": {
                    "Tige filetée fixation rail ~ B3E11 ~ 000630": {
                        "id": "201903080015",
                        "barcode": "000630",
                        "place": "B3E11",
                        "designation": "Tige filetée fixation rail"
                    }
                },
                "12": {
                    "Vérin pousseur ~ B3E12 ~ 000651": {
                        "id": "201903110019",
                        "barcode": "000651",
                        "place": "B3E12",
                        "designation": "Vérin pousseur"
                    }
                },
                "13": {
                    "Cliquet anti retour simple rail elevateur ~ B3E13 ~ 000646": {
                        "id": "201903110014",
                        "barcode": "000646",
                        "place": "B3E13",
                        "designation": "Cliquet anti retour simple rail elevateur"
                    }
                },
                "01": {
                    "Chien à pousser 63mm ~ B3E01 ~ 000620": {
                        "id": "201903080005",
                        "barcode": "000620",
                        "place": "B3E01",
                        "designation": "Chien à pousser 63mm"
                    }
                },
                "02": {
                    "Chien à pousser 73mm ~ B3E02 ~ 000621": {
                        "id": "201903080006",
                        "barcode": "000621",
                        "place": "B3E02",
                        "designation": "Chien à pousser 73mm"
                    }
                },
                "03": {
                    "Chien à pousser 93mm ~ B3E03 ~ 000622": {
                        "id": "201903080007",
                        "barcode": "000622",
                        "place": "B3E03",
                        "designation": "Chien à pousser 93mm"
                    }
                },
                "04": {
                    "Ressort chien a pousser standart 45/65 ~ B3E04 ~ 000623": {
                        "id": "201903080008",
                        "barcode": "000623",
                        "place": "B3E04",
                        "designation": "Ressort chien a pousser standart 45/65"
                    }
                },
                "04bis": {
                    "Ressort chien a pousser d'1 mm plus utilisé ~ B3E04BIS ~ 001869": {
                        "id": "202009100001",
                        "barcode": "001869",
                        "place": "B3E04BIS",
                        "designation": "Ressort chien a pousser d'1 mm plus utilisé"
                    }
                },
                "05": {
                    "Entretoise chien a pousser ~ B3E05 ~ 000624": {
                        "id": "201903080009",
                        "barcode": "000624",
                        "place": "B3E05",
                        "designation": "Entretoise chien a pousser"
                    }
                },
                "06": {
                    "Bloc noir nylon ~ B3E06 ~ 000625": {
                        "id": "201903080010",
                        "barcode": "000625",
                        "place": "B3E06",
                        "designation": "Bloc noir nylon"
                    }
                },
                "07": {
                    "Divers fixation rail dunnewold ~ B3E07 ~ 000626": {
                        "id": "201903080011",
                        "barcode": "000626",
                        "place": "B3E07",
                        "designation": "Divers fixation rail dunnewold"
                    }
                },
                "08": {
                    "Roulette convoyeur blanche accrochage ~ B3E08 ~ 000627": {
                        "id": "201903080012",
                        "barcode": "000627",
                        "place": "B3E08",
                        "designation": "Roulette convoyeur blanche accrochage"
                    }
                },
                "09": {
                    "Pignon convoyeur bleu accrochage ~ B3E09 ~ 000629": {
                        "id": "201903080014",
                        "barcode": "000629",
                        "place": "B3E09",
                        "designation": "Pignon convoyeur bleu accrochage"
                    }
                }
            },
            "F": {
                "01": {
                    "Ficelle D=4,79mm BOBINE DE 300 METRES ~ B3F01 ~ 000666": {
                        "id": "201903110034",
                        "barcode": "000666",
                        "place": "B3F01",
                        "designation": "Ficelle D=4,79mm BOBINE DE 300 METRES"
                    }
                },
                "02": {
                    "Ficelle DRISSE Polyamide - Diam=4mm (Bobine de 100m) ~ B3F02 ~ 000667": {
                        "id": "201903110035",
                        "barcode": "000667",
                        "place": "B3F02",
                        "designation": "Ficelle DRISSE Polyamide - Diam=4mm (Bobine de 100m)"
                    }
                },
                "03": {
                    "Detecteur de stockage (saturation) ~ B3F03 ~ 000668": {
                        "id": "201903110036",
                        "barcode": "000668",
                        "place": "B3F03",
                        "designation": "Detecteur de stockage (saturation)"
                    }
                }
            }
        }
    },
    "Rangée C": {
        "1 Colonne": {
            "A": {
                "01": {
                    "Outil pour démontage membrane ~ C1A01 ~ 000749": {
                        "id": "201903130004",
                        "barcode": "000749",
                        "place": "C1A01",
                        "designation": "Outil pour démontage membrane"
                    },
                    "Graisse et pinceau pour montage membrane ~ C1A01 ~ 002528": {
                        "id": "202312290007",
                        "barcode": "002528",
                        "place": "C1A01",
                        "designation": "Graisse et pinceau pour montage membrane"
                    }
                },
                "02": {
                    "Vis Presse CHC 10X60 INOX (Boîte de 100) ~ C1A02 ~ 000735": {
                        "id": "201903120066",
                        "barcode": "000735",
                        "place": "C1A02",
                        "designation": "Vis Presse CHC 10X60 INOX (Boîte de 100)"
                    },
                    "Vis Presse CHC 10X45 INOX (boite de 100) ~ C1A02 ~ 000736": {
                        "id": "201903120067",
                        "barcode": "000736",
                        "place": "C1A02",
                        "designation": "Vis Presse CHC 10X45 INOX (boite de 100)"
                    },
                    "Vis type H de 8X35 INOX (Boîte de 100) ~ C1A02 ~ 002186": {
                        "id": "202201310001",
                        "barcode": "002186",
                        "place": "C1A02",
                        "designation": "Vis type H de 8X35 INOX (Boîte de 100)"
                    },
                    "Vis Presse CHC 16X32 INOX ~ C1A02 ~ 002616": {
                        "id": "202410210001",
                        "barcode": "002616",
                        "place": "C1A02",
                        "designation": "Vis Presse CHC 16X32 INOX"
                    }
                },
                "03": {
                    "Différentes pièces laissée par Jensen au chgt panier ~ C1A03 ~ 002304": {
                        "id": "202212060004",
                        "barcode": "002304",
                        "place": "C1A03",
                        "designation": "Différentes pièces laissée par Jensen au chgt panier"
                    }
                },
                "04": {
                    "Soupape hydraulique (occasion) ~ C1A04 ~ 000701": {
                        "id": "201903120032",
                        "barcode": "000701",
                        "place": "C1A04",
                        "designation": "Soupape hydraulique (occasion)"
                    },
                    "Adaptateur hydraulique Alu moule 111577 /cylindre principale LP571/572 hydraulique (retour rapide d'huile) ~ C1A04 ~ 002328": {
                        "id": "202302010001",
                        "barcode": "002328",
                        "place": "C1A04",
                        "designation": "Adaptateur hydraulique Alu moule 111577 /cylindre principale LP571/572 hydraulique (retour rapide d'huile)"
                    },
                    "Manchon hydraulique entre adaptateur Alu et tuyau huile retour LP571/572 (retour rapide d'huile) ~ C1A04 ~ 002329": {
                        "id": "202302010002",
                        "barcode": "002329",
                        "place": "C1A04",
                        "designation": "Manchon hydraulique entre adaptateur Alu et tuyau huile retour LP571/572 (retour rapide d'huile)"
                    },
                    "Joint KL A160X2 hydraulique pour adaptateur LP571/572 (retour rapide d'huile) ~ C1A04 ~ 002330": {
                        "id": "202302010003",
                        "barcode": "002330",
                        "place": "C1A04",
                        "designation": "Joint KL A160X2 hydraulique pour adaptateur LP571/572 (retour rapide d'huile)"
                    }
                },
                "05": {
                    "Support de panier complet avec coquilles pour presse LP572 ~ C1A05 ~ 000750": {
                        "id": "201903130005",
                        "barcode": "000750",
                        "place": "C1A05",
                        "designation": "Support de panier complet avec coquilles pour presse LP572"
                    }
                },
                "06": {
                    "Cartouche Automatique de graisse tunnel Kannegiesser ~ C1A06 ~ 000702": {
                        "id": "201903120033",
                        "barcode": "000702",
                        "place": "C1A06",
                        "designation": "Cartouche Automatique de graisse tunnel Kannegiesser"
                    },
                    "Entrainement PERMA PRO C ~ C1A06 ~ 000703": {
                        "id": "201903120034",
                        "barcode": "000703",
                        "place": "C1A06",
                        "designation": "Entrainement PERMA PRO C"
                    }
                },
                "07": {
                    "Support de cable essoreuse Kannegiesser ~ C1A07 ~ 002397": {
                        "id": "202307110002",
                        "barcode": "002397",
                        "place": "C1A07",
                        "designation": "Support de cable essoreuse Kannegiesser"
                    },
                    "Support de cable essoreuse Kannegiesser ~ C1A07 ~ 002398": {
                        "id": "202307110003",
                        "barcode": "002398",
                        "place": "C1A07",
                        "designation": "Support de cable essoreuse Kannegiesser"
                    },
                    "Bouchon essoreuse Kannegiesser ~ C1A07 ~ 002399": {
                        "id": "202307110004",
                        "barcode": "002399",
                        "place": "C1A07",
                        "designation": "Bouchon essoreuse Kannegiesser"
                    },
                    "Bouchon essoreuse Kannegiesser ~ C1A07 ~ 002400": {
                        "id": "202307110005",
                        "barcode": "002400",
                        "place": "C1A07",
                        "designation": "Bouchon essoreuse Kannegiesser"
                    },
                    "Bride essoreuse Kannegiesser ~ C1A07 ~ 002401": {
                        "id": "202307110006",
                        "barcode": "002401",
                        "place": "C1A07",
                        "designation": "Bride essoreuse Kannegiesser"
                    },
                    "Cale de calage de coussin d'air ( RESSORT PNEUMATIQUE FS 200-10 ) ~ C1A07 ~ 002419": {
                        "id": "202307280004",
                        "barcode": "002419",
                        "place": "C1A07",
                        "designation": "Cale de calage de coussin d'air ( RESSORT PNEUMATIQUE FS 200-10 )"
                    }
                },
                "07 Bis": {
                    "Cabochon protecteur sw23 ~ C1A07BIS ~ 000551": {
                        "id": "201903070006",
                        "barcode": "000551",
                        "place": "C1A07BIS",
                        "designation": "Cabochon protecteur sw23"
                    }
                },
                "08": {
                    "Jonction plastique de panier ~ C1A08 ~ 002290": {
                        "id": "202211040001",
                        "barcode": "002290",
                        "place": "C1A08",
                        "designation": "Jonction plastique de panier"
                    }
                }
            },
            "B": {
                "10": {
                    "Pressotat hydraulique ~ C1B10 ~ 000744": {
                        "id": "201903120075",
                        "barcode": "000744",
                        "place": "C1B10",
                        "designation": "Pressotat hydraulique"
                    },
                    "Pressotat hydraulique ~ C1B10 ~ 000745": {
                        "id": "201903120076",
                        "barcode": "000745",
                        "place": "C1B10",
                        "designation": "Pressotat hydraulique"
                    }
                },
                "11": {
                    "Étoile accouplement pompe hydraulique presse ~ C1B11 ~ 000746": {
                        "id": "201903130001",
                        "barcode": "000746",
                        "place": "C1B11",
                        "designation": "Étoile accouplement pompe hydraulique presse"
                    },
                    "Accouplement de pompe hydraulique ~ C1B11 ~ 000747": {
                        "id": "201903130002",
                        "barcode": "000747",
                        "place": "C1B11",
                        "designation": "Accouplement de pompe hydraulique"
                    }
                },
                "12": {
                    "Jeu de coquilles pour presse LP572 par paire ~ C1B12 ~ 000748": {
                        "id": "201903130003",
                        "barcode": "000748",
                        "place": "C1B12",
                        "designation": "Jeu de coquilles pour presse LP572 par paire"
                    }
                },
                "13": {
                    "Filtre à air ~ C1B13 ~ 002420": {
                        "id": "202308080001",
                        "barcode": "002420",
                        "place": "C1B13",
                        "designation": "Filtre à air"
                    }
                },
                "01": {
                    "Filtre Hydraulique HIFI ~ C1B01 ~ 001872": {
                        "id": "202010120002",
                        "barcode": "001872",
                        "place": "C1B01",
                        "designation": "Filtre Hydraulique HIFI"
                    }
                },
                "02": {
                    "Filtre Hydraulique FLEETGUARD ~ C1B02 ~ 000734": {
                        "id": "201903120065",
                        "barcode": "000734",
                        "place": "C1B02",
                        "designation": "Filtre Hydraulique FLEETGUARD"
                    }
                },
                "03": {
                    "Clavette 6X6X35 pour arbre entrainement tapis de presse ~ C1B03 ~ 002321": {
                        "id": "202301200002",
                        "barcode": "002321",
                        "place": "C1B03",
                        "designation": "Clavette 6X6X35 pour arbre entrainement tapis de presse"
                    },
                    "Roulement 6205 inox pour arbre gomme entrainement tapis de presse ~ C1B03 ~ 002322": {
                        "id": "202301200003",
                        "barcode": "002322",
                        "place": "C1B03",
                        "designation": "Roulement 6205 inox pour arbre gomme entrainement tapis de presse"
                    },
                    "Circlips inox dia 25 ext pour arbre gomme entrainement tapis de presse ~ C1B03 ~ 002323": {
                        "id": "202301200004",
                        "barcode": "002323",
                        "place": "C1B03",
                        "designation": "Circlips inox dia 25 ext pour arbre gomme entrainement tapis de presse"
                    },
                    "Circlips inox dia 50 int pour arbre gomme entrainement tapis de presse ~ C1B03 ~ 002324": {
                        "id": "202301200005",
                        "barcode": "002324",
                        "place": "C1B03",
                        "designation": "Circlips inox dia 50 int pour arbre gomme entrainement tapis de presse"
                    }
                },
                "04": {
                    "Outillage pour presse ~ C1B04 ~ 000738": {
                        "id": "201903120069",
                        "barcode": "000738",
                        "place": "C1B04",
                        "designation": "Outillage pour presse"
                    },
                    "Pressostat de pression de la membrane ~ C1B04 ~ 002221": {
                        "id": "202204110001",
                        "barcode": "002221",
                        "place": "C1B04",
                        "designation": "Pressostat de pression de la membrane"
                    }
                },
                "05": {
                    "Coude hydraulique + divers ~ C1B05 ~ 000739": {
                        "id": "201903120070",
                        "barcode": "000739",
                        "place": "C1B05",
                        "designation": "Coude hydraulique + divers"
                    }
                },
                "06": {
                    "Bouchon 1\"1/2 ~ C1B06 ~ 000737": {
                        "id": "201903120068",
                        "barcode": "000737",
                        "place": "C1B06",
                        "designation": "Bouchon 1\"1/2"
                    },
                    "Raccord ~ C1B06 ~ 000740": {
                        "id": "201903120071",
                        "barcode": "000740",
                        "place": "C1B06",
                        "designation": "Raccord"
                    }
                },
                "07": {
                    "Filtre mis a l'air ~ C1B07 ~ 000741": {
                        "id": "201903120072",
                        "barcode": "000741",
                        "place": "C1B07",
                        "designation": "Filtre mis a l'air"
                    }
                },
                "08": {
                    "Support filtre mis a l'air ~ C1B08 ~ 000742": {
                        "id": "201903120073",
                        "barcode": "000742",
                        "place": "C1B08",
                        "designation": "Support filtre mis a l'air"
                    }
                },
                "09": {
                    "Filtre a huile pour groupe ~ C1B09 ~ 000743": {
                        "id": "201903120074",
                        "barcode": "000743",
                        "place": "C1B09",
                        "designation": "Filtre a huile pour groupe"
                    }
                }
            },
            "C": {
                "01": {
                    "Detecteur de niveau tunnel Kanne ~ C1C01 ~ 001929": {
                        "id": "202103220002",
                        "barcode": "001929",
                        "place": "C1C01",
                        "designation": "Detecteur de niveau tunnel Kanne"
                    },
                    "Adaptateur detecteur niveau tunnel Kanne ~ C1C01 ~ 001930": {
                        "id": "202103220003",
                        "barcode": "001930",
                        "place": "C1C01",
                        "designation": "Adaptateur detecteur niveau tunnel Kanne"
                    }
                },
                "02": {
                    "Codeur IVO ~ C1C02 ~ 001701": {
                        "id": "201908010002",
                        "barcode": "001701",
                        "place": "C1C02",
                        "designation": "Codeur IVO"
                    },
                    "Codeur pour navette Kanne ~ C1C02 ~ 001931": {
                        "id": "202103220004",
                        "barcode": "001931",
                        "place": "C1C02",
                        "designation": "Codeur pour navette Kanne"
                    }
                },
                "03": {
                    "Rondelles jaunes filtres a eau ~ C1C03 ~ 001709": {
                        "id": "201910010003",
                        "barcode": "001709",
                        "place": "C1C03",
                        "designation": "Rondelles jaunes filtres a eau"
                    }
                },
                "03 Bis": {
                    "Joint plat séchoir kannegiesser ~ C1C03BIS ~ 000550": {
                        "id": "201903070005",
                        "barcode": "000550",
                        "place": "C1C03BIS",
                        "designation": "Joint plat séchoir kannegiesser"
                    }
                },
                "04": {
                    "Codeur pour tunnel 10X35 Kanne ~ C1C04 ~ 002354": {
                        "id": "202304110004",
                        "barcode": "002354",
                        "place": "C1C04",
                        "designation": "Codeur pour tunnel 10X35 Kanne"
                    }
                }
            },
            "D": {
                "01": {
                    "Vanne vapeur BURKERT 1'1/4 dn32 corps inox anti-coup bélier ~ C1D01 ~ 001126": {
                        "id": "201903260036",
                        "barcode": "001126",
                        "place": "C1D01",
                        "designation": "Vanne vapeur BURKERT 1'1/4 dn32 corps inox anti-coup bélier"
                    },
                    "Vanne vapeur BURKERT 1'1/4 dn32 corps laiton (remplace par inox ) ~ C1D01 ~ 001128": {
                        "id": "201903260038",
                        "barcode": "001128",
                        "place": "C1D01",
                        "designation": "Vanne vapeur BURKERT 1'1/4 dn32 corps laiton (remplace par inox )"
                    },
                    "Vanne vapeur SIEGE RENFORCE marque BURKERT 1'1/4 dn32 corps inox anti-coup bélier ~ C1D01 ~ 002554": {
                        "id": "202402260001",
                        "barcode": "002554",
                        "place": "C1D01",
                        "designation": "Vanne vapeur SIEGE RENFORCE marque BURKERT 1'1/4 dn32 corps inox anti-coup bélier"
                    }
                },
                "02": {
                    "Electrovanne d'eau BURKERT 1 pouce DN25 ~ C1D02 ~ 001127": {
                        "id": "201903260037",
                        "barcode": "001127",
                        "place": "C1D02",
                        "designation": "Electrovanne d'eau BURKERT 1 pouce DN25"
                    }
                },
                "03": {
                    "Limiteur de course Electrovanne de vapeur ~ C1D03 ~ 001132": {
                        "id": "201903260042",
                        "barcode": "001132",
                        "place": "C1D03",
                        "designation": "Limiteur de course Electrovanne de vapeur"
                    }
                },
                "04": {
                    "Electrovanne de vapeur BURKERT en 1/2 (purge des tunnels de lavage) ~ C1D04 ~ 001129": {
                        "id": "201903260039",
                        "barcode": "001129",
                        "place": "C1D04",
                        "designation": "Electrovanne de vapeur BURKERT en 1/2 (purge des tunnels de lavage)"
                    },
                    "Electrovanne de vapeur GEMU en 3/4 (purge des tunnels de lavage) ~ C1D04 ~ 002376": {
                        "id": "202305190003",
                        "barcode": "002376",
                        "place": "C1D04",
                        "designation": "Electrovanne de vapeur GEMU en 3/4 (purge des tunnels de lavage)"
                    }
                },
                "05": {
                    "Kit de réparation électrovanne diamètre 25 BURKERT ~ C1D05 ~ 001130": {
                        "id": "201903260040",
                        "barcode": "001130",
                        "place": "C1D05",
                        "designation": "Kit de réparation électrovanne diamètre 25 BURKERT"
                    },
                    "Kit de réparation électrovanne diamètre 32 BURKERT ~ C1D05 ~ 001131": {
                        "id": "201903260041",
                        "barcode": "001131",
                        "place": "C1D05",
                        "designation": "Kit de réparation électrovanne diamètre 32 BURKERT"
                    },
                    "Kit de réparation électrovanne diamètre 40 BURKERT ~ C1D05 ~ 001905": {
                        "id": "202101250001",
                        "barcode": "001905",
                        "place": "C1D05",
                        "designation": "Kit de réparation électrovanne diamètre 40 BURKERT"
                    }
                },
                "06": {
                    "Bride inox DN32,304L,PN10/16 ~ C1D06 ~ 000724": {
                        "id": "201903120055",
                        "barcode": "000724",
                        "place": "C1D06",
                        "designation": "Bride inox DN32,304L,PN10/16"
                    },
                    "Mamelon male/male INOX pour flexible vapeur ~ C1D06 ~ 000725": {
                        "id": "201903120056",
                        "barcode": "000725",
                        "place": "C1D06",
                        "designation": "Mamelon male/male INOX pour flexible vapeur"
                    },
                    "Coude 90° MALE FEMELLE 1\"1/4G pour flexible vapeur ~ C1D06 ~ 000726": {
                        "id": "201903120057",
                        "barcode": "000726",
                        "place": "C1D06",
                        "designation": "Coude 90° MALE FEMELLE 1\"1/4G pour flexible vapeur"
                    },
                    "Flexible Vapeur ondulant inox dn32 lg0.5ml embout 1'1/4 inox ~ C1D06 ~ 000727": {
                        "id": "201903120058",
                        "barcode": "000727",
                        "place": "C1D06",
                        "designation": "Flexible Vapeur ondulant inox dn32 lg0.5ml embout 1'1/4 inox"
                    },
                    "Flexible Vapeur Renforcé dn32 ~ C1D06 ~ 000728": {
                        "id": "201903120059",
                        "barcode": "000728",
                        "place": "C1D06",
                        "designation": "Flexible Vapeur Renforcé dn32"
                    },
                    "Sonde de niveau rouge plus longue ~ C1D06 ~ 000729": {
                        "id": "201903120060",
                        "barcode": "000729",
                        "place": "C1D06",
                        "designation": "Sonde de niveau rouge plus longue"
                    },
                    "Sonde de niveau noir plus petite ~ C1D06 ~ 000730": {
                        "id": "201903120061",
                        "barcode": "000730",
                        "place": "C1D06",
                        "designation": "Sonde de niveau noir plus petite"
                    },
                    "Sonde de niveau bleu longueur médiane ~ C1D06 ~ 000731": {
                        "id": "201903120062",
                        "barcode": "000731",
                        "place": "C1D06",
                        "designation": "Sonde de niveau bleu longueur médiane"
                    }
                },
                "07": {
                    "Détecteur visuel de niveau d'eau tunnel DN32-2500L/H ~ C1D07 ~ 000732": {
                        "id": "201903120063",
                        "barcode": "000732",
                        "place": "C1D07",
                        "designation": "Détecteur visuel de niveau d'eau tunnel DN32-2500L/H"
                    },
                    "Détecteur visuel de niveau d'eau tunnel DN50 ~ C1D07 ~ 001937": {
                        "id": "202104010001",
                        "barcode": "001937",
                        "place": "C1D07",
                        "designation": "Détecteur visuel de niveau d'eau tunnel DN50"
                    },
                    "Détecteur visuel de niveau d'eau tunnel DN40-6000L/H ~ C1D07 ~ 001938": {
                        "id": "202104010002",
                        "barcode": "001938",
                        "place": "C1D07",
                        "designation": "Détecteur visuel de niveau d'eau tunnel DN40-6000L/H"
                    },
                    "Réducteur simple MF 63X50 PVC pression pour détecteur visuel de niveau d'eau tunnel DN32 - 2500L/H ~ C1D07 ~ 001940": {
                        "id": "202104010004",
                        "barcode": "001940",
                        "place": "C1D07",
                        "designation": "Réducteur simple MF 63X50 PVC pression pour détecteur visuel de niveau d'eau tunnel DN32 - 2500L/H"
                    },
                    "Réducteur simple 50X40 MF PVC pression pour détecteur visuel de niveau d'eau tunnel DN32 - 2500L/H ~ C1D07 ~ 001941": {
                        "id": "202104010005",
                        "barcode": "001941",
                        "place": "C1D07",
                        "designation": "Réducteur simple 50X40 MF PVC pression pour détecteur visuel de niveau d'eau tunnel DN32 - 2500L/H"
                    },
                    "Joint torique 68X3.5 ~ C1D07 ~ 001943": {
                        "id": "202104010007",
                        "barcode": "001943",
                        "place": "C1D07",
                        "designation": "Joint torique 68X3.5"
                    },
                    "Embout pvc renforce fem d32 male 1'' (d26X34) ~ C1D07 ~ 001950": {
                        "id": "202104200001",
                        "barcode": "001950",
                        "place": "C1D07",
                        "designation": "Embout pvc renforce fem d32 male 1'' (d26X34)"
                    },
                    "Joint torique 46X3.5 ~ C1D07 ~ 002048": {
                        "id": "202109160001",
                        "barcode": "002048",
                        "place": "C1D07",
                        "designation": "Joint torique 46X3.5"
                    },
                    "Joint torique 50.39X3.53 ~ C1D07 ~ 002057": {
                        "id": "202110110001",
                        "barcode": "002057",
                        "place": "C1D07",
                        "designation": "Joint torique 50.39X3.53"
                    }
                }
            },
            "E": {
                "10": {
                    "Ressort inox vérin boîte à Niveau ~ C1E10 ~ 000719": {
                        "id": "201903120050",
                        "barcode": "000719",
                        "place": "C1E10",
                        "designation": "Ressort inox vérin boîte à Niveau"
                    }
                },
                "11": {
                    "Manchette caoutchouc vanne vidange Tunnel ~ C1E11 ~ 000715": {
                        "id": "201903120046",
                        "barcode": "000715",
                        "place": "C1E11",
                        "designation": "Manchette caoutchouc vanne vidange Tunnel"
                    }
                },
                "12": {
                    "Distributeur tunnel 10 ou séchoir ~ C1E12 ~ 000560": {
                        "id": "201903070015",
                        "barcode": "000560",
                        "place": "C1E12",
                        "designation": "Distributeur tunnel 10 ou séchoir"
                    }
                },
                "13": {
                    "Sonde de temperature PT 100 ~ C1E13 ~ 000721": {
                        "id": "201903120052",
                        "barcode": "000721",
                        "place": "C1E13",
                        "designation": "Sonde de temperature PT 100"
                    }
                },
                "14": {
                    "Support de sonde de niveau ~ C1E14 ~ 000722": {
                        "id": "201903120053",
                        "barcode": "000722",
                        "place": "C1E14",
                        "designation": "Support de sonde de niveau"
                    }
                },
                "15": {
                    "Bague teflon ~ C1E15 ~ 000723": {
                        "id": "201903120054",
                        "barcode": "000723",
                        "place": "C1E15",
                        "designation": "Bague teflon"
                    }
                },
                "16": {
                    "Goujons de vidandes ~ C1E16 ~ 002319": {
                        "id": "202301160002",
                        "barcode": "002319",
                        "place": "C1E16",
                        "designation": "Goujons de vidandes"
                    }
                },
                "17": {
                    "MOYEU AMOVIBLE 3030/050 MTL3030050 VECO ~ C1E17 ~ 002731": {
                        "id": "202511190002",
                        "barcode": "002731",
                        "place": "C1E17",
                        "designation": "MOYEU AMOVIBLE 3030/050 MTL3030050 VECO"
                    }
                },
                "18": {
                    "MOYEU AMOVIBLE 3030/055 MTL3030055 VECO ~ C1E18 ~ 002732": {
                        "id": "202511190003",
                        "barcode": "002732",
                        "place": "C1E18",
                        "designation": "MOYEU AMOVIBLE 3030/055 MTL3030055 VECO"
                    },
                    "MOYEU AMOVIBLE 3020/050 MTL3020050 VECO ~ C1E18 ~ 002733": {
                        "id": "202511190004",
                        "barcode": "002733",
                        "place": "C1E18",
                        "designation": "MOYEU AMOVIBLE 3020/050 MTL3020050 VECO"
                    }
                },
                "01": {
                    "Soufflet boite à niveau tunnel de lavage ~ C1E01 ~ 000714": {
                        "id": "201903120045",
                        "barcode": "000714",
                        "place": "C1E01",
                        "designation": "Soufflet boite à niveau tunnel de lavage"
                    }
                },
                "02": {
                    "Joint plaque injection vapeur ~ C1E02 ~ 002575": {
                        "id": "202405160004",
                        "barcode": "002575",
                        "place": "C1E02",
                        "designation": "Joint plaque injection vapeur"
                    }
                },
                "03": {
                    "Joint étanchéité tunnel 12 extérieur ~ C1E03 ~ 001859": {
                        "id": "202008240002",
                        "barcode": "001859",
                        "place": "C1E03",
                        "designation": "Joint étanchéité tunnel 12 extérieur"
                    }
                },
                "04": {
                    "Joint étanchéité tunnel 12 entrée ou sortie ? ~ C1E04 ~ 002014": {
                        "id": "202108170002",
                        "barcode": "002014",
                        "place": "C1E04",
                        "designation": "Joint étanchéité tunnel 12 entrée ou sortie ?"
                    }
                },
                "05": {
                    "Bande C/C noir 1400X20X2 ~ C1E05 ~ 001921": {
                        "id": "202103010001",
                        "barcode": "001921",
                        "place": "C1E05",
                        "designation": "Bande C/C noir 1400X20X2"
                    }
                },
                "06": {
                    "Joint de vidange TL 31341657 ~ C1E06 ~ 000713": {
                        "id": "201903120044",
                        "barcode": "000713",
                        "place": "C1E06",
                        "designation": "Joint de vidange TL 31341657"
                    },
                    "Ressort complet de verin de vidange TL 31341657 ~ C1E06 ~ 002237": {
                        "id": "202207190001",
                        "barcode": "002237",
                        "place": "C1E06",
                        "designation": "Ressort complet de verin de vidange TL 31341657"
                    }
                },
                "07": {
                    "Joint Boîte à Niveau ~ C1E07 ~ 000720": {
                        "id": "201903120051",
                        "barcode": "000720",
                        "place": "C1E07",
                        "designation": "Joint Boîte à Niveau"
                    }
                },
                "08": {
                    "Joint de verin Boîte à Niveau ~ C1E08 ~ 002283": {
                        "id": "202210270003",
                        "barcode": "002283",
                        "place": "C1E08",
                        "designation": "Joint de verin Boîte à Niveau"
                    }
                },
                "09": {
                    "Ressort boîte à Niveau 40X3X100 ~ C1E09 ~ 000717": {
                        "id": "201903120048",
                        "barcode": "000717",
                        "place": "C1E09",
                        "designation": "Ressort boîte à Niveau 40X3X100"
                    },
                    "Ressort boîte à Niveau 55X3X100 ~ C1E09 ~ 000718": {
                        "id": "201903120049",
                        "barcode": "000718",
                        "place": "C1E09",
                        "designation": "Ressort boîte à Niveau 55X3X100"
                    }
                }
            },
            "F": {
                "Vanne de vidange complete ~ C1F ~ 002020": {
                    "id": "202108190002",
                    "barcode": "002020",
                    "place": "C1F",
                    "designation": "Vanne de vidange complete"
                }
            }
        },
        "2 Colonne": {
            "A": {
                "10": {
                    "Rouleau de tapis derriere alveole D100 L800 avec axe D20 ~ C2A10 ~ 000827": {
                        "id": "201903140052",
                        "barcode": "000827",
                        "place": "C2A10",
                        "designation": "Rouleau de tapis derriere alveole D100 L800 avec axe D20"
                    }
                },
                "11": {
                    "Rouleau de tapis derriere alvéole D20mm L900 ~ C2A11 ~ 000825": {
                        "id": "201903140050",
                        "barcode": "000825",
                        "place": "C2A11",
                        "designation": "Rouleau de tapis derriere alvéole D20mm L900"
                    }
                },
                "12": {
                    "Arbre entrainement principal AMPICKER ~ C2A12 ~ 000831": {
                        "id": "201903150001",
                        "barcode": "000831",
                        "place": "C2A12",
                        "designation": "Arbre entrainement principal AMPICKER"
                    }
                },
                "Arbre tapis derrière séchoir Lavatec ~ C2A ~ 001758": {
                    "id": "202003110006",
                    "barcode": "001758",
                    "place": "C2A",
                    "designation": "Arbre tapis derrière séchoir Lavatec"
                },
                "01": {
                    "Entretoise rouleau ~ C2A01 ~ 000674": {
                        "id": "201903120005",
                        "barcode": "000674",
                        "place": "C2A01",
                        "designation": "Entretoise rouleau"
                    }
                },
                "05": {
                    "Arbre de tunnel D65x650 mm ~ C2A05 ~ 001978": {
                        "id": "202107190003",
                        "barcode": "001978",
                        "place": "C2A05",
                        "designation": "Arbre de tunnel D65x650 mm"
                    }
                },
                "06": {
                    "Arbre rouleau de tapis sechoir lavatec ~ C2A06 ~ 002021": {
                        "id": "202108190003",
                        "barcode": "002021",
                        "place": "C2A06",
                        "designation": "Arbre rouleau de tapis sechoir lavatec"
                    }
                },
                "07": {
                    "Arbre tendeur de tapis sechoir lavatec ~ C2A07 ~ 002022": {
                        "id": "202108190004",
                        "barcode": "002022",
                        "place": "C2A07",
                        "designation": "Arbre tendeur de tapis sechoir lavatec"
                    }
                },
                "08": {
                    "Arbre moteur rouleau de tapis sechoir lavatec ~ C2A08 ~ 002217": {
                        "id": "202203150001",
                        "barcode": "002217",
                        "place": "C2A08",
                        "designation": "Arbre moteur rouleau de tapis sechoir lavatec"
                    }
                },
                "09": {
                    "Rouleau côté moteur tapis derriere alveole 12 D100 L900 avec axe d20 ~ C2A09 ~ 002210": {
                        "id": "202203140001",
                        "barcode": "002210",
                        "place": "C2A09",
                        "designation": "Rouleau côté moteur tapis derriere alveole 12 D100 L900 avec axe d20"
                    }
                }
            },
            "B": {
                "10": {
                    "Silent bloc (butée caoutchouc ou plot) d50mm H2 5mm M10-1 tige ~ C2B10 ~ 002276": {
                        "id": "202210190001",
                        "barcode": "002276",
                        "place": "C2B10",
                        "designation": "Silent bloc (butée caoutchouc ou plot) d50mm H2 5mm M10-1 tige"
                    }
                },
                "11": {
                    "Rotule diamètre 10mm M10X1.25 ~ C2B11 ~ 000710": {
                        "id": "201903120041",
                        "barcode": "000710",
                        "place": "C2B11",
                        "designation": "Rotule diamètre 10mm M10X1.25"
                    }
                },
                "12": {
                    "Rotule M10X150 LS pas à droite ~ C2B12 ~ 000220": {
                        "id": "201901180013",
                        "barcode": "000220",
                        "place": "C2B12",
                        "designation": "Rotule M10X150 LS pas à droite"
                    }
                },
                "13": {
                    "Chape arrière 20/25 typ RB ~ C2B13 ~ 000711": {
                        "id": "201903120042",
                        "barcode": "000711",
                        "place": "C2B13",
                        "designation": "Chape arrière 20/25 typ RB"
                    }
                },
                "01": {
                    "Support tendeur occasion ~ C2B01 ~ 000712": {
                        "id": "201903120043",
                        "barcode": "000712",
                        "place": "C2B01",
                        "designation": "Support tendeur occasion"
                    }
                },
                "02": {
                    "Rail double pour plateau coulissant AMPICKER (LAVATEC) ~ C2B02 ~ 002284": {
                        "id": "202210270004",
                        "barcode": "002284",
                        "place": "C2B02",
                        "designation": "Rail double pour plateau coulissant AMPICKER (LAVATEC)"
                    }
                },
                "03": {
                    "Plateau coulissant AMPICKER (Lavatec) ~ C2B03 ~ 000704": {
                        "id": "201903120035",
                        "barcode": "000704",
                        "place": "C2B03",
                        "designation": "Plateau coulissant AMPICKER (Lavatec)"
                    },
                    "Patin sur plateau coulissant AMPICKER (Lavatec) ~ C2B03 ~ 002299": {
                        "id": "202212050001",
                        "barcode": "002299",
                        "place": "C2B03",
                        "designation": "Patin sur plateau coulissant AMPICKER (Lavatec)"
                    }
                },
                "04": {
                    "Plaque grippe ampicker (refait bih) ~ C2B04 ~ 000705": {
                        "id": "201903120036",
                        "barcode": "000705",
                        "place": "C2B04",
                        "designation": "Plaque grippe ampicker (refait bih)"
                    }
                },
                "05": {
                    "Roulette ~ C2B05 ~ 000706": {
                        "id": "201903120037",
                        "barcode": "000706",
                        "place": "C2B05",
                        "designation": "Roulette"
                    }
                },
                "06": {
                    "Axe Concentrique de Roulette ~ C2B06 ~ 000707": {
                        "id": "201903120038",
                        "barcode": "000707",
                        "place": "C2B06",
                        "designation": "Axe Concentrique de Roulette"
                    }
                },
                "07": {
                    "Axe Excentrique de Roulette ~ C2B07 ~ 000708": {
                        "id": "201903120039",
                        "barcode": "000708",
                        "place": "C2B07",
                        "designation": "Axe Excentrique de Roulette"
                    }
                },
                "08": {
                    "Bague bronze AMPICKER ~ C2B08 ~ 000185": {
                        "id": "201901150007",
                        "barcode": "000185",
                        "place": "C2B08",
                        "designation": "Bague bronze AMPICKER"
                    }
                },
                "09": {
                    "Rotule MRFO-C 6x1/8'' ~ C2B09 ~ 000709": {
                        "id": "201903120040",
                        "barcode": "000709",
                        "place": "C2B09",
                        "designation": "Rotule MRFO-C 6x1/8''"
                    }
                }
            },
            "C": {
                "10": {
                    "Bavette goulotte bypass kannegiesser ~ C2C10 ~ 000555": {
                        "id": "201903070010",
                        "barcode": "000555",
                        "place": "C2C10",
                        "designation": "Bavette goulotte bypass kannegiesser"
                    }
                },
                "01": {
                    "Cable ~ C2C01 ~ 000547": {
                        "id": "201903070002",
                        "barcode": "000547",
                        "place": "C2C01",
                        "designation": "Cable"
                    }
                },
                "02": {
                    "Plaque bruleur séchoir kannegiesser ~ C2C02 ~ 000546": {
                        "id": "201903070001",
                        "barcode": "000546",
                        "place": "C2C02",
                        "designation": "Plaque bruleur séchoir kannegiesser"
                    },
                    "Kit de réparation pour plaques mixtes I bruleur séchoir kannegiesser ~ C2C02 ~ 002729": {
                        "id": "202511180001",
                        "barcode": "002729",
                        "place": "C2C02",
                        "designation": "Kit de réparation pour plaques mixtes I bruleur séchoir kannegiesser"
                    }
                },
                "03": {
                    "Sonde UV séchoir ~ C2C03 ~ 001926": {
                        "id": "202103160001",
                        "barcode": "001926",
                        "place": "C2C03",
                        "designation": "Sonde UV séchoir"
                    }
                },
                "04": {
                    "Joint d'étanchéité porte séchoir kannegiesser ~ C2C04 ~ 000548": {
                        "id": "201903070003",
                        "barcode": "000548",
                        "place": "C2C04",
                        "designation": "Joint d'étanchéité porte séchoir kannegiesser"
                    },
                    "Filtre fin + joint bruleur séchoir kannegiesser ~ C2C04 ~ 000549": {
                        "id": "201903070004",
                        "barcode": "000549",
                        "place": "C2C04",
                        "designation": "Filtre fin + joint bruleur séchoir kannegiesser"
                    }
                },
                "05": {
                    "Tourillon axe de rouleau de guidage ~ C2C05 ~ 002505": {
                        "id": "202311220003",
                        "barcode": "002505",
                        "place": "C2C05",
                        "designation": "Tourillon axe de rouleau de guidage"
                    },
                    "Rouleau de guidage ~ C2C05 ~ 002515": {
                        "id": "202312140001",
                        "barcode": "002515",
                        "place": "C2C05",
                        "designation": "Rouleau de guidage"
                    },
                    "Hublot bruleur séchoir occasion ~ C2C05 ~ 002730": {
                        "id": "202511190001",
                        "barcode": "002730",
                        "place": "C2C05",
                        "designation": "Hublot bruleur séchoir occasion"
                    }
                },
                "07": {
                    "Soupape 2/2 voies ~ C2C07 ~ 001851": {
                        "id": "202007290002",
                        "barcode": "001851",
                        "place": "C2C07",
                        "designation": "Soupape 2/2 voies"
                    }
                },
                "08": {
                    "Bougie bruleur séchoir occasion ~ C2C08 ~ 000553": {
                        "id": "201903070008",
                        "barcode": "000553",
                        "place": "C2C08",
                        "designation": "Bougie bruleur séchoir occasion"
                    },
                    "Cle de Bougie ~ C2C08 ~ 002526": {
                        "id": "202312290005",
                        "barcode": "002526",
                        "place": "C2C08",
                        "designation": "Cle de Bougie"
                    }
                },
                "09": {
                    "Pressostat gaz ÜBA50A2 ~ C2C09 ~ 000552": {
                        "id": "201903070007",
                        "barcode": "000552",
                        "place": "C2C09",
                        "designation": "Pressostat gaz ÜBA50A2"
                    },
                    "Pressostat gaz GW150 A5 ~ C2C09 ~ 002527": {
                        "id": "202312290006",
                        "barcode": "002527",
                        "place": "C2C09",
                        "designation": "Pressostat gaz GW150 A5"
                    }
                }
            },
            "D": {
                "10": {
                    "Tissu pour filtre ~ C2D10 ~ 000554": {
                        "id": "201903070009",
                        "barcode": "000554",
                        "place": "C2D10",
                        "designation": "Tissu pour filtre"
                    }
                },
                "01": {
                    "Filtre racleur séchoir Lavatec ~ C2D01 ~ 000217": {
                        "id": "201901180010",
                        "barcode": "000217",
                        "place": "C2D01",
                        "designation": "Filtre racleur séchoir Lavatec"
                    }
                },
                "02": {
                    "Support filtre peluche ~ C2D02 ~ 000567": {
                        "id": "201903070022",
                        "barcode": "000567",
                        "place": "C2D02",
                        "designation": "Support filtre peluche"
                    }
                },
                "03": {
                    "Roue entrainement avec pneu monté sur moyeu ~ C2D03 ~ 000556": {
                        "id": "201903070011",
                        "barcode": "000556",
                        "place": "C2D03",
                        "designation": "Roue entrainement avec pneu monté sur moyeu"
                    }
                },
                "04": {
                    "Moyeu pour pneu plein bandage 230/75-120RS séchoir Lavatec ~ C2D04 ~ 002366": {
                        "id": "202305040002",
                        "barcode": "002366",
                        "place": "C2D04",
                        "designation": "Moyeu pour pneu plein bandage 230/75-120RS séchoir Lavatec"
                    }
                },
                "05": {
                    "Pneu plein bandage 230/75-120RS séchoir Lavatec (a commander chez Lavatec) ~ C2D05 ~ 002013": {
                        "id": "202108170001",
                        "barcode": "002013",
                        "place": "C2D05",
                        "designation": "Pneu plein bandage 230/75-120RS séchoir Lavatec (a commander chez Lavatec)"
                    }
                },
                "06": {
                    "Roue libre avec pneu monté sur le moyeu ~ C2D06 ~ 000566": {
                        "id": "201903070021",
                        "barcode": "000566",
                        "place": "C2D06",
                        "designation": "Roue libre avec pneu monté sur le moyeu"
                    }
                }
            },
            "E": {
                "10": {
                    "Convertisseur 0-10V 24Vdc pour sonde PT100 ~ C2E10 ~ 002472": {
                        "id": "202309120001",
                        "barcode": "002472",
                        "place": "C2E10",
                        "designation": "Convertisseur 0-10V 24Vdc pour sonde PT100"
                    }
                },
                "11": {
                    "Socle boitier siemens ~ C2E11 ~ 000575": {
                        "id": "201903070030",
                        "barcode": "000575",
                        "place": "C2E11",
                        "designation": "Socle boitier siemens"
                    },
                    "Boitier d'allumage Siemens séchoir ~ C2E11 ~ 001687": {
                        "id": "201905230001",
                        "barcode": "001687",
                        "place": "C2E11",
                        "designation": "Boitier d'allumage Siemens séchoir"
                    }
                },
                "12": {
                    "Pressostat DL5K-3 20Z gaz utilisé pour l'air B22 doit être remplacé par dl3A-3z d'après Lavatec ~ C2E12 ~ 000570": {
                        "id": "201903070025",
                        "barcode": "000570",
                        "place": "C2E12",
                        "designation": "Pressostat DL5K-3 20Z gaz utilisé pour l'air B22 doit être remplacé par dl3A-3z d'après Lavatec"
                    }
                },
                "13": {
                    "Pressostat air DL3A-3Z ~ C2E13 ~ 000572": {
                        "id": "201903070027",
                        "barcode": "000572",
                        "place": "C2E13",
                        "designation": "Pressostat air DL3A-3Z"
                    }
                },
                "14": {
                    "Bougie d'allumage séchoir lavatec ~ C2E14 ~ 000564": {
                        "id": "201903070019",
                        "barcode": "000564",
                        "place": "C2E14",
                        "designation": "Bougie d'allumage séchoir lavatec"
                    },
                    "Cle de Bougie ~ C2E14 ~ 002525": {
                        "id": "202312290004",
                        "barcode": "002525",
                        "place": "C2E14",
                        "designation": "Cle de Bougie"
                    }
                },
                "15": {
                    "Arbre Excentrique Galet Tambour (ou déja sur le moyeu) ~ C2E15 ~ 000561": {
                        "id": "201903070016",
                        "barcode": "000561",
                        "place": "C2E15",
                        "designation": "Arbre Excentrique Galet Tambour (ou déja sur le moyeu)"
                    }
                },
                "16": {
                    "Relais Thermistance ~ C2E16 ~ 000189": {
                        "id": "201901150011",
                        "barcode": "000189",
                        "place": "C2E16",
                        "designation": "Relais Thermistance"
                    }
                },
                "17": {
                    "Sonde de ionisation ~ C2E17 ~ 000188": {
                        "id": "201901150010",
                        "barcode": "000188",
                        "place": "C2E17",
                        "designation": "Sonde de ionisation"
                    }
                },
                "18": {
                    "Vis grille M4X10 TFHC ~ C2E18 ~ 000562": {
                        "id": "201903070017",
                        "barcode": "000562",
                        "place": "C2E18",
                        "designation": "Vis grille M4X10 TFHC"
                    }
                },
                "19": {
                    "Aimant avec plaques ~ C2E19 ~ 000563": {
                        "id": "201903070018",
                        "barcode": "000563",
                        "place": "C2E19",
                        "designation": "Aimant avec plaques"
                    }
                },
                "20": {
                    "Electrovanne Gaz petit débit ~ C2E20 ~ 000576": {
                        "id": "201903070031",
                        "barcode": "000576",
                        "place": "C2E20",
                        "designation": "Electrovanne Gaz petit débit"
                    }
                },
                "01": {
                    "Filtre bruleur pour séchoir ~ C2E01 ~ 000278": {
                        "id": "201901230001",
                        "barcode": "000278",
                        "place": "C2E01",
                        "designation": "Filtre bruleur pour séchoir"
                    }
                },
                "02": {
                    "Sonde température B17 (Combistat sécurité) ~ C2E02 ~ 000568": {
                        "id": "201903070023",
                        "barcode": "000568",
                        "place": "C2E02",
                        "designation": "Sonde température B17 (Combistat sécurité)"
                    }
                },
                "03": {
                    "Sonde PT100 ~ C2E03 ~ 000569": {
                        "id": "201903070024",
                        "barcode": "000569",
                        "place": "C2E03",
                        "designation": "Sonde PT100"
                    }
                },
                "04": {
                    "Pressostat DG50U-3 ~ C2E04 ~ 002187": {
                        "id": "202201310002",
                        "barcode": "002187",
                        "place": "C2E04",
                        "designation": "Pressostat DG50U-3"
                    }
                },
                "05": {
                    "Sonde température 200°c (peut être remplacé par un 300 °C) ~ C2E05 ~ 001691": {
                        "id": "201906170002",
                        "barcode": "001691",
                        "place": "C2E05",
                        "designation": "Sonde température 200°c (peut être remplacé par un 300 °C)"
                    },
                    "Sonde température 300°c ~ C2E05 ~ 001692": {
                        "id": "201906170003",
                        "barcode": "001692",
                        "place": "C2E05",
                        "designation": "Sonde température 300°c"
                    }
                },
                "06": {
                    "Distributeur sprinkler ~ C2E06 ~ 000558": {
                        "id": "201903070013",
                        "barcode": "000558",
                        "place": "C2E06",
                        "designation": "Distributeur sprinkler"
                    }
                },
                "07": {
                    "Vanne pneumatique sprinkler ~ C2E07 ~ 000559": {
                        "id": "201903070014",
                        "barcode": "000559",
                        "place": "C2E07",
                        "designation": "Vanne pneumatique sprinkler"
                    }
                },
                "08": {
                    "Pressostat d'air ~ C2E08 ~ 000565": {
                        "id": "201903070020",
                        "barcode": "000565",
                        "place": "C2E08",
                        "designation": "Pressostat d'air"
                    }
                },
                "08 Bis": {
                    "Turbine séchoir lavatec ~ C2E08BIS ~ 000186": {
                        "id": "201901150008",
                        "barcode": "000186",
                        "place": "C2E08BIS",
                        "designation": "Turbine séchoir lavatec"
                    }
                },
                "09": {
                    "Electrovanne gaz ~ C2E09 ~ 000574": {
                        "id": "201903070029",
                        "barcode": "000574",
                        "place": "C2E09",
                        "designation": "Electrovanne gaz"
                    }
                }
            },
            "F": {
                "Clamp lanceur avec axe+ecarteur (rondelle) ~ C2F ~ 000752": {
                    "id": "201903130007",
                    "barcode": "000752",
                    "place": "C2F",
                    "designation": "Clamp lanceur avec axe+ecarteur (rondelle)"
                }
            }
        },
        "3 Colonne": {
            "A": {
                "10": {
                    "Rouleau drop GP D35 L880 ~ C3A10 ~ 002294": {
                        "id": "202211220001",
                        "barcode": "002294",
                        "place": "C3A10",
                        "designation": "Rouleau drop GP D35 L880"
                    }
                },
                "11": {
                    "Rouleau gomme entrainement tapis LP571-581 ~ C3A11 ~ 001113": {
                        "id": "201903260023",
                        "barcode": "001113",
                        "place": "C3A11",
                        "designation": "Rouleau gomme entrainement tapis LP571-581"
                    }
                },
                "12": {
                    "Rouleau de tapis derriere alveole D101.6 L788 avec axe D20 sur 153mm et D20 sur L=17mm ~ C3A12 ~ 002350": {
                        "id": "202303270004",
                        "barcode": "002350",
                        "place": "C3A12",
                        "designation": "Rouleau de tapis derriere alveole D101.6 L788 avec axe D20 sur 153mm et D20 sur L=17mm"
                    }
                },
                "13": {
                    "Rouleau de tapis derriere alveole D101.6 L788 avec axe D20 ~ C3A13 ~ 002349": {
                        "id": "202303270003",
                        "barcode": "002349",
                        "place": "C3A13",
                        "designation": "Rouleau de tapis derriere alveole D101.6 L788 avec axe D20"
                    }
                },
                "14": {
                    "Arbre tapis derrière alvéole 12 ~ C3A14 ~ 000168": {
                        "id": "201901140003",
                        "barcode": "000168",
                        "place": "C3A14",
                        "designation": "Arbre tapis derrière alvéole 12"
                    }
                },
                "15": {
                    "Arbre rouleau diamètre 35mm l:807mm pour engageuse GP ~ C3A15 ~ 002316": {
                        "id": "202301110002",
                        "barcode": "002316",
                        "place": "C3A15",
                        "designation": "Arbre rouleau diamètre 35mm l:807mm pour engageuse GP"
                    }
                },
                "16": {
                    "Arbre rouleau diamètre 35mm l:882mm pour engageuse GP ~ C3A16 ~ 002315": {
                        "id": "202301110001",
                        "barcode": "002315",
                        "place": "C3A16",
                        "designation": "Arbre rouleau diamètre 35mm l:882mm pour engageuse GP"
                    }
                },
                "17": {
                    "Rouleau tapis sortie GP D40 L562 ~ C3A17 ~ 000834": {
                        "id": "201903150004",
                        "barcode": "000834",
                        "place": "C3A17",
                        "designation": "Rouleau tapis sortie GP D40 L562"
                    }
                },
                "18": {
                    "Rouleau de tapis derriere alveole D100 L800 avec axe D20 ~ C3A18 ~ 002348": {
                        "id": "202303270002",
                        "barcode": "002348",
                        "place": "C3A18",
                        "designation": "Rouleau de tapis derriere alveole D100 L800 avec axe D20"
                    },
                    "Tendeur pour Rouleau de tapis derriere alveole ~ C3A18 ~ 002370": {
                        "id": "202305160001",
                        "barcode": "002370",
                        "place": "C3A18",
                        "designation": "Tendeur pour Rouleau de tapis derriere alveole"
                    }
                },
                "01": {
                    "Rouleau d'avaloir GP ~ C3A01 ~ 002189": {
                        "id": "202202020001",
                        "barcode": "002189",
                        "place": "C3A01",
                        "designation": "Rouleau d'avaloir GP"
                    }
                },
                "02": {
                    "Rouleau tendeur grand tapis vert Maximat d=51/2 rl=735 (occasion) ~ C3A02 ~ 000828": {
                        "id": "201903140053",
                        "barcode": "000828",
                        "place": "C3A02",
                        "designation": "Rouleau tendeur grand tapis vert Maximat d=51/2 rl=735 (occasion)"
                    }
                },
                "03": {
                    "Rouleau tendeur entrainement convoyeur arrivée draps ~ C3A03 ~ 000830": {
                        "id": "201903140055",
                        "barcode": "000830",
                        "place": "C3A03",
                        "designation": "Rouleau tendeur entrainement convoyeur arrivée draps"
                    }
                },
                "04": {
                    "Rouleau jensen avec centreur D50 L835 ~ C3A04 ~ 000836": {
                        "id": "201903150006",
                        "barcode": "000836",
                        "place": "C3A04",
                        "designation": "Rouleau jensen avec centreur D50 L835"
                    }
                },
                "05": {
                    "Arbre rouleau Maximat avec poulie incorporée(bande verte) ~ C3A05 ~ 000824": {
                        "id": "201903140049",
                        "barcode": "000824",
                        "place": "C3A05",
                        "designation": "Arbre rouleau Maximat avec poulie incorporée(bande verte)"
                    }
                },
                "06": {
                    "Rouleau D50 L510 ~ C3A06 ~ 000835": {
                        "id": "201903150005",
                        "barcode": "000835",
                        "place": "C3A06",
                        "designation": "Rouleau D50 L510"
                    }
                },
                "07": {
                    "Rouleau Kalfass ~ C3A07 ~ 000829": {
                        "id": "201903140054",
                        "barcode": "000829",
                        "place": "C3A07",
                        "designation": "Rouleau Kalfass"
                    }
                },
                "08": {
                    "Rouleau aiguillage sous étiqueteuse D50 L640 ~ C3A08 ~ 000833": {
                        "id": "201903150003",
                        "barcode": "000833",
                        "place": "C3A08",
                        "designation": "Rouleau aiguillage sous étiqueteuse D50 L640"
                    }
                },
                "09": {
                    "Rouleau drop GP D35 L805 ~ C3A09 ~ 000832": {
                        "id": "201903150002",
                        "barcode": "000832",
                        "place": "C3A09",
                        "designation": "Rouleau drop GP D35 L805"
                    }
                }
            },
            "B": {
                "10": {
                    "Rouleau de pression gommé cpl 5-9mm ~ C3B10 ~ 002124": {
                        "id": "202111150005",
                        "barcode": "002124",
                        "place": "C3B10",
                        "designation": "Rouleau de pression gommé cpl 5-9mm"
                    },
                    "Element de chauffage cpl 5/6mm ~ C3B10 ~ 002125": {
                        "id": "202111150006",
                        "barcode": "002125",
                        "place": "C3B10",
                        "designation": "Element de chauffage cpl 5/6mm"
                    },
                    "Pince droite complete 5/6mm ~ C3B10 ~ 002126": {
                        "id": "202111150007",
                        "barcode": "002126",
                        "place": "C3B10",
                        "designation": "Pince droite complete 5/6mm"
                    },
                    "Plaque de pression 5/9mm ~ C3B10 ~ 002127": {
                        "id": "202111150008",
                        "barcode": "002127",
                        "place": "C3B10",
                        "designation": "Plaque de pression 5/9mm"
                    },
                    "Ressort à tension ~ C3B10 ~ 002128": {
                        "id": "202111160001",
                        "barcode": "002128",
                        "place": "C3B10",
                        "designation": "Ressort à tension"
                    },
                    "Ressort gaine SMG S ~ C3B10 ~ 002129": {
                        "id": "202111160002",
                        "barcode": "002129",
                        "place": "C3B10",
                        "designation": "Ressort gaine SMG S"
                    },
                    "Ressort ~ C3B10 ~ 002130": {
                        "id": "202111160003",
                        "barcode": "002130",
                        "place": "C3B10",
                        "designation": "Ressort"
                    },
                    "Ressort à tension ~ C3B10 ~ 002132": {
                        "id": "202111160005",
                        "barcode": "002132",
                        "place": "C3B10",
                        "designation": "Ressort à tension"
                    },
                    "Ressort ~ C3B10 ~ 002133": {
                        "id": "202111160006",
                        "barcode": "002133",
                        "place": "C3B10",
                        "designation": "Ressort"
                    },
                    "Ressort ~ C3B10 ~ 002134": {
                        "id": "202111160007",
                        "barcode": "002134",
                        "place": "C3B10",
                        "designation": "Ressort"
                    },
                    "Ressort de tension ~ C3B10 ~ 002135": {
                        "id": "202111160008",
                        "barcode": "002135",
                        "place": "C3B10",
                        "designation": "Ressort de tension"
                    },
                    "Ressort pour couteau SMG ~ C3B10 ~ 002136": {
                        "id": "202111160009",
                        "barcode": "002136",
                        "place": "C3B10",
                        "designation": "Ressort pour couteau SMG"
                    },
                    "Vis pour couteau SMG ~ C3B10 ~ 002137": {
                        "id": "202111160010",
                        "barcode": "002137",
                        "place": "C3B10",
                        "designation": "Vis pour couteau SMG"
                    },
                    "Couteau 5-12mm ~ C3B10 ~ 002138": {
                        "id": "202111160011",
                        "barcode": "002138",
                        "place": "C3B10",
                        "designation": "Couteau 5-12mm"
                    },
                    "Ressort ~ C3B10 ~ 002139": {
                        "id": "202111160012",
                        "barcode": "002139",
                        "place": "C3B10",
                        "designation": "Ressort"
                    },
                    "Ventilateur de 60 X 60X 25 en 24Vdc 1.13W ~ C3B10 ~ 002247": {
                        "id": "202208180003",
                        "barcode": "002247",
                        "place": "C3B10",
                        "designation": "Ventilateur de 60 X 60X 25 en 24Vdc 1.13W"
                    },
                    "Tôle élastique ~ C3B10 ~ 002252": {
                        "id": "202209140001",
                        "barcode": "002252",
                        "place": "C3B10",
                        "designation": "Tôle élastique"
                    }
                },
                "11": {
                    "Bande collante soudure AP28/25 0.25X16X30 ~ C3B11 ~ 000777": {
                        "id": "201903140002",
                        "barcode": "000777",
                        "place": "C3B11",
                        "designation": "Bande collante soudure AP28/25 0.25X16X30"
                    },
                    "Teflon soudure 0.08X20X50 ~ C3B11 ~ 000786": {
                        "id": "201903140011",
                        "barcode": "000786",
                        "place": "C3B11",
                        "designation": "Teflon soudure 0.08X20X50"
                    }
                },
                "12": {
                    "Bande caoutchouc soudure largeur 16mm ~ C3B12 ~ 000779": {
                        "id": "201903140004",
                        "barcode": "000779",
                        "place": "C3B12",
                        "designation": "Bande caoutchouc soudure largeur 16mm"
                    }
                },
                "13": {
                    "Guide Teflon Anti Soudure refait ~ C3B13 ~ 000780": {
                        "id": "201903140005",
                        "barcode": "000780",
                        "place": "C3B13",
                        "designation": "Guide Teflon Anti Soudure refait"
                    },
                    "Guide Teflon Anti Soudure epaisseur total teflon auto collante 0.6mm ~ C3B13 ~ 002541": {
                        "id": "202401300001",
                        "barcode": "002541",
                        "place": "C3B13",
                        "designation": "Guide Teflon Anti Soudure epaisseur total teflon auto collante 0.6mm"
                    }
                },
                "14": {
                    "Lame de Chauffe Latéral neuf (couteau) ~ C3B14 ~ 000781": {
                        "id": "201903140006",
                        "barcode": "000781",
                        "place": "C3B14",
                        "designation": "Lame de Chauffe Latéral neuf (couteau)"
                    }
                },
                "15": {
                    "Support complet avec couteau lame de Chauffe Latéral (droite et gauche) ~ C3B15 ~ 002327": {
                        "id": "202301300002",
                        "barcode": "002327",
                        "place": "C3B15",
                        "designation": "Support complet avec couteau lame de Chauffe Latéral (droite et gauche)"
                    }
                },
                "01": {
                    "Cable bruleur ~ C3B01 ~ 000812": {
                        "id": "201903140037",
                        "barcode": "000812",
                        "place": "C3B01",
                        "designation": "Cable bruleur"
                    },
                    "Divers hydraulique Lapauw ~ C3B01 ~ 002318": {
                        "id": "202301160001",
                        "barcode": "002318",
                        "place": "C3B01",
                        "designation": "Divers hydraulique Lapauw"
                    }
                },
                "02": {
                    "Servomoteur ~ C3B02 ~ 000819": {
                        "id": "201903140044",
                        "barcode": "000819",
                        "place": "C3B02",
                        "designation": "Servomoteur"
                    }
                },
                "03": {
                    "Sonde bruleur Weihaupt et Rielo occasion ~ C3B03 ~ 000172": {
                        "id": "201901140007",
                        "barcode": "000172",
                        "place": "C3B03",
                        "designation": "Sonde bruleur Weihaupt et Rielo occasion"
                    },
                    "Boitier d'allumage pour bruleur Lapauw ~ C3B03 ~ 000810": {
                        "id": "201903140035",
                        "barcode": "000810",
                        "place": "C3B03",
                        "designation": "Boitier d'allumage pour bruleur Lapauw"
                    }
                },
                "04": {
                    "Pressostat d'air ~ C3B04 ~ 000811": {
                        "id": "201903140036",
                        "barcode": "000811",
                        "place": "C3B04",
                        "designation": "Pressostat d'air"
                    }
                },
                "05": {
                    "Bougie bruleur Rielo ~ C3B05 ~ 002449": {
                        "id": "202308100002",
                        "barcode": "002449",
                        "place": "C3B05",
                        "designation": "Bougie bruleur Rielo"
                    }
                },
                "06": {
                    "Bouchon de vidange pompe fluide caloporteur lapauw ~ C3B06 ~ 001764": {
                        "id": "202003170006",
                        "barcode": "001764",
                        "place": "C3B06",
                        "designation": "Bouchon de vidange pompe fluide caloporteur lapauw"
                    },
                    "Joint d'etancheite pompe fluide caloporteur lapauw ~ C3B06 ~ 001765": {
                        "id": "202003170007",
                        "barcode": "001765",
                        "place": "C3B06",
                        "designation": "Joint d'etancheite pompe fluide caloporteur lapauw"
                    }
                }
            },
            "C": {
                "10": {
                    "Limiteur de sécurité de température (HTT) 250°C ~ C3C10 ~ 000807": {
                        "id": "201903140032",
                        "barcode": "000807",
                        "place": "C3C10",
                        "designation": "Limiteur de sécurité de température (HTT) 250°C"
                    }
                },
                "11": {
                    "Codeur moteur ~ C3C11 ~ 000809": {
                        "id": "201903140034",
                        "barcode": "000809",
                        "place": "C3C11",
                        "designation": "Codeur moteur"
                    }
                },
                "12": {
                    "Interrupteur d'insuffissance d'huile ~ C3C12 ~ 000808": {
                        "id": "201903140033",
                        "barcode": "000808",
                        "place": "C3C12",
                        "designation": "Interrupteur d'insuffissance d'huile"
                    }
                },
                "13": {
                    "Commande en facade d'armoire unité d'exploitation d'allumage de bruleur calandre Kannegiesser ~ C3C13 ~ 002448": {
                        "id": "202308100001",
                        "barcode": "002448",
                        "place": "C3C13",
                        "designation": "Commande en facade d'armoire unité d'exploitation d'allumage de bruleur calandre Kannegiesser"
                    }
                },
                "14": {
                    "Boitier d'allumage HTT 93HT81b R214 09 110 ~ C3C14 ~ 001954": {
                        "id": "202104200005",
                        "barcode": "001954",
                        "place": "C3C14",
                        "designation": "Boitier d'allumage HTT 93HT81b R214 09 110"
                    }
                },
                "15": {
                    "Bouchons de reservoir calandre pour vidange du fluide caloporteur ~ C3C15 ~ 002355": {
                        "id": "202304110005",
                        "barcode": "002355",
                        "place": "C3C15",
                        "designation": "Bouchons de reservoir calandre pour vidange du fluide caloporteur"
                    }
                },
                "16": {
                    "Garniture mécanique pompe fluide caloporteur GP ~ C3C16 ~ 000479": {
                        "id": "201903050038",
                        "barcode": "000479",
                        "place": "C3C16",
                        "designation": "Garniture mécanique pompe fluide caloporteur GP"
                    },
                    "Couvercle avec joint de reservoir calandre ~ C3C16 ~ 001727": {
                        "id": "201912110002",
                        "barcode": "001727",
                        "place": "C3C16",
                        "designation": "Couvercle avec joint de reservoir calandre"
                    },
                    "Palier lisse 25/35x35 pompe fluide caloporteur lapauw ~ C3C16 ~ 001763": {
                        "id": "202003170005",
                        "barcode": "001763",
                        "place": "C3C16",
                        "designation": "Palier lisse 25/35x35 pompe fluide caloporteur lapauw"
                    },
                    "Joint cuivre 10x12 pompe fluide caloporteur lapauw ~ C3C16 ~ 001766": {
                        "id": "202003170008",
                        "barcode": "001766",
                        "place": "C3C16",
                        "designation": "Joint cuivre 10x12 pompe fluide caloporteur lapauw"
                    },
                    "Tresses pompe fluide caloporteur GP ~ C3C16 ~ 001876": {
                        "id": "202011130001",
                        "barcode": "001876",
                        "place": "C3C16",
                        "designation": "Tresses pompe fluide caloporteur GP"
                    },
                    "Roulement 6306 C3 pompe fluide caloporteur GP ET PP VOIR ROULEMENT pour stock ~ C3C16 ~ 001878": {
                        "id": "202011130003",
                        "barcode": "001878",
                        "place": "C3C16",
                        "designation": "Roulement 6306 C3 pompe fluide caloporteur GP ET PP VOIR ROULEMENT pour stock"
                    },
                    "Tresses pompe fluide caloporteur PP ~ C3C16 ~ 001879": {
                        "id": "202011130004",
                        "barcode": "001879",
                        "place": "C3C16",
                        "designation": "Tresses pompe fluide caloporteur PP"
                    },
                    "Joint 207x217x0,5 pompe fluide caloporteur GP et PP ~ C3C16 ~ 001880": {
                        "id": "202011130005",
                        "barcode": "001880",
                        "place": "C3C16",
                        "designation": "Joint 207x217x0,5 pompe fluide caloporteur GP et PP"
                    },
                    "Garniture mécanique pompe fluide caloporteur PP ~ C3C16 ~ 001907": {
                        "id": "202101290001",
                        "barcode": "001907",
                        "place": "C3C16",
                        "designation": "Garniture mécanique pompe fluide caloporteur PP"
                    },
                    "Garniture (joint de 60 ) pompe fluide caloporteur PP et GP ~ C3C16 ~ 001908": {
                        "id": "202101290002",
                        "barcode": "001908",
                        "place": "C3C16",
                        "designation": "Garniture (joint de 60 ) pompe fluide caloporteur PP et GP"
                    },
                    "Joint environ 90 carbone pompe fluide caloporteur PP et GP ~ C3C16 ~ 001909": {
                        "id": "202101290003",
                        "barcode": "001909",
                        "place": "C3C16",
                        "designation": "Joint environ 90 carbone pompe fluide caloporteur PP et GP"
                    },
                    "Joint renforcé DN40 PN10 pompe fluide caloporteur PP et GP ~ C3C16 ~ 001918": {
                        "id": "202102040008",
                        "barcode": "001918",
                        "place": "C3C16",
                        "designation": "Joint renforcé DN40 PN10 pompe fluide caloporteur PP et GP"
                    },
                    "Joint plat 28x21 pompe fluide caloporteur lapauw ~ C3C16 ~ 002167": {
                        "id": "202111180002",
                        "barcode": "002167",
                        "place": "C3C16",
                        "designation": "Joint plat 28x21 pompe fluide caloporteur lapauw"
                    },
                    "Joint plat 18x21 pompe fluide caloporteur lapauw ~ C3C16 ~ 002168": {
                        "id": "202111180003",
                        "barcode": "002168",
                        "place": "C3C16",
                        "designation": "Joint plat 18x21 pompe fluide caloporteur lapauw"
                    },
                    "Joint environ 90 carbone pompe fluide caloporteur PP et GP ~ C3C16 ~ 002265": {
                        "id": "202209160002",
                        "barcode": "002265",
                        "place": "C3C16",
                        "designation": "Joint environ 90 carbone pompe fluide caloporteur PP et GP"
                    }
                },
                "20": {
                    "Calandre collecteur d'impurete ~ C3C20 ~ 002053": {
                        "id": "202109280001",
                        "barcode": "002053",
                        "place": "C3C20",
                        "designation": "Calandre collecteur d'impurete"
                    }
                },
                "01": {
                    "Tuyau spiral DN125 longueur 600 ~ C3C01 ~ 000797": {
                        "id": "201903140022",
                        "barcode": "000797",
                        "place": "C3C01",
                        "designation": "Tuyau spiral DN125 longueur 600"
                    },
                    "Tuyau spiral dn125 longueur : 450mm ~ C3C01 ~ 002571": {
                        "id": "202405150001",
                        "barcode": "002571",
                        "place": "C3C01",
                        "designation": "Tuyau spiral dn125 longueur : 450mm"
                    }
                },
                "02": {
                    "Calandre sonde PT100 gaz résiduel ~ C3C02 ~ 000798": {
                        "id": "201903140023",
                        "barcode": "000798",
                        "place": "C3C02",
                        "designation": "Calandre sonde PT100 gaz résiduel"
                    }
                },
                "03": {
                    "Manomètre differentiel 0 0,6BAR (FISA) ~ C3C03 ~ 000799": {
                        "id": "201903140024",
                        "barcode": "000799",
                        "place": "C3C03",
                        "designation": "Manomètre differentiel 0 0,6BAR (FISA)"
                    }
                },
                "04": {
                    "Manomètre -1 à 1.5 bar pour pompe fluide caloporteur ~ C3C04 ~ 000800": {
                        "id": "201903140025",
                        "barcode": "000800",
                        "place": "C3C04",
                        "designation": "Manomètre -1 à 1.5 bar pour pompe fluide caloporteur"
                    },
                    "Manomètre 0 à 6 bar pour pompe fluide caloporteur ~ C3C04 ~ 000801": {
                        "id": "201903140026",
                        "barcode": "000801",
                        "place": "C3C04",
                        "designation": "Manomètre 0 à 6 bar pour pompe fluide caloporteur"
                    }
                },
                "05": {
                    "Manomètre 0 24 bar ~ C3C05 ~ 000802": {
                        "id": "201903140027",
                        "barcode": "000802",
                        "place": "C3C05",
                        "designation": "Manomètre 0 24 bar"
                    }
                },
                "06": {
                    "Thermostat ~ C3C06 ~ 000803": {
                        "id": "201903140028",
                        "barcode": "000803",
                        "place": "C3C06",
                        "designation": "Thermostat"
                    }
                },
                "07": {
                    "Sonde de température ~ C3C07 ~ 000804": {
                        "id": "201903140029",
                        "barcode": "000804",
                        "place": "C3C07",
                        "designation": "Sonde de température"
                    }
                },
                "08": {
                    "Sonde PT100 d'huile thermique ~ C3C08 ~ 000805": {
                        "id": "201903140030",
                        "barcode": "000805",
                        "place": "C3C08",
                        "designation": "Sonde PT100 d'huile thermique"
                    }
                },
                "09": {
                    "Limiteur de sécurité de température (HTT) P.gaz résiduel 400°C ~ C3C09 ~ 000806": {
                        "id": "201903140031",
                        "barcode": "000806",
                        "place": "C3C09",
                        "designation": "Limiteur de sécurité de température (HTT) P.gaz résiduel 400°C"
                    }
                }
            },
            "D": {
                "10": {
                    "Vérin électrique linéaire LINAK ~ C3D10 ~ 001718": {
                        "id": "201910160001",
                        "barcode": "001718",
                        "place": "C3D10",
                        "designation": "Vérin électrique linéaire LINAK"
                    }
                },
                "11": {
                    "Levier doigt PP ~ C3D11 ~ 000676": {
                        "id": "201903120007",
                        "barcode": "000676",
                        "place": "C3D11",
                        "designation": "Levier doigt PP"
                    }
                },
                "12": {
                    "Ressort doigt PP ~ C3D12 ~ 000677": {
                        "id": "201903120008",
                        "barcode": "000677",
                        "place": "C3D12",
                        "designation": "Ressort doigt PP"
                    }
                },
                "13": {
                    "Fermoir de pince ~ C3D13 ~ 000687": {
                        "id": "201903120018",
                        "barcode": "000687",
                        "place": "C3D13",
                        "designation": "Fermoir de pince"
                    }
                },
                "01": {
                    "Support pour volet de pliage PP ~ C3D01 ~ 001760": {
                        "id": "202003170002",
                        "barcode": "001760",
                        "place": "C3D01",
                        "designation": "Support pour volet de pliage PP"
                    }
                },
                "02": {
                    "Guide de ski plieuse napkin PP ~ C3D02 ~ 000585": {
                        "id": "201903070040",
                        "barcode": "000585",
                        "place": "C3D02",
                        "designation": "Guide de ski plieuse napkin PP"
                    }
                },
                "03": {
                    "Chariot pour doigt d'empileur L=755mm l=812.5mm + un d'occasion ~ C3D03 ~ 002346": {
                        "id": "202303230001",
                        "barcode": "002346",
                        "place": "C3D03",
                        "designation": "Chariot pour doigt d'empileur L=755mm l=812.5mm + un d'occasion"
                    }
                },
                "04": {
                    "Guide vert table de plieuse napkin PP L=1500mm ~ C3D04 ~ 002036": {
                        "id": "202109130001",
                        "barcode": "002036",
                        "place": "C3D04",
                        "designation": "Guide vert table de plieuse napkin PP L=1500mm"
                    }
                },
                "05": {
                    "Table d'empilage L=790mm ~ C3D05 ~ 000697": {
                        "id": "201903120028",
                        "barcode": "000697",
                        "place": "C3D05",
                        "designation": "Table d'empilage L=790mm"
                    }
                },
                "06": {
                    "Table Model 400 L=275mm ~ C3D06 ~ 002692": {
                        "id": "202508280002",
                        "barcode": "002692",
                        "place": "C3D06",
                        "designation": "Table Model 400 L=275mm"
                    }
                }
            },
            "E": {
                "10": {
                    "Tendeur GP (tension Bracket) ~ C3E10 ~ 000688": {
                        "id": "201903120019",
                        "barcode": "000688",
                        "place": "C3E10",
                        "designation": "Tendeur GP (tension Bracket)"
                    }
                },
                "11": {
                    "Chariot de centrage GP COTE DROIT ~ C3E11 ~ 000693": {
                        "id": "201903120024",
                        "barcode": "000693",
                        "place": "C3E11",
                        "designation": "Chariot de centrage GP COTE DROIT"
                    },
                    "Chariot de centrage GP COTE GAUCHE ~ C3E11 ~ 000694": {
                        "id": "201903120025",
                        "barcode": "000694",
                        "place": "C3E11",
                        "designation": "Chariot de centrage GP COTE GAUCHE"
                    }
                },
                "12": {
                    "Volet pour aspiration engageuse GP ~ C3E12 ~ 001912": {
                        "id": "202102040002",
                        "barcode": "001912",
                        "place": "C3E12",
                        "designation": "Volet pour aspiration engageuse GP"
                    }
                },
                "13": {
                    "Support et roulette pp et gp ~ C3E13 ~ 001715": {
                        "id": "201910030001",
                        "barcode": "001715",
                        "place": "C3E13",
                        "designation": "Support et roulette pp et gp"
                    }
                },
                "14": {
                    "Courroie frein empileur 495X40mm perforations J ~ C3E14 ~ 000690": {
                        "id": "201903120021",
                        "barcode": "000690",
                        "place": "C3E14",
                        "designation": "Courroie frein empileur 495X40mm perforations J"
                    }
                },
                "15": {
                    "Crémaillere empileur GP PP Lapauw L=270mm ~ C3E15 ~ 001787": {
                        "id": "202004060004",
                        "barcode": "001787",
                        "place": "C3E15",
                        "designation": "Crémaillere empileur GP PP Lapauw L=270mm"
                    },
                    "Roue dentée pour crémaillere empileur GP PP Resident L=270mm ~ C3E15 ~ 001788": {
                        "id": "202004060005",
                        "barcode": "001788",
                        "place": "C3E15",
                        "designation": "Roue dentée pour crémaillere empileur GP PP Resident L=270mm"
                    }
                },
                "16": {
                    "Filtre de bourre GP (fait a la mesure par le magasin ) ~ C3E16 ~ 001716": {
                        "id": "201910100001",
                        "barcode": "001716",
                        "place": "C3E16",
                        "designation": "Filtre de bourre GP (fait a la mesure par le magasin )"
                    }
                },
                "17": {
                    "Roue codeuse GP-PP neuve NW48 ~ C3E17 ~ 000691": {
                        "id": "201903120022",
                        "barcode": "000691",
                        "place": "C3E17",
                        "designation": "Roue codeuse GP-PP neuve NW48"
                    },
                    "Roulements codeur SKF pour roue codeuse GP PP ~ C3E17 ~ 000692": {
                        "id": "201903120023",
                        "barcode": "000692",
                        "place": "C3E17",
                        "designation": "Roulements codeur SKF pour roue codeuse GP PP"
                    },
                    "Codeur baumer thalheim ~ C3E17 ~ 000733": {
                        "id": "201903120064",
                        "barcode": "000733",
                        "place": "C3E17",
                        "designation": "Codeur baumer thalheim"
                    },
                    "Bande de roulement pour Roue codeuse GP-PP occasion ~ C3E17 ~ 001614": {
                        "id": "201905020005",
                        "barcode": "001614",
                        "place": "C3E17",
                        "designation": "Bande de roulement pour Roue codeuse GP-PP occasion"
                    },
                    "Roue codeuse GP PP ~ C3E17 ~ 001979": {
                        "id": "202107270001",
                        "barcode": "001979",
                        "place": "C3E17",
                        "designation": "Roue codeuse GP PP"
                    },
                    "Support de roue codeuse GP PP ~ C3E17 ~ 002049": {
                        "id": "202109220001",
                        "barcode": "002049",
                        "place": "C3E17",
                        "designation": "Support de roue codeuse GP PP"
                    }
                },
                "01": {
                    "Coussinet plieuse GP ~ C3E01 ~ 000689": {
                        "id": "201903120020",
                        "barcode": "000689",
                        "place": "C3E01",
                        "designation": "Coussinet plieuse GP"
                    }
                },
                "02": {
                    "Rotary block - EN-FOLD ~ C3E02 ~ 000686": {
                        "id": "201903120017",
                        "barcode": "000686",
                        "place": "C3E02",
                        "designation": "Rotary block - EN-FOLD"
                    }
                },
                "03": {
                    "Coussinet ~ C3E03 ~ 000680": {
                        "id": "201903120011",
                        "barcode": "000680",
                        "place": "C3E03",
                        "designation": "Coussinet"
                    }
                },
                "04": {
                    "Poulie guide chariot de pinces ~ C3E04 ~ 000678": {
                        "id": "201903120009",
                        "barcode": "000678",
                        "place": "C3E04",
                        "designation": "Poulie guide chariot de pinces"
                    }
                },
                "05": {
                    "Anneau caoutchouc ~ C3E05 ~ 000681": {
                        "id": "201903120012",
                        "barcode": "000681",
                        "place": "C3E05",
                        "designation": "Anneau caoutchouc"
                    },
                    "Axe pour clamp lanceur ~ C3E05 ~ 002568": {
                        "id": "202405100001",
                        "barcode": "002568",
                        "place": "C3E05",
                        "designation": "Axe pour clamp lanceur"
                    },
                    "Ecarteur pour clamp lanceur ~ C3E05 ~ 002569": {
                        "id": "202405100002",
                        "barcode": "002569",
                        "place": "C3E05",
                        "designation": "Ecarteur pour clamp lanceur"
                    },
                    "Roulement aiguille NA 6901 pour clamp lanceur ~ C3E05 ~ 002570": {
                        "id": "202405100003",
                        "barcode": "002570",
                        "place": "C3E05",
                        "designation": "Roulement aiguille NA 6901 pour clamp lanceur"
                    }
                },
                "06": {
                    "Fusée essieu ~ C3E06 ~ 000682": {
                        "id": "201903120013",
                        "barcode": "000682",
                        "place": "C3E06",
                        "designation": "Fusée essieu"
                    }
                },
                "07": {
                    "Rouleau pour pince L:27MM ~ C3E07 ~ 000684": {
                        "id": "201903120015",
                        "barcode": "000684",
                        "place": "C3E07",
                        "designation": "Rouleau pour pince L:27MM"
                    },
                    "Rouleau pour pince L:33MM ~ C3E07 ~ 000685": {
                        "id": "201903120016",
                        "barcode": "000685",
                        "place": "C3E07",
                        "designation": "Rouleau pour pince L:33MM"
                    },
                    "Vis femelle TETE BOMBEE BTR M6x15mm pince GPb ( vis femelle + tige filetée + vis femelle monté sur machine) ~ C3E07 ~ 002281": {
                        "id": "202210270001",
                        "barcode": "002281",
                        "place": "C3E07",
                        "designation": "Vis femelle TETE BOMBEE BTR M6x15mm pince GPb ( vis femelle + tige filetée + vis femelle monté sur machine)"
                    },
                    "Tige filetée 6X50 din 916 hfc 710 pour vis femelle TETE BOMBEE BTR M6 X 15mm pince GP (vis femelle + tige filetée longueur 50mm + vis femelle monté sur machine) ~ C3E07 ~ 002508": {
                        "id": "202311280001",
                        "barcode": "002508",
                        "place": "C3E07",
                        "designation": "Tige filetée 6X50 din 916 hfc 710 pour vis femelle TETE BOMBEE BTR M6 X 15mm pince GP (vis femelle + tige filetée longueur 50mm + vis femelle monté sur machine)"
                    }
                },
                "08": {
                    "Axe engageuse GP ~ C3E08 ~ 000683": {
                        "id": "201903120014",
                        "barcode": "000683",
                        "place": "C3E08",
                        "designation": "Axe engageuse GP"
                    }
                },
                "09": {
                    "Poulie Tendeur GP ~ C3E09 ~ 000679": {
                        "id": "201903120010",
                        "barcode": "000679",
                        "place": "C3E09",
                        "designation": "Poulie Tendeur GP"
                    },
                    "Tendeur de courroie GP ~ C3E09 ~ 002282": {
                        "id": "202210270002",
                        "barcode": "002282",
                        "place": "C3E09",
                        "designation": "Tendeur de courroie GP"
                    }
                }
            },
            "F": {
                "Toile d'entretien secheuse PP GP (gratounet)180X160 ~ C3F ~ 000617": {
                    "id": "201903080002",
                    "barcode": "000617",
                    "place": "C3F",
                    "designation": "Toile d'entretien secheuse PP GP (gratounet)180X160"
                },
                "Toile PY pour cire 180X100 ~ C3F ~ 000618": {
                    "id": "201903080003",
                    "barcode": "000618",
                    "place": "C3F",
                    "designation": "Toile PY pour cire 180X100"
                },
                "Volet court (TWIN) sans réflecteur (largeur 31cm ) ~ C3F ~ 000753": {
                    "id": "201903130008",
                    "barcode": "000753",
                    "place": "C3F",
                    "designation": "Volet court (TWIN) sans réflecteur (largeur 31cm )"
                },
                "Volet long (tt600) empilage avec réflecteur (largeur 35cm ) ~ C3F ~ 000754": {
                    "id": "201903130009",
                    "barcode": "000754",
                    "place": "C3F",
                    "designation": "Volet long (tt600) empilage avec réflecteur (largeur 35cm )"
                },
                "Volet pliage classic (pick drop) ~ C3F ~ 001771": {
                    "id": "202003230002",
                    "barcode": "001771",
                    "place": "C3F",
                    "designation": "Volet pliage classic (pick drop)"
                },
                "Mousse de pliage pick drop 60X20X1000mm ~ C3F ~ 001772": {
                    "id": "202003230003",
                    "barcode": "001772",
                    "place": "C3F",
                    "designation": "Mousse de pliage pick drop 60X20X1000mm"
                },
                "Lame de pli cross C ~ C3F ~ 002019": {
                    "id": "202108190001",
                    "barcode": "002019",
                    "place": "C3F",
                    "designation": "Lame de pli cross C"
                },
                "Volet court (TWIN) avec réflecteur (largeur 31cm ) ~ C3F ~ 002555": {
                    "id": "202403280001",
                    "barcode": "002555",
                    "place": "C3F",
                    "designation": "Volet court (TWIN) avec réflecteur (largeur 31cm )"
                },
                "Volet long (tt600) empilage sans réflecteur (largeur 35cm ) ~ C3F ~ 002556": {
                    "id": "202403280002",
                    "barcode": "002556",
                    "place": "C3F",
                    "designation": "Volet long (tt600) empilage sans réflecteur (largeur 35cm )"
                }
            }
        }
    },
    "Rangée D": {
        "1 Colonne": {
            "A": {
                "10": {
                    "Palier lcte05 ~ D1A10 ~ 001047": {
                        "id": "201903210020",
                        "barcode": "001047",
                        "place": "D1A10",
                        "designation": "Palier lcte05"
                    }
                },
                "11": {
                    "Palier fltc25 ~ D1A11 ~ 001042": {
                        "id": "201903210015",
                        "barcode": "001042",
                        "place": "D1A11",
                        "designation": "Palier fltc25"
                    },
                    "Palier flcte 25 + roulement SKF 1204 l=49mm ~ D1A11 ~ 001899": {
                        "id": "202101070001",
                        "barcode": "001899",
                        "place": "D1A11",
                        "designation": "Palier flcte 25 + roulement SKF 1204 l=49mm"
                    }
                },
                "12": {
                    "Palier fd 205 ~ D1A12 ~ 001051": {
                        "id": "201903210024",
                        "barcode": "001051",
                        "place": "D1A12",
                        "designation": "Palier fd 205"
                    }
                },
                "13": {
                    "Roulement GE 30KRRB pour palier she06e ~ D1A13 ~ 001033": {
                        "id": "201903210006",
                        "barcode": "001033",
                        "place": "D1A13",
                        "designation": "Roulement GE 30KRRB pour palier she06e"
                    },
                    "Palier she06e pour roulement GE 30KRRB ~ D1A13 ~ 002037": {
                        "id": "202109140001",
                        "barcode": "002037",
                        "place": "D1A13",
                        "designation": "Palier she06e pour roulement GE 30KRRB"
                    }
                },
                "14": {
                    "Palier ucf206 ~ D1A14 ~ 002038": {
                        "id": "202109140002",
                        "barcode": "002038",
                        "place": "D1A14",
                        "designation": "Palier ucf206"
                    },
                    "Roulement 22208 ~ D1A14 ~ 002734": {
                        "id": "202511210001",
                        "barcode": "002734",
                        "place": "D1A14",
                        "designation": "Roulement 22208"
                    }
                },
                "15": {
                    "Bagues pour palier se509 ~ D1A15 ~ 001797": {
                        "id": "202004080002",
                        "barcode": "001797",
                        "place": "D1A15",
                        "designation": "Bagues pour palier se509"
                    },
                    "Palier SKF SE509 + joint Ulock seals U509 (1 pair) vendu avec ~ D1A15 ~ 001798": {
                        "id": "202004080003",
                        "barcode": "001798",
                        "place": "D1A15",
                        "designation": "Palier SKF SE509 + joint Ulock seals U509 (1 pair) vendu avec"
                    },
                    "Manchon de serrage H309 ~ D1A15 ~ 001799": {
                        "id": "202004080004",
                        "barcode": "001799",
                        "place": "D1A15",
                        "designation": "Manchon de serrage H309"
                    },
                    "Roulement SKF 22209 EK ~ D1A15 ~ 001800": {
                        "id": "202004080005",
                        "barcode": "001800",
                        "place": "D1A15",
                        "designation": "Roulement SKF 22209 EK"
                    }
                },
                "16": {
                    "Roulement FAH 22215-E1-XL-K et circlips (occasion) ~ D1A16 ~ 000699": {
                        "id": "201903120030",
                        "barcode": "000699",
                        "place": "D1A16",
                        "designation": "Roulement FAH 22215-E1-XL-K et circlips (occasion)"
                    },
                    "Bague de serrage galet/arbre (occasion ) ~ D1A16 ~ 001976": {
                        "id": "202107190001",
                        "barcode": "001976",
                        "place": "D1A16",
                        "designation": "Bague de serrage galet/arbre (occasion )"
                    },
                    "Douille de serrage H315 pour palier (occasion) ~ D1A16 ~ 002017": {
                        "id": "202108180003",
                        "barcode": "002017",
                        "place": "D1A16",
                        "designation": "Douille de serrage H315 pour palier (occasion)"
                    },
                    "Bague de serrage galet/arbre (occasion ) ~ D1A16 ~ 002028": {
                        "id": "202109010002",
                        "barcode": "002028",
                        "place": "D1A16",
                        "designation": "Bague de serrage galet/arbre (occasion )"
                    }
                },
                "17": {
                    "Manchon de serrage H315 pour palier ~ D1A17 ~ 000700": {
                        "id": "201903120031",
                        "barcode": "000700",
                        "place": "D1A17",
                        "designation": "Manchon de serrage H315 pour palier"
                    },
                    "Roulement FAH 22215-E1-XL-K ~ D1A17 ~ 002015": {
                        "id": "202108180001",
                        "barcode": "002015",
                        "place": "D1A17",
                        "designation": "Roulement FAH 22215-E1-XL-K"
                    },
                    "Palier seul entrainement pour axe 65mm ~ D1A17 ~ 002016": {
                        "id": "202108180002",
                        "barcode": "002016",
                        "place": "D1A17",
                        "designation": "Palier seul entrainement pour axe 65mm"
                    },
                    "Bague de serrage galet/arbre ~ D1A17 ~ 002018": {
                        "id": "202108180004",
                        "barcode": "002018",
                        "place": "D1A17",
                        "designation": "Bague de serrage galet/arbre"
                    },
                    "Palier libre complet entrainement pour axe 65mm ~ D1A17 ~ 002034": {
                        "id": "202109060001",
                        "barcode": "002034",
                        "place": "D1A17",
                        "designation": "Palier libre complet entrainement pour axe 65mm"
                    },
                    "Palier fixe complet entrainement pour axe 65mm ~ D1A17 ~ 002035": {
                        "id": "202109060002",
                        "barcode": "002035",
                        "place": "D1A17",
                        "designation": "Palier fixe complet entrainement pour axe 65mm"
                    },
                    "Joint ses va-065 ~ D1A17 ~ 002039": {
                        "id": "202109140003",
                        "barcode": "002039",
                        "place": "D1A17",
                        "designation": "Joint ses va-065"
                    }
                },
                "18": {
                    "Palier entrainement pour axe 65mm ( occasions) ~ D1A18 ~ 000698": {
                        "id": "201903120029",
                        "barcode": "000698",
                        "place": "D1A18",
                        "designation": "Palier entrainement pour axe 65mm ( occasions)"
                    }
                },
                "01": {
                    "Palier P52 pour rlt YAR 205 ~ D1A01 ~ 001029": {
                        "id": "201903210002",
                        "barcode": "001029",
                        "place": "D1A01",
                        "designation": "Palier P52 pour rlt YAR 205"
                    }
                },
                "02": {
                    "Palier INA 03.52 MST ~ D1A02 ~ 001039": {
                        "id": "201903210012",
                        "barcode": "001039",
                        "place": "D1A02",
                        "designation": "Palier INA 03.52 MST"
                    }
                },
                "03": {
                    "Palier UBPFL 203 avec roulement NSK ~ D1A03 ~ 001045": {
                        "id": "201903210018",
                        "barcode": "001045",
                        "place": "D1A03",
                        "designation": "Palier UBPFL 203 avec roulement NSK"
                    }
                },
                "04": {
                    "Palier fl002 ~ D1A04 ~ 001040": {
                        "id": "201903210013",
                        "barcode": "001040",
                        "place": "D1A04",
                        "designation": "Palier fl002"
                    }
                },
                "05": {
                    "Palier fl004 ~ D1A05 ~ 001041": {
                        "id": "201903210014",
                        "barcode": "001041",
                        "place": "D1A05",
                        "designation": "Palier fl004"
                    }
                },
                "06": {
                    "Palier UFL005 E FYH ~ D1A06 ~ 001043": {
                        "id": "201903210016",
                        "barcode": "001043",
                        "place": "D1A06",
                        "designation": "Palier UFL005 E FYH"
                    }
                },
                "07": {
                    "Palier rlctea (lftc20) ~ D1A07 ~ 001044": {
                        "id": "201903210017",
                        "barcode": "001044",
                        "place": "D1A07",
                        "designation": "Palier rlctea (lftc20)"
                    }
                },
                "08": {
                    "Palier lcte04 avec roulement ucfl AH204 ~ D1A08 ~ 001046": {
                        "id": "201903210019",
                        "barcode": "001046",
                        "place": "D1A08",
                        "designation": "Palier lcte04 avec roulement ucfl AH204"
                    }
                },
                "09": {
                    "Palier fl 204 ~ D1A09 ~ 001049": {
                        "id": "201903210022",
                        "barcode": "001049",
                        "place": "D1A09",
                        "designation": "Palier fl 204"
                    }
                }
            },
            "B": {
                "10": {
                    "Roulements à billes 16003 ~ D1B10 ~ 001019": {
                        "id": "201903200048",
                        "barcode": "001019",
                        "place": "D1B10",
                        "designation": "Roulements à billes 16003"
                    }
                },
                "11": {
                    "Roulements à billes 16100 ~ D1B11 ~ 001017": {
                        "id": "201903200046",
                        "barcode": "001017",
                        "place": "D1B11",
                        "designation": "Roulements à billes 16100"
                    }
                },
                "12": {
                    "Roulements à billes 61800 2rs pour roll on ~ D1B12 ~ 001843": {
                        "id": "202007080001",
                        "barcode": "001843",
                        "place": "D1B12",
                        "designation": "Roulements à billes 61800 2rs pour roll on"
                    }
                },
                "13": {
                    "Roulements à billes 61801 2rs ~ D1B13 ~ 001018": {
                        "id": "201903200047",
                        "barcode": "001018",
                        "place": "D1B13",
                        "designation": "Roulements à billes 61801 2rs"
                    }
                },
                "14": {
                    "Roulements 61902 2rs ~ D1B14 ~ 001021": {
                        "id": "201903200050",
                        "barcode": "001021",
                        "place": "D1B14",
                        "designation": "Roulements 61902 2rs"
                    }
                },
                "15": {
                    "Roulements 5011021 stiber NSS 12 ~ D1B15 ~ 001022": {
                        "id": "201903200051",
                        "barcode": "001022",
                        "place": "D1B15",
                        "designation": "Roulements 5011021 stiber NSS 12"
                    }
                },
                "16": {
                    "Axe écrou ~ D1B16 ~ 001023": {
                        "id": "201903200052",
                        "barcode": "001023",
                        "place": "D1B16",
                        "designation": "Axe écrou"
                    }
                },
                "17": {
                    "Axe écrou ~ D1B17 ~ 001024": {
                        "id": "201903200053",
                        "barcode": "001024",
                        "place": "D1B17",
                        "designation": "Axe écrou"
                    }
                },
                "18": {
                    "Axe écrou ~ D1B18 ~ 001025": {
                        "id": "201903200054",
                        "barcode": "001025",
                        "place": "D1B18",
                        "designation": "Axe écrou"
                    }
                },
                "19": {
                    "Axe écrou non référencé ~ D1B19 ~ 001026": {
                        "id": "201903200055",
                        "barcode": "001026",
                        "place": "D1B19",
                        "designation": "Axe écrou non référencé"
                    }
                },
                "20": {
                    "Axe écrou ~ D1B20 ~ 001027": {
                        "id": "201903200056",
                        "barcode": "001027",
                        "place": "D1B20",
                        "designation": "Axe écrou"
                    }
                },
                "21": {
                    "Axe écrou de 22 ~ D1B21 ~ 002317": {
                        "id": "202301110003",
                        "barcode": "002317",
                        "place": "D1B21",
                        "designation": "Axe écrou de 22"
                    }
                },
                "22": {
                    "Roulement Su 005 zen ~ D1B22 ~ 001037": {
                        "id": "201903210010",
                        "barcode": "001037",
                        "place": "D1B22",
                        "designation": "Roulement Su 005 zen"
                    }
                },
                "23": {
                    "Roulement Su004 gsh 20 rrb ~ D1B23 ~ 001035": {
                        "id": "201903210008",
                        "barcode": "001035",
                        "place": "D1B23",
                        "designation": "Roulement Su004 gsh 20 rrb"
                    }
                },
                "24": {
                    "Roulement rae 25 nppb ~ D1B24 ~ 001034": {
                        "id": "201903210007",
                        "barcode": "001034",
                        "place": "D1B24",
                        "designation": "Roulement rae 25 nppb"
                    }
                },
                "25": {
                    "Roulement yet 203 ~ D1B25 ~ 001038": {
                        "id": "201903210011",
                        "barcode": "001038",
                        "place": "D1B25",
                        "designation": "Roulement yet 203"
                    }
                },
                "26": {
                    "Palier a bride Alu U006 + FL06-7 ~ D1B26 ~ 002310": {
                        "id": "202212300001",
                        "barcode": "002310",
                        "place": "D1B26",
                        "designation": "Palier a bride Alu U006 + FL06-7"
                    }
                },
                "27": {
                    "Roulement ASS206 ~ D1B27 ~ 001030": {
                        "id": "201903210003",
                        "barcode": "001030",
                        "place": "D1B27",
                        "designation": "Roulement ASS206"
                    }
                },
                "28": {
                    "Roulements LR207 NPPU ~ D1B28 ~ 001020": {
                        "id": "201903200049",
                        "barcode": "001020",
                        "place": "D1B28",
                        "designation": "Roulements LR207 NPPU"
                    }
                },
                "29": {
                    "Roulements US.207.G2 pour palier NTN SNR FD2 bande entrée calandre ~ D1B29 ~ 002238": {
                        "id": "202207220001",
                        "barcode": "002238",
                        "place": "D1B29",
                        "designation": "Roulements US.207.G2 pour palier NTN SNR FD2 bande entrée calandre"
                    },
                    "Roulements 1726207-2RS1 bande entrée calandre ~ D1B29 ~ 002269": {
                        "id": "202209220001",
                        "barcode": "002269",
                        "place": "D1B29",
                        "designation": "Roulements 1726207-2RS1 bande entrée calandre"
                    },
                    "Palier NTN SNR FD2 pour roulements US.207.G2 bande entrée calandre ~ D1B29 ~ 002270": {
                        "id": "202209220002",
                        "barcode": "002270",
                        "place": "D1B29",
                        "designation": "Palier NTN SNR FD2 pour roulements US.207.G2 bande entrée calandre"
                    },
                    "Roulements cs207llu bande entrée calandre identique 1726207-2RS1 ~ D1B29 ~ 002285": {
                        "id": "202210280001",
                        "barcode": "002285",
                        "place": "D1B29",
                        "designation": "Roulements cs207llu bande entrée calandre identique 1726207-2RS1"
                    }
                },
                "30": {
                    "Roulement rale 25 nppb ~ D1B30 ~ 001032": {
                        "id": "201903210005",
                        "barcode": "001032",
                        "place": "D1B30",
                        "designation": "Roulement rale 25 nppb"
                    }
                },
                "31": {
                    "Butée à aiguilles AXK 1024 a ~ D1B31 ~ 001031": {
                        "id": "201903210004",
                        "barcode": "001031",
                        "place": "D1B31",
                        "designation": "Butée à aiguilles AXK 1024 a"
                    }
                },
                "32": {
                    "Roulement YAR 205-2F (vis de pression) ~ D1B32 ~ 001028": {
                        "id": "201903210001",
                        "barcode": "001028",
                        "place": "D1B32",
                        "designation": "Roulement YAR 205-2F (vis de pression)"
                    }
                },
                "01": {
                    "Roulements à billes 6205 2rs ~ D1B01 ~ 001008": {
                        "id": "201903200037",
                        "barcode": "001008",
                        "place": "D1B01",
                        "designation": "Roulements à billes 6205 2rs"
                    }
                },
                "02": {
                    "Roulements à billes 6206 ft150 ~ D1B02 ~ 001009": {
                        "id": "201903200038",
                        "barcode": "001009",
                        "place": "D1B02",
                        "designation": "Roulements à billes 6206 ft150"
                    }
                },
                "03": {
                    "Roulements à billes 6207 zz ~ D1B03 ~ 001010": {
                        "id": "201903200039",
                        "barcode": "001010",
                        "place": "D1B03",
                        "designation": "Roulements à billes 6207 zz"
                    }
                },
                "04": {
                    "Roulements à billes 6208 2rs ~ D1B04 ~ 001011": {
                        "id": "201903200040",
                        "barcode": "001011",
                        "place": "D1B04",
                        "designation": "Roulements à billes 6208 2rs"
                    }
                },
                "05": {
                    "Roulements à billes 6301 2z ~ D1B05 ~ 001012": {
                        "id": "201903200041",
                        "barcode": "001012",
                        "place": "D1B05",
                        "designation": "Roulements à billes 6301 2z"
                    }
                },
                "06": {
                    "Roulements à billes 6302 2rs ~ D1B06 ~ 001013": {
                        "id": "201903200042",
                        "barcode": "001013",
                        "place": "D1B06",
                        "designation": "Roulements à billes 6302 2rs"
                    }
                },
                "07": {
                    "Roulements à billes 6304 2rs ~ D1B07 ~ 001014": {
                        "id": "201903200043",
                        "barcode": "001014",
                        "place": "D1B07",
                        "designation": "Roulements à billes 6304 2rs"
                    }
                },
                "08": {
                    "Roulements à billes 6306 2rs ~ D1B08 ~ 001015": {
                        "id": "201903200044",
                        "barcode": "001015",
                        "place": "D1B08",
                        "designation": "Roulements à billes 6306 2rs"
                    }
                },
                "09": {
                    "Roulements à billes 6308 2rs ~ D1B09 ~ 001016": {
                        "id": "201903200045",
                        "barcode": "001016",
                        "place": "D1B09",
                        "designation": "Roulements à billes 6308 2rs"
                    }
                }
            },
            "C": {
                "10": {
                    "Roulements à billes 5307 nppu ~ D1C10 ~ 000994": {
                        "id": "201903200023",
                        "barcode": "000994",
                        "place": "D1C10",
                        "designation": "Roulements à billes 5307 nppu"
                    }
                },
                "11": {
                    "Roulements à billes 6000-2z ~ D1C11 ~ 000995": {
                        "id": "201903200024",
                        "barcode": "000995",
                        "place": "D1C11",
                        "designation": "Roulements à billes 6000-2z"
                    }
                },
                "12": {
                    "Roulements à billes 6001-2z (en skf) ~ D1C12 ~ 000996": {
                        "id": "201903200025",
                        "barcode": "000996",
                        "place": "D1C12",
                        "designation": "Roulements à billes 6001-2z (en skf)"
                    }
                },
                "13": {
                    "Roulements à billes 6002 DDU ~ D1C13 ~ 000997": {
                        "id": "201903200026",
                        "barcode": "000997",
                        "place": "D1C13",
                        "designation": "Roulements à billes 6002 DDU"
                    }
                },
                "14": {
                    "Roulements à billes 6003-EE ~ D1C14 ~ 000998": {
                        "id": "201903200027",
                        "barcode": "000998",
                        "place": "D1C14",
                        "designation": "Roulements à billes 6003-EE"
                    }
                },
                "15": {
                    "Roulements à billes 6004 EE ~ D1C15 ~ 000999": {
                        "id": "201903200028",
                        "barcode": "000999",
                        "place": "D1C15",
                        "designation": "Roulements à billes 6004 EE"
                    }
                },
                "16": {
                    "Roulements à billes 6004 2rs ~ D1C16 ~ 001000": {
                        "id": "201903200029",
                        "barcode": "001000",
                        "place": "D1C16",
                        "designation": "Roulements à billes 6004 2rs"
                    }
                },
                "17": {
                    "Roulements à billes 6005 rs ~ D1C17 ~ 001001": {
                        "id": "201903200030",
                        "barcode": "001001",
                        "place": "D1C17",
                        "designation": "Roulements à billes 6005 rs"
                    }
                },
                "18": {
                    "Roulements à billes 6006 rs ~ D1C18 ~ 002033": {
                        "id": "202109020004",
                        "barcode": "002033",
                        "place": "D1C18",
                        "designation": "Roulements à billes 6006 rs"
                    }
                },
                "19": {
                    "Roulements à billes 6007 2 rs ~ D1C19 ~ 001002": {
                        "id": "201903200031",
                        "barcode": "001002",
                        "place": "D1C19",
                        "designation": "Roulements à billes 6007 2 rs"
                    }
                },
                "20": {
                    "Roulements à billes 6008 2z ~ D1C20 ~ 001003": {
                        "id": "201903200032",
                        "barcode": "001003",
                        "place": "D1C20",
                        "designation": "Roulements à billes 6008 2z"
                    }
                },
                "21": {
                    "Roulements à billes 6013 ~ D1C21 ~ 001995": {
                        "id": "202107300001",
                        "barcode": "001995",
                        "place": "D1C21",
                        "designation": "Roulements à billes 6013"
                    }
                },
                "22": {
                    "Roulements à billes 6200 2z ~ D1C22 ~ 001004": {
                        "id": "201903200033",
                        "barcode": "001004",
                        "place": "D1C22",
                        "designation": "Roulements à billes 6200 2z"
                    }
                },
                "23": {
                    "Roulements à billes 6201-2RS ~ D1C23 ~ 000094": {
                        "id": "201801250053",
                        "barcode": "000094",
                        "place": "D1C23",
                        "designation": "Roulements à billes 6201-2RS"
                    }
                },
                "24": {
                    "Roulements à billes 6202 2rs ~ D1C24 ~ 001005": {
                        "id": "201903200034",
                        "barcode": "001005",
                        "place": "D1C24",
                        "designation": "Roulements à billes 6202 2rs"
                    }
                },
                "25": {
                    "Roulements à billes 6203 ee ~ D1C25 ~ 001006": {
                        "id": "201903200035",
                        "barcode": "001006",
                        "place": "D1C25",
                        "designation": "Roulements à billes 6203 ee"
                    }
                },
                "26": {
                    "Roulements à billes 6204 2z ~ D1C26 ~ 001007": {
                        "id": "201903200036",
                        "barcode": "001007",
                        "place": "D1C26",
                        "designation": "Roulements à billes 6204 2z"
                    }
                },
                "01": {
                    "Roulement 608 zz ~ D1C01 ~ 000988": {
                        "id": "201903200017",
                        "barcode": "000988",
                        "place": "D1C01",
                        "designation": "Roulement 608 zz"
                    }
                },
                "02": {
                    "Roulement 627ee ~ D1C02 ~ 000989": {
                        "id": "201903200018",
                        "barcode": "000989",
                        "place": "D1C02",
                        "designation": "Roulement 627ee"
                    }
                },
                "03": {
                    "Roulement 1200 ETN9 ~ D1C03 ~ 000990": {
                        "id": "201903200019",
                        "barcode": "000990",
                        "place": "D1C03",
                        "designation": "Roulement 1200 ETN9"
                    }
                },
                "04": {
                    "Roulement 1201 ~ D1C04 ~ 000991": {
                        "id": "201903200020",
                        "barcode": "000991",
                        "place": "D1C04",
                        "designation": "Roulement 1201"
                    }
                },
                "05": {
                    "Roulements à billes 1204 ETN19 ~ D1C05 ~ 000104": {
                        "id": "201801250063",
                        "barcode": "000104",
                        "place": "D1C05",
                        "designation": "Roulements à billes 1204 ETN19"
                    }
                },
                "06": {
                    "Roulements à billes 2200e-2rs ~ D1C06 ~ 000992": {
                        "id": "201903200021",
                        "barcode": "000992",
                        "place": "D1C06",
                        "designation": "Roulements à billes 2200e-2rs"
                    }
                },
                "07": {
                    "Roulements à billes 2201-2RS ~ D1C07 ~ 000050": {
                        "id": "201801250009",
                        "barcode": "000050",
                        "place": "D1C07",
                        "designation": "Roulements à billes 2201-2RS"
                    }
                },
                "08": {
                    "Roulements à billes 2202-2RS ~ D1C08 ~ 000122": {
                        "id": "201801250081",
                        "barcode": "000122",
                        "place": "D1C08",
                        "designation": "Roulements à billes 2202-2RS"
                    }
                },
                "09": {
                    "Roulements à billes 2204-2rs ~ D1C09 ~ 000993": {
                        "id": "201903200022",
                        "barcode": "000993",
                        "place": "D1C09",
                        "designation": "Roulements à billes 2204-2rs"
                    }
                }
            },
            "D": {
                "01": {
                    "Morceau de chaine SIMPLE pas 12.7 ~ D1D01 ~ 002030": {
                        "id": "202109020001",
                        "barcode": "002030",
                        "place": "D1D01",
                        "designation": "Morceau de chaine SIMPLE pas 12.7"
                    }
                },
                "02": {
                    "Chaine 12.7 ~ D1D02 ~ 000986": {
                        "id": "201903200015",
                        "barcode": "000986",
                        "place": "D1D02",
                        "designation": "Chaine 12.7"
                    }
                },
                "03": {
                    "Morceau de chaine 15.875 ~ D1D03 ~ 002031": {
                        "id": "202109020002",
                        "barcode": "002031",
                        "place": "D1D03",
                        "designation": "Morceau de chaine 15.875"
                    }
                },
                "04": {
                    "Chaine 15.8 ~ D1D04 ~ 002372": {
                        "id": "202305170001",
                        "barcode": "002372",
                        "place": "D1D04",
                        "designation": "Chaine 15.8"
                    }
                },
                "05": {
                    "Morceau de chaine 19.02 ~ D1D05 ~ 002032": {
                        "id": "202109020003",
                        "barcode": "002032",
                        "place": "D1D05",
                        "designation": "Morceau de chaine 19.02"
                    }
                },
                "06": {
                    "Chaine 19.05 ~ D1D06 ~ 000987": {
                        "id": "201903200016",
                        "barcode": "000987",
                        "place": "D1D06",
                        "designation": "Chaine 19.05"
                    }
                },
                "07": {
                    "Chaine double en 12.7 ~ D1D07 ~ 001748": {
                        "id": "202002260003",
                        "barcode": "001748",
                        "place": "D1D07",
                        "designation": "Chaine double en 12.7"
                    }
                }
            },
            "E": {
                "10": {
                    "Attache rapide 12.7 ~ D1E10 ~ 000974": {
                        "id": "201903200003",
                        "barcode": "000974",
                        "place": "D1E10",
                        "designation": "Attache rapide 12.7"
                    }
                },
                "11": {
                    "Demi maille 12.7 ~ D1E11 ~ 000975": {
                        "id": "201903200004",
                        "barcode": "000975",
                        "place": "D1E11",
                        "designation": "Demi maille 12.7"
                    }
                },
                "12": {
                    "Attache rapide 15.875 ~ D1E12 ~ 000979": {
                        "id": "201903200008",
                        "barcode": "000979",
                        "place": "D1E12",
                        "designation": "Attache rapide 15.875"
                    }
                },
                "13": {
                    "Demi maille 15.875 ~ D1E13 ~ 000976": {
                        "id": "201903200005",
                        "barcode": "000976",
                        "place": "D1E13",
                        "designation": "Demi maille 15.875"
                    }
                },
                "14": {
                    "Attache rapide 19.05 ~ D1E14 ~ 000982": {
                        "id": "201903200011",
                        "barcode": "000982",
                        "place": "D1E14",
                        "designation": "Attache rapide 19.05"
                    }
                },
                "15": {
                    "Demi maille 19.02 ~ D1E15 ~ 000981": {
                        "id": "201903200010",
                        "barcode": "000981",
                        "place": "D1E15",
                        "designation": "Demi maille 19.02"
                    }
                },
                "16": {
                    "Attache rapide double 15.875 ~ D1E16 ~ 000978": {
                        "id": "201903200007",
                        "barcode": "000978",
                        "place": "D1E16",
                        "designation": "Attache rapide double 15.875"
                    }
                },
                "17": {
                    "Attache rapide double en 12.7 ~ D1E17 ~ 001747": {
                        "id": "202002260002",
                        "barcode": "001747",
                        "place": "D1E17",
                        "designation": "Attache rapide double en 12.7"
                    }
                },
                "18": {
                    "Maillon de chaine en 15.875 ~ D1E18 ~ 000977": {
                        "id": "201903200006",
                        "barcode": "000977",
                        "place": "D1E18",
                        "designation": "Maillon de chaine en 15.875"
                    }
                },
                "19": {
                    "Attache rapide triple 15.875 ~ D1E19 ~ 000980": {
                        "id": "201903200009",
                        "barcode": "000980",
                        "place": "D1E19",
                        "designation": "Attache rapide triple 15.875"
                    }
                },
                "20": {
                    "Chaine double en 15.875 ~ D1E20 ~ 000983": {
                        "id": "201903200012",
                        "barcode": "000983",
                        "place": "D1E20",
                        "designation": "Chaine double en 15.875"
                    }
                },
                "21": {
                    "Chaine simple 9.525 ~ D1E21 ~ 000984": {
                        "id": "201903200013",
                        "barcode": "000984",
                        "place": "D1E21",
                        "designation": "Chaine simple 9.525"
                    },
                    "Chaine 8 ~ D1E21 ~ 002624": {
                        "id": "202412090001",
                        "barcode": "002624",
                        "place": "D1E21",
                        "designation": "Chaine 8"
                    }
                },
                "01": {
                    "Ressort 195 A 10X1.25X93.5 ~ D1E01 ~ 000963": {
                        "id": "201903190012",
                        "barcode": "000963",
                        "place": "D1E01",
                        "designation": "Ressort 195 A 10X1.25X93.5"
                    }
                },
                "02": {
                    "Ressort VD 273 B 20X2.5X27 ~ D1E02 ~ 000964": {
                        "id": "201903190013",
                        "barcode": "000964",
                        "place": "D1E02",
                        "designation": "Ressort VD 273 B 20X2.5X27"
                    }
                },
                "03": {
                    "Ressort VD313AC ~ D1E03 ~ 000965": {
                        "id": "201903190014",
                        "barcode": "000965",
                        "place": "D1E03",
                        "designation": "Ressort VD313AC"
                    }
                },
                "04": {
                    "Silent bloc (butée caoutchouc ou plot) male M8 25X25 ~ D1E04 ~ 000966": {
                        "id": "201903190015",
                        "barcode": "000966",
                        "place": "D1E04",
                        "designation": "Silent bloc (butée caoutchouc ou plot) male M8 25X25"
                    }
                },
                "05": {
                    "Silent bloc (butée caoutchouc ou plot) male M8 30X20 ~ D1E05 ~ 000969": {
                        "id": "201903190018",
                        "barcode": "000969",
                        "place": "D1E05",
                        "designation": "Silent bloc (butée caoutchouc ou plot) male M8 30X20"
                    }
                },
                "06": {
                    "Silent bloc (butée caoutchouc ou plot) male M6 20X15 ~ D1E06 ~ 000968": {
                        "id": "201903190017",
                        "barcode": "000968",
                        "place": "D1E06",
                        "designation": "Silent bloc (butée caoutchouc ou plot) male M6 20X15"
                    }
                },
                "06bis": {
                    "Attache rapide 8 n°206 05B1 ~ D1E06BIS ~ 002625": {
                        "id": "202412090002",
                        "barcode": "002625",
                        "place": "D1E06BIS",
                        "designation": "Attache rapide 8 n°206 05B1"
                    },
                    "Demi maille 8 n°206 05B1 ~ D1E06BIS ~ 002700": {
                        "id": "202510030001",
                        "barcode": "002700",
                        "place": "D1E06BIS",
                        "designation": "Demi maille 8 n°206 05B1"
                    }
                },
                "08": {
                    "Attache rapide 9.525 ~ D1E08 ~ 000972": {
                        "id": "201903200001",
                        "barcode": "000972",
                        "place": "D1E08",
                        "designation": "Attache rapide 9.525"
                    }
                },
                "09": {
                    "Demi maille 9.525 ~ D1E09 ~ 000973": {
                        "id": "201903200002",
                        "barcode": "000973",
                        "place": "D1E09",
                        "designation": "Demi maille 9.525"
                    }
                }
            },
            "F": {
                "Morceau d'échelle avec patins et roulettes ~ D1F ~ 002585": {
                    "id": "202406100001",
                    "barcode": "002585",
                    "place": "D1F",
                    "designation": "Morceau d'échelle avec patins et roulettes"
                }
            }
        },
        "2 Colonne": {
            "A": {
                "Tambour Moteur INTERROLL 113I - 0,37KW - virole inox agro - 230/400 V / 50Hz L=750mm ~ D2A ~ 000876": {
                    "id": "201903150046",
                    "barcode": "000876",
                    "place": "D2A",
                    "designation": "Tambour Moteur INTERROLL 113I - 0,37KW - virole inox agro - 230/400 V / 50Hz L=750mm"
                },
                "Tambour Moteur INTERROLL avec garnissage MI-DMO113 0,37KW - 230/400 V / 50Hz L=600mm ~ D2A ~ 000877": {
                    "id": "201903150047",
                    "barcode": "000877",
                    "place": "D2A",
                    "designation": "Tambour Moteur INTERROLL avec garnissage MI-DMO113 0,37KW - 230/400 V / 50Hz L=600mm"
                },
                "Tambour moteur VOLLENHOVE (Diam=110 - L=460) ~ D2A ~ 000880": {
                    "id": "201903150050",
                    "barcode": "000880",
                    "place": "D2A",
                    "designation": "Tambour moteur VOLLENHOVE (Diam=110 - L=460)"
                },
                "Tambour Moteur 0.11kw INTERROLL L=410mm ~ D2A ~ 001838": {
                    "id": "202006220001",
                    "barcode": "001838",
                    "place": "D2A",
                    "designation": "Tambour Moteur 0.11kw INTERROLL L=410mm"
                },
                "Tambour Moteur INTERROLL 113E - 0,37KW - 0.32m/s - 230/400 V / 50Hz R L=600 , CSA ~ D2A ~ 002404": {
                    "id": "202307200001",
                    "barcode": "002404",
                    "place": "D2A",
                    "designation": "Tambour Moteur INTERROLL 113E - 0,37KW - 0.32m/s - 230/400 V / 50Hz R L=600 , CSA"
                },
                "Tambour Moteur VOLLENHOVE (Diam=113 - L=760) 0.37kw ~ D2A ~ 002584": {
                    "id": "202406040002",
                    "barcode": "002584",
                    "place": "D2A",
                    "designation": "Tambour Moteur VOLLENHOVE (Diam=113 - L=760) 0.37kw"
                },
                "Tambour moteur VAN DER GRAAF (Diam=110 - L=760) ~ D2A ~ 002594": {
                    "id": "202406270001",
                    "barcode": "002594",
                    "place": "D2A",
                    "designation": "Tambour moteur VAN DER GRAAF (Diam=110 - L=760)"
                },
                "Tambour Moteur INTERROLL 113 - 0,55KW - 1.04m/s - 230/400 V / 50Hz diamètre 112 mm L=562mm ~ D2A ~ 002597": {
                    "id": "202407050001",
                    "barcode": "002597",
                    "place": "D2A",
                    "designation": "Tambour Moteur INTERROLL 113 - 0,55KW - 1.04m/s - 230/400 V / 50Hz diamètre 112 mm L=562mm"
                },
                "01": {
                    "Bande à coller pour rouleau moteur ~ D2A01 ~ 001814": {
                        "id": "202004140003",
                        "barcode": "001814",
                        "place": "D2A01",
                        "designation": "Bande à coller pour rouleau moteur"
                    },
                    "Colle collage bande avec durcisseur ~ D2A01 ~ 001815": {
                        "id": "202004140004",
                        "barcode": "001815",
                        "place": "D2A01",
                        "designation": "Colle collage bande avec durcisseur"
                    }
                },
                "02": {
                    "Bande adhesive pour rouleau moteur ~ D2A02 ~ 002493": {
                        "id": "202310250001",
                        "barcode": "002493",
                        "place": "D2A02",
                        "designation": "Bande adhesive pour rouleau moteur"
                    }
                },
                "03": {
                    "Support tambour moteur interroll ~ D2A03 ~ 000878": {
                        "id": "201903150048",
                        "barcode": "000878",
                        "place": "D2A03",
                        "designation": "Support tambour moteur interroll"
                    },
                    "Support tambour moteur interroll tapis ampicker ~ D2A03 ~ 002701": {
                        "id": "202206240002",
                        "barcode": "002701",
                        "place": "D2A03",
                        "designation": "Support tambour moteur interroll tapis ampicker"
                    }
                }
            },
            "B": {
                "01": {
                    "Kit de remontée pompe de forage ~ D2B01 ~ 000952": {
                        "id": "201903190001",
                        "barcode": "000952",
                        "place": "D2B01",
                        "designation": "Kit de remontée pompe de forage"
                    },
                    "Pion de sécurité ~ D2B01 ~ 000953": {
                        "id": "201903190002",
                        "barcode": "000953",
                        "place": "D2B01",
                        "designation": "Pion de sécurité"
                    }
                },
                "02": {
                    "Distributeur 3/2 24Vac adoucisseur ~ D2B02 ~ 000956": {
                        "id": "201903190005",
                        "barcode": "000956",
                        "place": "D2B02",
                        "designation": "Distributeur 3/2 24Vac adoucisseur"
                    }
                },
                "03": {
                    "Douille graphite (vendu par 10) pour pompe Grunfos C20-5 ~ D2B03 ~ 000958": {
                        "id": "201903190007",
                        "barcode": "000958",
                        "place": "D2B03",
                        "designation": "Douille graphite (vendu par 10) pour pompe Grunfos C20-5"
                    },
                    "Kit de joint pour pompe Grunfos C20-5 ~ D2B03 ~ 000959": {
                        "id": "201903190008",
                        "barcode": "000959",
                        "place": "D2B03",
                        "designation": "Kit de joint pour pompe Grunfos C20-5"
                    },
                    "Garniture pour pompe Grunfos C20-5 ~ D2B03 ~ 000960": {
                        "id": "201903190009",
                        "barcode": "000960",
                        "place": "D2B03",
                        "designation": "Garniture pour pompe Grunfos C20-5"
                    }
                },
                "04": {
                    "Kit étanchéité pour pompe WILO MV16'' F/E ~ D2B04 ~ 002353": {
                        "id": "202304110003",
                        "barcode": "002353",
                        "place": "D2B04",
                        "designation": "Kit étanchéité pour pompe WILO MV16'' F/E"
                    },
                    "Kit accouplement MVI D14 X D14 TRI pour pompe WILO ~ D2B04 ~ 002390": {
                        "id": "202306160001",
                        "barcode": "002390",
                        "place": "D2B04",
                        "designation": "Kit accouplement MVI D14 X D14 TRI pour pompe WILO"
                    }
                },
                "05": {
                    "Corps (Pompe KOCH) ~ D2B05 ~ 002180": {
                        "id": "202201140001",
                        "barcode": "002180",
                        "place": "D2B05",
                        "designation": "Corps (Pompe KOCH)"
                    }
                },
                "06": {
                    "Kit garniture méca (Pompe KOCH) ~ D2B06 ~ 000482": {
                        "id": "201903050041",
                        "barcode": "000482",
                        "place": "D2B06",
                        "designation": "Kit garniture méca (Pompe KOCH)"
                    },
                    "Joint de corps (Pompe KOCH) ~ D2B06 ~ 001919": {
                        "id": "202102040009",
                        "barcode": "001919",
                        "place": "D2B06",
                        "designation": "Joint de corps (Pompe KOCH)"
                    }
                },
                "07": {
                    "Pompe KOSCH/HANNING ~ D2B07 ~ 000484": {
                        "id": "201903050043",
                        "barcode": "000484",
                        "place": "D2B07",
                        "designation": "Pompe KOSCH/HANNING"
                    },
                    "Moteur pour pompe KOSCH/HANNING ~ D2B07 ~ 002264": {
                        "id": "202209160001",
                        "barcode": "002264",
                        "place": "D2B07",
                        "designation": "Moteur pour pompe KOSCH/HANNING"
                    }
                },
                "08": {
                    "Pompe immergée Lowara 1.5kw ~ D2B08 ~ 001951": {
                        "id": "202104200002",
                        "barcode": "001951",
                        "place": "D2B08",
                        "designation": "Pompe immergée Lowara 1.5kw"
                    }
                }
            },
            "C": {
                "Motoréducteur LENZE 0.37kw ~ D2C ~ 000881": {
                    "id": "201903150051",
                    "barcode": "000881",
                    "place": "D2C",
                    "designation": "Motoréducteur LENZE 0.37kw"
                },
                "Réducteur LIND JACOBSEN & CO ~ D2C ~ 000882": {
                    "id": "201903150052",
                    "barcode": "000882",
                    "place": "D2C",
                    "designation": "Réducteur LIND JACOBSEN & CO"
                },
                "Réducteur LIND JACOBSEN & CO ~ D2C ~ 000883": {
                    "id": "201903150053",
                    "barcode": "000883",
                    "place": "D2C",
                    "designation": "Réducteur LIND JACOBSEN & CO"
                },
                "Réducteur nord ~ D2C ~ 000884": {
                    "id": "201903150054",
                    "barcode": "000884",
                    "place": "D2C",
                    "designation": "Réducteur nord"
                },
                "Réducteur METRICON 20.1 ~ D2C ~ 000885": {
                    "id": "201903150055",
                    "barcode": "000885",
                    "place": "D2C",
                    "designation": "Réducteur METRICON 20.1"
                },
                "Réducteur METRICON 20.1 ~ D2C ~ 000886": {
                    "id": "201903150056",
                    "barcode": "000886",
                    "place": "D2C",
                    "designation": "Réducteur METRICON 20.1"
                },
                "Réducteur METRICON 40.1 ~ D2C ~ 000887": {
                    "id": "201903150057",
                    "barcode": "000887",
                    "place": "D2C",
                    "designation": "Réducteur METRICON 40.1"
                },
                "Réducteur METRICON 40.1 ~ D2C ~ 000888": {
                    "id": "201903150058",
                    "barcode": "000888",
                    "place": "D2C",
                    "designation": "Réducteur METRICON 40.1"
                },
                "Réducteur METRICON 40.1 ~ D2C ~ 000889": {
                    "id": "201903150059",
                    "barcode": "000889",
                    "place": "D2C",
                    "designation": "Réducteur METRICON 40.1"
                },
                "Réducteur METRICON 23.1 ~ D2C ~ 000890": {
                    "id": "201903150060",
                    "barcode": "000890",
                    "place": "D2C",
                    "designation": "Réducteur METRICON 23.1"
                },
                "Réducteur METRICON 40.1 ~ D2C ~ 000891": {
                    "id": "201903150061",
                    "barcode": "000891",
                    "place": "D2C",
                    "designation": "Réducteur METRICON 40.1"
                },
                "Réducteur METRICON 23.1 ~ D2C ~ 000892": {
                    "id": "201903150062",
                    "barcode": "000892",
                    "place": "D2C",
                    "designation": "Réducteur METRICON 23.1"
                },
                "Réducteur METRICON 20.1 ~ D2C ~ 002176": {
                    "id": "202201100001",
                    "barcode": "002176",
                    "place": "D2C",
                    "designation": "Réducteur METRICON 20.1"
                },
                "Réducteur METRICON 40.1 ~ D2C ~ 002177": {
                    "id": "202201100002",
                    "barcode": "002177",
                    "place": "D2C",
                    "designation": "Réducteur METRICON 40.1"
                }
            },
            "D": {
                "10": {
                    "Pignon embrayage ~ D2D10 ~ 000935": {
                        "id": "201903180030",
                        "barcode": "000935",
                        "place": "D2D10",
                        "designation": "Pignon embrayage"
                    }
                },
                "11": {
                    "Pignon 21 dents pour moyeu 1610 ~ D2D11 ~ 000936": {
                        "id": "201903180031",
                        "barcode": "000936",
                        "place": "D2D11",
                        "designation": "Pignon 21 dents pour moyeu 1610"
                    }
                },
                "13": {
                    "Pignon 21 dts al25mm réf identique: 40485211 ou 40020721 ~ D2D13 ~ 000938": {
                        "id": "201903180033",
                        "barcode": "000938",
                        "place": "D2D13",
                        "designation": "Pignon 21 dts al25mm réf identique: 40485211 ou 40020721"
                    }
                },
                "14": {
                    "Pignon 21 dts ~ D2D14 ~ 000939": {
                        "id": "201903180034",
                        "barcode": "000939",
                        "place": "D2D14",
                        "designation": "Pignon 21 dts"
                    }
                },
                "15": {
                    "Pignon 21 dents alesage 25 avec 2 taraudages M6 ~ D2D15 ~ 001722": {
                        "id": "201910250001",
                        "barcode": "001722",
                        "place": "D2D15",
                        "designation": "Pignon 21 dents alesage 25 avec 2 taraudages M6"
                    }
                },
                "16": {
                    "Pignon 22 dts moyeu 19 ~ D2D16 ~ 000940": {
                        "id": "201903180035",
                        "barcode": "000940",
                        "place": "D2D16",
                        "designation": "Pignon 22 dts moyeu 19"
                    }
                },
                "19": {
                    "Pignon triple 21 dts ~ D2D19 ~ 000943": {
                        "id": "201903180038",
                        "barcode": "000943",
                        "place": "D2D19",
                        "designation": "Pignon triple 21 dts"
                    }
                },
                "20": {
                    "Pignon 23 dents pour moyeu 1610 ~ D2D20 ~ 000948": {
                        "id": "201903180043",
                        "barcode": "000948",
                        "place": "D2D20",
                        "designation": "Pignon 23 dents pour moyeu 1610"
                    }
                },
                "21": {
                    "Pignon 23 dts al25 ~ D2D21 ~ 000944": {
                        "id": "201903180039",
                        "barcode": "000944",
                        "place": "D2D21",
                        "designation": "Pignon 23 dts al25"
                    }
                },
                "22": {
                    "Pignon moteur Z=25 dents H6 ~ D2D22 ~ 001887": {
                        "id": "202012040001",
                        "barcode": "001887",
                        "place": "D2D22",
                        "designation": "Pignon moteur Z=25 dents H6"
                    }
                },
                "23": {
                    "Pignon avec poulie ~ D2D23 ~ 000947": {
                        "id": "201903180042",
                        "barcode": "000947",
                        "place": "D2D23",
                        "designation": "Pignon avec poulie"
                    }
                },
                "24": {
                    "Pignon triple 23 dts al25mm ~ D2D24 ~ 000949": {
                        "id": "201903180044",
                        "barcode": "000949",
                        "place": "D2D24",
                        "designation": "Pignon triple 23 dts al25mm"
                    }
                },
                "25": {
                    "Pignon triple 23 dts ~ D2D25 ~ 000950": {
                        "id": "201903180045",
                        "barcode": "000950",
                        "place": "D2D25",
                        "designation": "Pignon triple 23 dts"
                    }
                },
                "26": {
                    "Pignon 19 dents sur moyeu TL 1008 d=20 ~ D2D26 ~ 001959": {
                        "id": "202105030004",
                        "barcode": "001959",
                        "place": "D2D26",
                        "designation": "Pignon 19 dents sur moyeu TL 1008 d=20"
                    }
                },
                "27": {
                    "Pignon 23 dents sur moyeu TL 1210 (d=20) ~ D2D27 ~ 001960": {
                        "id": "202105030005",
                        "barcode": "001960",
                        "place": "D2D27",
                        "designation": "Pignon 23 dents sur moyeu TL 1210 (d=20)"
                    }
                },
                "28": {
                    "Pignon 32 dents alesage 25 avec 1 taraudage M6 ~ D2D28 ~ 002359": {
                        "id": "202304280002",
                        "barcode": "002359",
                        "place": "D2D28",
                        "designation": "Pignon 32 dents alesage 25 avec 1 taraudage M6"
                    }
                },
                "29": {
                    "Pignon 1/2\"X5/16\" T=30 D=25mm ~ D2D29 ~ 000942": {
                        "id": "201903180037",
                        "barcode": "000942",
                        "place": "D2D29",
                        "designation": "Pignon 1/2\"X5/16\" T=30 D=25mm"
                    }
                },
                "30": {
                    "Pignon 32 dents alesage 20 avec 1 taraudage M5 ~ D2D30 ~ 002373": {
                        "id": "202305170002",
                        "barcode": "002373",
                        "place": "D2D30",
                        "designation": "Pignon 32 dents alesage 20 avec 1 taraudage M5"
                    }
                },
                "01": {
                    "Pignon tendeur ~ D2D01 ~ 000926": {
                        "id": "201903180021",
                        "barcode": "000926",
                        "place": "D2D01",
                        "designation": "Pignon tendeur"
                    }
                },
                "02": {
                    "Pignon tendeur ~ D2D02 ~ 000927": {
                        "id": "201903180022",
                        "barcode": "000927",
                        "place": "D2D02",
                        "designation": "Pignon tendeur"
                    }
                },
                "03": {
                    "Pignon M7 21 dts ~ D2D03 ~ 000928": {
                        "id": "201903180023",
                        "barcode": "000928",
                        "place": "D2D03",
                        "designation": "Pignon M7 21 dts"
                    }
                },
                "04": {
                    "PIGNON 12 DENTS CLAVETE AL=20mm. ~ D2D04 ~ 000929": {
                        "id": "201903180024",
                        "barcode": "000929",
                        "place": "D2D04",
                        "designation": "PIGNON 12 DENTS CLAVETE AL=20mm."
                    }
                },
                "05": {
                    "Pignon 12 dts 1/2 ~ D2D05 ~ 000931": {
                        "id": "201903180026",
                        "barcode": "000931",
                        "place": "D2D05",
                        "designation": "Pignon 12 dts 1/2"
                    }
                },
                "06": {
                    "Pignon fou 12dts 1/2 ~ D2D06 ~ 000932": {
                        "id": "201903180027",
                        "barcode": "000932",
                        "place": "D2D06",
                        "designation": "Pignon fou 12dts 1/2"
                    }
                },
                "07": {
                    "Pignon M6 14 dents GP et PP ~ D2D07 ~ 001915": {
                        "id": "202102040005",
                        "barcode": "001915",
                        "place": "D2D07",
                        "designation": "Pignon M6 14 dents GP et PP"
                    }
                },
                "08": {
                    "Pignon 3/4 19 dents GP et PP ~ D2D08 ~ 000239": {
                        "id": "201901220004",
                        "barcode": "000239",
                        "place": "D2D08",
                        "designation": "Pignon 3/4 19 dents GP et PP"
                    }
                },
                "09": {
                    "Pignon 19 dts al25mm ~ D2D09 ~ 000934": {
                        "id": "201903180029",
                        "barcode": "000934",
                        "place": "D2D09",
                        "designation": "Pignon 19 dts al25mm"
                    }
                }
            },
            "E": {
                "10": {
                    "Poulie ~ D2E10 ~ 000921": {
                        "id": "201903180016",
                        "barcode": "000921",
                        "place": "D2E10",
                        "designation": "Poulie"
                    }
                },
                "11": {
                    "Poulie de tension ~ D2E11 ~ 000922": {
                        "id": "201903180017",
                        "barcode": "000922",
                        "place": "D2E11",
                        "designation": "Poulie de tension"
                    }
                },
                "12": {
                    "Poulie F/MT-90S ~ D2E12 ~ 000923": {
                        "id": "201903180018",
                        "barcode": "000923",
                        "place": "D2E12",
                        "designation": "Poulie F/MT-90S"
                    }
                },
                "13": {
                    "Poulie spz-71 ~ D2E13 ~ 000924": {
                        "id": "201903180019",
                        "barcode": "000924",
                        "place": "D2E13",
                        "designation": "Poulie spz-71"
                    }
                },
                "14": {
                    "Axe réducteur roll on ~ D2E14 ~ 000925": {
                        "id": "201903180020",
                        "barcode": "000925",
                        "place": "D2E14",
                        "designation": "Axe réducteur roll on"
                    }
                },
                "15": {
                    "Circlips 52 int en inox ~ D2E15 ~ 001115": {
                        "id": "201903260025",
                        "barcode": "001115",
                        "place": "D2E15",
                        "designation": "Circlips 52 int en inox"
                    },
                    "Circlips extérieur de 25 ~ D2E15 ~ 001116": {
                        "id": "201903260026",
                        "barcode": "001116",
                        "place": "D2E15",
                        "designation": "Circlips extérieur de 25"
                    }
                },
                "16": {
                    "Moyeu 1610 ~ D2E16 ~ 000951": {
                        "id": "201903180046",
                        "barcode": "000951",
                        "place": "D2E16",
                        "designation": "Moyeu 1610"
                    }
                },
                "17": {
                    "Bagues a collerette 12/18X12 ~ D2E17 ~ 001707": {
                        "id": "201910010001",
                        "barcode": "001707",
                        "place": "D2E17",
                        "designation": "Bagues a collerette 12/18X12"
                    },
                    "Bagues a collerette 16/10 10X10-22X3 ~ D2E17 ~ 002040": {
                        "id": "202109140004",
                        "barcode": "002040",
                        "place": "D2E17",
                        "designation": "Bagues a collerette 16/10 10X10-22X3"
                    },
                    "Bagues a collerette 10/13-10 ~ D2E17 ~ 002041": {
                        "id": "202109140005",
                        "barcode": "002041",
                        "place": "D2E17",
                        "designation": "Bagues a collerette 10/13-10"
                    }
                },
                "18": {
                    "Joint torique 45X4X0.70 ~ D2E18 ~ 001942": {
                        "id": "202104010006",
                        "barcode": "001942",
                        "place": "D2E18",
                        "designation": "Joint torique 45X4X0.70"
                    },
                    "Joint a levres 25X35X6dl ~ D2E18 ~ 002042": {
                        "id": "202109140006",
                        "barcode": "002042",
                        "place": "D2E18",
                        "designation": "Joint a levres 25X35X6dl"
                    },
                    "Joint a levres 62X40X7 ~ D2E18 ~ 002043": {
                        "id": "202109140007",
                        "barcode": "002043",
                        "place": "D2E18",
                        "designation": "Joint a levres 62X40X7"
                    },
                    "Joint torique 45X5 ~ D2E18 ~ 002044": {
                        "id": "202109140008",
                        "barcode": "002044",
                        "place": "D2E18",
                        "designation": "Joint torique 45X5"
                    },
                    "Joint torique 70X4 ~ D2E18 ~ 002045": {
                        "id": "202109140009",
                        "barcode": "002045",
                        "place": "D2E18",
                        "designation": "Joint torique 70X4"
                    },
                    "Joint torique sy100-30-4a-20 ~ D2E18 ~ 002046": {
                        "id": "202109140010",
                        "barcode": "002046",
                        "place": "D2E18",
                        "designation": "Joint torique sy100-30-4a-20"
                    },
                    "Bagues caoutchouc 25X47X7 ~ D2E18 ~ 002047": {
                        "id": "202109140011",
                        "barcode": "002047",
                        "place": "D2E18",
                        "designation": "Bagues caoutchouc 25X47X7"
                    },
                    "Joint torique 70X3 ~ D2E18 ~ 002286": {
                        "id": "202210310001",
                        "barcode": "002286",
                        "place": "D2E18",
                        "designation": "Joint torique 70X3"
                    },
                    "Joint torique 20X30X6 ~ D2E18 ~ 002288": {
                        "id": "202210310003",
                        "barcode": "002288",
                        "place": "D2E18",
                        "designation": "Joint torique 20X30X6"
                    },
                    "Bague AF 35X47 ~ D2E18 ~ 002289": {
                        "id": "202210310004",
                        "barcode": "002289",
                        "place": "D2E18",
                        "designation": "Bague AF 35X47"
                    }
                },
                "01": {
                    "Roue intermédiaire engageuse GP ~ D2E01 ~ 000912": {
                        "id": "201903180007",
                        "barcode": "000912",
                        "place": "D2E01",
                        "designation": "Roue intermédiaire engageuse GP"
                    }
                },
                "02": {
                    "Poulie crantée engageuse GP ~ D2E02 ~ 000913": {
                        "id": "201903180008",
                        "barcode": "000913",
                        "place": "D2E02",
                        "designation": "Poulie crantée engageuse GP"
                    }
                },
                "03": {
                    "Roue dentée larg 36mm engageuse GP ~ D2E03 ~ 000914": {
                        "id": "201903180009",
                        "barcode": "000914",
                        "place": "D2E03",
                        "designation": "Roue dentée larg 36mm engageuse GP"
                    }
                },
                "04": {
                    "Poulie ~ D2E04 ~ 000915": {
                        "id": "201903180010",
                        "barcode": "000915",
                        "place": "D2E04",
                        "designation": "Poulie"
                    }
                },
                "05": {
                    "Poulie ~ D2E05 ~ 000916": {
                        "id": "201903180011",
                        "barcode": "000916",
                        "place": "D2E05",
                        "designation": "Poulie"
                    }
                },
                "06": {
                    "Poulie dentée z=20 ~ D2E06 ~ 000917": {
                        "id": "201903180012",
                        "barcode": "000917",
                        "place": "D2E06",
                        "designation": "Poulie dentée z=20"
                    }
                },
                "07": {
                    "Poulie ~ D2E07 ~ 000919": {
                        "id": "201903180014",
                        "barcode": "000919",
                        "place": "D2E07",
                        "designation": "Poulie"
                    }
                },
                "08": {
                    "Poulie moteur ~ D2E08 ~ 000918": {
                        "id": "201903180013",
                        "barcode": "000918",
                        "place": "D2E08",
                        "designation": "Poulie moteur"
                    }
                },
                "09": {
                    "Poulie libre ~ D2E09 ~ 000920": {
                        "id": "201903180015",
                        "barcode": "000920",
                        "place": "D2E09",
                        "designation": "Poulie libre"
                    }
                },
                "16bis": {
                    "Douille a aiguilles porte coulissante stockage linge magasin ~ D2E16BIS ~ 002637": {
                        "id": "202501160001",
                        "barcode": "002637",
                        "place": "D2E16BIS",
                        "designation": "Douille a aiguilles porte coulissante stockage linge magasin"
                    }
                }
            }
        },
        "3 Colonne": {
            "A": {
                "Motoréducteur USOCOM 1400tr/min 0.37kw ~ D3A ~ 000273": {
                    "id": "201901220038",
                    "barcode": "000273",
                    "place": "D3A",
                    "designation": "Motoréducteur USOCOM 1400tr/min 0.37kw"
                },
                "Motoréducteur NORD ~ D3A ~ 000837": {
                    "id": "201903150007",
                    "barcode": "000837",
                    "place": "D3A",
                    "designation": "Motoréducteur NORD"
                },
                "Motoréducteur NORD ~ D3A ~ 000838": {
                    "id": "201903150008",
                    "barcode": "000838",
                    "place": "D3A",
                    "designation": "Motoréducteur NORD"
                },
                "Motoréducteur SEW ~ D3A ~ 000839": {
                    "id": "201903150009",
                    "barcode": "000839",
                    "place": "D3A",
                    "designation": "Motoréducteur SEW"
                },
                "Motoréducteur NORD GREEN 0.55kw ~ D3A ~ 000840": {
                    "id": "201903150010",
                    "barcode": "000840",
                    "place": "D3A",
                    "designation": "Motoréducteur NORD GREEN 0.55kw"
                },
                "Motoreducteur SEW 0.37kw 50t diam 20 + bras anti rotation ~ D3A ~ 000841": {
                    "id": "201903150011",
                    "barcode": "000841",
                    "place": "D3A",
                    "designation": "Motoreducteur SEW 0.37kw 50t diam 20 + bras anti rotation"
                },
                "Motoréducteur SUMITOMO ~ D3A ~ 000842": {
                    "id": "201903150012",
                    "barcode": "000842",
                    "place": "D3A",
                    "designation": "Motoréducteur SUMITOMO"
                }
            },
            "B": {
                "Motoréducteur ABM 0.18kw ~ D3B ~ 000843": {
                    "id": "201903150013",
                    "barcode": "000843",
                    "place": "D3B",
                    "designation": "Motoréducteur ABM 0.18kw"
                },
                "Motoréducteur BONFIGLIOLI 0.25kw ~ D3B ~ 000844": {
                    "id": "201903150014",
                    "barcode": "000844",
                    "place": "D3B",
                    "designation": "Motoréducteur BONFIGLIOLI 0.25kw"
                },
                "Motoréducteur BONFIGLIOLI roll on 0.25kw ~ D3B ~ 000845": {
                    "id": "201903150015",
                    "barcode": "000845",
                    "place": "D3B",
                    "designation": "Motoréducteur BONFIGLIOLI roll on 0.25kw"
                },
                "Motoréducteur CARL REHFUSS 0.18kw dévidoir filmeuse ~ D3B ~ 000846": {
                    "id": "201903150016",
                    "barcode": "000846",
                    "place": "D3B",
                    "designation": "Motoréducteur CARL REHFUSS 0.18kw dévidoir filmeuse"
                },
                "Motoréducteur SIEMENS 0.37kw ~ D3B ~ 000847": {
                    "id": "201903150017",
                    "barcode": "000847",
                    "place": "D3B",
                    "designation": "Motoréducteur SIEMENS 0.37kw"
                },
                "Motoréducteur SIEMENS 0.37kw ~ D3B ~ 000848": {
                    "id": "201903150018",
                    "barcode": "000848",
                    "place": "D3B",
                    "designation": "Motoréducteur SIEMENS 0.37kw"
                },
                "Motoréducteur BONFIGLIOLI/NERIMOTORI 0.18kw ~ D3B ~ 000850": {
                    "id": "201903150020",
                    "barcode": "000850",
                    "place": "D3B",
                    "designation": "Motoréducteur BONFIGLIOLI/NERIMOTORI 0.18kw"
                },
                "Motoréducteur NORD 0.37kw i=25 ~ D3B ~ 001824": {
                    "id": "202004280001",
                    "barcode": "001824",
                    "place": "D3B",
                    "designation": "Motoréducteur NORD 0.37kw i=25"
                },
                "Motoréducteur BONFIGLIOLI 1.2kw ~ D3B ~ 002309": {
                    "id": "202208010001",
                    "barcode": "002309",
                    "place": "D3B",
                    "designation": "Motoréducteur BONFIGLIOLI 1.2kw"
                },
                "Reducteur pour Roll on du Motoréducteur BONFIGLIOLI 0.25kw ~ D3B ~ 002565": {
                    "id": "202404260001",
                    "barcode": "002565",
                    "place": "D3B",
                    "designation": "Reducteur pour Roll on du Motoréducteur BONFIGLIOLI 0.25kw"
                }
            },
            "C": {
                "1": {
                    "Cable de commande palan DEMAG 10 pôle 10m ~ D3C01 ~ 000852": {
                        "id": "201903150022",
                        "barcode": "000852",
                        "place": "D3C01",
                        "designation": "Cable de commande palan DEMAG 10 pôle 10m"
                    },
                    "Connecteur palan DEMAG ~ D3C01 ~ 000853": {
                        "id": "201903150023",
                        "barcode": "000853",
                        "place": "D3C01",
                        "designation": "Connecteur palan DEMAG"
                    },
                    "Frein KEB pour navette industrielle avec garniture 0208530-6230 ~ D3C01 ~ 000854": {
                        "id": "201903150024",
                        "barcode": "000854",
                        "place": "D3C01",
                        "designation": "Frein KEB pour navette industrielle avec garniture 0208530-6230"
                    }
                },
                "2": {
                    "Frein intorq pour moteur Maximat ~ D3C02 ~ 000855": {
                        "id": "201903150025",
                        "barcode": "000855",
                        "place": "D3C02",
                        "designation": "Frein intorq pour moteur Maximat"
                    },
                    "Disque de frein intorq moteur Maximat ~ D3C02 ~ 001841": {
                        "id": "202007020001",
                        "barcode": "001841",
                        "place": "D3C02",
                        "designation": "Disque de frein intorq moteur Maximat"
                    },
                    "Pignon de frein intorq moteur Maximat ~ D3C02 ~ 002356": {
                        "id": "202304140001",
                        "barcode": "002356",
                        "place": "D3C02",
                        "designation": "Pignon de frein intorq moteur Maximat"
                    }
                },
                "3": {
                    "Bras de réaction SEW pour réducteur WA30 (anti rotation) ~ D3C03 ~ 000856": {
                        "id": "201903150026",
                        "barcode": "000856",
                        "place": "D3C03",
                        "designation": "Bras de réaction SEW pour réducteur WA30 (anti rotation)"
                    },
                    "Bras de réaction SEW pour SA37T sur trous (anti rotation) ~ D3C03 ~ 000857": {
                        "id": "201903150027",
                        "barcode": "000857",
                        "place": "D3C03",
                        "designation": "Bras de réaction SEW pour SA37T sur trous (anti rotation)"
                    }
                },
                "Motoreducteur KEB avec frein 0.25kw pour navette industrielle ~ D3C ~ 000190": {
                    "id": "201901150012",
                    "barcode": "000190",
                    "place": "D3C",
                    "designation": "Motoreducteur KEB avec frein 0.25kw pour navette industrielle"
                },
                "Moteur frein SIEMENS pas utilisé ~ D3C ~ 000859": {
                    "id": "201903150029",
                    "barcode": "000859",
                    "place": "D3C",
                    "designation": "Moteur frein SIEMENS pas utilisé"
                },
                "Moteur et codeur LENZE (moteur de pince GP PP) ~ D3C ~ 000860": {
                    "id": "201903150030",
                    "barcode": "000860",
                    "place": "D3C",
                    "designation": "Moteur et codeur LENZE (moteur de pince GP PP)"
                },
                "Moteur Ventilateur ELECKTROR 0.13 kw ~ D3C ~ 000872": {
                    "id": "201903150042",
                    "barcode": "000872",
                    "place": "D3C",
                    "designation": "Moteur Ventilateur ELECKTROR 0.13 kw"
                },
                "Moteur AVEC FREIN MAXIMAT 0.18KW VEM ou Watt(electromotor) ou ABB ~ D3C ~ 001725": {
                    "id": "201911220001",
                    "barcode": "001725",
                    "place": "D3C",
                    "designation": "Moteur AVEC FREIN MAXIMAT 0.18KW VEM ou Watt(electromotor) ou ABB"
                },
                "Turbine d'aspiration plieuse éponge ~ D3C ~ 002239": {
                    "id": "202207290001",
                    "barcode": "002239",
                    "place": "D3C",
                    "designation": "Turbine d'aspiration plieuse éponge"
                },
                "Turbine d'aspiration plieuse maximat ~ D3C ~ 002602": {
                    "id": "202407240001",
                    "barcode": "002602",
                    "place": "D3C",
                    "designation": "Turbine d'aspiration plieuse maximat"
                },
                "Grille de protection pour turbine d'aspiration plieuse maximat ~ D3C ~ 002617": {
                    "id": "202410210002",
                    "barcode": "002617",
                    "place": "D3C",
                    "designation": "Grille de protection pour turbine d'aspiration plieuse maximat"
                },
                "Moteur AVEC FREIN MAXIMAT 0.37/0.42KW B3 VEM ou WATT ou JENSEN ~ D3C ~ 002632": {
                    "id": "202501080001",
                    "barcode": "002632",
                    "place": "D3C",
                    "designation": "Moteur AVEC FREIN MAXIMAT 0.37/0.42KW B3 VEM ou WATT ou JENSEN"
                }
            },
            "D": {
                "Moteur SANS FREIN MAXIMAT 0.37KW B3 ATTENTION SANS FREIN ~ D3D ~ 000858": {
                    "id": "201903150028",
                    "barcode": "000858",
                    "place": "D3D",
                    "designation": "Moteur SANS FREIN MAXIMAT 0.37KW B3 ATTENTION SANS FREIN"
                },
                "Moteur SIEMENS 3 KW 230/400 2890tr/min turbine AIR DE BRULEUR -b35 (patte+ bride B5) ~ D3D ~ 000861": {
                    "id": "201903150031",
                    "barcode": "000861",
                    "place": "D3D",
                    "designation": "Moteur SIEMENS 3 KW 230/400 2890tr/min turbine AIR DE BRULEUR -b35 (patte+ bride B5)"
                },
                "Moteur SIEMENS 0.55kw ~ D3D ~ 000862": {
                    "id": "201903150032",
                    "barcode": "000862",
                    "place": "D3D",
                    "designation": "Moteur SIEMENS 0.55kw"
                },
                "Moteur VEM Extraction Calandre GP/PP 2.2kw ~ D3D ~ 000863": {
                    "id": "201903150033",
                    "barcode": "000863",
                    "place": "D3D",
                    "designation": "Moteur VEM Extraction Calandre GP/PP 2.2kw"
                },
                "Moteur MEZ 0.75KW ~ D3D ~ 000864": {
                    "id": "201903150034",
                    "barcode": "000864",
                    "place": "D3D",
                    "designation": "Moteur MEZ 0.75KW"
                },
                "Moteur SIEMENS 0.55KW ~ D3D ~ 000865": {
                    "id": "201903150035",
                    "barcode": "000865",
                    "place": "D3D",
                    "designation": "Moteur SIEMENS 0.55KW"
                },
                "Moteur MEZ/Electra 0.25kw 685tr/mn ~ D3D ~ 000866": {
                    "id": "201903150036",
                    "barcode": "000866",
                    "place": "D3D",
                    "designation": "Moteur MEZ/Electra 0.25kw 685tr/mn"
                },
                "Moteur VEM 0.37KW ~ D3D ~ 000867": {
                    "id": "201903150037",
                    "barcode": "000867",
                    "place": "D3D",
                    "designation": "Moteur VEM 0.37KW"
                },
                "Moteur ALMO 0.37kw ~ D3D ~ 000868": {
                    "id": "201903150038",
                    "barcode": "000868",
                    "place": "D3D",
                    "designation": "Moteur ALMO 0.37kw"
                },
                "Moteur BONFIGLIOLI 0,25Kw - B14 230/400V ~ D3D ~ 000869": {
                    "id": "201903150039",
                    "barcode": "000869",
                    "place": "D3D",
                    "designation": "Moteur BONFIGLIOLI 0,25Kw - B14 230/400V"
                },
                "Moteur ALMO T63 0.18kw 230/400 1350tr/mn ~ D3D ~ 000870": {
                    "id": "201903150040",
                    "barcode": "000870",
                    "place": "D3D",
                    "designation": "Moteur ALMO T63 0.18kw 230/400 1350tr/mn"
                },
                "Moteur ALMO T71 0.18kw 230/400v 680tr/mn ~ D3D ~ 000871": {
                    "id": "201903150041",
                    "barcode": "000871",
                    "place": "D3D",
                    "designation": "Moteur ALMO T71 0.18kw 230/400v 680tr/mn"
                },
                "Moteur NORD SK63 0.12kw 4P B14 230/400 1350tr/mn ~ D3D ~ 000873": {
                    "id": "201903150043",
                    "barcode": "000873",
                    "place": "D3D",
                    "designation": "Moteur NORD SK63 0.12kw 4P B14 230/400 1350tr/mn"
                },
                "Moteur VEM 0.18kw ~ D3D ~ 000874": {
                    "id": "201903150044",
                    "barcode": "000874",
                    "place": "D3D",
                    "designation": "Moteur VEM 0.18kw"
                },
                "Moteur SIEMENS 0.18kw ~ D3D ~ 000875": {
                    "id": "201903150045",
                    "barcode": "000875",
                    "place": "D3D",
                    "designation": "Moteur SIEMENS 0.18kw"
                },
                "Moteur VEM 0.12kw ~ D3D ~ 001749": {
                    "id": "202002260004",
                    "barcode": "001749",
                    "place": "D3D",
                    "designation": "Moteur VEM 0.12kw"
                },
                "Moteur SIEMENS 0.12kw ~ D3D ~ 001884": {
                    "id": "202011260001",
                    "barcode": "001884",
                    "place": "D3D",
                    "designation": "Moteur SIEMENS 0.12kw"
                },
                "Moteur B14 ABB 0.37kw ~ D3D ~ 002654": {
                    "id": "202503140001",
                    "barcode": "002654",
                    "place": "D3D",
                    "designation": "Moteur B14 ABB 0.37kw"
                },
                "Moteur B3 VEM de1.5Kw 2900TR/MIN ~ D3D ~ 002735": {
                    "id": "202511250001",
                    "barcode": "002735",
                    "place": "D3D",
                    "designation": "Moteur B3 VEM de1.5Kw 2900TR/MIN"
                }
            },
            "E": {
                "10": {
                    "Courroie blanche L=5210mm l=50mm centreur tapis épaisseur 0.4 mm ~ D3E10 ~ 001686": {
                        "id": "201905210002",
                        "barcode": "001686",
                        "place": "D3E10",
                        "designation": "Courroie blanche L=5210mm l=50mm centreur tapis épaisseur 0.4 mm"
                    }
                },
                "11": {
                    "Courroie L=2520mm l=40mm ~ D3E11 ~ 002174": {
                        "id": "202112200002",
                        "barcode": "002174",
                        "place": "D3E11",
                        "designation": "Courroie L=2520mm l=40mm"
                    }
                },
                "12": {
                    "Courroie plate verte l=3250 ~ D3E12 ~ 000902": {
                        "id": "201903150072",
                        "barcode": "000902",
                        "place": "D3E12",
                        "designation": "Courroie plate verte l=3250"
                    }
                },
                "13": {
                    "Bande courroie bleue L=3882mm l=50mm ~ D3E13 ~ 000911": {
                        "id": "201903180006",
                        "barcode": "000911",
                        "place": "D3E13",
                        "designation": "Bande courroie bleue L=3882mm l=50mm"
                    }
                },
                "14": {
                    "Bande courroie bleue L=3625mm l=50mm ~ D3E14 ~ 000910": {
                        "id": "201903180005",
                        "barcode": "000910",
                        "place": "D3E14",
                        "designation": "Bande courroie bleue L=3625mm l=50mm"
                    }
                },
                "15": {
                    "Courroie ronde polycord verte napkin PP de 6 ~ D3E15 ~ 000907": {
                        "id": "201903180002",
                        "barcode": "000907",
                        "place": "D3E15",
                        "designation": "Courroie ronde polycord verte napkin PP de 6"
                    },
                    "Courroie ronde noir de 6 entrainement 2 rouleaux devant l'engagement ~ D3E15 ~ 001849": {
                        "id": "202007240001",
                        "barcode": "001849",
                        "place": "D3E15",
                        "designation": "Courroie ronde noir de 6 entrainement 2 rouleaux devant l'engagement"
                    }
                },
                "16": {
                    "Courroie ronde polycord verte napkin PP de 8 ~ D3E16 ~ 000906": {
                        "id": "201903180001",
                        "barcode": "000906",
                        "place": "D3E16",
                        "designation": "Courroie ronde polycord verte napkin PP de 8"
                    }
                },
                "01": {
                    "Courroie L=555mm ~ D3E01 ~ 000893": {
                        "id": "201903150063",
                        "barcode": "000893",
                        "place": "D3E01",
                        "designation": "Courroie L=555mm"
                    }
                },
                "02": {
                    "Courroie plate verte L=1240mm ~ D3E02 ~ 000894": {
                        "id": "201903150064",
                        "barcode": "000894",
                        "place": "D3E02",
                        "designation": "Courroie plate verte L=1240mm"
                    }
                },
                "03": {
                    "Courroie moteur L=1020mm ~ D3E03 ~ 000895": {
                        "id": "201903150065",
                        "barcode": "000895",
                        "place": "D3E03",
                        "designation": "Courroie moteur L=1020mm"
                    }
                },
                "04": {
                    "Courroie plate verte L=3050mm (pliage manche ) ~ D3E04 ~ 000896": {
                        "id": "201903150066",
                        "barcode": "000896",
                        "place": "D3E04",
                        "designation": "Courroie plate verte L=3050mm (pliage manche )"
                    }
                },
                "05": {
                    "Courroie plate verte L=730mm ~ D3E05 ~ 000897": {
                        "id": "201903150067",
                        "barcode": "000897",
                        "place": "D3E05",
                        "designation": "Courroie plate verte L=730mm"
                    }
                },
                "06": {
                    "Courroie plate verte L=1460mm l=40mm ~ D3E06 ~ 000898": {
                        "id": "201903150068",
                        "barcode": "000898",
                        "place": "D3E06",
                        "designation": "Courroie plate verte L=1460mm l=40mm"
                    }
                },
                "07": {
                    "Courroie verte plate L=2480mm l= 40mm ou 2530X40 chez Maas ~ D3E07 ~ 000899": {
                        "id": "201903150069",
                        "barcode": "000899",
                        "place": "D3E07",
                        "designation": "Courroie verte plate L=2480mm l= 40mm ou 2530X40 chez Maas"
                    }
                },
                "08": {
                    "Courroie plate verte L=1500mm l=50mm ~ D3E08 ~ 000900": {
                        "id": "201903150070",
                        "barcode": "000900",
                        "place": "D3E08",
                        "designation": "Courroie plate verte L=1500mm l=50mm"
                    }
                },
                "09": {
                    "Courroie plate verte l=575mm ~ D3E09 ~ 000901": {
                        "id": "201903150071",
                        "barcode": "000901",
                        "place": "D3E09",
                        "designation": "Courroie plate verte l=575mm"
                    }
                },
                "11bis": {
                    "Courroie plate verte L=520mm l=40mm ~ D3E11BIS ~ 002500": {
                        "id": "202311100003",
                        "barcode": "002500",
                        "place": "D3E11BIS",
                        "designation": "Courroie plate verte L=520mm l=40mm"
                    }
                },
                "12bis": {
                    "Courroie plate verte L=1340mm l=40mm ~ D3E12BIS ~ 002499": {
                        "id": "202311100002",
                        "barcode": "002499",
                        "place": "D3E12BIS",
                        "designation": "Courroie plate verte L=1340mm l=40mm"
                    }
                },
                "14bis": {
                    "Courroie plate verte L=1530mm l=40mm ~ D3E14BIS ~ 002498": {
                        "id": "202311100001",
                        "barcode": "002498",
                        "place": "D3E14BIS",
                        "designation": "Courroie plate verte L=1530mm l=40mm"
                    }
                }
            },
            "F": {
                "Courroie crantée blanche ouverte (Long=7,5m largeur 15mm) ~ D3F ~ 000908": {
                    "id": "201903180003",
                    "barcode": "000908",
                    "place": "D3F",
                    "designation": "Courroie crantée blanche ouverte (Long=7,5m largeur 15mm)"
                },
                "Courroie LL-5MR-15-steel ~ D3F ~ 000909": {
                    "id": "201903180004",
                    "barcode": "000909",
                    "place": "D3F",
                    "designation": "Courroie LL-5MR-15-steel"
                },
                "Stock rouleau Courroie ronde polycord de 6 (D3E15) ~ D3F ~ 002178": {
                    "id": "202201100003",
                    "barcode": "002178",
                    "place": "D3F",
                    "designation": "Stock rouleau Courroie ronde polycord de 6 (D3E15)"
                }
            },
            "G": {
                "10": {
                    "Courroie 13X1450 /spa veco 200 ~ D3G10 ~ 000280": {
                        "id": "201901230003",
                        "barcode": "000280",
                        "place": "D3G10",
                        "designation": "Courroie 13X1450 /spa veco 200"
                    }
                },
                "11": {
                    "Courroie 9.5X2150 spz 2137 ~ D3G11 ~ 001260": {
                        "id": "201904050011",
                        "barcode": "001260",
                        "place": "D3G11",
                        "designation": "Courroie 9.5X2150 spz 2137"
                    }
                },
                "12": {
                    "Courroie spa 2900 (CTA resident) ~ D3G12 ~ 001261": {
                        "id": "201904050012",
                        "barcode": "001261",
                        "place": "D3G12",
                        "designation": "Courroie spa 2900 (CTA resident)"
                    }
                },
                "13": {
                    "Courroie SPB 2000 ~ D3G13 ~ 001263": {
                        "id": "201904050014",
                        "barcode": "001263",
                        "place": "D3G13",
                        "designation": "Courroie SPB 2000"
                    }
                },
                "14": {
                    "Courroie spa 3750 ld (CTA industriel) ~ D3G14 ~ 001262": {
                        "id": "201904050013",
                        "barcode": "001262",
                        "place": "D3G14",
                        "designation": "Courroie spa 3750 ld (CTA industriel)"
                    }
                },
                "01": {
                    "Courroie spz 750 ~ D3G01 ~ 001250": {
                        "id": "201904050001",
                        "barcode": "001250",
                        "place": "D3G01",
                        "designation": "Courroie spz 750"
                    }
                },
                "02": {
                    "Courroie A33 13X850 ~ D3G02 ~ 002058": {
                        "id": "202110110002",
                        "barcode": "002058",
                        "place": "D3G02",
                        "designation": "Courroie A33 13X850"
                    },
                    "Courroie A34 13X875 ~ D3G02 ~ 002059": {
                        "id": "202110110003",
                        "barcode": "002059",
                        "place": "D3G02",
                        "designation": "Courroie A34 13X875"
                    }
                },
                "03": {
                    "Courroie A38 13X965 ~ D3G03 ~ 001251": {
                        "id": "201904050002",
                        "barcode": "001251",
                        "place": "D3G03",
                        "designation": "Courroie A38 13X965"
                    },
                    "Courroie A38 13X975 ~ D3G03 ~ 001252": {
                        "id": "201904050003",
                        "barcode": "001252",
                        "place": "D3G03",
                        "designation": "Courroie A38 13X975"
                    },
                    "Courroie A38 ABB1341 ~ D3G03 ~ 002374": {
                        "id": "202305190001",
                        "barcode": "002374",
                        "place": "D3G03",
                        "designation": "Courroie A38 ABB1341"
                    }
                },
                "04": {
                    "Courroie A40/13 1045 / 13X1016 Li ~ D3G04 ~ 001770": {
                        "id": "202003230001",
                        "barcode": "001770",
                        "place": "D3G04",
                        "designation": "Courroie A40/13 1045 / 13X1016 Li"
                    }
                },
                "05": {
                    "Courroie A47 13X1200 ~ D3G05 ~ 001254": {
                        "id": "201904050005",
                        "barcode": "001254",
                        "place": "D3G05",
                        "designation": "Courroie A47 13X1200"
                    }
                },
                "06": {
                    "Courroie VP2 1250 spa ~ D3G06 ~ 001256": {
                        "id": "201904050007",
                        "barcode": "001256",
                        "place": "D3G06",
                        "designation": "Courroie VP2 1250 spa"
                    }
                },
                "07": {
                    "Courroie VP2 1307 spa D ~ D3G07 ~ 001255": {
                        "id": "201904050006",
                        "barcode": "001255",
                        "place": "D3G07",
                        "designation": "Courroie VP2 1307 spa D"
                    }
                },
                "08": {
                    "Courroie A53 OPTIBELT A1380 Ld/13X1350 Li ~ D3G08 ~ 001305": {
                        "id": "201904080010",
                        "barcode": "001305",
                        "place": "D3G08",
                        "designation": "Courroie A53 OPTIBELT A1380 Ld/13X1350 Li"
                    }
                },
                "09": {
                    "Courroie A54 13X1372 ~ D3G09 ~ 001257": {
                        "id": "201904050008",
                        "barcode": "001257",
                        "place": "D3G09",
                        "designation": "Courroie A54 13X1372"
                    }
                }
            },
            "H": {
                "10": {
                    "Courroie synchrone OPTIBELT A1420 5M largeur 20mm ~ D3H10 ~ 001306": {
                        "id": "201904080011",
                        "barcode": "001306",
                        "place": "D3H10",
                        "designation": "Courroie synchrone OPTIBELT A1420 5M largeur 20mm"
                    },
                    "Courroie synchrone OPTIBELT A1350 5M largeur 20mm ~ D3H10 ~ 002643": {
                        "id": "202502070001",
                        "barcode": "002643",
                        "place": "D3H10",
                        "designation": "Courroie synchrone OPTIBELT A1350 5M largeur 20mm"
                    }
                },
                "11": {
                    "Courroie crantée OPTIBELT 1595-5m-25 ~ D3H11 ~ 001307": {
                        "id": "201904080012",
                        "barcode": "001307",
                        "place": "D3H11",
                        "designation": "Courroie crantée OPTIBELT 1595-5m-25"
                    }
                },
                "12": {
                    "Courroie crantée OPTIBELT 1690-5m-25 Roll on ~ D3H12 ~ 001304": {
                        "id": "201904080009",
                        "barcode": "001304",
                        "place": "D3H12",
                        "designation": "Courroie crantée OPTIBELT 1690-5m-25 Roll on"
                    }
                },
                "13": {
                    "Courroie crantée OPTIBELT HTD 620 5M 5 ~ D3H13 ~ 001309": {
                        "id": "201904090001",
                        "barcode": "001309",
                        "place": "D3H13",
                        "designation": "Courroie crantée OPTIBELT HTD 620 5M 5"
                    }
                },
                "14": {
                    "Courroie crantée OPTIBELT oméga 711 3M larg 7mm ~ D3H14 ~ 001308": {
                        "id": "201904080013",
                        "barcode": "001308",
                        "place": "D3H14",
                        "designation": "Courroie crantée OPTIBELT oméga 711 3M larg 7mm"
                    }
                },
                "15": {
                    "Courroie crantée OPTIBELT oméga 711 3M larg 20mm avec rainure ~ D3H15 ~ 001310": {
                        "id": "201904090002",
                        "barcode": "001310",
                        "place": "D3H15",
                        "designation": "Courroie crantée OPTIBELT oméga 711 3M larg 20mm avec rainure"
                    }
                },
                "16": {
                    "Courroie crantée OPTIBELT oméga 711 3M larg 20mm sans rainure ~ D3H16 ~ 001311": {
                        "id": "201904090003",
                        "barcode": "001311",
                        "place": "D3H16",
                        "designation": "Courroie crantée OPTIBELT oméga 711 3M larg 20mm sans rainure"
                    }
                },
                "17": {
                    "Courroie double HTD-D8M30 L=1760 ~ D3H17 ~ 001312": {
                        "id": "201904090004",
                        "barcode": "001312",
                        "place": "D3H17",
                        "designation": "Courroie double HTD-D8M30 L=1760"
                    }
                },
                "18": {
                    "Courroie double HTD8M30 L=1120 ~ D3H18 ~ 001313": {
                        "id": "201904090005",
                        "barcode": "001313",
                        "place": "D3H18",
                        "designation": "Courroie double HTD8M30 L=1120"
                    }
                },
                "01": {
                    "Courroie xpz 710 /3vx280 ~ D3H01 ~ 001296": {
                        "id": "201904080001",
                        "barcode": "001296",
                        "place": "D3H01",
                        "designation": "Courroie xpz 710 /3vx280"
                    }
                },
                "02": {
                    "Courroie xpz 750 ~ D3H02 ~ 001298": {
                        "id": "201904080003",
                        "barcode": "001298",
                        "place": "D3H02",
                        "designation": "Courroie xpz 750"
                    },
                    "Courroie xpz 762 ~ D3H02 ~ 001904": {
                        "id": "202101140002",
                        "barcode": "001904",
                        "place": "D3H02",
                        "designation": "Courroie xpz 762"
                    }
                },
                "03": {
                    "Courroie xpz 787 ~ D3H03 ~ 001297": {
                        "id": "201904080002",
                        "barcode": "001297",
                        "place": "D3H03",
                        "designation": "Courroie xpz 787"
                    }
                },
                "04": {
                    "Courroie xpz 962 ~ D3H04 ~ 001299": {
                        "id": "201904080004",
                        "barcode": "001299",
                        "place": "D3H04",
                        "designation": "Courroie xpz 962"
                    }
                },
                "05": {
                    "Courroie xpz 1512 ~ D3H05 ~ 001301": {
                        "id": "201904080006",
                        "barcode": "001301",
                        "place": "D3H05",
                        "designation": "Courroie xpz 1512"
                    }
                },
                "06": {
                    "Courroie xpz 1580 ~ D3H06 ~ 001302": {
                        "id": "201904080007",
                        "barcode": "001302",
                        "place": "D3H06",
                        "designation": "Courroie xpz 1580"
                    }
                },
                "07": {
                    "Courroie crantée OPTIBELT zr360h 100 long: 914.4mm larg: 25.4mm ~ D3H07 ~ 001724": {
                        "id": "201910300001",
                        "barcode": "001724",
                        "place": "D3H07",
                        "designation": "Courroie crantée OPTIBELT zr360h 100 long: 914.4mm larg: 25.4mm"
                    }
                },
                "08": {
                    "Courroie synchro AT10-50 LP=700mm ~ D3H08 ~ 001303": {
                        "id": "201904080008",
                        "barcode": "001303",
                        "place": "D3H08",
                        "designation": "Courroie synchro AT10-50 LP=700mm"
                    }
                },
                "09": {
                    "Courroie POWER GRIP GT2 1120 8MGT l=30mm ~ D3H09 ~ 001948": {
                        "id": "202104190001",
                        "barcode": "001948",
                        "place": "D3H09",
                        "designation": "Courroie POWER GRIP GT2 1120 8MGT l=30mm"
                    }
                }
            }
        }
    },
    "Rangée E": {
        "Filtre à peluche sechoir Electrolux T4900/T41200 ~ Filtre-à- ~ 001790": {
            "id": "202004060007",
            "barcode": "001790",
            "place": "Filtre-à-",
            "designation": "Filtre à peluche sechoir Electrolux T4900/T41200"
        },
        "Tamis a peluches sechoir Kannegiesser D40 ~ Tamis-a-p ~ 002165": {
            "id": "202111170014",
            "barcode": "002165",
            "place": "Tamis-a-p",
            "designation": "Tamis a peluches sechoir Kannegiesser D40"
        },
        "1 Colonne": {
            "A": {
                "10": {
                    "Lubrificateur d'huile, série 2 REXROTH en 3/8 ~ E1A10 ~ 001138": {
                        "id": "201903260048",
                        "barcode": "001138",
                        "place": "E1A10",
                        "designation": "Lubrificateur d'huile, série 2 REXROTH en 3/8"
                    }
                },
                "11": {
                    "Filtre et régulateur de pression série 2 REXROTH ~ E1A11 ~ 002203": {
                        "id": "202203040001",
                        "barcode": "002203",
                        "place": "E1A11",
                        "designation": "Filtre et régulateur de pression série 2 REXROTH"
                    }
                },
                "12": {
                    "Intermédiaire FRL REXROTH serie AS2 en 3/8 ~ E1A12 ~ 001133": {
                        "id": "201903260043",
                        "barcode": "001133",
                        "place": "E1A12",
                        "designation": "Intermédiaire FRL REXROTH serie AS2 en 3/8"
                    }
                },
                "13": {
                    "Kit reparation Purgeur automatique Bekomat 21 ~ E1A13 ~ 001991": {
                        "id": "202107280007",
                        "barcode": "001991",
                        "place": "E1A13",
                        "designation": "Kit reparation Purgeur automatique Bekomat 21"
                    },
                    "Purgeur automatique Bekomat 21 ~ E1A13 ~ 002075": {
                        "id": "202110280007",
                        "barcode": "002075",
                        "place": "E1A13",
                        "designation": "Purgeur automatique Bekomat 21"
                    }
                },
                "14": {
                    "FRL FESTO filtre regulateur ~ E1A14 ~ 001710": {
                        "id": "201910010004",
                        "barcode": "001710",
                        "place": "E1A14",
                        "designation": "FRL FESTO filtre regulateur"
                    },
                    "Sectionneur FESTO de FRL ~ E1A14 ~ 002375": {
                        "id": "202305190002",
                        "barcode": "002375",
                        "place": "E1A14",
                        "designation": "Sectionneur FESTO de FRL"
                    }
                },
                "15": {
                    "Ensemble sectionneur FRL filtre regulateur SMC ~ E1A15 ~ 001852": {
                        "id": "202007290003",
                        "barcode": "001852",
                        "place": "E1A15",
                        "designation": "Ensemble sectionneur FRL filtre regulateur SMC"
                    }
                },
                "16": {
                    "Pièces détachées FRL ~ E1A16 ~ 001139": {
                        "id": "201903260049",
                        "barcode": "001139",
                        "place": "E1A16",
                        "designation": "Pièces détachées FRL"
                    }
                },
                "17": {
                    "Demarrage progressif FRL Rexroth ~ E1A17 ~ 001134": {
                        "id": "201903260044",
                        "barcode": "001134",
                        "place": "E1A17",
                        "designation": "Demarrage progressif FRL Rexroth"
                    },
                    "Demarrage progressif SMC pour Maximat ~ E1A17 ~ 002334": {
                        "id": "202302230003",
                        "barcode": "002334",
                        "place": "E1A17",
                        "designation": "Demarrage progressif SMC pour Maximat"
                    }
                },
                "01": {
                    "Kit assemblage FRL REXROTH serie AS2 ~ E1A01 ~ 002198": {
                        "id": "202203030001",
                        "barcode": "002198",
                        "place": "E1A01",
                        "designation": "Kit assemblage FRL REXROTH serie AS2"
                    },
                    "Kit assemblage FRL REXROTH ~ E1A01 ~ 002199": {
                        "id": "202203030002",
                        "barcode": "002199",
                        "place": "E1A01",
                        "designation": "Kit assemblage FRL REXROTH"
                    }
                },
                "02": {
                    "Manomètre pneumatique occasion ~ E1A02 ~ 000274": {
                        "id": "201901220039",
                        "barcode": "000274",
                        "place": "E1A02",
                        "designation": "Manomètre pneumatique occasion"
                    }
                },
                "03": {
                    "Manomètre 16 bars ~ E1A03 ~ 000275": {
                        "id": "201901220040",
                        "barcode": "000275",
                        "place": "E1A03",
                        "designation": "Manomètre 16 bars"
                    }
                },
                "04": {
                    "Sectionneur serie 2 REXROTH en 1/4 ~ E1A04 ~ 001137": {
                        "id": "201903260047",
                        "barcode": "001137",
                        "place": "E1A04",
                        "designation": "Sectionneur serie 2 REXROTH en 1/4"
                    }
                },
                "05": {
                    "Filtre serie AS2 en 1/4 REXROTH ~ E1A05 ~ 002060": {
                        "id": "202110120001",
                        "barcode": "002060",
                        "place": "E1A05",
                        "designation": "Filtre serie AS2 en 1/4 REXROTH"
                    }
                },
                "06": {
                    "Lubrificateur d'huile, série AS2 REXROTH en 1/4 ~ E1A06 ~ 001136": {
                        "id": "201903260046",
                        "barcode": "001136",
                        "place": "E1A06",
                        "designation": "Lubrificateur d'huile, série AS2 REXROTH en 1/4"
                    }
                },
                "07": {
                    "Sectionneur serie 2 REXROTHen 3/8 ~ E1A07 ~ 002200": {
                        "id": "202203030003",
                        "barcode": "002200",
                        "place": "E1A07",
                        "designation": "Sectionneur serie 2 REXROTHen 3/8"
                    }
                },
                "08": {
                    "Filtre serie AS2 en 3/8 REXROTH ~ E1A08 ~ 002202": {
                        "id": "202203030005",
                        "barcode": "002202",
                        "place": "E1A08",
                        "designation": "Filtre serie AS2 en 3/8 REXROTH"
                    }
                },
                "09": {
                    "Filtre et régulateur de pression serie AS2 en 1/4 REXROTH ~ E1A09 ~ 002201": {
                        "id": "202203030004",
                        "barcode": "002201",
                        "place": "E1A09",
                        "designation": "Filtre et régulateur de pression serie AS2 en 1/4 REXROTH"
                    }
                }
            },
            "B": {
                "10": {
                    "Support de vérin REXROTH ~ E1B10 ~ 001120": {
                        "id": "201903260030",
                        "barcode": "001120",
                        "place": "E1B10",
                        "designation": "Support de vérin REXROTH"
                    }
                },
                "11": {
                    "Colllier pour détecteur SICK 8 25 mm ~ E1B11 ~ 001122": {
                        "id": "201903260032",
                        "barcode": "001122",
                        "place": "E1B11",
                        "designation": "Colllier pour détecteur SICK 8 25 mm"
                    }
                },
                "12": {
                    "Ecrou de détecteur de vérin METAL WORK ~ E1B12 ~ 001123": {
                        "id": "201903260033",
                        "barcode": "001123",
                        "place": "E1B12",
                        "designation": "Ecrou de détecteur de vérin METAL WORK"
                    }
                },
                "13": {
                    "Support de vérin sans tige ~ E1B13 ~ 002183": {
                        "id": "202201200002",
                        "barcode": "002183",
                        "place": "E1B13",
                        "designation": "Support de vérin sans tige"
                    }
                },
                "14": {
                    "Support de vérin BOCH ~ E1B14 ~ 001124": {
                        "id": "201903260034",
                        "barcode": "001124",
                        "place": "E1B14",
                        "designation": "Support de vérin BOCH"
                    }
                },
                "15": {
                    "Support de vérin REXROTH ~ E1B15 ~ 001125": {
                        "id": "201903260035",
                        "barcode": "001125",
                        "place": "E1B15",
                        "designation": "Support de vérin REXROTH"
                    }
                },
                "16": {
                    "Kit de reparation joint V pour vérin sans tige NBR D25 ~ E1B16 ~ 002457": {
                        "id": "202308160004",
                        "barcode": "002457",
                        "place": "E1B16",
                        "designation": "Kit de reparation joint V pour vérin sans tige NBR D25"
                    }
                },
                "17": {
                    "Kit de joint S50 pour réparation ~ E1B17 ~ 002736": {
                        "id": "202512120001",
                        "barcode": "002736",
                        "place": "E1B17",
                        "designation": "Kit de joint S50 pour réparation"
                    }
                },
                "01": {
                    "Détecteur de vérin ORIGA ~ E1B01 ~ 001110": {
                        "id": "201903260020",
                        "barcode": "001110",
                        "place": "E1B01",
                        "designation": "Détecteur de vérin ORIGA"
                    }
                },
                "02": {
                    "Détecteur de vérin PNEUMAX ~ E1B02 ~ 001111": {
                        "id": "201903260021",
                        "barcode": "001111",
                        "place": "E1B02",
                        "designation": "Détecteur de vérin PNEUMAX"
                    }
                },
                "03": {
                    "Détecteur de vérin SICK ~ E1B03 ~ 001112": {
                        "id": "201903260022",
                        "barcode": "001112",
                        "place": "E1B03",
                        "designation": "Détecteur de vérin SICK"
                    }
                },
                "04": {
                    "Détecteur de vérin PARKER ~ E1B04 ~ 001114": {
                        "id": "201903260024",
                        "barcode": "001114",
                        "place": "E1B04",
                        "designation": "Détecteur de vérin PARKER"
                    }
                },
                "05": {
                    "Détecteur de vérin FESTO SME-8-zs-kl-led-24 ~ E1B05 ~ 001118": {
                        "id": "201903260028",
                        "barcode": "001118",
                        "place": "E1B05",
                        "designation": "Détecteur de vérin FESTO SME-8-zs-kl-led-24"
                    }
                },
                "06": {
                    "Détecteur de vérin 3 fils REXROTH (= AVENTICS R412022870) DE 10 A 30v DC ~ E1B06 ~ 001119": {
                        "id": "201903260029",
                        "barcode": "001119",
                        "place": "E1B06",
                        "designation": "Détecteur de vérin 3 fils REXROTH (= AVENTICS R412022870) DE 10 A 30v DC"
                    }
                },
                "07": {
                    "Détecteur de vérin PARKER ~ E1B07 ~ 001121": {
                        "id": "201903260031",
                        "barcode": "001121",
                        "place": "E1B07",
                        "designation": "Détecteur de vérin PARKER"
                    }
                },
                "08": {
                    "Détecteur de vérin METAL WORK ~ E1B08 ~ 001117": {
                        "id": "201903260027",
                        "barcode": "001117",
                        "place": "E1B08",
                        "designation": "Détecteur de vérin METAL WORK"
                    }
                },
                "09": {
                    "Détecteur de vérin AVENTCS DE 10 A 230v AC ou DC ~ E1B09 ~ 001109": {
                        "id": "201903260019",
                        "barcode": "001109",
                        "place": "E1B09",
                        "designation": "Détecteur de vérin AVENTCS DE 10 A 230v AC ou DC"
                    }
                }
            },
            "C": {
                "10": {
                    "Bobine electrovanne NORGREEN 230V 6VA redressé ~ E1C10 ~ 001103": {
                        "id": "201903260013",
                        "barcode": "001103",
                        "place": "E1C10",
                        "designation": "Bobine electrovanne NORGREEN 230V 6VA redressé"
                    }
                },
                "11": {
                    "Bobine electrovanne DANFOSS 24V 9.5w ~ E1C11 ~ 001107": {
                        "id": "201903260017",
                        "barcode": "001107",
                        "place": "E1C11",
                        "designation": "Bobine electrovanne DANFOSS 24V 9.5w"
                    }
                },
                "12": {
                    "Bobine electropilote M16/18 24Vdc METAL WORK ~ E1C12 ~ 001108": {
                        "id": "201903260018",
                        "barcode": "001108",
                        "place": "E1C12",
                        "designation": "Bobine electropilote M16/18 24Vdc METAL WORK"
                    }
                },
                "13": {
                    "Connecteur pour electrovanne ~ E1C13 ~ 001643": {
                        "id": "201905060009",
                        "barcode": "001643",
                        "place": "E1C13",
                        "designation": "Connecteur pour electrovanne"
                    }
                },
                "14": {
                    "Connecteur pour electrovanne ~ E1C14 ~ 001642": {
                        "id": "201905060008",
                        "barcode": "001642",
                        "place": "E1C14",
                        "designation": "Connecteur pour electrovanne"
                    },
                    "Connecteur pour electrovanne ~ E1C14 ~ 001644": {
                        "id": "201905060010",
                        "barcode": "001644",
                        "place": "E1C14",
                        "designation": "Connecteur pour electrovanne"
                    }
                },
                "01": {
                    "Tête d'electrovanne ~ E1C01 ~ 001098": {
                        "id": "201903260008",
                        "barcode": "001098",
                        "place": "E1C01",
                        "designation": "Tête d'electrovanne"
                    }
                },
                "02": {
                    "Bobine electrovanne BURKERT 24vac 4w ~ E1C02 ~ 001099": {
                        "id": "201903260009",
                        "barcode": "001099",
                        "place": "E1C02",
                        "designation": "Bobine electrovanne BURKERT 24vac 4w"
                    }
                },
                "03": {
                    "Bobine electrovanne BURKERT 24vdc 4w ~ E1C03 ~ 001100": {
                        "id": "201903260010",
                        "barcode": "001100",
                        "place": "E1C03",
                        "designation": "Bobine electrovanne BURKERT 24vdc 4w"
                    }
                },
                "04": {
                    "Tête d'electrovanne ~ E1C04 ~ 001101": {
                        "id": "201903260011",
                        "barcode": "001101",
                        "place": "E1C04",
                        "designation": "Tête d'electrovanne"
                    }
                },
                "05": {
                    "Bobine electrovanne CAMOZZI 24vdc 5w ~ E1C05 ~ 001102": {
                        "id": "201903260012",
                        "barcode": "001102",
                        "place": "E1C05",
                        "designation": "Bobine electrovanne CAMOZZI 24vdc 5w"
                    }
                },
                "06": {
                    "Bobine electrovanne PARKER 24vdc 2.6w ~ E1C06 ~ 001105": {
                        "id": "201903260015",
                        "barcode": "001105",
                        "place": "E1C06",
                        "designation": "Bobine electrovanne PARKER 24vdc 2.6w"
                    }
                },
                "07": {
                    "Tête d'electrovanne din 43650 ~ E1C07 ~ 001104": {
                        "id": "201903260014",
                        "barcode": "001104",
                        "place": "E1C07",
                        "designation": "Tête d'electrovanne din 43650"
                    }
                },
                "08": {
                    "Bobine electrovanne 032102 24Vdc 100°/°ED ~ E1C08 ~ 001831": {
                        "id": "202005080002",
                        "barcode": "001831",
                        "place": "E1C08",
                        "designation": "Bobine electrovanne 032102 24Vdc 100°/°ED"
                    }
                },
                "09": {
                    "Bobine electrovanne BOSCH 24Vdc 2W ~ E1C09 ~ 001106": {
                        "id": "201903260016",
                        "barcode": "001106",
                        "place": "E1C09",
                        "designation": "Bobine electrovanne BOSCH 24Vdc 2W"
                    }
                },
                "09 bis": {
                    "Bobine electrovanne 230Vac ~ E1C09BIS ~ 002298": {
                        "id": "202211290001",
                        "barcode": "002298",
                        "place": "E1C09BIS",
                        "designation": "Bobine electrovanne 230Vac"
                    }
                }
            },
            "D": {
                "10": {
                    "Distributeur AVENTICS 5/2 24Vdc ~ E1D10 ~ 002169": {
                        "id": "202111190001",
                        "barcode": "002169",
                        "place": "E1D10",
                        "designation": "Distributeur AVENTICS 5/2 24Vdc"
                    }
                },
                "11": {
                    "Distributeur FESTO ~ E1D11 ~ 001088": {
                        "id": "201903250037",
                        "barcode": "001088",
                        "place": "E1D11",
                        "designation": "Distributeur FESTO"
                    }
                },
                "12": {
                    "Distributeur METAL WORK 5/2 bistable en 24V dc ~ E1D12 ~ 001089": {
                        "id": "201903250038",
                        "barcode": "001089",
                        "place": "E1D12",
                        "designation": "Distributeur METAL WORK 5/2 bistable en 24V dc"
                    }
                },
                "13": {
                    "Distributeur SMC 24Vdc ~ E1D13 ~ 001087": {
                        "id": "201903250036",
                        "barcode": "001087",
                        "place": "E1D13",
                        "designation": "Distributeur SMC 24Vdc"
                    }
                },
                "14": {
                    "Distributeur BURKERT monostable 24v ac/dc 2w ~ E1D14 ~ 001091": {
                        "id": "201903260001",
                        "barcode": "001091",
                        "place": "E1D14",
                        "designation": "Distributeur BURKERT monostable 24v ac/dc 2w"
                    }
                },
                "15": {
                    "Distributeur CAMOZZI serie 3 ~ E1D15 ~ 001092": {
                        "id": "201903260002",
                        "barcode": "001092",
                        "place": "E1D15",
                        "designation": "Distributeur CAMOZZI serie 3"
                    }
                },
                "16": {
                    "Distributeur 5/2 NORGREN en 3/8'' 24Vdc ~ E1D16 ~ 002509": {
                        "id": "202312010001",
                        "barcode": "002509",
                        "place": "E1D16",
                        "designation": "Distributeur 5/2 NORGREN en 3/8'' 24Vdc"
                    }
                },
                "17": {
                    "Distributeur PNEUMAX en G1/8'' ~ E1D17 ~ 001094": {
                        "id": "201903260004",
                        "barcode": "001094",
                        "place": "E1D17",
                        "designation": "Distributeur PNEUMAX en G1/8''"
                    }
                },
                "18": {
                    "Distributeur ORIGA ~ E1D18 ~ 001095": {
                        "id": "201903260005",
                        "barcode": "001095",
                        "place": "E1D18",
                        "designation": "Distributeur ORIGA"
                    }
                },
                "19": {
                    "Distributeur CAMOZZI 5/3 CENTRE FERME ~ E1D19 ~ 001096": {
                        "id": "201903260006",
                        "barcode": "001096",
                        "place": "E1D19",
                        "designation": "Distributeur CAMOZZI 5/3 CENTRE FERME"
                    }
                },
                "20": {
                    "Module de securité pneumatique Metal Work serie one ~ E1D20 ~ 001932": {
                        "id": "202103260001",
                        "barcode": "001932",
                        "place": "E1D20",
                        "designation": "Module de securité pneumatique Metal Work serie one"
                    }
                },
                "01": {
                    "Distributeur REXROTH ~ E1D01 ~ 001078": {
                        "id": "201903250027",
                        "barcode": "001078",
                        "place": "E1D01",
                        "designation": "Distributeur REXROTH"
                    }
                },
                "02": {
                    "Distributeur METAL WORK 24Vdc ~ E1D02 ~ 001079": {
                        "id": "201903250028",
                        "barcode": "001079",
                        "place": "E1D02",
                        "designation": "Distributeur METAL WORK 24Vdc"
                    }
                },
                "03": {
                    "Distributeur METAL WORK 24Vac ~ E1D03 ~ 001082": {
                        "id": "201903250031",
                        "barcode": "001082",
                        "place": "E1D03",
                        "designation": "Distributeur METAL WORK 24Vac"
                    }
                },
                "04": {
                    "Distributeur METAL WORK 5/2 G1/8 monostable sans bobine ~ E1D04 ~ 001081": {
                        "id": "201903250030",
                        "barcode": "001081",
                        "place": "E1D04",
                        "designation": "Distributeur METAL WORK 5/2 G1/8 monostable sans bobine"
                    }
                },
                "05": {
                    "Distributeur METAL WORK 5/3 centre ouvert G1/8 en 220 V ~ E1D05 ~ 002596": {
                        "id": "202407030001",
                        "barcode": "002596",
                        "place": "E1D05",
                        "designation": "Distributeur METAL WORK 5/3 centre ouvert G1/8 en 220 V"
                    }
                },
                "06": {
                    "Distributeur BURKERT bistable 4/2 en 24V ac/dc ~ E1D06 ~ 001083": {
                        "id": "201903250032",
                        "barcode": "001083",
                        "place": "E1D06",
                        "designation": "Distributeur BURKERT bistable 4/2 en 24V ac/dc"
                    }
                },
                "07": {
                    "Distributeur REXROTH 24V dc ~ E1D07 ~ 001084": {
                        "id": "201903250033",
                        "barcode": "001084",
                        "place": "E1D07",
                        "designation": "Distributeur REXROTH 24V dc"
                    }
                },
                "08": {
                    "Distributeur NORGREEN ~ E1D08 ~ 001085": {
                        "id": "201903250034",
                        "barcode": "001085",
                        "place": "E1D08",
                        "designation": "Distributeur NORGREEN"
                    }
                },
                "08bis": {
                    "Distributeur METAL WORK 5/3 centre fermé ~ E1D08BIS ~ 002552": {
                        "id": "202402190001",
                        "barcode": "002552",
                        "place": "E1D08BIS",
                        "designation": "Distributeur METAL WORK 5/3 centre fermé"
                    }
                },
                "09": {
                    "Distributeur IMI HERION 230V ~ E1D09 ~ 001086": {
                        "id": "201903250035",
                        "barcode": "001086",
                        "place": "E1D09",
                        "designation": "Distributeur IMI HERION 230V"
                    }
                }
            },
            "E": {
                "10": {
                    "Electrovanne GEMU type 0324 dn12 en 24Vdc ~ E1E10 ~ 001063": {
                        "id": "201903250012",
                        "barcode": "001063",
                        "place": "E1E10",
                        "designation": "Electrovanne GEMU type 0324 dn12 en 24Vdc"
                    }
                },
                "11": {
                    "Electrovanne Burkert 24v dc ~ E1E11 ~ 002068": {
                        "id": "202110270005",
                        "barcode": "002068",
                        "place": "E1E11",
                        "designation": "Electrovanne Burkert 24v dc"
                    }
                },
                "12": {
                    "Electrovanne Burkert 24v ac g1/4 ~ E1E12 ~ 001065": {
                        "id": "201903250014",
                        "barcode": "001065",
                        "place": "E1E12",
                        "designation": "Electrovanne Burkert 24v ac g1/4"
                    }
                },
                "13": {
                    "Electrovanne Burkert 24v dc g1/8 ~ E1E13 ~ 001066": {
                        "id": "201903250015",
                        "barcode": "001066",
                        "place": "E1E13",
                        "designation": "Electrovanne Burkert 24v dc g1/8"
                    }
                },
                "14": {
                    "Electrovanne Burkert 24v ac g1/8 ~ E1E14 ~ 001067": {
                        "id": "201903250016",
                        "barcode": "001067",
                        "place": "E1E14",
                        "designation": "Electrovanne Burkert 24v ac g1/8"
                    }
                },
                "15": {
                    "Tete d'electrovanne Burkert 24v ac ~ E1E15 ~ 001069": {
                        "id": "201903250018",
                        "barcode": "001069",
                        "place": "E1E15",
                        "designation": "Tete d'electrovanne Burkert 24v ac"
                    }
                },
                "16": {
                    "Electrovanne Burkert g1/8 4w ~ E1E16 ~ 001070": {
                        "id": "201903250019",
                        "barcode": "001070",
                        "place": "E1E16",
                        "designation": "Electrovanne Burkert g1/8 4w"
                    }
                },
                "17": {
                    "Electrovanne Burkert 230vac g3/8 8w ~ E1E17 ~ 001071": {
                        "id": "201903250020",
                        "barcode": "001071",
                        "place": "E1E17",
                        "designation": "Electrovanne Burkert 230vac g3/8 8w"
                    }
                },
                "18": {
                    "Electrovanne Burkert g1/8 4w ~ E1E18 ~ 001072": {
                        "id": "201903250021",
                        "barcode": "001072",
                        "place": "E1E18",
                        "designation": "Electrovanne Burkert g1/8 4w"
                    }
                },
                "19": {
                    "Electrovanne Burkert g1/8 4w ~ E1E19 ~ 001073": {
                        "id": "201903250022",
                        "barcode": "001073",
                        "place": "E1E19",
                        "designation": "Electrovanne Burkert g1/8 4w"
                    }
                },
                "20": {
                    "Electrovanne Burkert 230vac g1/4 8w ~ E1E20 ~ 001075": {
                        "id": "201903250024",
                        "barcode": "001075",
                        "place": "E1E20",
                        "designation": "Electrovanne Burkert 230vac g1/4 8w"
                    }
                },
                "21": {
                    "Electrovanne CAMOZZI g1/8 24Vdc 5w ~ E1E21 ~ 001074": {
                        "id": "201903250023",
                        "barcode": "001074",
                        "place": "E1E21",
                        "designation": "Electrovanne CAMOZZI g1/8 24Vdc 5w"
                    }
                },
                "22": {
                    "Minidistributeur Aventis 5/2 M5 rappel diff 24Vdc ~ E1E22 ~ 002518": {
                        "id": "202312210001",
                        "barcode": "002518",
                        "place": "E1E22",
                        "designation": "Minidistributeur Aventis 5/2 M5 rappel diff 24Vdc"
                    }
                },
                "23": {
                    "Reducteur de debit en 1/4'' ~ E1E23 ~ 002529": {
                        "id": "202401030001",
                        "barcode": "002529",
                        "place": "E1E23",
                        "designation": "Reducteur de debit en 1/4''"
                    }
                },
                "24": {
                    "Vanne 3/2 contact NO pneumatique diamètre 4 ~ E1E24 ~ 002684": {
                        "id": "202504290001",
                        "barcode": "002684",
                        "place": "E1E24",
                        "designation": "Vanne 3/2 contact NO pneumatique diamètre 4"
                    },
                    "Vanne 3/2 contact NC pneumatique diamètre 4 ~ E1E24 ~ 002685": {
                        "id": "202504290002",
                        "barcode": "002685",
                        "place": "E1E24",
                        "designation": "Vanne 3/2 contact NC pneumatique diamètre 4"
                    }
                },
                "01": {
                    "Electrovanne Burkert 24Vac G1/2 4w ~ E1E01 ~ 001052": {
                        "id": "201903250001",
                        "barcode": "001052",
                        "place": "E1E01",
                        "designation": "Electrovanne Burkert 24Vac G1/2 4w"
                    }
                },
                "02": {
                    "Electrovanne Burkert 24Vdc G1/2 4w ~ E1E02 ~ 001053": {
                        "id": "201903250002",
                        "barcode": "001053",
                        "place": "E1E02",
                        "designation": "Electrovanne Burkert 24Vdc G1/2 4w"
                    }
                },
                "03": {
                    "Electrovanne Burkert 24Vdc G1/2 10w ~ E1E03 ~ 001054": {
                        "id": "201903250003",
                        "barcode": "001054",
                        "place": "E1E03",
                        "designation": "Electrovanne Burkert 24Vdc G1/2 10w"
                    }
                },
                "04": {
                    "Electrovanne Burkert 230Vac G1/2 8w ~ E1E04 ~ 001055": {
                        "id": "201903250004",
                        "barcode": "001055",
                        "place": "E1E04",
                        "designation": "Electrovanne Burkert 230Vac G1/2 8w"
                    }
                },
                "05": {
                    "Electrovanne Burkert 24Vac G3/4 8w ~ E1E05 ~ 001056": {
                        "id": "201903250005",
                        "barcode": "001056",
                        "place": "E1E05",
                        "designation": "Electrovanne Burkert 24Vac G3/4 8w"
                    }
                },
                "06": {
                    "Electrovanne DANFOSS 24Vdc ~ E1E06 ~ 001057": {
                        "id": "201903250006",
                        "barcode": "001057",
                        "place": "E1E06",
                        "designation": "Electrovanne DANFOSS 24Vdc"
                    },
                    "Bobine electrovanne DANFOSS 24Vdc ~ E1E06 ~ 001058": {
                        "id": "201903250007",
                        "barcode": "001058",
                        "place": "E1E06",
                        "designation": "Bobine electrovanne DANFOSS 24Vdc"
                    }
                },
                "07": {
                    "Electrovanne Burkert 24Vdc G1/8 4w ~ E1E07 ~ 001059": {
                        "id": "201903250008",
                        "barcode": "001059",
                        "place": "E1E07",
                        "designation": "Electrovanne Burkert 24Vdc G1/8 4w"
                    }
                },
                "08": {
                    "Electrovanne BURKERT 24v dc ~ E1E08 ~ 001064": {
                        "id": "201903250013",
                        "barcode": "001064",
                        "place": "E1E08",
                        "designation": "Electrovanne BURKERT 24v dc"
                    }
                },
                "09": {
                    "Distributeur NORGREEN ~ E1E09 ~ 001061": {
                        "id": "201903250010",
                        "barcode": "001061",
                        "place": "E1E09",
                        "designation": "Distributeur NORGREEN"
                    },
                    "Bobine NORGREEN 230V 15VA pour distributeur NORGREEN ~ E1E09 ~ 001062": {
                        "id": "201903250011",
                        "barcode": "001062",
                        "place": "E1E09",
                        "designation": "Bobine NORGREEN 230V 15VA pour distributeur NORGREEN"
                    }
                },
                "10bis": {
                    "Electrovanne GEMU type 0324 dn12 en 24Vac 50hz ~ E1E10BIS ~ 002540": {
                        "id": "202401170001",
                        "barcode": "002540",
                        "place": "E1E10BIS",
                        "designation": "Electrovanne GEMU type 0324 dn12 en 24Vac 50hz"
                    }
                }
            },
            "F": {
                "Tuyau PEX diamètre 16 ~ E1F ~ 000408": {
                    "id": "201902120015",
                    "barcode": "000408",
                    "place": "E1F",
                    "designation": "Tuyau PEX diamètre 16"
                }
            }
        },
        "2 Colonne": {
            "A": {
                "Tuyau d'air trycoclair 13X20 ~ E2A ~ 001835": {
                    "id": "202006080002",
                    "barcode": "001835",
                    "place": "E2A",
                    "designation": "Tuyau d'air trycoclair 13X20"
                },
                "Tuyau d'air trycoclair 6X12 ~ E2A ~ 002070": {
                    "id": "202110280002",
                    "barcode": "002070",
                    "place": "E2A",
                    "designation": "Tuyau d'air trycoclair 6X12"
                },
                "Tuyau d'air trycoclair 10X16 ~ E2A ~ 002071": {
                    "id": "202110280003",
                    "barcode": "002071",
                    "place": "E2A",
                    "designation": "Tuyau d'air trycoclair 10X16"
                },
                "Tuyau d'air trycoclair 25X34 ~ E2A ~ 002530": {
                    "id": "202401040001",
                    "barcode": "002530",
                    "place": "E2A",
                    "designation": "Tuyau d'air trycoclair 25X34"
                }
            },
            "B": {
                "Tuyau produit lessiviel 12X19 (surplus Chreystens) ~ E2B ~ 002074": {
                    "id": "202110280006",
                    "barcode": "002074",
                    "place": "E2B",
                    "designation": "Tuyau produit lessiviel 12X19 (surplus Chreystens)"
                },
                "Tuyau agriflex 25 mm sorti IBC ~ E2B ~ 002170": {
                    "id": "202111220001",
                    "barcode": "002170",
                    "place": "E2B",
                    "designation": "Tuyau agriflex 25 mm sorti IBC"
                }
            },
            "C": {
                "10": {
                    "Chape arriere REXROTH ~ E2C10 ~ 001183": {
                        "id": "201903280026",
                        "barcode": "001183",
                        "place": "E2C10",
                        "designation": "Chape arriere REXROTH"
                    }
                },
                "11": {
                    "Chape arriere AVENTICS ~ E2C11 ~ 001184": {
                        "id": "201903280027",
                        "barcode": "001184",
                        "place": "E2C11",
                        "designation": "Chape arriere AVENTICS"
                    }
                },
                "12": {
                    "Chape avant accouplement verin ~ E2C12 ~ 001185": {
                        "id": "201903280028",
                        "barcode": "001185",
                        "place": "E2C12",
                        "designation": "Chape avant accouplement verin"
                    }
                },
                "13": {
                    "Ecrou avant accouplement verin ~ E2C13 ~ 001186": {
                        "id": "201903280029",
                        "barcode": "001186",
                        "place": "E2C13",
                        "designation": "Ecrou avant accouplement verin"
                    },
                    "Feutre pour joint d16/d30 d'ecrou avant accouplement verin ~ E2C13 ~ 002478": {
                        "id": "202309190003",
                        "barcode": "002478",
                        "place": "E2C13",
                        "designation": "Feutre pour joint d16/d30 d'ecrou avant accouplement verin"
                    }
                },
                "14": {
                    "Joint nez avant pour vérin 32X1300 ~ E2C14 ~ 001187": {
                        "id": "201903280030",
                        "barcode": "001187",
                        "place": "E2C14",
                        "designation": "Joint nez avant pour vérin 32X1300"
                    }
                },
                "15": {
                    "Chape arriere MP2 ~ E2C15 ~ 001177": {
                        "id": "201903280020",
                        "barcode": "001177",
                        "place": "E2C15",
                        "designation": "Chape arriere MP2"
                    },
                    "Chape avant din 7151 M16X1.5 ~ E2C15 ~ 001713": {
                        "id": "201910020001",
                        "barcode": "001713",
                        "place": "E2C15",
                        "designation": "Chape avant din 7151 M16X1.5"
                    }
                },
                "16": {
                    "Kit de joint nez de vérin LP572 (incomplet) ~ E2C16 ~ 001684": {
                        "id": "201905200002",
                        "barcode": "001684",
                        "place": "E2C16",
                        "designation": "Kit de joint nez de vérin LP572 (incomplet)"
                    }
                },
                "18": {
                    "Chape arriere vérin butee M6 ~ E2C18 ~ 001987": {
                        "id": "202107280003",
                        "barcode": "001987",
                        "place": "E2C18",
                        "designation": "Chape arriere vérin butee M6"
                    }
                },
                "19": {
                    "Chape arriere vérin D40 ~ E2C19 ~ 002274": {
                        "id": "202210120001",
                        "barcode": "002274",
                        "place": "E2C19",
                        "designation": "Chape arriere vérin D40"
                    }
                },
                "20": {
                    "Chape arriere AB3 D8-10 ~ E2C20 ~ 002343": {
                        "id": "202303200001",
                        "barcode": "002343",
                        "place": "E2C20",
                        "designation": "Chape arriere AB3 D8-10"
                    }
                },
                "21": {
                    "Chape avant vérin D40 12X125 ~ E2C21 ~ 002377": {
                        "id": "202306010001",
                        "barcode": "002377",
                        "place": "E2C21",
                        "designation": "Chape avant vérin D40 12X125"
                    }
                },
                "01": {
                    "Chape avant vérin M4X8 ~ E2C01 ~ 001176": {
                        "id": "201903280019",
                        "barcode": "001176",
                        "place": "E2C01",
                        "designation": "Chape avant vérin M4X8"
                    }
                },
                "02": {
                    "Chape avant vérin butee M6 5X10 ~ E2C02 ~ 002072": {
                        "id": "202110280004",
                        "barcode": "002072",
                        "place": "E2C02",
                        "designation": "Chape avant vérin butee M6 5X10"
                    }
                },
                "03": {
                    "Chape avant vérin 6X12 M6 ~ E2C03 ~ 001178": {
                        "id": "201903280021",
                        "barcode": "001178",
                        "place": "E2C03",
                        "designation": "Chape avant vérin 6X12 M6"
                    }
                },
                "04": {
                    "Chape avant vérin 8X16 M8 ~ E2C04 ~ 001174": {
                        "id": "201903280017",
                        "barcode": "001174",
                        "place": "E2C04",
                        "designation": "Chape avant vérin 8X16 M8"
                    }
                },
                "05": {
                    "Chape de Vérin 10X20 M10 ~ E2C05 ~ 001175": {
                        "id": "201903280018",
                        "barcode": "001175",
                        "place": "E2C05",
                        "designation": "Chape de Vérin 10X20 M10"
                    }
                },
                "06": {
                    "Chape avant vérin 12X24 M12X1.25 ~ E2C06 ~ 001179": {
                        "id": "201903280022",
                        "barcode": "001179",
                        "place": "E2C06",
                        "designation": "Chape avant vérin 12X24 M12X1.25"
                    }
                },
                "07": {
                    "Chape arriere vérin11 M08 pour diamètre 32 ~ E2C07 ~ 001180": {
                        "id": "201903280023",
                        "barcode": "001180",
                        "place": "E2C07",
                        "designation": "Chape arriere vérin11 M08 pour diamètre 32"
                    }
                },
                "08": {
                    "Chape arriered vérin engageuse GP pour vérin d32 ~ E2C08 ~ 001910": {
                        "id": "202102010001",
                        "barcode": "001910",
                        "place": "E2C08",
                        "designation": "Chape arriered vérin engageuse GP pour vérin d32"
                    }
                },
                "09": {
                    "Chape arriere vérin D32 ~ E2C09 ~ 001182": {
                        "id": "201903280025",
                        "barcode": "001182",
                        "place": "E2C09",
                        "designation": "Chape arriere vérin D32"
                    }
                }
            },
            "D": {
                "10": {
                    "Vérin iso 32X50 ~ E2D10 ~ 001172": {
                        "id": "201903280015",
                        "barcode": "001172",
                        "place": "E2D10",
                        "designation": "Vérin iso 32X50"
                    }
                },
                "11": {
                    "Vérin RK2040/50 ~ E2D11 ~ 001173": {
                        "id": "201903280016",
                        "barcode": "001173",
                        "place": "E2D11",
                        "designation": "Vérin RK2040/50"
                    }
                },
                "12": {
                    "Mini verin ISO 6432 D25 C125 ~ E2D12 ~ 002690": {
                        "id": "202506130001",
                        "barcode": "002690",
                        "place": "E2D12",
                        "designation": "Mini verin ISO 6432 D25 C125"
                    }
                },
                "01": {
                    "Vérin iso 25X60 ~ E2D01 ~ 001162": {
                        "id": "201903280005",
                        "barcode": "001162",
                        "place": "E2D01",
                        "designation": "Vérin iso 25X60"
                    }
                },
                "02": {
                    "Vérin iso 25X65 ~ E2D02 ~ 001163": {
                        "id": "201903280006",
                        "barcode": "001163",
                        "place": "E2D02",
                        "designation": "Vérin iso 25X65"
                    }
                },
                "03": {
                    "Vérin iso 25X100 ~ E2D03 ~ 001164": {
                        "id": "201903280007",
                        "barcode": "001164",
                        "place": "E2D03",
                        "designation": "Vérin iso 25X100"
                    }
                },
                "04": {
                    "Vérin iso 25X160 ~ E2D04 ~ 001169": {
                        "id": "201903280012",
                        "barcode": "001169",
                        "place": "E2D04",
                        "designation": "Vérin iso 25X160"
                    }
                },
                "05": {
                    "Vérin iso 25X200 ~ E2D05 ~ 001165": {
                        "id": "201903280008",
                        "barcode": "001165",
                        "place": "E2D05",
                        "designation": "Vérin iso 25X200"
                    }
                },
                "06": {
                    "Vérin iso 25X215 ~ E2D06 ~ 001166": {
                        "id": "201903280009",
                        "barcode": "001166",
                        "place": "E2D06",
                        "designation": "Vérin iso 25X215"
                    }
                },
                "07": {
                    "Vérin iso 25X225 ~ E2D07 ~ 001167": {
                        "id": "201903280010",
                        "barcode": "001167",
                        "place": "E2D07",
                        "designation": "Vérin iso 25X225"
                    }
                },
                "08": {
                    "Vérin iso 25X250 ~ E2D08 ~ 001168": {
                        "id": "201903280011",
                        "barcode": "001168",
                        "place": "E2D08",
                        "designation": "Vérin iso 25X250"
                    }
                },
                "09": {
                    "Vérin iso 25X400 ~ E2D09 ~ 001170": {
                        "id": "201903280013",
                        "barcode": "001170",
                        "place": "E2D09",
                        "designation": "Vérin iso 25X400"
                    },
                    "Vérin iso 25X500 ~ E2D09 ~ 001171": {
                        "id": "201903280014",
                        "barcode": "001171",
                        "place": "E2D09",
                        "designation": "Vérin iso 25X500"
                    }
                }
            },
            "E": {
                "10": {
                    "Vérin PWB suisse 20X25 ~ E2E10 ~ 001151": {
                        "id": "201903270009",
                        "barcode": "001151",
                        "place": "E2E10",
                        "designation": "Vérin PWB suisse 20X25"
                    }
                },
                "11": {
                    "Vérin iso 20X25 ~ E2E11 ~ 001152": {
                        "id": "201903270010",
                        "barcode": "001152",
                        "place": "E2E11",
                        "designation": "Vérin iso 20X25"
                    }
                },
                "12": {
                    "Vérin iso 20X50 ~ E2E12 ~ 001153": {
                        "id": "201903270011",
                        "barcode": "001153",
                        "place": "E2E12",
                        "designation": "Vérin iso 20X50"
                    }
                },
                "13": {
                    "Vérin iso 20X80 ~ E2E13 ~ 001154": {
                        "id": "201903270012",
                        "barcode": "001154",
                        "place": "E2E13",
                        "designation": "Vérin iso 20X80"
                    }
                },
                "14": {
                    "Vérin iso 20X100 ~ E2E14 ~ 001155": {
                        "id": "201903270013",
                        "barcode": "001155",
                        "place": "E2E14",
                        "designation": "Vérin iso 20X100"
                    }
                },
                "15": {
                    "Vérin iso 20X500 ~ E2E15 ~ 001158": {
                        "id": "201903280001",
                        "barcode": "001158",
                        "place": "E2E15",
                        "designation": "Vérin iso 20X500"
                    }
                },
                "16": {
                    "Vérin iso 25X25 ~ E2E16 ~ 001157": {
                        "id": "201903270015",
                        "barcode": "001157",
                        "place": "E2E16",
                        "designation": "Vérin iso 25X25"
                    }
                },
                "17": {
                    "Vérin 25x25 special JENSEN ~ E2E17 ~ 001156": {
                        "id": "201903270014",
                        "barcode": "001156",
                        "place": "E2E17",
                        "designation": "Vérin 25x25 special JENSEN"
                    }
                },
                "18": {
                    "Vérin iso 25X35 ~ E2E18 ~ 001159": {
                        "id": "201903280002",
                        "barcode": "001159",
                        "place": "E2E18",
                        "designation": "Vérin iso 25X35"
                    }
                },
                "19": {
                    "Vérin 25X35 (special Jensen) ~ E2E19 ~ 001160": {
                        "id": "201903280003",
                        "barcode": "001160",
                        "place": "E2E19",
                        "designation": "Vérin 25X35 (special Jensen)"
                    }
                },
                "20": {
                    "Vérin iso 25X50 ~ E2E20 ~ 001161": {
                        "id": "201903280004",
                        "barcode": "001161",
                        "place": "E2E20",
                        "designation": "Vérin iso 25X50"
                    }
                },
                "01": {
                    "Vérin iso 10X80 ~ E2E01 ~ 001140": {
                        "id": "201903260050",
                        "barcode": "001140",
                        "place": "E2E01",
                        "designation": "Vérin iso 10X80"
                    }
                },
                "02": {
                    "Vérin iso 12X10 ~ E2E02 ~ 001142": {
                        "id": "201903260052",
                        "barcode": "001142",
                        "place": "E2E02",
                        "designation": "Vérin iso 12X10"
                    }
                },
                "03": {
                    "Vérin iso 16X10 ~ E2E03 ~ 002389": {
                        "id": "202306080001",
                        "barcode": "002389",
                        "place": "E2E03",
                        "designation": "Vérin iso 16X10"
                    }
                },
                "04": {
                    "Vérin double tige 16X25 ~ E2E04 ~ 001146": {
                        "id": "201903270004",
                        "barcode": "001146",
                        "place": "E2E04",
                        "designation": "Vérin double tige 16X25"
                    }
                },
                "05": {
                    "Vérin iso 16X25 ~ E2E05 ~ 001145": {
                        "id": "201903270003",
                        "barcode": "001145",
                        "place": "E2E05",
                        "designation": "Vérin iso 16X25"
                    }
                },
                "06": {
                    "Vérin iso 16X50 ~ E2E06 ~ 001144": {
                        "id": "201903270002",
                        "barcode": "001144",
                        "place": "E2E06",
                        "designation": "Vérin iso 16X50"
                    }
                },
                "07": {
                    "Vérin iso 16X400 ~ E2E07 ~ 001147": {
                        "id": "201903270005",
                        "barcode": "001147",
                        "place": "E2E07",
                        "designation": "Vérin iso 16X400"
                    }
                },
                "08": {
                    "Vérin iso 20X15 ~ E2E08 ~ 001197": {
                        "id": "201903290008",
                        "barcode": "001197",
                        "place": "E2E08",
                        "designation": "Vérin iso 20X15"
                    }
                },
                "09": {
                    "Vérin 20X25 ~ E2E09 ~ 001150": {
                        "id": "201903270008",
                        "barcode": "001150",
                        "place": "E2E09",
                        "designation": "Vérin 20X25"
                    }
                }
            },
            "F": {
                "Tuyau PEX diamètre 12 ~ E2F ~ 000468": {
                    "id": "201903050027",
                    "barcode": "000468",
                    "place": "E2F",
                    "designation": "Tuyau PEX diamètre 12"
                }
            }
        },
        "3 Colonne": {
            "A": {
                "01": {
                    "Tuyau d'air diamètre 10X12 (25m) ~ E3A01 ~ 001992": {
                        "id": "202107280008",
                        "barcode": "001992",
                        "place": "E3A01",
                        "designation": "Tuyau d'air diamètre 10X12 (25m)"
                    }
                },
                "02": {
                    "Tuyau d'air diamètre 14X16 (25m) ~ E3A02 ~ 001990": {
                        "id": "202107280006",
                        "barcode": "001990",
                        "place": "E3A02",
                        "designation": "Tuyau d'air diamètre 14X16 (25m)"
                    }
                }
            },
            "B": {
                "01": {
                    "Tuyau d'air diamètre 6X8 (25m) tube bi-polymère noir ~ E3B01 ~ 001988": {
                        "id": "202107280004",
                        "barcode": "001988",
                        "place": "E3B01",
                        "designation": "Tuyau d'air diamètre 6X8 (25m) tube bi-polymère noir"
                    }
                },
                "02": {
                    "Tuyau d'air diamètre 8X10 (25m) ~ E3B02 ~ 001989": {
                        "id": "202107280005",
                        "barcode": "001989",
                        "place": "E3B02",
                        "designation": "Tuyau d'air diamètre 8X10 (25m)"
                    }
                }
            },
            "C": {
                "01": {
                    "Tuyau d'air diamètre 2.5X4 (25m) tube bi-polymère noir ~ E3C01 ~ 001717": {
                        "id": "201910110001",
                        "barcode": "001717",
                        "place": "E3C01",
                        "designation": "Tuyau d'air diamètre 2.5X4 (25m) tube bi-polymère noir"
                    }
                },
                "02": {
                    "Tuyau d'air diamètre 3X5 (25m) tube bi-polymère noir ~ E3C02 ~ 001985": {
                        "id": "202107280001",
                        "barcode": "001985",
                        "place": "E3C02",
                        "designation": "Tuyau d'air diamètre 3X5 (25m) tube bi-polymère noir"
                    }
                },
                "03": {
                    "Tuyau d'air diamètre 4X6 (25m) tube bi-polymère noir ~ E3C03 ~ 001986": {
                        "id": "202107280002",
                        "barcode": "001986",
                        "place": "E3C03",
                        "designation": "Tuyau d'air diamètre 4X6 (25m) tube bi-polymère noir"
                    }
                },
                "04": {
                    "Tuyau d'air double bitube soudé pu98 diamètre 6 ~ E3C04 ~ 001610": {
                        "id": "201905020001",
                        "barcode": "001610",
                        "place": "E3C04",
                        "designation": "Tuyau d'air double bitube soudé pu98 diamètre 6"
                    }
                }
            },
            "D": {
                "00": {
                    "Vérin carré 40X70 ~ E3D00 ~ 001217": {
                        "id": "201904030017",
                        "barcode": "001217",
                        "place": "E3D00",
                        "designation": "Vérin carré 40X70"
                    },
                    "Vis tête basse M6 X16 pour vérin guidé ~ E3D00 ~ 002558": {
                        "id": "202403290002",
                        "barcode": "002558",
                        "place": "E3D00",
                        "designation": "Vis tête basse M6 X16 pour vérin guidé"
                    }
                },
                "01": {
                    "Vérin carré 40X50 ~ E3D01 ~ 002620": {
                        "id": "202411070001",
                        "barcode": "002620",
                        "place": "E3D01",
                        "designation": "Vérin carré 40X50"
                    }
                },
                "02": {
                    "Vérin carré 40X80 ~ E3D02 ~ 001218": {
                        "id": "201904030018",
                        "barcode": "001218",
                        "place": "E3D02",
                        "designation": "Vérin carré 40X80"
                    }
                },
                "03": {
                    "Vérin carré 40X100 ~ E3D03 ~ 001219": {
                        "id": "201904030019",
                        "barcode": "001219",
                        "place": "E3D03",
                        "designation": "Vérin carré 40X100"
                    }
                },
                "04": {
                    "Vérin carré 40X150 ~ E3D04 ~ 001220": {
                        "id": "201904030020",
                        "barcode": "001220",
                        "place": "E3D04",
                        "designation": "Vérin carré 40X150"
                    }
                },
                "05": {
                    "Vérin carré 40X400 ~ E3D05 ~ 001221": {
                        "id": "201904030021",
                        "barcode": "001221",
                        "place": "E3D05",
                        "designation": "Vérin carré 40X400"
                    }
                },
                "05 Bis": {
                    "Vérin carré 40X640 ~ E3D05BIS ~ 001224": {
                        "id": "201904030024",
                        "barcode": "001224",
                        "place": "E3D05BIS",
                        "designation": "Vérin carré 40X640"
                    }
                },
                "06": {
                    "Vérin carré 50X25 ~ E3D06 ~ 001222": {
                        "id": "201904030022",
                        "barcode": "001222",
                        "place": "E3D06",
                        "designation": "Vérin carré 50X25"
                    }
                },
                "07": {
                    "Vérin carré 63X100 ~ E3D07 ~ 001696": {
                        "id": "201907240001",
                        "barcode": "001696",
                        "place": "E3D07",
                        "designation": "Vérin carré 63X100"
                    }
                },
                "08": {
                    "Vérin carré 80X50 ~ E3D08 ~ 001223": {
                        "id": "201904030023",
                        "barcode": "001223",
                        "place": "E3D08",
                        "designation": "Vérin carré 80X50"
                    }
                },
                "09": {
                    "Vérin carré 100X50 ~ E3D09 ~ 001226": {
                        "id": "201904030026",
                        "barcode": "001226",
                        "place": "E3D09",
                        "designation": "Vérin carré 100X50"
                    }
                }
            },
            "E": {
                "10": {
                    "Vérin carré avec guidage 25X70 ~ E3E10 ~ 001208": {
                        "id": "201904030008",
                        "barcode": "001208",
                        "place": "E3E10",
                        "designation": "Vérin carré avec guidage 25X70"
                    }
                },
                "11": {
                    "Vérin carré 32X25 ~ E3E11 ~ 001209": {
                        "id": "201904030009",
                        "barcode": "001209",
                        "place": "E3E11",
                        "designation": "Vérin carré 32X25"
                    }
                },
                "12": {
                    "Vérin carré 32X65 ~ E3E12 ~ 001210": {
                        "id": "201904030010",
                        "barcode": "001210",
                        "place": "E3E12",
                        "designation": "Vérin carré 32X65"
                    }
                },
                "13": {
                    "Vérin carré 32X80 avec guide carré ~ E3E13 ~ 001211": {
                        "id": "201904030011",
                        "barcode": "001211",
                        "place": "E3E13",
                        "designation": "Vérin carré 32X80 avec guide carré"
                    },
                    "Vérin carré 32X80 sans guide carré ne pas recommandé ~ E3E13 ~ 002553": {
                        "id": "202402190002",
                        "barcode": "002553",
                        "place": "E3E13",
                        "designation": "Vérin carré 32X80 sans guide carré ne pas recommandé"
                    }
                },
                "14": {
                    "Vérin carré 32X100 ~ E3E14 ~ 001212": {
                        "id": "201904030012",
                        "barcode": "001212",
                        "place": "E3E14",
                        "designation": "Vérin carré 32X100"
                    },
                    "Vérin carré 32X150 ~ E3E14 ~ 001213": {
                        "id": "201904030013",
                        "barcode": "001213",
                        "place": "E3E14",
                        "designation": "Vérin carré 32X150"
                    }
                },
                "15": {
                    "Vérin carré 32X200 ~ E3E15 ~ 001214": {
                        "id": "201904030014",
                        "barcode": "001214",
                        "place": "E3E15",
                        "designation": "Vérin carré 32X200"
                    }
                },
                "16": {
                    "Vérin carré 32X250 ~ E3E16 ~ 001215": {
                        "id": "201904030015",
                        "barcode": "001215",
                        "place": "E3E16",
                        "designation": "Vérin carré 32X250"
                    },
                    "Vérin carré 32X410 exclusivement PARKER pour entraxe ~ E3E16 ~ 001216": {
                        "id": "201904030016",
                        "barcode": "001216",
                        "place": "E3E16",
                        "designation": "Vérin carré 32X410 exclusivement PARKER pour entraxe"
                    }
                },
                "17": {
                    "Vérin losange 25X25 ~ E3E17 ~ 001837": {
                        "id": "202006150002",
                        "barcode": "001837",
                        "place": "E3E17",
                        "designation": "Vérin losange 25X25"
                    }
                },
                "01": {
                    "Vérin carré JOUCOMATIC ~ E3E01 ~ 001198": {
                        "id": "201904020001",
                        "barcode": "001198",
                        "place": "E3E01",
                        "designation": "Vérin carré JOUCOMATIC"
                    }
                },
                "02": {
                    "Vérin 12X10 avec ressort ~ E3E02 ~ 001199": {
                        "id": "201904020002",
                        "barcode": "001199",
                        "place": "E3E02",
                        "designation": "Vérin 12X10 avec ressort"
                    }
                },
                "03": {
                    "Vérin carré 12X10 ~ E3E03 ~ 001200": {
                        "id": "201904020003",
                        "barcode": "001200",
                        "place": "E3E03",
                        "designation": "Vérin carré 12X10"
                    }
                },
                "04": {
                    "Vérin carré 20X50 ~ E3E04 ~ 001202": {
                        "id": "201904030002",
                        "barcode": "001202",
                        "place": "E3E04",
                        "designation": "Vérin carré 20X50"
                    }
                },
                "05": {
                    "Vérin carré 20X50 avec guide ~ E3E05 ~ 001203": {
                        "id": "201904030003",
                        "barcode": "001203",
                        "place": "E3E05",
                        "designation": "Vérin carré 20X50 avec guide"
                    }
                },
                "06": {
                    "Vérin carré 25X10 ~ E3E06 ~ 001204": {
                        "id": "201904030004",
                        "barcode": "001204",
                        "place": "E3E06",
                        "designation": "Vérin carré 25X10"
                    }
                },
                "07": {
                    "Vérin carré 25X25 ~ E3E07 ~ 001205": {
                        "id": "201904030005",
                        "barcode": "001205",
                        "place": "E3E07",
                        "designation": "Vérin carré 25X25"
                    }
                },
                "08": {
                    "Vérin carré 25X30 avec guide ~ E3E08 ~ 001206": {
                        "id": "201904030006",
                        "barcode": "001206",
                        "place": "E3E08",
                        "designation": "Vérin carré 25X30 avec guide"
                    }
                },
                "09": {
                    "Vérin carré 25X40 ~ E3E09 ~ 001207": {
                        "id": "201904030007",
                        "barcode": "001207",
                        "place": "E3E09",
                        "designation": "Vérin carré 25X40"
                    }
                },
                "09 Bis": {
                    "Vérin carré 25X50 ~ E3E09BIS ~ 002312": {
                        "id": "202301020002",
                        "barcode": "002312",
                        "place": "E3E09BIS",
                        "designation": "Vérin carré 25X50"
                    }
                }
            }
        },
        "4 Colonne": {
            "01": {
                "Vérin 32X1300 ~ E4 ~ 001706": {
                    "id": "201909300001",
                    "barcode": "001706",
                    "place": "E4",
                    "designation": "Vérin 32X1300"
                }
            },
            "02": {
                "Vérin carré 40X1050 ~ E4 ~ 001227": {
                    "id": "201904030027",
                    "barcode": "001227",
                    "place": "E4",
                    "designation": "Vérin carré 40X1050"
                }
            },
            "03": {
                "Vérin carré 50X1050 ~ E4 ~ 001228": {
                    "id": "201904030028",
                    "barcode": "001228",
                    "place": "E4",
                    "designation": "Vérin carré 50X1050"
                }
            },
            "04": {
                "Vérin carré 80X700 ~ E4 ~ 001225": {
                    "id": "201904030025",
                    "barcode": "001225",
                    "place": "E4",
                    "designation": "Vérin carré 80X700"
                }
            },
            "05": {
                "Verin sans tige 25X800 ~ E4 ~ 001188": {
                    "id": "201903280031",
                    "barcode": "001188",
                    "place": "E4",
                    "designation": "Verin sans tige 25X800"
                }
            },
            "06": {
                "Vérin sans tige 25X1040 ~ E4 ~ 001189": {
                    "id": "201903280032",
                    "barcode": "001189",
                    "place": "E4",
                    "designation": "Vérin sans tige 25X1040"
                }
            },
            "07": {
                "Vérin carré 63X800 pour tapis T5.8 ~ E4 ~ 002626": {
                    "id": "202412120001",
                    "barcode": "002626",
                    "place": "E4",
                    "designation": "Vérin carré 63X800 pour tapis T5.8"
                }
            }
        }
    },
    "Rangée F": {
        "1 Colonne": {
            "A": {
                "10": {
                    "Disjoncteur thermique 0-1.6A ~ F1A10 ~ 001589": {
                        "id": "201904190009",
                        "barcode": "001589",
                        "place": "F1A10",
                        "designation": "Disjoncteur thermique 0-1.6A"
                    }
                },
                "11": {
                    "Disjoncteur thermique 0.63-1A ~ F1A11 ~ 002084": {
                        "id": "202111030009",
                        "barcode": "002084",
                        "place": "F1A11",
                        "designation": "Disjoncteur thermique 0.63-1A"
                    }
                },
                "12": {
                    "Disjoncteur thermique 1-1.6A ~ F1A12 ~ 001591": {
                        "id": "201904190011",
                        "barcode": "001591",
                        "place": "F1A12",
                        "designation": "Disjoncteur thermique 1-1.6A"
                    }
                },
                "13": {
                    "Disjoncteur thermique 1.6-2.5A ~ F1A13 ~ 001595": {
                        "id": "201904190015",
                        "barcode": "001595",
                        "place": "F1A13",
                        "designation": "Disjoncteur thermique 1.6-2.5A"
                    }
                },
                "14": {
                    "Disjoncteur thermique 2.5-4A ~ F1A14 ~ 001592": {
                        "id": "201904190012",
                        "barcode": "001592",
                        "place": "F1A14",
                        "designation": "Disjoncteur thermique 2.5-4A"
                    }
                },
                "15": {
                    "Disjoncteur thermique 4-6.3A ~ F1A15 ~ 001596": {
                        "id": "201904190016",
                        "barcode": "001596",
                        "place": "F1A15",
                        "designation": "Disjoncteur thermique 4-6.3A"
                    }
                },
                "16": {
                    "Disjoncteur thermique 6-10A ~ F1A16 ~ 002543": {
                        "id": "202207010003",
                        "barcode": "002543",
                        "place": "F1A16",
                        "designation": "Disjoncteur thermique 6-10A"
                    }
                },
                "17": {
                    "Disjoncteur thermique 10-16A ~ F1A17 ~ 001867": {
                        "id": "202009080002",
                        "barcode": "001867",
                        "place": "F1A17",
                        "designation": "Disjoncteur thermique 10-16A"
                    },
                    "Bloc additif pour Disjoncteur MOELLER ~ F1A17 ~ 002387": {
                        "id": "202306010011",
                        "barcode": "002387",
                        "place": "F1A17",
                        "designation": "Bloc additif pour Disjoncteur MOELLER"
                    }
                },
                "18": {
                    "Bloc additif ~ F1A18 ~ 001597": {
                        "id": "201904190017",
                        "barcode": "001597",
                        "place": "F1A18",
                        "designation": "Bloc additif"
                    }
                },
                "19": {
                    "Bloc additif ~ F1A19 ~ 001598": {
                        "id": "201904190018",
                        "barcode": "001598",
                        "place": "F1A19",
                        "designation": "Bloc additif"
                    }
                },
                "20": {
                    "Bloc additif ~ F1A20 ~ 001599": {
                        "id": "201904190019",
                        "barcode": "001599",
                        "place": "F1A20",
                        "designation": "Bloc additif"
                    }
                },
                "21": {
                    "Relais thermique PHOENIX CONTACT ~ F1A21 ~ 001602": {
                        "id": "201904190022",
                        "barcode": "001602",
                        "place": "F1A21",
                        "designation": "Relais thermique PHOENIX CONTACT"
                    }
                },
                "22": {
                    "Relais controle de niveau ~ F1A22 ~ 001600": {
                        "id": "201904190020",
                        "barcode": "001600",
                        "place": "F1A22",
                        "designation": "Relais controle de niveau"
                    }
                },
                "23": {
                    "Relais controle de niveau ~ F1A23 ~ 001601": {
                        "id": "201904190021",
                        "barcode": "001601",
                        "place": "F1A23",
                        "designation": "Relais controle de niveau"
                    }
                },
                "01": {
                    "Disjoncteur thermique 0.7-1A ~ F1A01 ~ 001582": {
                        "id": "201904190002",
                        "barcode": "001582",
                        "place": "F1A01",
                        "designation": "Disjoncteur thermique 0.7-1A"
                    }
                },
                "02": {
                    "Disjoncteur thermique 1.8 2.5A ~ F1A02 ~ 001583": {
                        "id": "201904190003",
                        "barcode": "001583",
                        "place": "F1A02",
                        "designation": "Disjoncteur thermique 1.8 2.5A"
                    }
                },
                "03": {
                    "Disjoncteur thermique 0.9 1.25A ~ F1A03 ~ 002083": {
                        "id": "202111030008",
                        "barcode": "002083",
                        "place": "F1A03",
                        "designation": "Disjoncteur thermique 0.9 1.25A"
                    }
                },
                "04": {
                    "Disjoncteur thermique 4.5-6.3A ~ F1A04 ~ 001593": {
                        "id": "201904190013",
                        "barcode": "001593",
                        "place": "F1A04",
                        "designation": "Disjoncteur thermique 4.5-6.3A"
                    }
                },
                "05": {
                    "Disjoncteur thermique 7 10A ~ F1A05 ~ 001585": {
                        "id": "201904190005",
                        "barcode": "001585",
                        "place": "F1A05",
                        "designation": "Disjoncteur thermique 7 10A"
                    }
                },
                "06": {
                    "Disjoncteur thermique 0-0.4A ~ F1A06 ~ 001586": {
                        "id": "201904190006",
                        "barcode": "001586",
                        "place": "F1A06",
                        "designation": "Disjoncteur thermique 0-0.4A"
                    }
                },
                "07": {
                    "Disjoncteur thermique 0-0.63A ~ F1A07 ~ 001587": {
                        "id": "201904190007",
                        "barcode": "001587",
                        "place": "F1A07",
                        "designation": "Disjoncteur thermique 0-0.63A"
                    }
                },
                "08": {
                    "Disjoncteur thermique 2.5-4A ~ F1A08 ~ 001588": {
                        "id": "201904190008",
                        "barcode": "001588",
                        "place": "F1A08",
                        "designation": "Disjoncteur thermique 2.5-4A"
                    }
                },
                "09": {
                    "Disjoncteur thermique 0-6.3A ~ F1A09 ~ 001590": {
                        "id": "201904190010",
                        "barcode": "001590",
                        "place": "F1A09",
                        "designation": "Disjoncteur thermique 0-6.3A"
                    }
                }
            },
            "B": {
                "10": {
                    "Relais 2 poles FINDER 24Vdc ~ F1B10 ~ 002081": {
                        "id": "202111030006",
                        "barcode": "002081",
                        "place": "F1B10",
                        "designation": "Relais 2 poles FINDER 24Vdc"
                    }
                },
                "11": {
                    "Relais 1 pole OMRON 24Vdc ~ F1B11 ~ 002106": {
                        "id": "202111100007",
                        "barcode": "002106",
                        "place": "F1B11",
                        "designation": "Relais 1 pole OMRON 24Vdc"
                    },
                    "Embase pour relais 1 pole OMRON avec voyant 24Vac/dc ~ F1B11 ~ 002667": {
                        "id": "202503250001",
                        "barcode": "002667",
                        "place": "F1B11",
                        "designation": "Embase pour relais 1 pole OMRON avec voyant 24Vac/dc"
                    }
                },
                "12": {
                    "Relais WEIDMULLER 12-28Vdc ~ F1B12 ~ 001546": {
                        "id": "201904180005",
                        "barcode": "001546",
                        "place": "F1B12",
                        "designation": "Relais WEIDMULLER 12-28Vdc"
                    }
                },
                "13": {
                    "Relais MURR 51465 ~ F1B13 ~ 000453": {
                        "id": "201903050012",
                        "barcode": "000453",
                        "place": "F1B13",
                        "designation": "Relais MURR 51465"
                    }
                },
                "14": {
                    "Relais sur embase 24 Vdc WEIDMULLER 1 contact (séchoir Lavatec) ~ F1B14 ~ 002648": {
                        "id": "202503120003",
                        "barcode": "002648",
                        "place": "F1B14",
                        "designation": "Relais sur embase 24 Vdc WEIDMULLER 1 contact (séchoir Lavatec)"
                    }
                },
                "15": {
                    "Relais sur embase 230Vac WEIDMULLER 1 contact (séchoir Lavatec) ~ F1B15 ~ 002649": {
                        "id": "202503120004",
                        "barcode": "002649",
                        "place": "F1B15",
                        "designation": "Relais sur embase 230Vac WEIDMULLER 1 contact (séchoir Lavatec)"
                    }
                },
                "01": {
                    "Embase PHOENIX CONTACT pour relais 2p led 24Vdc ~ F1B01 ~ 002100": {
                        "id": "202111100001",
                        "barcode": "002100",
                        "place": "F1B01",
                        "designation": "Embase PHOENIX CONTACT pour relais 2p led 24Vdc"
                    }
                },
                "02": {
                    "Embase Finder pour relais 1p led 24Vdc ~ F1B02 ~ 001533": {
                        "id": "201904160041",
                        "barcode": "001533",
                        "place": "F1B02",
                        "designation": "Embase Finder pour relais 1p led 24Vdc"
                    },
                    "Embase PHOENIX CONTACT pour relais 1p avec led 24Vdc ~ F1B02 ~ 002103": {
                        "id": "202111100004",
                        "barcode": "002103",
                        "place": "F1B02",
                        "designation": "Embase PHOENIX CONTACT pour relais 1p avec led 24Vdc"
                    }
                },
                "03": {
                    "Embase PHOENIX CONTACT pour relais 1p avec led 230Vac ~ F1B03 ~ 002305": {
                        "id": "202212070001",
                        "barcode": "002305",
                        "place": "F1B03",
                        "designation": "Embase PHOENIX CONTACT pour relais 1p avec led 230Vac"
                    }
                },
                "04": {
                    "Embase pour relais 1 pole et 2 poles ~ F1B04 ~ 001698": {
                        "id": "201907240003",
                        "barcode": "001698",
                        "place": "F1B04",
                        "designation": "Embase pour relais 1 pole et 2 poles"
                    }
                },
                "05": {
                    "Accroche micro relais ~ F1B05 ~ 001523": {
                        "id": "201904160031",
                        "barcode": "001523",
                        "place": "F1B05",
                        "designation": "Accroche micro relais"
                    }
                },
                "06": {
                    "Base pour relais 4 poles FINDER ~ F1B06 ~ 002104": {
                        "id": "202111100005",
                        "barcode": "002104",
                        "place": "F1B06",
                        "designation": "Base pour relais 4 poles FINDER"
                    },
                    "Base pour relais 4 poles OMRON ~ F1B06 ~ 002105": {
                        "id": "202111100006",
                        "barcode": "002105",
                        "place": "F1B06",
                        "designation": "Base pour relais 4 poles OMRON"
                    }
                },
                "07": {
                    "Relais 3 poles FINDER 250Vac ~ F1B07 ~ 002077": {
                        "id": "202111030002",
                        "barcode": "002077",
                        "place": "F1B07",
                        "designation": "Relais 3 poles FINDER 250Vac"
                    }
                },
                "08": {
                    "Base pour relais 3 poles FINDER ~ F1B08 ~ 002079": {
                        "id": "202111030004",
                        "barcode": "002079",
                        "place": "F1B08",
                        "designation": "Base pour relais 3 poles FINDER"
                    },
                    "Relais 3 poles FINDER 24Vdc ~ F1B08 ~ 002662": {
                        "id": "202503200002",
                        "barcode": "002662",
                        "place": "F1B08",
                        "designation": "Relais 3 poles FINDER 24Vdc"
                    }
                },
                "09": {
                    "Relais embase 24/230Vac 2 contacts WEIDMULLER ~ F1B09 ~ 001545": {
                        "id": "201904180004",
                        "barcode": "001545",
                        "place": "F1B09",
                        "designation": "Relais embase 24/230Vac 2 contacts WEIDMULLER"
                    }
                }
            },
            "C": {
                "10": {
                    "Relais 2 poles SCHRACK 24Vac ~ F1C10 ~ 002292": {
                        "id": "202211080001",
                        "barcode": "002292",
                        "place": "F1C10",
                        "designation": "Relais 2 poles SCHRACK 24Vac"
                    }
                },
                "11": {
                    "Relais 2 poles Camozzi 230Vac ~ F1C11 ~ 002670": {
                        "id": "202503270002",
                        "barcode": "002670",
                        "place": "F1C11",
                        "designation": "Relais 2 poles Camozzi 230Vac"
                    }
                },
                "12": {
                    "Relais 2 poles OMRON 24Vac ~ F1C12 ~ 001537": {
                        "id": "201904160045",
                        "barcode": "001537",
                        "place": "F1C12",
                        "designation": "Relais 2 poles OMRON 24Vac"
                    }
                },
                "13": {
                    "Relais 4 poles FINDER 230 Vac ~ F1C13 ~ 002661": {
                        "id": "202503200001",
                        "barcode": "002661",
                        "place": "F1C13",
                        "designation": "Relais 4 poles FINDER 230 Vac"
                    }
                },
                "14": {
                    "Embase et relais 2 poles OMRON 24Vdc ~ F1C14 ~ 001544": {
                        "id": "201904180003",
                        "barcode": "001544",
                        "place": "F1C14",
                        "designation": "Embase et relais 2 poles OMRON 24Vdc"
                    },
                    "Relais OMRON 24Vdc ~ F1C14 ~ 002704": {
                        "id": "202510090003",
                        "barcode": "002704",
                        "place": "F1C14",
                        "designation": "Relais OMRON 24Vdc"
                    }
                },
                "15": {
                    "Relais 4 poles FINDER 24Vac ~ F1C15 ~ 001542": {
                        "id": "201904180001",
                        "barcode": "001542",
                        "place": "F1C15",
                        "designation": "Relais 4 poles FINDER 24Vac"
                    }
                },
                "16": {
                    "Relais OMRON 24Vdc ~ F1C16 ~ 002531": {
                        "id": "202401040002",
                        "barcode": "002531",
                        "place": "F1C16",
                        "designation": "Relais OMRON 24Vdc"
                    }
                },
                "00": {
                    "Relais 1p Finder/phénix contact 24Vdc ~ F1C00 ~ 001534": {
                        "id": "201904160042",
                        "barcode": "001534",
                        "place": "F1C00",
                        "designation": "Relais 1p Finder/phénix contact 24Vdc"
                    }
                },
                "01": {
                    "Relais PHOENIX CONTACT 1 pole (bobine 60Vdc) ~ F1C01 ~ 002668": {
                        "id": "202503250002",
                        "barcode": "002668",
                        "place": "F1C01",
                        "designation": "Relais PHOENIX CONTACT 1 pole (bobine 60Vdc)"
                    }
                },
                "02": {
                    "Relais OMRON 1 pole 24Vdc ~ F1C02 ~ 001531": {
                        "id": "201904160039",
                        "barcode": "001531",
                        "place": "F1C02",
                        "designation": "Relais OMRON 1 pole 24Vdc"
                    }
                },
                "03": {
                    "Relais OMRON 1 pole 230Vac ~ F1C03 ~ 001532": {
                        "id": "201904160040",
                        "barcode": "001532",
                        "place": "F1C03",
                        "designation": "Relais OMRON 1 pole 230Vac"
                    }
                },
                "04": {
                    "Relais 1 pole 230Vac type 40.51 ~ F1C04 ~ 001528": {
                        "id": "201904160036",
                        "barcode": "001528",
                        "place": "F1C04",
                        "designation": "Relais 1 pole 230Vac type 40.51"
                    }
                },
                "05": {
                    "Relais 1 pole 24Vdc type 40.51 ~ F1C05 ~ 001530": {
                        "id": "201904160038",
                        "barcode": "001530",
                        "place": "F1C05",
                        "designation": "Relais 1 pole 24Vdc type 40.51"
                    }
                },
                "06": {
                    "Relais SCHRACK a souder ~ F1C06 ~ 001524": {
                        "id": "201904160032",
                        "barcode": "001524",
                        "place": "F1C06",
                        "designation": "Relais SCHRACK a souder"
                    }
                },
                "07": {
                    "Relais 2 poles SCHRACK 24Vdc ~ F1C07 ~ 002101": {
                        "id": "202111100002",
                        "barcode": "002101",
                        "place": "F1C07",
                        "designation": "Relais 2 poles SCHRACK 24Vdc"
                    }
                },
                "08": {
                    "Relais 2 poles 24Vdc ~ F1C08 ~ 002102": {
                        "id": "202111100003",
                        "barcode": "002102",
                        "place": "F1C08",
                        "designation": "Relais 2 poles 24Vdc"
                    }
                },
                "09": {
                    "Relais 2 poles Schrack 230Vac ~ F1C09 ~ 002107": {
                        "id": "202111100008",
                        "barcode": "002107",
                        "place": "F1C09",
                        "designation": "Relais 2 poles Schrack 230Vac"
                    }
                }
            },
            "D": {
                "0": {
                    "Blocage mécanique contacteur lad9r1 ~ F1D00 ~ 001873": {
                        "id": "202010160001",
                        "barcode": "001873",
                        "place": "F1D00",
                        "designation": "Blocage mécanique contacteur lad9r1"
                    }
                },
                "10": {
                    "Contacteur inverseur SCHNEIDER 24V ac ~ F1D10 ~ 001578": {
                        "id": "201904180037",
                        "barcode": "001578",
                        "place": "F1D10",
                        "designation": "Contacteur inverseur SCHNEIDER 24V ac"
                    }
                },
                "11": {
                    "Contacteur SCHNEIDER 24Vdc ~ F1D11 ~ 001553": {
                        "id": "201904180012",
                        "barcode": "001553",
                        "place": "F1D11",
                        "designation": "Contacteur SCHNEIDER 24Vdc"
                    }
                },
                "12": {
                    "Contacteur SCHNEIDER ~ F1D12 ~ 001554": {
                        "id": "201904180013",
                        "barcode": "001554",
                        "place": "F1D12",
                        "designation": "Contacteur SCHNEIDER"
                    }
                },
                "13": {
                    "Contacteur SCHNEIDER ~ F1D13 ~ 001579": {
                        "id": "201904180038",
                        "barcode": "001579",
                        "place": "F1D13",
                        "designation": "Contacteur SCHNEIDER"
                    }
                },
                "14": {
                    "Contacteur SCHNEIDER ~ F1D14 ~ 001555": {
                        "id": "201904180014",
                        "barcode": "001555",
                        "place": "F1D14",
                        "designation": "Contacteur SCHNEIDER"
                    }
                },
                "15": {
                    "Contacteur SCHNEIDER 230Vac ~ F1D15 ~ 001580": {
                        "id": "201904180039",
                        "barcode": "001580",
                        "place": "F1D15",
                        "designation": "Contacteur SCHNEIDER 230Vac"
                    }
                },
                "16": {
                    "Contacteur SCHNEIDER ~ F1D16 ~ 001557": {
                        "id": "201904180016",
                        "barcode": "001557",
                        "place": "F1D16",
                        "designation": "Contacteur SCHNEIDER"
                    }
                },
                "17": {
                    "Contacteur SCHNEIDER ~ F1D17 ~ 001556": {
                        "id": "201904180015",
                        "barcode": "001556",
                        "place": "F1D17",
                        "designation": "Contacteur SCHNEIDER"
                    }
                },
                "18": {
                    "Contacteur SCHNEIDER 24Vac ~ F1D18 ~ 001558": {
                        "id": "201904180017",
                        "barcode": "001558",
                        "place": "F1D18",
                        "designation": "Contacteur SCHNEIDER 24Vac"
                    }
                },
                "19": {
                    "Contacteur SCHNEIDER 230V ~ F1D19 ~ 001559": {
                        "id": "201904180018",
                        "barcode": "001559",
                        "place": "F1D19",
                        "designation": "Contacteur SCHNEIDER 230V"
                    },
                    "Contacteur SCHNEIDER 230V ~ F1D19 ~ 002705": {
                        "id": "202510090004",
                        "barcode": "002705",
                        "place": "F1D19",
                        "designation": "Contacteur SCHNEIDER 230V"
                    }
                },
                "20": {
                    "Contacteur SCHNEIDER a encliqueter 24Vdc ~ F1D20 ~ 001742": {
                        "id": "202002050006",
                        "barcode": "001742",
                        "place": "F1D20",
                        "designation": "Contacteur SCHNEIDER a encliqueter 24Vdc"
                    }
                },
                "21": {
                    "Contacteur SCHNEIDER fil a encliqueter 24Vac ~ F1D21 ~ 001561": {
                        "id": "201904180020",
                        "barcode": "001561",
                        "place": "F1D21",
                        "designation": "Contacteur SCHNEIDER fil a encliqueter 24Vac"
                    }
                },
                "22": {
                    "Contacteur SCHNEIDER a vis 24Vac ~ F1D22 ~ 001874": {
                        "id": "202010160002",
                        "barcode": "001874",
                        "place": "F1D22",
                        "designation": "Contacteur SCHNEIDER a vis 24Vac"
                    }
                },
                "23": {
                    "Contacteur SCHNEIDER 24Vac ~ F1D23 ~ 001963": {
                        "id": "202105180001",
                        "barcode": "001963",
                        "place": "F1D23",
                        "designation": "Contacteur SCHNEIDER 24Vac"
                    }
                },
                "01": {
                    "Bloc additif ladn22 ~ F1D01 ~ 001547": {
                        "id": "201904180006",
                        "barcode": "001547",
                        "place": "F1D01",
                        "designation": "Bloc additif ladn22"
                    }
                },
                "02": {
                    "Bloc additif ladn31 ~ F1D02 ~ 001548": {
                        "id": "201904180007",
                        "barcode": "001548",
                        "place": "F1D02",
                        "designation": "Bloc additif ladn31"
                    }
                },
                "03": {
                    "Bloc additif ladn 11 ~ F1D03 ~ 001549": {
                        "id": "201904180008",
                        "barcode": "001549",
                        "place": "F1D03",
                        "designation": "Bloc additif ladn 11"
                    }
                },
                "04": {
                    "Bloc additif ladn20 ~ F1D04 ~ 001550": {
                        "id": "201904180009",
                        "barcode": "001550",
                        "place": "F1D04",
                        "designation": "Bloc additif ladn20"
                    }
                },
                "05": {
                    "Bloc additif ladn02 ~ F1D05 ~ 001551": {
                        "id": "201904180010",
                        "barcode": "001551",
                        "place": "F1D05",
                        "designation": "Bloc additif ladn02"
                    }
                },
                "06": {
                    "Bloc additif ladn 203 ~ F1D06 ~ 001736": {
                        "id": "202001150001",
                        "barcode": "001736",
                        "place": "F1D06",
                        "designation": "Bloc additif ladn 203"
                    }
                },
                "07": {
                    "Barrette schneider lad 9V6 ~ F1D07 ~ 001576": {
                        "id": "201904180035",
                        "barcode": "001576",
                        "place": "F1D07",
                        "designation": "Barrette schneider lad 9V6"
                    }
                },
                "08": {
                    "Bloc de raccordement SCHNEIDER GV2-AF01 ~ F1D08 ~ 001723": {
                        "id": "201910250002",
                        "barcode": "001723",
                        "place": "F1D08",
                        "designation": "Bloc de raccordement SCHNEIDER GV2-AF01"
                    },
                    "Bloc de raccordement schneider lad 341 ~ F1D08 ~ 002646": {
                        "id": "202503120001",
                        "barcode": "002646",
                        "place": "F1D08",
                        "designation": "Bloc de raccordement schneider lad 341"
                    }
                },
                "09": {
                    "Kit inverseur SCHNEIDER lad9r1 ~ F1D09 ~ 001575": {
                        "id": "201904180034",
                        "barcode": "001575",
                        "place": "F1D09",
                        "designation": "Kit inverseur SCHNEIDER lad9r1"
                    }
                }
            },
            "E": {
                "10": {
                    "Contacteur MOELLER 24Vac avec NC ~ F1E10 ~ 001569": {
                        "id": "201904180028",
                        "barcode": "001569",
                        "place": "F1E10",
                        "designation": "Contacteur MOELLER 24Vac avec NC"
                    }
                },
                "11": {
                    "Contacteur MOELLER 24Vac avec NO ~ F1E11 ~ 001570": {
                        "id": "201904180029",
                        "barcode": "001570",
                        "place": "F1E11",
                        "designation": "Contacteur MOELLER 24Vac avec NO"
                    }
                },
                "12": {
                    "Additif MOELLER 3NO + 1NF ~ F1E12 ~ 001571": {
                        "id": "201904180030",
                        "barcode": "001571",
                        "place": "F1E12",
                        "designation": "Additif MOELLER 3NO + 1NF"
                    },
                    "Filtre RC MOELLER ~ F1E12 ~ 001572": {
                        "id": "201904180031",
                        "barcode": "001572",
                        "place": "F1E12",
                        "designation": "Filtre RC MOELLER"
                    },
                    "Additif MOELLER 2 NF+ 2NO ~ F1E12 ~ 002382": {
                        "id": "202306010006",
                        "barcode": "002382",
                        "place": "F1E12",
                        "designation": "Additif MOELLER 2 NF+ 2NO"
                    }
                },
                "13": {
                    "Contacteur MOELLER 230Vac ~ F1E13 ~ 001573": {
                        "id": "201904180032",
                        "barcode": "001573",
                        "place": "F1E13",
                        "designation": "Contacteur MOELLER 230Vac"
                    }
                },
                "14": {
                    "Bloc de raccordement contacteur EATON/ MOELLER ~ F1E14 ~ 001574": {
                        "id": "201904180033",
                        "barcode": "001574",
                        "place": "F1E14",
                        "designation": "Bloc de raccordement contacteur EATON/ MOELLER"
                    }
                },
                "15": {
                    "Supresseur de surtension SIEMENS ~ F1E15 ~ 001923": {
                        "id": "202103020002",
                        "barcode": "001923",
                        "place": "F1E15",
                        "designation": "Supresseur de surtension SIEMENS"
                    },
                    "Supresseur de surtension 24-48V SIEMENS ~ F1E15 ~ 002647": {
                        "id": "202503120002",
                        "barcode": "002647",
                        "place": "F1E15",
                        "designation": "Supresseur de surtension 24-48V SIEMENS"
                    },
                    "Suppresseur de surtension siemens ~ F1E15 ~ 002702": {
                        "id": "202510090001",
                        "barcode": "002702",
                        "place": "F1E15",
                        "designation": "Suppresseur de surtension siemens"
                    }
                },
                "16": {
                    "Blos aux 2no 2nc Contacteur siemens bruleur calandre ~ F1E16 ~ 001922": {
                        "id": "202103020001",
                        "barcode": "001922",
                        "place": "F1E16",
                        "designation": "Blos aux 2no 2nc Contacteur siemens bruleur calandre"
                    }
                },
                "17": {
                    "Contacteur siemens bruleur calandre ~ F1E17 ~ 001924": {
                        "id": "202103020003",
                        "barcode": "001924",
                        "place": "F1E17",
                        "designation": "Contacteur siemens bruleur calandre"
                    }
                },
                "18": {
                    "Blos aux 2no 2nc Contacteur siemens bruleur calandre ~ F1E18 ~ 001925": {
                        "id": "202103020004",
                        "barcode": "001925",
                        "place": "F1E18",
                        "designation": "Blos aux 2no 2nc Contacteur siemens bruleur calandre"
                    }
                },
                "01": {
                    "Relais auxiliaire SIEMENS 24VDC ~ F1E01 ~ 001761": {
                        "id": "202003170003",
                        "barcode": "001761",
                        "place": "F1E01",
                        "designation": "Relais auxiliaire SIEMENS 24VDC"
                    }
                },
                "02": {
                    "Relais EATON ~ F1E02 ~ 001562": {
                        "id": "201904180021",
                        "barcode": "001562",
                        "place": "F1E02",
                        "designation": "Relais EATON"
                    }
                },
                "04": {
                    "Contacteur SIEMENS ~ F1E04 ~ 001565": {
                        "id": "201904180024",
                        "barcode": "001565",
                        "place": "F1E04",
                        "designation": "Contacteur SIEMENS"
                    }
                },
                "05": {
                    "Contacteur SIEMENS ~ F1E05 ~ 001563": {
                        "id": "201904180022",
                        "barcode": "001563",
                        "place": "F1E05",
                        "designation": "Contacteur SIEMENS"
                    }
                },
                "06": {
                    "Contacteur SIEMENS ~ F1E06 ~ 001566": {
                        "id": "201904180025",
                        "barcode": "001566",
                        "place": "F1E06",
                        "designation": "Contacteur SIEMENS"
                    }
                },
                "07": {
                    "Contacteur MOELLER 220Vac avec NO ~ F1E07 ~ 001567": {
                        "id": "201904180026",
                        "barcode": "001567",
                        "place": "F1E07",
                        "designation": "Contacteur MOELLER 220Vac avec NO"
                    }
                },
                "08": {
                    "Contacteur MOELLER 24Vdc avec NC ~ F1E08 ~ 001732": {
                        "id": "201912200004",
                        "barcode": "001732",
                        "place": "F1E08",
                        "designation": "Contacteur MOELLER 24Vdc avec NC"
                    }
                },
                "09": {
                    "Contacteur MOELLER 24Vdc avec NO ~ F1E09 ~ 001568": {
                        "id": "201904180027",
                        "barcode": "001568",
                        "place": "F1E09",
                        "designation": "Contacteur MOELLER 24Vdc avec NO"
                    }
                }
            },
            "F": {
                "01": {
                    "Carte relais WAGO ~ F1F01 ~ 001525": {
                        "id": "201904160033",
                        "barcode": "001525",
                        "place": "F1F01",
                        "designation": "Carte relais WAGO"
                    },
                    "Carte relais PHOENIX CONTACT ~ F1F01 ~ 001526": {
                        "id": "201904160034",
                        "barcode": "001526",
                        "place": "F1F01",
                        "designation": "Carte relais PHOENIX CONTACT"
                    }
                }
            }
        },
        "2 Colonne": {
            "A": {
                "01": {
                    "Pédale SIEMENS ~ F2A01 ~ 001504": {
                        "id": "201904160012",
                        "barcode": "001504",
                        "place": "F2A01",
                        "designation": "Pédale SIEMENS"
                    }
                },
                "02": {
                    "Fin de course BERNSTEIN ~ F2A02 ~ 001508": {
                        "id": "201904160016",
                        "barcode": "001508",
                        "place": "F2A02",
                        "designation": "Fin de course BERNSTEIN"
                    },
                    "Fin de course BERNSTEIN essoreuse ~ F2A02 ~ 002549": {
                        "id": "202402150002",
                        "barcode": "002549",
                        "place": "F2A02",
                        "designation": "Fin de course BERNSTEIN essoreuse"
                    }
                },
                "03": {
                    "Fin de course BERNSTEIN ~ F2A03 ~ 001512": {
                        "id": "201904160020",
                        "barcode": "001512",
                        "place": "F2A03",
                        "designation": "Fin de course BERNSTEIN"
                    }
                },
                "04": {
                    "Fin de course BERNSTEIN ~ F2A04 ~ 001511": {
                        "id": "201904160019",
                        "barcode": "001511",
                        "place": "F2A04",
                        "designation": "Fin de course BERNSTEIN"
                    }
                }
            },
            "B": {
                "10": {
                    "Cellule fourche OMRON ~ F2B10 ~ 001498": {
                        "id": "201904160006",
                        "barcode": "001498",
                        "place": "F2B10",
                        "designation": "Cellule fourche OMRON"
                    }
                },
                "11": {
                    "Fin de course OMRON ~ F2B11 ~ 001503": {
                        "id": "201904160011",
                        "barcode": "001503",
                        "place": "F2B11",
                        "designation": "Fin de course OMRON"
                    }
                },
                "12": {
                    "Cellule OMRON ~ F2B12 ~ 001501": {
                        "id": "201904160009",
                        "barcode": "001501",
                        "place": "F2B12",
                        "designation": "Cellule OMRON"
                    }
                },
                "13": {
                    "Pont redressé phoenix contact ~ F2B13 ~ 002383": {
                        "id": "202306010007",
                        "barcode": "002383",
                        "place": "F2B13",
                        "designation": "Pont redressé phoenix contact"
                    },
                    "Circuit RC ~ F2B13 ~ 002384": {
                        "id": "202306010008",
                        "barcode": "002384",
                        "place": "F2B13",
                        "designation": "Circuit RC"
                    }
                },
                "01": {
                    "Cellule OMRON ~ F2B01 ~ 001487": {
                        "id": "201904120060",
                        "barcode": "001487",
                        "place": "F2B01",
                        "designation": "Cellule OMRON"
                    },
                    "Cellule OMRON ~ F2B01 ~ 001488": {
                        "id": "201904120061",
                        "barcode": "001488",
                        "place": "F2B01",
                        "designation": "Cellule OMRON"
                    }
                },
                "02": {
                    "Cellule OMRON ~ F2B02 ~ 001489": {
                        "id": "201904120062",
                        "barcode": "001489",
                        "place": "F2B02",
                        "designation": "Cellule OMRON"
                    },
                    "Cellule OMRON ~ F2B02 ~ 001490": {
                        "id": "201904120063",
                        "barcode": "001490",
                        "place": "F2B02",
                        "designation": "Cellule OMRON"
                    }
                },
                "03": {
                    "Cellule OMRON ~ F2B03 ~ 001491": {
                        "id": "201904120064",
                        "barcode": "001491",
                        "place": "F2B03",
                        "designation": "Cellule OMRON"
                    }
                },
                "04": {
                    "Cellule OMRON ~ F2B04 ~ 001492": {
                        "id": "201904120065",
                        "barcode": "001492",
                        "place": "F2B04",
                        "designation": "Cellule OMRON"
                    }
                },
                "05": {
                    "Cellule OMRON ~ F2B05 ~ 001493": {
                        "id": "201904160001",
                        "barcode": "001493",
                        "place": "F2B05",
                        "designation": "Cellule OMRON"
                    }
                },
                "06": {
                    "Cellule OMRON E ~ F2B06 ~ 001494": {
                        "id": "201904160002",
                        "barcode": "001494",
                        "place": "F2B06",
                        "designation": "Cellule OMRON E"
                    },
                    "Cellule OMRON R ~ F2B06 ~ 001495": {
                        "id": "201904160003",
                        "barcode": "001495",
                        "place": "F2B06",
                        "designation": "Cellule OMRON R"
                    }
                },
                "07": {
                    "Cellule OMRON ~ F2B07 ~ 001496": {
                        "id": "201904160004",
                        "barcode": "001496",
                        "place": "F2B07",
                        "designation": "Cellule OMRON"
                    }
                },
                "08": {
                    "Cellule OMRON ~ F2B08 ~ 001826": {
                        "id": "202004300002",
                        "barcode": "001826",
                        "place": "F2B08",
                        "designation": "Cellule OMRON"
                    }
                },
                "09": {
                    "Cellule OMRON e2a-m18ks08-wp-b1 remplacé par PEPPERL FUSCH PEP326161-0088 ~ F2B09 ~ 001499": {
                        "id": "201904160007",
                        "barcode": "001499",
                        "place": "F2B09",
                        "designation": "Cellule OMRON e2a-m18ks08-wp-b1 remplacé par PEPPERL FUSCH PEP326161-0088"
                    }
                }
            },
            "C": {
                "10": {
                    "Cellule SICK ~ F2C10 ~ 001474": {
                        "id": "201904120047",
                        "barcode": "001474",
                        "place": "F2C10",
                        "designation": "Cellule SICK"
                    }
                },
                "11": {
                    "Cellule SICK ~ F2C11 ~ 001476": {
                        "id": "201904120049",
                        "barcode": "001476",
                        "place": "F2C11",
                        "designation": "Cellule SICK"
                    },
                    "Cellule SICK ~ F2C11 ~ 002144": {
                        "id": "202111160017",
                        "barcode": "002144",
                        "place": "F2C11",
                        "designation": "Cellule SICK"
                    }
                },
                "12": {
                    "Cellule SICK ~ F2C12 ~ 001475": {
                        "id": "201904120048",
                        "barcode": "001475",
                        "place": "F2C12",
                        "designation": "Cellule SICK"
                    }
                },
                "13": {
                    "Cellule SICK à fourche ~ F2C13 ~ 001477": {
                        "id": "201904120050",
                        "barcode": "001477",
                        "place": "F2C13",
                        "designation": "Cellule SICK à fourche"
                    }
                },
                "14": {
                    "Cellule IFM ~ F2C14 ~ 001478": {
                        "id": "201904120051",
                        "barcode": "001478",
                        "place": "F2C14",
                        "designation": "Cellule IFM"
                    }
                },
                "15": {
                    "Cellule IFM OG5119 (ou en lieu et place XUB4 BPANM12) ~ F2C15 ~ 001479": {
                        "id": "201904120052",
                        "barcode": "001479",
                        "place": "F2C15",
                        "designation": "Cellule IFM OG5119 (ou en lieu et place XUB4 BPANM12)"
                    },
                    "Cellule BALLUFF avec suppression d'arrière plan ~ F2C15 ~ 002566": {
                        "id": "202404260002",
                        "barcode": "002566",
                        "place": "F2C15",
                        "designation": "Cellule BALLUFF avec suppression d'arrière plan"
                    }
                },
                "16": {
                    "Cellule OMRON réglable ~ F2C16 ~ 002256": {
                        "id": "202209140005",
                        "barcode": "002256",
                        "place": "F2C16",
                        "designation": "Cellule OMRON réglable"
                    }
                },
                "17": {
                    "Cellule IFM ~ F2C17 ~ 001481": {
                        "id": "201904120054",
                        "barcode": "001481",
                        "place": "F2C17",
                        "designation": "Cellule IFM"
                    }
                },
                "18": {
                    "Cellule IFM ~ F2C18 ~ 001482": {
                        "id": "201904120055",
                        "barcode": "001482",
                        "place": "F2C18",
                        "designation": "Cellule IFM"
                    }
                },
                "19": {
                    "Cellule IFM ~ F2C19 ~ 001483": {
                        "id": "201904120056",
                        "barcode": "001483",
                        "place": "F2C19",
                        "designation": "Cellule IFM"
                    }
                },
                "20": {
                    "Cellule IFM ~ F2C20 ~ 001484": {
                        "id": "201904120057",
                        "barcode": "001484",
                        "place": "F2C20",
                        "designation": "Cellule IFM"
                    }
                },
                "21": {
                    "Cellule IFM ~ F2C21 ~ 001485": {
                        "id": "201904120058",
                        "barcode": "001485",
                        "place": "F2C21",
                        "designation": "Cellule IFM"
                    }
                },
                "22": {
                    "Cellule IFM ~ F2C22 ~ 001486": {
                        "id": "201904120059",
                        "barcode": "001486",
                        "place": "F2C22",
                        "designation": "Cellule IFM"
                    }
                },
                "23": {
                    "Cellule BALLUFF inductif M12 inox non noyé a connecteur ~ F2C23 ~ 001611": {
                        "id": "201905020002",
                        "barcode": "001611",
                        "place": "F2C23",
                        "designation": "Cellule BALLUFF inductif M12 inox non noyé a connecteur"
                    }
                },
                "24": {
                    "Cellule BALUFF inductif M12 2 fils ~ F2C24 ~ 001612": {
                        "id": "201905020003",
                        "barcode": "001612",
                        "place": "F2C24",
                        "designation": "Cellule BALUFF inductif M12 2 fils"
                    }
                },
                "25": {
                    "Cellule LEUZE ~ F2C25 ~ 002235": {
                        "id": "202207120003",
                        "barcode": "002235",
                        "place": "F2C25",
                        "designation": "Cellule LEUZE"
                    }
                },
                "01": {
                    "Cellule SICK ~ F2C01 ~ 001463": {
                        "id": "201904120036",
                        "barcode": "001463",
                        "place": "F2C01",
                        "designation": "Cellule SICK"
                    }
                },
                "02": {
                    "Cellule SICK wtb9-3p2261 ~ F2C02 ~ 001464": {
                        "id": "201904120037",
                        "barcode": "001464",
                        "place": "F2C02",
                        "designation": "Cellule SICK wtb9-3p2261"
                    },
                    "Cellule SICK avec fil ~ F2C02 ~ 002255": {
                        "id": "202209140004",
                        "barcode": "002255",
                        "place": "F2C02",
                        "designation": "Cellule SICK avec fil"
                    }
                },
                "03": {
                    "Cellule SICK wtb9-3p3061p06 ~ F2C03 ~ 001465": {
                        "id": "201904120038",
                        "barcode": "001465",
                        "place": "F2C03",
                        "designation": "Cellule SICK wtb9-3p3061p06"
                    }
                },
                "04": {
                    "Cellule SICK ime12-06bpszcok ~ F2C04 ~ 001466": {
                        "id": "201904120039",
                        "barcode": "001466",
                        "place": "F2C04",
                        "designation": "Cellule SICK ime12-06bpszcok"
                    }
                },
                "05": {
                    "Cellule SICK ~ F2C05 ~ 001467": {
                        "id": "201904120040",
                        "barcode": "001467",
                        "place": "F2C05",
                        "designation": "Cellule SICK"
                    }
                },
                "06": {
                    "Cellule SICK a reflecteur wl9-3P2232 (remplace la wl9-2p330 ) ~ F2C06 ~ 001468": {
                        "id": "201904120041",
                        "barcode": "001468",
                        "place": "F2C06",
                        "designation": "Cellule SICK a reflecteur wl9-3P2232 (remplace la wl9-2p330 )"
                    }
                },
                "07": {
                    "Cellule SICK ~ F2C07 ~ 001473": {
                        "id": "201904120046",
                        "barcode": "001473",
                        "place": "F2C07",
                        "designation": "Cellule SICK"
                    }
                },
                "08": {
                    "Cellule SICK ~ F2C08 ~ 001472": {
                        "id": "201904120045",
                        "barcode": "001472",
                        "place": "F2C08",
                        "designation": "Cellule SICK"
                    }
                },
                "09": {
                    "Cellule SICK a reflecteur ~ F2C09 ~ 002087": {
                        "id": "202111030012",
                        "barcode": "002087",
                        "place": "F2C09",
                        "designation": "Cellule SICK a reflecteur"
                    }
                },
                "13bis": {
                    "Cellule inductif haute température BALUFF M18 avec fil ~ F2C13BIS ~ 002567": {
                        "id": "202405030001",
                        "barcode": "002567",
                        "place": "F2C13BIS",
                        "designation": "Cellule inductif haute température BALUFF M18 avec fil"
                    },
                    "Cellule inductif haute température BALUFF M18 sans fil ~ F2C13BIS ~ 002580": {
                        "id": "202405280002",
                        "barcode": "002580",
                        "place": "F2C13BIS",
                        "designation": "Cellule inductif haute température BALUFF M18 sans fil"
                    }
                }
            },
            "D": {
                "10": {
                    "Cellule SCHNEIDER ~ F2D10 ~ 001459": {
                        "id": "201904120032",
                        "barcode": "001459",
                        "place": "F2D10",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "11": {
                    "Cellule SCHNEIDER ~ F2D11 ~ 001460": {
                        "id": "201904120033",
                        "barcode": "001460",
                        "place": "F2D11",
                        "designation": "Cellule SCHNEIDER"
                    },
                    "Cellule DATASENSING remplace xum1apbnl2 ~ F2D11 ~ 002588": {
                        "id": "202406240002",
                        "barcode": "002588",
                        "place": "F2D11",
                        "designation": "Cellule DATASENSING remplace xum1apbnl2"
                    }
                },
                "12": {
                    "Cellule SCHNEIDER récepteur ~ F2D12 ~ 001461": {
                        "id": "201904120034",
                        "barcode": "001461",
                        "place": "F2D12",
                        "designation": "Cellule SCHNEIDER récepteur"
                    }
                },
                "13": {
                    "Cellule SCHNEIDER émetteur ~ F2D13 ~ 001825": {
                        "id": "202004300001",
                        "barcode": "001825",
                        "place": "F2D13",
                        "designation": "Cellule SCHNEIDER émetteur"
                    }
                },
                "14": {
                    "Cellule SCHNEIDER ~ F2D14 ~ 001983": {
                        "id": "202107270005",
                        "barcode": "001983",
                        "place": "F2D14",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "15": {
                    "Cellule SCHNEIDER ~ F2D15 ~ 002008": {
                        "id": "202108100001",
                        "barcode": "002008",
                        "place": "F2D15",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "16": {
                    "Cellule SCHNEIDER ~ F2D16 ~ 002027": {
                        "id": "202109010001",
                        "barcode": "002027",
                        "place": "F2D16",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "17": {
                    "Fin de course SCHNEIDER ZCP27 ~ F2D17 ~ 002090": {
                        "id": "202111040003",
                        "barcode": "002090",
                        "place": "F2D17",
                        "designation": "Fin de course SCHNEIDER ZCP27"
                    },
                    "Tete pour fin de course SCHNEIDER ZCP27 ~ F2D17 ~ 002230": {
                        "id": "202207050002",
                        "barcode": "002230",
                        "place": "F2D17",
                        "designation": "Tete pour fin de course SCHNEIDER ZCP27"
                    },
                    "Sortie PE PG11 pour fin de course SCHNEIDER ZCP27 ~ F2D17 ~ 002231": {
                        "id": "202207050003",
                        "barcode": "002231",
                        "place": "F2D17",
                        "designation": "Sortie PE PG11 pour fin de course SCHNEIDER ZCP27"
                    }
                },
                "18": {
                    "Cellule SCHNEIDER ~ F2D18 ~ 001982": {
                        "id": "202107270004",
                        "barcode": "001982",
                        "place": "F2D18",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "19": {
                    "Bloc contact de fin de course SCHNEIDER ZCP27 ~ F2D19 ~ 002232": {
                        "id": "202207050004",
                        "barcode": "002232",
                        "place": "F2D19",
                        "designation": "Bloc contact de fin de course SCHNEIDER ZCP27"
                    }
                },
                "00": {
                    "Cellule SCHNEIDER ~ F2D00 ~ 002086": {
                        "id": "202111030011",
                        "barcode": "002086",
                        "place": "F2D00",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "01": {
                    "Cellule SCHNEIDER ~ F2D01 ~ 001447": {
                        "id": "201904120020",
                        "barcode": "001447",
                        "place": "F2D01",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "02": {
                    "Cellule SCHNEIDER ~ F2D02 ~ 001449": {
                        "id": "201904120022",
                        "barcode": "001449",
                        "place": "F2D02",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "03": {
                    "Cellule SCHNEIDER ~ F2D03 ~ 001450": {
                        "id": "201904120023",
                        "barcode": "001450",
                        "place": "F2D03",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "04": {
                    "Cellule SCHNEIDER ~ F2D04 ~ 001451": {
                        "id": "201904120024",
                        "barcode": "001451",
                        "place": "F2D04",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "05": {
                    "Cellule SCHNEIDER ~ F2D05 ~ 001452": {
                        "id": "201904120025",
                        "barcode": "001452",
                        "place": "F2D05",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "06": {
                    "Cellule SCHNEIDER ~ F2D06 ~ 001454": {
                        "id": "201904120027",
                        "barcode": "001454",
                        "place": "F2D06",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "06 Bis": {
                    "Cellule SCHNEIDER ~ F2D06BIS ~ 001453": {
                        "id": "201904120026",
                        "barcode": "001453",
                        "place": "F2D06BIS",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "07": {
                    "Cellule SCHNEIDER ~ F2D07 ~ 001455": {
                        "id": "201904120028",
                        "barcode": "001455",
                        "place": "F2D07",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "08": {
                    "Cellule SCHNEIDER ~ F2D08 ~ 001457": {
                        "id": "201904120030",
                        "barcode": "001457",
                        "place": "F2D08",
                        "designation": "Cellule SCHNEIDER"
                    }
                },
                "09": {
                    "Cellule SCHNEIDER ~ F2D09 ~ 001458": {
                        "id": "201904120031",
                        "barcode": "001458",
                        "place": "F2D09",
                        "designation": "Cellule SCHNEIDER"
                    }
                }
            },
            "E": {
                "10": {
                    "Cellule TURCK ~ F2E10 ~ 001434": {
                        "id": "201904120007",
                        "barcode": "001434",
                        "place": "F2E10",
                        "designation": "Cellule TURCK"
                    }
                },
                "11": {
                    "Cellule LEUZE ~ F2E11 ~ 001435": {
                        "id": "201904120008",
                        "barcode": "001435",
                        "place": "F2E11",
                        "designation": "Cellule LEUZE"
                    },
                    "Cellule LEUZE pour CAB a connecteur ~ F2E11 ~ 001745": {
                        "id": "202002200001",
                        "barcode": "001745",
                        "place": "F2E11",
                        "designation": "Cellule LEUZE pour CAB a connecteur"
                    },
                    "Cellule LEUZE pour postes VT a fil ~ F2E11 ~ 002367": {
                        "id": "202305110001",
                        "barcode": "002367",
                        "place": "F2E11",
                        "designation": "Cellule LEUZE pour postes VT a fil"
                    }
                },
                "12": {
                    "Cellule inductive M12 marque GW ~ F2E12 ~ 001436": {
                        "id": "201904120009",
                        "barcode": "001436",
                        "place": "F2E12",
                        "designation": "Cellule inductive M12 marque GW"
                    }
                },
                "13": {
                    "Cellule SCHOENBUCH ~ F2E13 ~ 001437": {
                        "id": "201904120010",
                        "barcode": "001437",
                        "place": "F2E13",
                        "designation": "Cellule SCHOENBUCH"
                    }
                },
                "14": {
                    "Cellule OMRON ~ F2E14 ~ 001438": {
                        "id": "201904120011",
                        "barcode": "001438",
                        "place": "F2E14",
                        "designation": "Cellule OMRON"
                    }
                },
                "15": {
                    "Cellule TURCK ~ F2E15 ~ 001439": {
                        "id": "201904120012",
                        "barcode": "001439",
                        "place": "F2E15",
                        "designation": "Cellule TURCK"
                    }
                },
                "16": {
                    "Cellule inductif CONTRINEX (ref cbbs: 71050247)en 12mm laveuse artisanale ~ F2E16 ~ 001440": {
                        "id": "201904120013",
                        "barcode": "001440",
                        "place": "F2E16",
                        "designation": "Cellule inductif CONTRINEX (ref cbbs: 71050247)en 12mm laveuse artisanale"
                    }
                },
                "17": {
                    "Cellule inductif CONTRINEX en 8mm ~ F2E17 ~ 001441": {
                        "id": "201904120014",
                        "barcode": "001441",
                        "place": "F2E17",
                        "designation": "Cellule inductif CONTRINEX en 8mm"
                    }
                },
                "18": {
                    "Cellule ELGAB 60067-813 ~ F2E18 ~ 001443": {
                        "id": "201904120016",
                        "barcode": "001443",
                        "place": "F2E18",
                        "designation": "Cellule ELGAB 60067-813"
                    }
                },
                "19": {
                    "Cellule ELGAB 60067-805 ~ F2E19 ~ 001442": {
                        "id": "201904120015",
                        "barcode": "001442",
                        "place": "F2E19",
                        "designation": "Cellule ELGAB 60067-805"
                    }
                },
                "20": {
                    "Inter Magnétique JACOB type 102.201.99-40389.001 ~ F2E20 ~ 001444": {
                        "id": "201904120017",
                        "barcode": "001444",
                        "place": "F2E20",
                        "designation": "Inter Magnétique JACOB type 102.201.99-40389.001"
                    }
                },
                "21": {
                    "Sonde pt 100 cl.b ~ F2E21 ~ 001445": {
                        "id": "201904120018",
                        "barcode": "001445",
                        "place": "F2E21",
                        "designation": "Sonde pt 100 cl.b"
                    }
                },
                "22": {
                    "Sonde JL=3M ~ F2E22 ~ 001446": {
                        "id": "201904120019",
                        "barcode": "001446",
                        "place": "F2E22",
                        "designation": "Sonde JL=3M"
                    }
                },
                "23": {
                    "Capteur détecteur FLOTTEUR (carotte) ~ F2E23 ~ 001470": {
                        "id": "201904120043",
                        "barcode": "001470",
                        "place": "F2E23",
                        "designation": "Capteur détecteur FLOTTEUR (carotte)"
                    }
                },
                "24": {
                    "Capteur détecteur FLOTTEUR tuba 1 ~ F2E24 ~ 001469": {
                        "id": "201904120042",
                        "barcode": "001469",
                        "place": "F2E24",
                        "designation": "Capteur détecteur FLOTTEUR tuba 1"
                    }
                },
                "25": {
                    "Capteur détecteur FLOTTEUR avec protection métallique ~ F2E25 ~ 001471": {
                        "id": "201904120044",
                        "barcode": "001471",
                        "place": "F2E25",
                        "designation": "Capteur détecteur FLOTTEUR avec protection métallique"
                    }
                },
                "01": {
                    "Cellule PEPPERL+FLUCHS ~ F2E01 ~ 000851": {
                        "id": "201903150021",
                        "barcode": "000851",
                        "place": "F2E01",
                        "designation": "Cellule PEPPERL+FLUCHS"
                    }
                },
                "02": {
                    "Cellule PEPPERL+FLUCHS ~ F2E02 ~ 001425": {
                        "id": "201904110042",
                        "barcode": "001425",
                        "place": "F2E02",
                        "designation": "Cellule PEPPERL+FLUCHS"
                    }
                },
                "03": {
                    "Cellule PEPPERL+FLUCHS ~ F2E03 ~ 001427": {
                        "id": "201904110044",
                        "barcode": "001427",
                        "place": "F2E03",
                        "designation": "Cellule PEPPERL+FLUCHS"
                    }
                },
                "04": {
                    "Cellule PEPPERL+FLUCHS ~ F2E04 ~ 001428": {
                        "id": "201904120001",
                        "barcode": "001428",
                        "place": "F2E04",
                        "designation": "Cellule PEPPERL+FLUCHS"
                    }
                },
                "05": {
                    "Cellule PEPPERL+FLUCHS ~ F2E05 ~ 001426": {
                        "id": "201904110043",
                        "barcode": "001426",
                        "place": "F2E05",
                        "designation": "Cellule PEPPERL+FLUCHS"
                    }
                },
                "06": {
                    "Cellule PEPPERL+FLUCHS ~ F2E06 ~ 001429": {
                        "id": "201904120002",
                        "barcode": "001429",
                        "place": "F2E06",
                        "designation": "Cellule PEPPERL+FLUCHS"
                    }
                },
                "07": {
                    "Cellule BANNER ~ F2E07 ~ 001430": {
                        "id": "201904120003",
                        "barcode": "001430",
                        "place": "F2E07",
                        "designation": "Cellule BANNER"
                    }
                },
                "08": {
                    "Cellule PEPPERL+FLUCHS emetteur ~ F2E08 ~ 001431": {
                        "id": "201904120004",
                        "barcode": "001431",
                        "place": "F2E08",
                        "designation": "Cellule PEPPERL+FLUCHS emetteur"
                    },
                    "Cellule PEPPERL+FLUCHS recepteur ~ F2E08 ~ 001432": {
                        "id": "201904120005",
                        "barcode": "001432",
                        "place": "F2E08",
                        "designation": "Cellule PEPPERL+FLUCHS recepteur"
                    }
                },
                "09": {
                    "Cellule ALLEN BRADLEY ~ F2E09 ~ 001433": {
                        "id": "201904120006",
                        "barcode": "001433",
                        "place": "F2E09",
                        "designation": "Cellule ALLEN BRADLEY"
                    }
                },
                "19bis": {
                    "Aimant pour détecteur magnétique ~ F2E19BIS ~ 002610": {
                        "id": "202409110001",
                        "barcode": "002610",
                        "place": "F2E19BIS",
                        "designation": "Aimant pour détecteur magnétique"
                    }
                }
            }
        },
        "3 Colonne": {
            "A": {
                "01": {
                    "Verrine SCHNEIDER serie XVE orange ~ F3A01 ~ 001405": {
                        "id": "201904110022",
                        "barcode": "001405",
                        "place": "F3A01",
                        "designation": "Verrine SCHNEIDER serie XVE orange"
                    },
                    "Verrine SCHNEIDER serie XVE verte ~ F3A01 ~ 001406": {
                        "id": "201904110023",
                        "barcode": "001406",
                        "place": "F3A01",
                        "designation": "Verrine SCHNEIDER serie XVE verte"
                    },
                    "Verrine SCHNEIDER serie XVE rouge ~ F3A01 ~ 001407": {
                        "id": "201904110024",
                        "barcode": "001407",
                        "place": "F3A01",
                        "designation": "Verrine SCHNEIDER serie XVE rouge"
                    },
                    "Verrine SCHNEIDER serie XVE blanche ~ F3A01 ~ 001408": {
                        "id": "201904110025",
                        "barcode": "001408",
                        "place": "F3A01",
                        "designation": "Verrine SCHNEIDER serie XVE blanche"
                    },
                    "Ampoule led pour verrine 24V ~ F3A01 ~ 002677": {
                        "id": "202504030001",
                        "barcode": "002677",
                        "place": "F3A01",
                        "designation": "Ampoule led pour verrine 24V"
                    },
                    "Verrine SCHNEIDER jaune ~ F3A01 ~ 002695": {
                        "id": "202510010001",
                        "barcode": "002695",
                        "place": "F3A01",
                        "designation": "Verrine SCHNEIDER jaune"
                    },
                    "Verrine SCHNEIDER rouge ~ F3A01 ~ 002696": {
                        "id": "202510010002",
                        "barcode": "002696",
                        "place": "F3A01",
                        "designation": "Verrine SCHNEIDER rouge"
                    },
                    "Verrine SCHNEIDER vert ~ F3A01 ~ 002697": {
                        "id": "202510010003",
                        "barcode": "002697",
                        "place": "F3A01",
                        "designation": "Verrine SCHNEIDER vert"
                    }
                },
                "02": {
                    "Verrine buzzer SCHNEIDER 220V ~ F3A02 ~ 001409": {
                        "id": "201904110026",
                        "barcode": "001409",
                        "place": "F3A02",
                        "designation": "Verrine buzzer SCHNEIDER 220V"
                    },
                    "Verrine embase et couvercle SCHNEIDER sans tube a decharge ~ F3A02 ~ 001410": {
                        "id": "201904110027",
                        "barcode": "001410",
                        "place": "F3A02",
                        "designation": "Verrine embase et couvercle SCHNEIDER sans tube a decharge"
                    },
                    "Pied et tube de verrine SCHNEIDER ~ F3A02 ~ 001411": {
                        "id": "201904110028",
                        "barcode": "001411",
                        "place": "F3A02",
                        "designation": "Pied et tube de verrine SCHNEIDER"
                    },
                    "Verrine serie XVB SCHNEIDER blanc ~ F3A02 ~ 002485": {
                        "id": "202310020001",
                        "barcode": "002485",
                        "place": "F3A02",
                        "designation": "Verrine serie XVB SCHNEIDER blanc"
                    },
                    "Verrine serie XVB SCHNEIDER jaune ~ F3A02 ~ 002486": {
                        "id": "202310020002",
                        "barcode": "002486",
                        "place": "F3A02",
                        "designation": "Verrine serie XVB SCHNEIDER jaune"
                    },
                    "Verrine serie XVB SCHNEIDER rouge ~ F3A02 ~ 002487": {
                        "id": "202310020003",
                        "barcode": "002487",
                        "place": "F3A02",
                        "designation": "Verrine serie XVB SCHNEIDER rouge"
                    },
                    "Verrine serie XVB SCHNEIDER orange ~ F3A02 ~ 002488": {
                        "id": "202310020004",
                        "barcode": "002488",
                        "place": "F3A02",
                        "designation": "Verrine serie XVB SCHNEIDER orange"
                    },
                    "Couvercle SCHNEIDER ~ F3A02 ~ 002489": {
                        "id": "202310020005",
                        "barcode": "002489",
                        "place": "F3A02",
                        "designation": "Couvercle SCHNEIDER"
                    },
                    "Verrine serie XVB SCHNEIDER vert ~ F3A02 ~ 002497": {
                        "id": "202311060002",
                        "barcode": "002497",
                        "place": "F3A02",
                        "designation": "Verrine serie XVB SCHNEIDER vert"
                    },
                    "Verrine buzzer SCHNEIDER 12 a 48V DC ~ F3A02 ~ 002548": {
                        "id": "202402150001",
                        "barcode": "002548",
                        "place": "F3A02",
                        "designation": "Verrine buzzer SCHNEIDER 12 a 48V DC"
                    }
                },
                "03": {
                    "POIGNEE ROTATIVE EN FACADE de Disjoncteur eaton ~ F3A03 ~ 000170": {
                        "id": "201901140005",
                        "barcode": "000170",
                        "place": "F3A03",
                        "designation": "POIGNEE ROTATIVE EN FACADE de Disjoncteur eaton"
                    },
                    "Divers séctionneur ~ F3A03 ~ 002703": {
                        "id": "202510090002",
                        "barcode": "002703",
                        "place": "F3A03",
                        "designation": "Divers séctionneur"
                    }
                },
                "04": {
                    "Différent Arret d'urgence monté sur boite ~ F3A04 ~ 001412": {
                        "id": "201904110029",
                        "barcode": "001412",
                        "place": "F3A04",
                        "designation": "Différent Arret d'urgence monté sur boite"
                    },
                    "Garde pour bouton tournant ~ F3A04 ~ 001413": {
                        "id": "201904110030",
                        "barcode": "001413",
                        "place": "F3A04",
                        "designation": "Garde pour bouton tournant"
                    }
                },
                "05": {
                    "Boitier SCHNEIDER ~ F3A05 ~ 001414": {
                        "id": "201904110031",
                        "barcode": "001414",
                        "place": "F3A05",
                        "designation": "Boitier SCHNEIDER"
                    },
                    "Boitier harmony SCHNEIDER ~ F3A05 ~ 002195": {
                        "id": "202202040001",
                        "barcode": "002195",
                        "place": "F3A05",
                        "designation": "Boitier harmony SCHNEIDER"
                    }
                },
                "06": {
                    "Voyant orange luna 1 ~ F3A06 ~ 001415": {
                        "id": "201904110032",
                        "barcode": "001415",
                        "place": "F3A06",
                        "designation": "Voyant orange luna 1"
                    }
                },
                "07": {
                    "Boitier de discontacteur SCHNEIDER ~ F3A07 ~ 001416": {
                        "id": "201904110033",
                        "barcode": "001416",
                        "place": "F3A07",
                        "designation": "Boitier de discontacteur SCHNEIDER"
                    }
                }
            },
            "B": {
                "10": {
                    "Alimentation stabilise 230V/24Vdc 10A ~ F3B10 ~ 001605": {
                        "id": "201904190025",
                        "barcode": "001605",
                        "place": "F3B10",
                        "designation": "Alimentation stabilise 230V/24Vdc 10A"
                    }
                },
                "11": {
                    "Alimentation stabilisée JUMO ~ F3B11 ~ 001608": {
                        "id": "201904190028",
                        "barcode": "001608",
                        "place": "F3B11",
                        "designation": "Alimentation stabilisée JUMO"
                    }
                },
                "01": {
                    "Transformateur 400/230V ~ F3B01 ~ 001607": {
                        "id": "201904190027",
                        "barcode": "001607",
                        "place": "F3B01",
                        "designation": "Transformateur 400/230V"
                    }
                },
                "02": {
                    "Transformateur BURKLE SCHOCK ~ F3B02 ~ 000226": {
                        "id": "201901180019",
                        "barcode": "000226",
                        "place": "F3B02",
                        "designation": "Transformateur BURKLE SCHOCK"
                    }
                },
                "03": {
                    "Transformateur de Sécurité ~ F3B03 ~ 000225": {
                        "id": "201901180018",
                        "barcode": "000225",
                        "place": "F3B03",
                        "designation": "Transformateur de Sécurité"
                    }
                },
                "04": {
                    "Transformateur d'isolement 230V LEGRAND ~ F3B04 ~ 000224": {
                        "id": "201901180017",
                        "barcode": "000224",
                        "place": "F3B04",
                        "designation": "Transformateur d'isolement 230V LEGRAND"
                    }
                },
                "05": {
                    "Alimentation 3X400/24Vdc ~ F3B05 ~ 001606": {
                        "id": "201904190026",
                        "barcode": "001606",
                        "place": "F3B05",
                        "designation": "Alimentation 3X400/24Vdc"
                    }
                },
                "06": {
                    "Alimentation stabilisée 230-570VAC/24DC 10A ~ F3B06 ~ 002693": {
                        "id": "202509190001",
                        "barcode": "002693",
                        "place": "F3B06",
                        "designation": "Alimentation stabilisée 230-570VAC/24DC 10A"
                    }
                },
                "07": {
                    "Transformateur d'isolement 380V ~ F3B07 ~ 002628": {
                        "id": "202412190002",
                        "barcode": "002628",
                        "place": "F3B07",
                        "designation": "Transformateur d'isolement 380V"
                    }
                },
                "08": {
                    "Alimentation Stabilisée B§R 230V/400V SEC 24V DC 10A ~ F3B08 ~ 000205": {
                        "id": "201901150027",
                        "barcode": "000205",
                        "place": "F3B08",
                        "designation": "Alimentation Stabilisée B§R 230V/400V SEC 24V DC 10A"
                    },
                    "Alimentation stabilisée WAGO ~ F3B08 ~ 000206": {
                        "id": "201901150028",
                        "barcode": "000206",
                        "place": "F3B08",
                        "designation": "Alimentation stabilisée WAGO"
                    }
                },
                "09": {
                    "Alimentation Stabilisée MURR ELEKTRONIK 230V SEC 24V DC 10A ~ F3B09 ~ 001945": {
                        "id": "202104060001",
                        "barcode": "001945",
                        "place": "F3B09",
                        "designation": "Alimentation Stabilisée MURR ELEKTRONIK 230V SEC 24V DC 10A"
                    },
                    "Alimentation Stabilisée PHOENIX CONTACT 100/ 240V SEC 24V DC 5A ~ F3B09 ~ 001946": {
                        "id": "202104060002",
                        "barcode": "001946",
                        "place": "F3B09",
                        "designation": "Alimentation Stabilisée PHOENIX CONTACT 100/ 240V SEC 24V DC 5A"
                    },
                    "Alimentation Stabilisée Phoenix contact 100/ 240V SEC 24V DC 10A ~ F3B09 ~ 002378": {
                        "id": "202306010002",
                        "barcode": "002378",
                        "place": "F3B09",
                        "designation": "Alimentation Stabilisée Phoenix contact 100/ 240V SEC 24V DC 10A"
                    }
                }
            },
            "C": {
                "10": {
                    "Connecteur sonde tunnel de lavage ~ F3C10 ~ 001647": {
                        "id": "201905070002",
                        "barcode": "001647",
                        "place": "F3C10",
                        "designation": "Connecteur sonde tunnel de lavage"
                    }
                },
                "11": {
                    "Repartiteur ~ F3C11 ~ 001645": {
                        "id": "201905060011",
                        "barcode": "001645",
                        "place": "F3C11",
                        "designation": "Repartiteur"
                    },
                    "Repartiteur ~ F3C11 ~ 002114": {
                        "id": "202111120004",
                        "barcode": "002114",
                        "place": "F3C11",
                        "designation": "Repartiteur"
                    }
                },
                "12": {
                    "Repartiteur ~ F3C12 ~ 001646": {
                        "id": "201905070001",
                        "barcode": "001646",
                        "place": "F3C12",
                        "designation": "Repartiteur"
                    }
                },
                "13": {
                    "Support Jensen ~ F3C13 ~ 001705": {
                        "id": "201909040001",
                        "barcode": "001705",
                        "place": "F3C13",
                        "designation": "Support Jensen"
                    }
                },
                "14": {
                    "Reflecteur autocollant SCHNEIDER ~ F3C14 ~ 001417": {
                        "id": "201904110034",
                        "barcode": "001417",
                        "place": "F3C14",
                        "designation": "Reflecteur autocollant SCHNEIDER"
                    }
                },
                "15": {
                    "Reflecteur rond diametre 8 SCHNEIDER ~ F3C15 ~ 001418": {
                        "id": "201904110035",
                        "barcode": "001418",
                        "place": "F3C15",
                        "designation": "Reflecteur rond diametre 8 SCHNEIDER"
                    }
                },
                "16": {
                    "Reflecteur rectangle ~ F3C16 ~ 001419": {
                        "id": "201904110036",
                        "barcode": "001419",
                        "place": "F3C16",
                        "designation": "Reflecteur rectangle"
                    }
                },
                "17": {
                    "Reflecteur carre SICK ~ F3C17 ~ 001420": {
                        "id": "201904110037",
                        "barcode": "001420",
                        "place": "F3C17",
                        "designation": "Reflecteur carre SICK"
                    }
                },
                "18": {
                    "Divers support pour reflecteur ~ F3C18 ~ 001422": {
                        "id": "201904110039",
                        "barcode": "001422",
                        "place": "F3C18",
                        "designation": "Divers support pour reflecteur"
                    }
                },
                "01": {
                    "Connecteur prise M8 male 4 poles ~ F3C01 ~ 001650": {
                        "id": "201905070005",
                        "barcode": "001650",
                        "place": "F3C01",
                        "designation": "Connecteur prise M8 male 4 poles"
                    }
                },
                "02": {
                    "Connecteur prise M8 femelle 4 poles ~ F3C02 ~ 001651": {
                        "id": "201905070006",
                        "barcode": "001651",
                        "place": "F3C02",
                        "designation": "Connecteur prise M8 femelle 4 poles"
                    }
                },
                "03": {
                    "Connecteur prise M8 femelle 3 poles ~ F3C03 ~ 002476": {
                        "id": "202309190001",
                        "barcode": "002476",
                        "place": "F3C03",
                        "designation": "Connecteur prise M8 femelle 3 poles"
                    }
                },
                "04": {
                    "Adaptateur M8 femelle/M12 male 4 poles ~ F3C04 ~ 001649": {
                        "id": "201905070004",
                        "barcode": "001649",
                        "place": "F3C04",
                        "designation": "Adaptateur M8 femelle/M12 male 4 poles"
                    }
                },
                "05": {
                    "Connecteur prise M8 male 3 poles ~ F3C05 ~ 001640": {
                        "id": "201905060006",
                        "barcode": "001640",
                        "place": "F3C05",
                        "designation": "Connecteur prise M8 male 3 poles"
                    }
                },
                "06": {
                    "Connecteur prise 4 poles male M12 ~ F3C06 ~ 001653": {
                        "id": "201905070008",
                        "barcode": "001653",
                        "place": "F3C06",
                        "designation": "Connecteur prise 4 poles male M12"
                    }
                },
                "07": {
                    "Connecteur prise 4 poles femelle M12 ~ F3C07 ~ 001652": {
                        "id": "201905070007",
                        "barcode": "001652",
                        "place": "F3C07",
                        "designation": "Connecteur prise 4 poles femelle M12"
                    }
                },
                "08": {
                    "Connecteur et cable Jensen pour GP & PP ~ F3C08 ~ 001654": {
                        "id": "201905070009",
                        "barcode": "001654",
                        "place": "F3C08",
                        "designation": "Connecteur et cable Jensen pour GP & PP"
                    }
                },
                "09": {
                    "Cable de balance precia molen ~ F3C09 ~ 000212": {
                        "id": "201901180005",
                        "barcode": "000212",
                        "place": "F3C09",
                        "designation": "Cable de balance precia molen"
                    },
                    "Cable de balance precia molen ~ F3C09 ~ 002112": {
                        "id": "202111120002",
                        "barcode": "002112",
                        "place": "F3C09",
                        "designation": "Cable de balance precia molen"
                    }
                }
            },
            "D": {
                "10": {
                    "Connecteur avec fil M8 droit femelle 4 broches ~ F3D10 ~ 002110": {
                        "id": "202111100011",
                        "barcode": "002110",
                        "place": "F3D10",
                        "designation": "Connecteur avec fil M8 droit femelle 4 broches"
                    }
                },
                "11": {
                    "Connecteur avec cable prise M8 fem 3 poles ~ F3D11 ~ 002477": {
                        "id": "202309190002",
                        "barcode": "002477",
                        "place": "F3D11",
                        "designation": "Connecteur avec cable prise M8 fem 3 poles"
                    }
                },
                "12": {
                    "Prolongateur M8 droit 4 broches ~ F3D12 ~ 002109": {
                        "id": "202111100010",
                        "barcode": "002109",
                        "place": "F3D12",
                        "designation": "Prolongateur M8 droit 4 broches"
                    }
                },
                "13": {
                    "Connecteur Escha M12 ~ F3D13 ~ 001628": {
                        "id": "201905030014",
                        "barcode": "001628",
                        "place": "F3D13",
                        "designation": "Connecteur Escha M12"
                    }
                },
                "01": {
                    "Connecteur avec fil femelle coudée M12 4 broches ~ F3D01 ~ 001629": {
                        "id": "201905030015",
                        "barcode": "001629",
                        "place": "F3D01",
                        "designation": "Connecteur avec fil femelle coudée M12 4 broches"
                    }
                },
                "02": {
                    "Connecteur avec fil femelle droit M12 4 broches ~ F3D02 ~ 001634": {
                        "id": "201905030020",
                        "barcode": "001634",
                        "place": "F3D02",
                        "designation": "Connecteur avec fil femelle droit M12 4 broches"
                    }
                },
                "03": {
                    "Prolongateur droit/coudé 4 broches M12 ~ F3D03 ~ 001630": {
                        "id": "201905030016",
                        "barcode": "001630",
                        "place": "F3D03",
                        "designation": "Prolongateur droit/coudé 4 broches M12"
                    }
                },
                "04": {
                    "Prolongateur 4 broches M12 ~ F3D04 ~ 001631": {
                        "id": "201905030017",
                        "barcode": "001631",
                        "place": "F3D04",
                        "designation": "Prolongateur 4 broches M12"
                    }
                },
                "05": {
                    "Prolongateur M12 male/femelle 3 broches ~ F3D05 ~ 001632": {
                        "id": "201905030018",
                        "barcode": "001632",
                        "place": "F3D05",
                        "designation": "Prolongateur M12 male/femelle 3 broches"
                    }
                },
                "06": {
                    "Prolongateur 3 broches M8 male/ M12 femelle ~ F3D06 ~ 001636": {
                        "id": "201905060002",
                        "barcode": "001636",
                        "place": "F3D06",
                        "designation": "Prolongateur 3 broches M8 male/ M12 femelle"
                    },
                    "Prolongateur 3 broches M8 male/ M12 fem ~ F3D06 ~ 002113": {
                        "id": "202111120003",
                        "barcode": "002113",
                        "place": "F3D06",
                        "designation": "Prolongateur 3 broches M8 male/ M12 fem"
                    }
                },
                "07": {
                    "Connecteur avec fil M8 femelle 3 poles ~ F3D07 ~ 002111": {
                        "id": "202111120001",
                        "barcode": "002111",
                        "place": "F3D07",
                        "designation": "Connecteur avec fil M8 femelle 3 poles"
                    }
                },
                "08": {
                    "Prolongateur M8 3 poles male/femelle ~ F3D08 ~ 001641": {
                        "id": "201905060007",
                        "barcode": "001641",
                        "place": "F3D08",
                        "designation": "Prolongateur M8 3 poles male/femelle"
                    }
                },
                "09": {
                    "Connecteur avec fil M8 coudée femelle 4 poles ~ F3D09 ~ 001638": {
                        "id": "201905060004",
                        "barcode": "001638",
                        "place": "F3D09",
                        "designation": "Connecteur avec fil M8 coudée femelle 4 poles"
                    }
                }
            },
            "E": {
                "10": {
                    "Filtre noir armoire electrique ~ F3E10 ~ 001321": {
                        "id": "201904090013",
                        "barcode": "001321",
                        "place": "F3E10",
                        "designation": "Filtre noir armoire electrique"
                    }
                },
                "11": {
                    "Condensateur electrique 4nF ~ F3E11 ~ 002458": {
                        "id": "202308160005",
                        "barcode": "002458",
                        "place": "F3E11",
                        "designation": "Condensateur electrique 4nF"
                    },
                    "Condensateur electrique 8nF ~ F3E11 ~ 002533": {
                        "id": "202401040004",
                        "barcode": "002533",
                        "place": "F3E11",
                        "designation": "Condensateur electrique 8nF"
                    },
                    "Condensateur electrique 12nF ~ F3E11 ~ 002740": {
                        "id": "202512300002",
                        "barcode": "002740",
                        "place": "F3E11",
                        "designation": "Condensateur electrique 12nF"
                    },
                    "Condensateur electrique 6nF ~ F3E11 ~ 002741": {
                        "id": "202512300003",
                        "barcode": "002741",
                        "place": "F3E11",
                        "designation": "Condensateur electrique 6nF"
                    }
                },
                "01": {
                    "Ventilateur 120X120 en 24vDC ~ F3E01 ~ 001315": {
                        "id": "201904090007",
                        "barcode": "001315",
                        "place": "F3E01",
                        "designation": "Ventilateur 120X120 en 24vDC"
                    }
                },
                "02": {
                    "Ventilateur 120X120 en 230V ac ~ F3E02 ~ 001316": {
                        "id": "201904090008",
                        "barcode": "001316",
                        "place": "F3E02",
                        "designation": "Ventilateur 120X120 en 230V ac"
                    }
                },
                "03": {
                    "Ventilateur 92X92 en 230v AC ~ F3E03 ~ 002099": {
                        "id": "202111090001",
                        "barcode": "002099",
                        "place": "F3E03",
                        "designation": "Ventilateur 92X92 en 230v AC"
                    }
                },
                "04": {
                    "Ventilateur 92X92 en 24vDC ~ F3E04 ~ 001317": {
                        "id": "201904090009",
                        "barcode": "001317",
                        "place": "F3E04",
                        "designation": "Ventilateur 92X92 en 24vDC"
                    }
                },
                "05": {
                    "Ventilateur Fandis 88X88 en 230v AC ~ F3E05 ~ 001318": {
                        "id": "201904090010",
                        "barcode": "001318",
                        "place": "F3E05",
                        "designation": "Ventilateur Fandis 88X88 en 230v AC"
                    }
                },
                "06": {
                    "Filtre blanc armoire electrique ~ F3E06 ~ 001322": {
                        "id": "201904090014",
                        "barcode": "001322",
                        "place": "F3E06",
                        "designation": "Filtre blanc armoire electrique"
                    }
                },
                "07": {
                    "Filtre et protection ventilateur ~ F3E07 ~ 001320": {
                        "id": "201904090012",
                        "barcode": "001320",
                        "place": "F3E07",
                        "designation": "Filtre et protection ventilateur"
                    }
                },
                "08": {
                    "Filtre complet ventilateur (vendu avec les ventileurs ) ~ F3E08 ~ 000210": {
                        "id": "201901180003",
                        "barcode": "000210",
                        "place": "F3E08",
                        "designation": "Filtre complet ventilateur (vendu avec les ventileurs )"
                    }
                },
                "09": {
                    "Cordon d'alimentation ventilateur CC900 ~ F3E09 ~ 001319": {
                        "id": "201904090011",
                        "barcode": "001319",
                        "place": "F3E09",
                        "designation": "Cordon d'alimentation ventilateur CC900"
                    }
                }
            },
            "F": {
                "Ventilateur 325X325 en 230V ac ~ F3F ~ 001314": {
                    "id": "201904090006",
                    "barcode": "001314",
                    "place": "F3F",
                    "designation": "Ventilateur 325X325 en 230V ac"
                }
            }
        }
    },
    "Rangée G": {
        "1 Colonne": {
            "A": {
                "01": {
                    "Tagsys L40 ou L400 lecture de puce ~ G1A01 ~ 001726": {
                        "id": "201912110001",
                        "barcode": "001726",
                        "place": "G1A01",
                        "designation": "Tagsys L40 ou L400 lecture de puce"
                    }
                },
                "02": {
                    "Tagsys L400 4 ports tunnel de lecture de puce ~ G1A02 ~ 001952": {
                        "id": "202104200003",
                        "barcode": "001952",
                        "place": "G1A02",
                        "designation": "Tagsys L400 4 ports tunnel de lecture de puce"
                    }
                },
                "03": {
                    "Cordons/notices programmation Tagsys L40/L400 lecture de puce ~ G1A03 ~ 002403": {
                        "id": "202307180001",
                        "barcode": "002403",
                        "place": "G1A03",
                        "designation": "Cordons/notices programmation Tagsys L40/L400 lecture de puce"
                    }
                },
                "04": {
                    "Ferrite double sur fil rond diametre 9.5mm ~ G1A04 ~ 000277": {
                        "id": "201901220042",
                        "barcode": "000277",
                        "place": "G1A04",
                        "designation": "Ferrite double sur fil rond diametre 9.5mm"
                    }
                },
                "05": {
                    "Adaptateur usb/serie lecture de puce RFID HF + divers DATAMARS ~ G1A05 ~ 002303": {
                        "id": "202212060003",
                        "barcode": "002303",
                        "place": "G1A05",
                        "designation": "Adaptateur usb/serie lecture de puce RFID HF + divers DATAMARS"
                    },
                    "Tagsys lecture de puce RFID e-connecting goods ~ G1A05 ~ 002542": {
                        "id": "202401310001",
                        "barcode": "002542",
                        "place": "G1A05",
                        "designation": "Tagsys lecture de puce RFID e-connecting goods"
                    }
                }
            },
            "B": {
                "01": {
                    "Variateur Danfoss CALANDRE PP ~ G1B01 ~ 001241": {
                        "id": "201904040013",
                        "barcode": "001241",
                        "place": "G1B01",
                        "designation": "Variateur Danfoss CALANDRE PP"
                    }
                },
                "02": {
                    "Variateur Danfoss CALANDRE GP ~ G1B02 ~ 002218": {
                        "id": "202203170001",
                        "barcode": "002218",
                        "place": "G1B02",
                        "designation": "Variateur Danfoss CALANDRE GP"
                    }
                },
                "03": {
                    "Variateur TELEMECANIQUE Altivar 31 ~ G1B03 ~ 000227": {
                        "id": "201901180020",
                        "barcode": "000227",
                        "place": "G1B03",
                        "designation": "Variateur TELEMECANIQUE Altivar 31"
                    }
                },
                "04": {
                    "Variateur KEB 9.F4.S8D-3420/1.2 ~ G1B04 ~ 002229": {
                        "id": "202207050001",
                        "barcode": "002229",
                        "place": "G1B04",
                        "designation": "Variateur KEB 9.F4.S8D-3420/1.2"
                    }
                },
                "05": {
                    "Variateur KEB 10.F4.F8D-4000 ~ G1B05 ~ 002300": {
                        "id": "202206240001",
                        "barcode": "002300",
                        "place": "G1B05",
                        "designation": "Variateur KEB 10.F4.F8D-4000"
                    }
                }
            },
            "C": {
                "10": {
                    "Console ecran programmable Clarus controle machine à laver 25kg ~ G1C10 ~ 001236": {
                        "id": "201904040008",
                        "barcode": "001236",
                        "place": "G1C10",
                        "designation": "Console ecran programmable Clarus controle machine à laver 25kg"
                    }
                },
                "11": {
                    "Ecran de presse Lavatec sans EPROM ~ G1C11 ~ 001240": {
                        "id": "201904040012",
                        "barcode": "001240",
                        "place": "G1C11",
                        "designation": "Ecran de presse Lavatec sans EPROM"
                    }
                },
                "01": {
                    "Ecran d'essoreuse Kannegiesser CTT-11 ~ G1C01 ~ 002089": {
                        "id": "202111040002",
                        "barcode": "002089",
                        "place": "G1C01",
                        "designation": "Ecran d'essoreuse Kannegiesser CTT-11"
                    }
                },
                "02": {
                    "Ecran SIEMENS SIMATIC PANEL ~ G1C02 ~ 001239": {
                        "id": "201904040011",
                        "barcode": "001239",
                        "place": "G1C02",
                        "designation": "Ecran SIEMENS SIMATIC PANEL"
                    }
                },
                "03": {
                    "Ecran TELEMECANIQUE MAGELIS gestion tapis VT ~ G1C03 ~ 000234": {
                        "id": "201901180027",
                        "barcode": "000234",
                        "place": "G1C03",
                        "designation": "Ecran TELEMECANIQUE MAGELIS gestion tapis VT"
                    }
                },
                "04": {
                    "Ecran JENSEN CT1081 ~ G1C04 ~ 001237": {
                        "id": "201904040009",
                        "barcode": "001237",
                        "place": "G1C04",
                        "designation": "Ecran JENSEN CT1081"
                    }
                },
                "05": {
                    "Ecran BR POWER PANEL 400 ~ G1C05 ~ 002051": {
                        "id": "202109220003",
                        "barcode": "002051",
                        "place": "G1C05",
                        "designation": "Ecran BR POWER PANEL 400"
                    }
                },
                "06": {
                    "Ecran BR Napkin Lapauw ~ G1C06 ~ 002357": {
                        "id": "202304170001",
                        "barcode": "002357",
                        "place": "G1C06",
                        "designation": "Ecran BR Napkin Lapauw"
                    }
                },
                "07": {
                    "Ecran BR POWER PANEL ~ G1C07 ~ 001238": {
                        "id": "201904040010",
                        "barcode": "001238",
                        "place": "G1C07",
                        "designation": "Ecran BR POWER PANEL"
                    }
                },
                "08": {
                    "ECRAN NBT03 kannegiesser ~ G1C08 ~ 002344": {
                        "id": "202303200002",
                        "barcode": "002344",
                        "place": "G1C08",
                        "designation": "ECRAN NBT03 kannegiesser"
                    }
                },
                "09": {
                    "Ecran Jensen ~ G1C09 ~ 002050": {
                        "id": "202109220002",
                        "barcode": "002050",
                        "place": "G1C09",
                        "designation": "Ecran Jensen"
                    }
                }
            },
            "D": {
                "10": {
                    "Carte de sorties digitales X20 ~ G1D10 ~ 001192": {
                        "id": "201903290003",
                        "barcode": "001192",
                        "place": "G1D10",
                        "designation": "Carte de sorties digitales X20"
                    }
                },
                "11": {
                    "Carte de bus X20 Kannégiesser tunnel et séchoir ~ G1D11 ~ 002619": {
                        "id": "202411040001",
                        "barcode": "002619",
                        "place": "G1D11",
                        "designation": "Carte de bus X20 Kannégiesser tunnel et séchoir"
                    }
                },
                "12": {
                    "Carte de sortie automate ~ G1D12 ~ 000260": {
                        "id": "201901220025",
                        "barcode": "000260",
                        "place": "G1D12",
                        "designation": "Carte de sortie automate"
                    }
                },
                "13": {
                    "Carte d'entrées X20 automate ~ G1D13 ~ 000258": {
                        "id": "201901220023",
                        "barcode": "000258",
                        "place": "G1D13",
                        "designation": "Carte d'entrées X20 automate"
                    }
                },
                "14": {
                    "Carte d'entrées 20 automate ~ G1D14 ~ 001193": {
                        "id": "201903290004",
                        "barcode": "001193",
                        "place": "G1D14",
                        "designation": "Carte d'entrées 20 automate"
                    }
                },
                "15": {
                    "Carte d'entrées digitales X20 ~ G1D15 ~ 000259": {
                        "id": "201901220024",
                        "barcode": "000259",
                        "place": "G1D15",
                        "designation": "Carte d'entrées digitales X20"
                    }
                },
                "16": {
                    "Carte compteur digital X20 ~ G1D16 ~ 000261": {
                        "id": "201901220026",
                        "barcode": "000261",
                        "place": "G1D16",
                        "designation": "Carte compteur digital X20"
                    }
                },
                "17": {
                    "Carte d'alimentation automate X20 ~ G1D17 ~ 000262": {
                        "id": "201901220027",
                        "barcode": "000262",
                        "place": "G1D17",
                        "designation": "Carte d'alimentation automate X20"
                    }
                },
                "18": {
                    "Carte d'alimentation X20 24V ~ G1D18 ~ 001194": {
                        "id": "201903290005",
                        "barcode": "001194",
                        "place": "G1D18",
                        "designation": "Carte d'alimentation X20 24V"
                    }
                },
                "19": {
                    "Carte automate X20 ~ G1D19 ~ 000263": {
                        "id": "201901220028",
                        "barcode": "000263",
                        "place": "G1D19",
                        "designation": "Carte automate X20"
                    }
                },
                "20": {
                    "Carte CPU TSX57103 (linge sale) ~ G1D20 ~ 001885": {
                        "id": "202011270001",
                        "barcode": "001885",
                        "place": "G1D20",
                        "designation": "Carte CPU TSX57103 (linge sale)"
                    }
                },
                "21": {
                    "Carte d'automate ~ G1D21 ~ 001229": {
                        "id": "201904040001",
                        "barcode": "001229",
                        "place": "G1D21",
                        "designation": "Carte d'automate"
                    }
                },
                "22": {
                    "Carte ICP DAS NS-205PSE Industrial Unmanaged 5-Port 10/100 Power Over Ethernet (PoE) Switch ~ G1D22 ~ 002146": {
                        "id": "202111160019",
                        "barcode": "002146",
                        "place": "G1D22",
                        "designation": "Carte ICP DAS NS-205PSE Industrial Unmanaged 5-Port 10/100 Power Over Ethernet (PoE) Switch"
                    }
                },
                "28": {
                    "Fibre Optique plastique (vendu au mètre ) ~ G1D28 ~ 001195": {
                        "id": "201903290006",
                        "barcode": "001195",
                        "place": "G1D28",
                        "designation": "Fibre Optique plastique (vendu au mètre )"
                    }
                },
                "29": {
                    "Clavier de commande variateur KEB F4 ~ G1D29 ~ 000454": {
                        "id": "201903050013",
                        "barcode": "000454",
                        "place": "G1D29",
                        "designation": "Clavier de commande variateur KEB F4"
                    },
                    "Clavier de commande variateur KEB F4 avec fibre optique ~ G1D29 ~ 000455": {
                        "id": "201903050014",
                        "barcode": "000455",
                        "place": "G1D29",
                        "designation": "Clavier de commande variateur KEB F4 avec fibre optique"
                    },
                    "Clavier de commande variateur KEB F5 ~ G1D29 ~ 000456": {
                        "id": "201903050015",
                        "barcode": "000456",
                        "place": "G1D29",
                        "designation": "Clavier de commande variateur KEB F5"
                    },
                    "Raccord a souder Fibre Optique ~ G1D29 ~ 001861": {
                        "id": "202008240004",
                        "barcode": "001861",
                        "place": "G1D29",
                        "designation": "Raccord a souder Fibre Optique"
                    },
                    "Raccord a souder Fibre Optique ~ G1D29 ~ 002093": {
                        "id": "202111050002",
                        "barcode": "002093",
                        "place": "G1D29",
                        "designation": "Raccord a souder Fibre Optique"
                    }
                },
                "30": {
                    "Port serie ethernet MOXA a programmer par Sodilec ~ G1D30 ~ 001196": {
                        "id": "201903290007",
                        "barcode": "001196",
                        "place": "G1D30",
                        "designation": "Port serie ethernet MOXA a programmer par Sodilec"
                    }
                },
                "31": {
                    "Convertisseur RS232/485 ~ G1D31 ~ 001232": {
                        "id": "201904040004",
                        "barcode": "001232",
                        "place": "G1D31",
                        "designation": "Convertisseur RS232/485"
                    }
                },
                "32": {
                    "Convertisseur RS422/485 ~ G1D32 ~ 000233": {
                        "id": "201901180026",
                        "barcode": "000233",
                        "place": "G1D32",
                        "designation": "Convertisseur RS422/485"
                    }
                },
                "33": {
                    "SIOX RS232 interface L40 ~ G1D33 ~ 001234": {
                        "id": "201904040006",
                        "barcode": "001234",
                        "place": "G1D33",
                        "designation": "SIOX RS232 interface L40"
                    }
                },
                "34": {
                    "Boitier et lecteur de puce TCI 620 51 M pour Metricon ~ G1D34 ~ 001953": {
                        "id": "202104200004",
                        "barcode": "001953",
                        "place": "G1D34",
                        "designation": "Boitier et lecteur de puce TCI 620 51 M pour Metricon"
                    }
                },
                "35": {
                    "Resistance de décharge KEB ~ G1D35 ~ 001235": {
                        "id": "201904040007",
                        "barcode": "001235",
                        "place": "G1D35",
                        "designation": "Resistance de décharge KEB"
                    }
                },
                "01": {
                    "Carte de sortie analogiques X20 ~ G1D01 ~ 001190": {
                        "id": "201903290001",
                        "barcode": "001190",
                        "place": "G1D01",
                        "designation": "Carte de sortie analogiques X20"
                    }
                },
                "02": {
                    "Carte d'entrée analogiques X20 ~ G1D02 ~ 000250": {
                        "id": "201901220015",
                        "barcode": "000250",
                        "place": "G1D02",
                        "designation": "Carte d'entrée analogiques X20"
                    }
                },
                "03": {
                    "Carte d'entrée de température X20 ~ G1D03 ~ 000251": {
                        "id": "201901220016",
                        "barcode": "000251",
                        "place": "G1D03",
                        "designation": "Carte d'entrée de température X20"
                    }
                },
                "04": {
                    "Carte d'entrée de température ~ G1D04 ~ 000252": {
                        "id": "201901220017",
                        "barcode": "000252",
                        "place": "G1D04",
                        "designation": "Carte d'entrée de température"
                    }
                },
                "05": {
                    "Carte d'Interface X20 ~ G1D05 ~ 000253": {
                        "id": "201901220018",
                        "barcode": "000253",
                        "place": "G1D05",
                        "designation": "Carte d'Interface X20"
                    }
                },
                "06": {
                    "Carte de sorties digitales X20 ~ G1D06 ~ 000254": {
                        "id": "201901220019",
                        "barcode": "000254",
                        "place": "G1D06",
                        "designation": "Carte de sorties digitales X20"
                    }
                },
                "07": {
                    "Carte de sorties digitales X20 ~ G1D07 ~ 000255": {
                        "id": "201901220020",
                        "barcode": "000255",
                        "place": "G1D07",
                        "designation": "Carte de sorties digitales X20"
                    }
                },
                "08": {
                    "Carte d'interface X20 ~ G1D08 ~ 000256": {
                        "id": "201901220021",
                        "barcode": "000256",
                        "place": "G1D08",
                        "designation": "Carte d'interface X20"
                    }
                },
                "09": {
                    "Carte digital X20 - 8 entrées - 24VDC ~ G1D09 ~ 001191": {
                        "id": "201903290002",
                        "barcode": "001191",
                        "place": "G1D09",
                        "designation": "Carte digital X20 - 8 entrées - 24VDC"
                    }
                }
            },
            "E": {
                "10": {
                    "Carte 8 entrées analogiques ~ G1E10 ~ 000265": {
                        "id": "201901220030",
                        "barcode": "000265",
                        "place": "G1E10",
                        "designation": "Carte 8 entrées analogiques"
                    }
                },
                "11": {
                    "Carte 16 entrées digitales ~ G1E11 ~ 000266": {
                        "id": "201901220031",
                        "barcode": "000266",
                        "place": "G1E11",
                        "designation": "Carte 16 entrées digitales"
                    }
                },
                "12": {
                    "Carte 4 entrées analogiques ~ G1E12 ~ 000267": {
                        "id": "201901220032",
                        "barcode": "000267",
                        "place": "G1E12",
                        "designation": "Carte 4 entrées analogiques"
                    },
                    "Carte electronique de bus IF672 ~ G1E12 ~ 002606": {
                        "id": "202409040003",
                        "barcode": "002606",
                        "place": "G1E12",
                        "designation": "Carte electronique de bus IF672"
                    }
                },
                "13": {
                    "Carte mixte TOR 16 entrées 24VDC ~ G1E13 ~ 000268": {
                        "id": "201901220033",
                        "barcode": "000268",
                        "place": "G1E13",
                        "designation": "Carte mixte TOR 16 entrées 24VDC"
                    },
                    "Carte d'entrées/sorties combinées ~ G1E13 ~ 000269": {
                        "id": "201901220034",
                        "barcode": "000269",
                        "place": "G1E13",
                        "designation": "Carte d'entrées/sorties combinées"
                    }
                },
                "14": {
                    "Carte d'interface (4 emplacements) ~ G1E14 ~ 000270": {
                        "id": "201901220035",
                        "barcode": "000270",
                        "place": "G1E14",
                        "designation": "Carte d'interface (4 emplacements)"
                    },
                    "Carte 8 entrées digitales 24VDC ~ G1E14 ~ 000271": {
                        "id": "201901220036",
                        "barcode": "000271",
                        "place": "G1E14",
                        "designation": "Carte 8 entrées digitales 24VDC"
                    }
                },
                "17": {
                    "Carte d'entree automate SIEMENS Simatic S7-300 ~ G1E17 ~ 002380": {
                        "id": "202306010004",
                        "barcode": "002380",
                        "place": "G1E17",
                        "designation": "Carte d'entree automate SIEMENS Simatic S7-300"
                    },
                    "Carte de sortie automate SIEMENS Simatic S7-300 ~ G1E17 ~ 002381": {
                        "id": "202306010005",
                        "barcode": "002381",
                        "place": "G1E17",
                        "designation": "Carte de sortie automate SIEMENS Simatic S7-300"
                    }
                },
                "18": {
                    "Carte de sortie automate OMRON ~ G1E18 ~ 000249": {
                        "id": "201901220014",
                        "barcode": "000249",
                        "place": "G1E18",
                        "designation": "Carte de sortie automate OMRON"
                    }
                },
                "19": {
                    "Automate Siemens Simatic S7-300 cpu313C ~ G1E19 ~ 000232": {
                        "id": "201901180025",
                        "barcode": "000232",
                        "place": "G1E19",
                        "designation": "Automate Siemens Simatic S7-300 cpu313C"
                    },
                    "Carte analogique automate Siemens Simatic S7-300 ~ G1E19 ~ 002379": {
                        "id": "202306010003",
                        "barcode": "002379",
                        "place": "G1E19",
                        "designation": "Carte analogique automate Siemens Simatic S7-300"
                    }
                },
                "01": {
                    "Carte d'automate SIGMATEC dias ddi 161 ~ G1E01 ~ 000230": {
                        "id": "201901180023",
                        "barcode": "000230",
                        "place": "G1E01",
                        "designation": "Carte d'automate SIGMATEC dias ddi 161"
                    }
                },
                "02": {
                    "Carte de sortie automate Jensen ~ G1E02 ~ 000243": {
                        "id": "201901220008",
                        "barcode": "000243",
                        "place": "G1E02",
                        "designation": "Carte de sortie automate Jensen"
                    },
                    "Carte d'automate Port Fibre Optique JENSEN ~ G1E02 ~ 000244": {
                        "id": "201901220009",
                        "barcode": "000244",
                        "place": "G1E02",
                        "designation": "Carte d'automate Port Fibre Optique JENSEN"
                    },
                    "Carte de sortie automate JENSEN ~ G1E02 ~ 001230": {
                        "id": "201904040002",
                        "barcode": "001230",
                        "place": "G1E02",
                        "designation": "Carte de sortie automate JENSEN"
                    }
                },
                "03": {
                    "Carte d'alimentation automate JENSEN 24V DC ~ G1E03 ~ 000245": {
                        "id": "201901220010",
                        "barcode": "000245",
                        "place": "G1E03",
                        "designation": "Carte d'alimentation automate JENSEN 24V DC"
                    }
                },
                "04": {
                    "SIOX S45 DIGITAL IN/OUT ~ G1E04 ~ 000235": {
                        "id": "201901180028",
                        "barcode": "000235",
                        "place": "G1E04",
                        "designation": "SIOX S45 DIGITAL IN/OUT"
                    }
                },
                "05": {
                    "Carte d'alimentation automate JENSEN 24V DC ~ G1E05 ~ 001231": {
                        "id": "201904040003",
                        "barcode": "001231",
                        "place": "G1E05",
                        "designation": "Carte d'alimentation automate JENSEN 24V DC"
                    }
                },
                "06": {
                    "Carte d'entrée automate OMRON ~ G1E06 ~ 000246": {
                        "id": "201901220011",
                        "barcode": "000246",
                        "place": "G1E06",
                        "designation": "Carte d'entrée automate OMRON"
                    }
                },
                "07": {
                    "Carte d'entrée OMRON ~ G1E07 ~ 000247": {
                        "id": "201901220012",
                        "barcode": "000247",
                        "place": "G1E07",
                        "designation": "Carte d'entrée OMRON"
                    }
                },
                "08": {
                    "Carte de sortie OMRON ~ G1E08 ~ 000248": {
                        "id": "201901220013",
                        "barcode": "000248",
                        "place": "G1E08",
                        "designation": "Carte de sortie OMRON"
                    }
                },
                "09": {
                    "Carte de sorties digitales ~ G1E09 ~ 000264": {
                        "id": "201901220029",
                        "barcode": "000264",
                        "place": "G1E09",
                        "designation": "Carte de sorties digitales"
                    }
                }
            }
        },
        "2 Colonne": {
            "C": {
                "10": {
                    "Cle de porte SCHNEIDER ~ G2C10 ~ 001388": {
                        "id": "201904110005",
                        "barcode": "001388",
                        "place": "G2C10",
                        "designation": "Cle de porte SCHNEIDER"
                    }
                },
                "11": {
                    "Cle de porte SCHNEIDER ~ G2C11 ~ 001390": {
                        "id": "201904110007",
                        "barcode": "001390",
                        "place": "G2C11",
                        "designation": "Cle de porte SCHNEIDER"
                    }
                },
                "12": {
                    "Cle de porte SCHNEIDER ~ G2C12 ~ 001389": {
                        "id": "201904110006",
                        "barcode": "001389",
                        "place": "G2C12",
                        "designation": "Cle de porte SCHNEIDER"
                    }
                },
                "13": {
                    "Securité de porte SCHMERSAL ~ G2C13 ~ 001391": {
                        "id": "201904110008",
                        "barcode": "001391",
                        "place": "G2C13",
                        "designation": "Securité de porte SCHMERSAL"
                    },
                    "Cle de securite SCHMERSAL ~ G2C13 ~ 001392": {
                        "id": "201904110009",
                        "barcode": "001392",
                        "place": "G2C13",
                        "designation": "Cle de securite SCHMERSAL"
                    }
                },
                "14": {
                    "Cle de securite SICK ~ G2C14 ~ 001394": {
                        "id": "201904110011",
                        "barcode": "001394",
                        "place": "G2C14",
                        "designation": "Cle de securite SICK"
                    },
                    "Securite porte SICK ~ G2C14 ~ 002094": {
                        "id": "202111080001",
                        "barcode": "002094",
                        "place": "G2C14",
                        "designation": "Securite porte SICK"
                    }
                },
                "15": {
                    "Securité de porte EUCHNER ~ G2C15 ~ 001395": {
                        "id": "201904110012",
                        "barcode": "001395",
                        "place": "G2C15",
                        "designation": "Securité de porte EUCHNER"
                    },
                    "Languette coudée cle de securité de porte EUCHNER ~ G2C15 ~ 002268": {
                        "id": "202209200001",
                        "barcode": "002268",
                        "place": "G2C15",
                        "designation": "Languette coudée cle de securité de porte EUCHNER"
                    }
                },
                "16": {
                    "Relais de securite PILZ ~ G2C16 ~ 001396": {
                        "id": "201904110013",
                        "barcode": "001396",
                        "place": "G2C16",
                        "designation": "Relais de securite PILZ"
                    },
                    "Relais de securite PILZ programmé filmeuse Beck ~ G2C16 ~ 002224": {
                        "id": "202207010002",
                        "barcode": "002224",
                        "place": "G2C16",
                        "designation": "Relais de securite PILZ programmé filmeuse Beck"
                    }
                },
                "17": {
                    "Relais de securite PILZ ~ G2C17 ~ 001397": {
                        "id": "201904110014",
                        "barcode": "001397",
                        "place": "G2C17",
                        "designation": "Relais de securite PILZ"
                    }
                },
                "18": {
                    "Relais de securite SCHNEIDER preventa ~ G2C18 ~ 001398": {
                        "id": "201904110015",
                        "barcode": "001398",
                        "place": "G2C18",
                        "designation": "Relais de securite SCHNEIDER preventa"
                    }
                },
                "19": {
                    "Relais de securite DUELCO ~ G2C19 ~ 001935": {
                        "id": "202103300001",
                        "barcode": "001935",
                        "place": "G2C19",
                        "designation": "Relais de securite DUELCO"
                    }
                },
                "20": {
                    "Module d'occasion Relais de securite ~ G2C20 ~ 001399": {
                        "id": "201904110016",
                        "barcode": "001399",
                        "place": "G2C20",
                        "designation": "Module d'occasion Relais de securite"
                    }
                },
                "21": {
                    "Arret d'urgence a cable SCHNEIDER ~ G2C21 ~ 001733": {
                        "id": "201912200005",
                        "barcode": "001733",
                        "place": "G2C21",
                        "designation": "Arret d'urgence a cable SCHNEIDER"
                    }
                },
                "22": {
                    "Aimant de securite PILZ ~ G2C22 ~ 001402": {
                        "id": "201904110019",
                        "barcode": "001402",
                        "place": "G2C22",
                        "designation": "Aimant de securite PILZ"
                    }
                },
                "23": {
                    "Gache de securite SCHNEIDER xcste5512 ~ G2C23 ~ 001400": {
                        "id": "201904110017",
                        "barcode": "001400",
                        "place": "G2C23",
                        "designation": "Gache de securite SCHNEIDER xcste5512"
                    }
                },
                "24": {
                    "Aimant de securite SICK ~ G2C24 ~ 001403": {
                        "id": "201904110020",
                        "barcode": "001403",
                        "place": "G2C24",
                        "designation": "Aimant de securite SICK"
                    },
                    "Securite electrique SICK avec son aimant ~ G2C24 ~ 002534": {
                        "id": "202401040005",
                        "barcode": "002534",
                        "place": "G2C24",
                        "designation": "Securite electrique SICK avec son aimant"
                    }
                },
                "25": {
                    "Detecteur de gaz OLDAM ~ G2C25 ~ 001993": {
                        "id": "202107280009",
                        "barcode": "001993",
                        "place": "G2C25",
                        "designation": "Detecteur de gaz OLDAM"
                    }
                },
                "26": {
                    "Interverrouillage porte ~ G2C26 ~ 001404": {
                        "id": "201904110021",
                        "barcode": "001404",
                        "place": "G2C26",
                        "designation": "Interverrouillage porte"
                    }
                },
                "27": {
                    "Cellule magnétique TURCK ~ G2C27 ~ 002402": {
                        "id": "202307130001",
                        "barcode": "002402",
                        "place": "G2C27",
                        "designation": "Cellule magnétique TURCK"
                    }
                },
                "01": {
                    "Sécurité de porte SCHNEIDER ~ G2C01 ~ 001379": {
                        "id": "201904100045",
                        "barcode": "001379",
                        "place": "G2C01",
                        "designation": "Sécurité de porte SCHNEIDER"
                    }
                },
                "02": {
                    "Sécurité de porte SCHNEIDER ~ G2C02 ~ 001380": {
                        "id": "201904100046",
                        "barcode": "001380",
                        "place": "G2C02",
                        "designation": "Sécurité de porte SCHNEIDER"
                    }
                },
                "03": {
                    "Sécurité de porte SCHNEIDER ~ G2C03 ~ 001381": {
                        "id": "201904100047",
                        "barcode": "001381",
                        "place": "G2C03",
                        "designation": "Sécurité de porte SCHNEIDER"
                    }
                },
                "04": {
                    "Sécurité de porte SCHNEIDER ~ G2C04 ~ 001382": {
                        "id": "201904100048",
                        "barcode": "001382",
                        "place": "G2C04",
                        "designation": "Sécurité de porte SCHNEIDER"
                    }
                },
                "05": {
                    "Centreur de porte SCHNEIDER ~ G2C05 ~ 001383": {
                        "id": "201904100049",
                        "barcode": "001383",
                        "place": "G2C05",
                        "designation": "Centreur de porte SCHNEIDER"
                    }
                },
                "06": {
                    "Sécurité de porte SCHNEIDER ~ G2C06 ~ 001384": {
                        "id": "201904110001",
                        "barcode": "001384",
                        "place": "G2C06",
                        "designation": "Sécurité de porte SCHNEIDER"
                    }
                },
                "07": {
                    "Sécurité de porte SCHNEIDER ~ G2C07 ~ 001385": {
                        "id": "201904110002",
                        "barcode": "001385",
                        "place": "G2C07",
                        "designation": "Sécurité de porte SCHNEIDER"
                    }
                },
                "08": {
                    "Sécurité de porte SCHNEIDER ~ G2C08 ~ 001386": {
                        "id": "201904110003",
                        "barcode": "001386",
                        "place": "G2C08",
                        "designation": "Sécurité de porte SCHNEIDER"
                    }
                },
                "09": {
                    "Cle de porte SCHNEIDER ~ G2C09 ~ 001387": {
                        "id": "201904110004",
                        "barcode": "001387",
                        "place": "G2C09",
                        "designation": "Cle de porte SCHNEIDER"
                    }
                }
            },
            "D": {
                "10": {
                    "ARU SCHNEIDER tourner pour rearmer ~ G2D10 ~ 001360": {
                        "id": "201904100026",
                        "barcode": "001360",
                        "place": "G2D10",
                        "designation": "ARU SCHNEIDER tourner pour rearmer"
                    }
                },
                "11": {
                    "ARU SCHNEIDER sans tourner pour rearmer ~ G2D11 ~ 001984": {
                        "id": "202107270006",
                        "barcode": "001984",
                        "place": "G2D11",
                        "designation": "ARU SCHNEIDER sans tourner pour rearmer"
                    }
                },
                "12": {
                    "Coup de poing noir SCHNEIDER sans accrochage pour embase ~ G2D12 ~ 001362": {
                        "id": "201904100028",
                        "barcode": "001362",
                        "place": "G2D12",
                        "designation": "Coup de poing noir SCHNEIDER sans accrochage pour embase"
                    },
                    "Coup de poing jaune SCHNEIDER sans accrochage pour embase ~ G2D12 ~ 002096": {
                        "id": "202111080003",
                        "barcode": "002096",
                        "place": "G2D12",
                        "designation": "Coup de poing jaune SCHNEIDER sans accrochage pour embase"
                    },
                    "Coup de poing noir SCHNEIDER avec accrochage a visser ~ G2D12 ~ 002604": {
                        "id": "202409040001",
                        "barcode": "002604",
                        "place": "G2D12",
                        "designation": "Coup de poing noir SCHNEIDER avec accrochage a visser"
                    }
                },
                "13": {
                    "Tete poussoir rouge SCHNEIDER ~ G2D13 ~ 001363": {
                        "id": "201904100029",
                        "barcode": "001363",
                        "place": "G2D13",
                        "designation": "Tete poussoir rouge SCHNEIDER"
                    }
                },
                "14": {
                    "Tete poussoir vert SCHNEIDER ~ G2D14 ~ 001364": {
                        "id": "201904100030",
                        "barcode": "001364",
                        "place": "G2D14",
                        "designation": "Tete poussoir vert SCHNEIDER"
                    }
                },
                "15": {
                    "Bouton noir affl SCHNEIDER ~ G2D15 ~ 001365": {
                        "id": "201904100031",
                        "barcode": "001365",
                        "place": "G2D15",
                        "designation": "Bouton noir affl SCHNEIDER"
                    }
                },
                "16": {
                    "Bouton double touche M/A SCHNEIDER ~ G2D16 ~ 001366": {
                        "id": "201904100032",
                        "barcode": "001366",
                        "place": "G2D16",
                        "designation": "Bouton double touche M/A SCHNEIDER"
                    }
                },
                "17": {
                    "Corps SCHNEIDER ~ G2D17 ~ 001371": {
                        "id": "201904100037",
                        "barcode": "001371",
                        "place": "G2D17",
                        "designation": "Corps SCHNEIDER"
                    }
                },
                "18": {
                    "Led SCHNEIDER pour verrine 230V ~ G2D18 ~ 001368": {
                        "id": "201904100034",
                        "barcode": "001368",
                        "place": "G2D18",
                        "designation": "Led SCHNEIDER pour verrine 230V"
                    }
                },
                "19": {
                    "Led SCHNEIDER pour verrine 24Vac/dc ~ G2D19 ~ 002097": {
                        "id": "202111080004",
                        "barcode": "002097",
                        "place": "G2D19",
                        "designation": "Led SCHNEIDER pour verrine 24Vac/dc"
                    }
                },
                "20": {
                    "Tete de voyant SCHNEIDER ~ G2D20 ~ 001370": {
                        "id": "201904100036",
                        "barcode": "001370",
                        "place": "G2D20",
                        "designation": "Tete de voyant SCHNEIDER"
                    }
                },
                "21": {
                    "Led rouge SCHNEIDER ~ G2D21 ~ 001374": {
                        "id": "201904100040",
                        "barcode": "001374",
                        "place": "G2D21",
                        "designation": "Led rouge SCHNEIDER"
                    }
                },
                "22": {
                    "Led bleue SCHNEIDER ~ G2D22 ~ 001372": {
                        "id": "201904100038",
                        "barcode": "001372",
                        "place": "G2D22",
                        "designation": "Led bleue SCHNEIDER"
                    }
                },
                "23": {
                    "Led verte SCHNEIDER ~ G2D23 ~ 001373": {
                        "id": "201904100039",
                        "barcode": "001373",
                        "place": "G2D23",
                        "designation": "Led verte SCHNEIDER"
                    }
                },
                "24": {
                    "Led blanche SCHNEIDER ~ G2D24 ~ 001375": {
                        "id": "201904100041",
                        "barcode": "001375",
                        "place": "G2D24",
                        "designation": "Led blanche SCHNEIDER"
                    }
                },
                "25": {
                    "Capochon rouge et noir ~ G2D25 ~ 001367": {
                        "id": "201904100033",
                        "barcode": "001367",
                        "place": "G2D25",
                        "designation": "Capochon rouge et noir"
                    }
                },
                "26": {
                    "Bouton poussoir ~ G2D26 ~ 001376": {
                        "id": "201904100042",
                        "barcode": "001376",
                        "place": "G2D26",
                        "designation": "Bouton poussoir"
                    }
                },
                "27": {
                    "Contact NC pour boite SCHNEIDER ~ G2D27 ~ 001377": {
                        "id": "201904100043",
                        "barcode": "001377",
                        "place": "G2D27",
                        "designation": "Contact NC pour boite SCHNEIDER"
                    }
                },
                "28": {
                    "Contact NO pour boite SCHNEIDER ~ G2D28 ~ 001378": {
                        "id": "201904100044",
                        "barcode": "001378",
                        "place": "G2D28",
                        "designation": "Contact NO pour boite SCHNEIDER"
                    }
                },
                "29": {
                    "Led verte SCHNEIDER 230V ~ G2D29 ~ 002331": {
                        "id": "202302090001",
                        "barcode": "002331",
                        "place": "G2D29",
                        "designation": "Led verte SCHNEIDER 230V"
                    }
                },
                "30": {
                    "Bouton tournant 3 positions a rappel SCHNEIDER ~ G2D30 ~ 002473": {
                        "id": "202309120002",
                        "barcode": "002473",
                        "place": "G2D30",
                        "designation": "Bouton tournant 3 positions a rappel SCHNEIDER"
                    }
                },
                "31": {
                    "Bouton tournant 2 positions a rappel SCHNEIDER ~ G2D31 ~ 002474": {
                        "id": "202309120003",
                        "barcode": "002474",
                        "place": "G2D31",
                        "designation": "Bouton tournant 2 positions a rappel SCHNEIDER"
                    }
                },
                "32": {
                    "Bouton tournant 2 positions fixes SCHNEIDER ~ G2D32 ~ 002475": {
                        "id": "202309120004",
                        "barcode": "002475",
                        "place": "G2D32",
                        "designation": "Bouton tournant 2 positions fixes SCHNEIDER"
                    }
                },
                "33": {
                    "Bouton tournant noir a rappel a clé 455 SCHNEIDER ~ G2D33 ~ 002175": {
                        "id": "202201070001",
                        "barcode": "002175",
                        "place": "G2D33",
                        "designation": "Bouton tournant noir a rappel a clé 455 SCHNEIDER"
                    }
                },
                "34": {
                    "Bouton tournant noir 2 positions pour boite a clé 455 SCHNEIDER ~ G2D34 ~ 002645": {
                        "id": "202503070001",
                        "barcode": "002645",
                        "place": "G2D34",
                        "designation": "Bouton tournant noir 2 positions pour boite a clé 455 SCHNEIDER"
                    },
                    "Coup de poing noir SCHNEIDER sans accrochage a visser ~ G2D34 ~ 002678": {
                        "id": "202504110001",
                        "barcode": "002678",
                        "place": "G2D34",
                        "designation": "Coup de poing noir SCHNEIDER sans accrochage a visser"
                    },
                    "Coup de poing jaune SCHNEIDER sans accrochage a visser ~ G2D34 ~ 002679": {
                        "id": "202504110002",
                        "barcode": "002679",
                        "place": "G2D34",
                        "designation": "Coup de poing jaune SCHNEIDER sans accrochage a visser"
                    }
                },
                "01": {
                    "Contact NO SCHNEIDER ~ G2D01 ~ 001351": {
                        "id": "201904100017",
                        "barcode": "001351",
                        "place": "G2D01",
                        "designation": "Contact NO SCHNEIDER"
                    }
                },
                "02": {
                    "Contact NC SCHNEIDER ~ G2D02 ~ 001352": {
                        "id": "201904100018",
                        "barcode": "001352",
                        "place": "G2D02",
                        "designation": "Contact NC SCHNEIDER"
                    }
                },
                "03": {
                    "Corps de contact SCHNEIDER ~ G2D03 ~ 001353": {
                        "id": "201904100019",
                        "barcode": "001353",
                        "place": "G2D03",
                        "designation": "Corps de contact SCHNEIDER"
                    }
                },
                "04": {
                    "Bouton tournant 2 positions a cle 421E SCHNEIDER ~ G2D04 ~ 001354": {
                        "id": "201904100020",
                        "barcode": "001354",
                        "place": "G2D04",
                        "designation": "Bouton tournant 2 positions a cle 421E SCHNEIDER"
                    }
                },
                "05": {
                    "Bouton tournant 2 positions a cle 455 SCHNEIDER ~ G2D05 ~ 001355": {
                        "id": "201904100021",
                        "barcode": "001355",
                        "place": "G2D05",
                        "designation": "Bouton tournant 2 positions a cle 455 SCHNEIDER"
                    }
                },
                "06": {
                    "Bouton tournant 3 positions SCHNEIDER ~ G2D06 ~ 001357": {
                        "id": "201904100023",
                        "barcode": "001357",
                        "place": "G2D06",
                        "designation": "Bouton tournant 3 positions SCHNEIDER"
                    },
                    "Bouton tournant 3 positions a cle 421 SCHNEIDER ~ G2D06 ~ 002095": {
                        "id": "202111080002",
                        "barcode": "002095",
                        "place": "G2D06",
                        "designation": "Bouton tournant 3 positions a cle 421 SCHNEIDER"
                    }
                },
                "07": {
                    "Bouton tournant 2 positions a cle 421 SCHNEIDER ~ G2D07 ~ 001358": {
                        "id": "201904100024",
                        "barcode": "001358",
                        "place": "G2D07",
                        "designation": "Bouton tournant 2 positions a cle 421 SCHNEIDER"
                    }
                },
                "08": {
                    "Manipulateur SCHNEIDER ~ G2D08 ~ 001359": {
                        "id": "201904100025",
                        "barcode": "001359",
                        "place": "G2D08",
                        "designation": "Manipulateur SCHNEIDER"
                    }
                },
                "09": {
                    "ARU à clé SCHNEIDER ~ G2D09 ~ 001361": {
                        "id": "201904100027",
                        "barcode": "001361",
                        "place": "G2D09",
                        "designation": "ARU à clé SCHNEIDER"
                    }
                }
            },
            "E": {
                "10": {
                    "Voyant MOELLER ~ G2E10 ~ 001332": {
                        "id": "201904090024",
                        "barcode": "001332",
                        "place": "G2E10",
                        "designation": "Voyant MOELLER"
                    }
                },
                "11": {
                    "Selecteur MOELLER ~ G2E11 ~ 001333": {
                        "id": "201904090025",
                        "barcode": "001333",
                        "place": "G2E11",
                        "designation": "Selecteur MOELLER"
                    }
                },
                "12": {
                    "Fixation MOELLER ~ G2E12 ~ 001334": {
                        "id": "201904090026",
                        "barcode": "001334",
                        "place": "G2E12",
                        "designation": "Fixation MOELLER"
                    }
                },
                "13": {
                    "Selecteur KRAUS NAIMER 11 positions ~ G2E13 ~ 001335": {
                        "id": "201904100001",
                        "barcode": "001335",
                        "place": "G2E13",
                        "designation": "Selecteur KRAUS NAIMER 11 positions"
                    }
                },
                "14": {
                    "Divers commande électrique ~ G2E14 ~ 001342": {
                        "id": "201904100008",
                        "barcode": "001342",
                        "place": "G2E14",
                        "designation": "Divers commande électrique"
                    }
                },
                "15": {
                    "Selecteur à clé ALLEN BRADLEY ~ G2E15 ~ 001336": {
                        "id": "201904100002",
                        "barcode": "001336",
                        "place": "G2E15",
                        "designation": "Selecteur à clé ALLEN BRADLEY"
                    }
                },
                "16": {
                    "Bride ALLEN BRADLEY ~ G2E16 ~ 001338": {
                        "id": "201904100004",
                        "barcode": "001338",
                        "place": "G2E16",
                        "designation": "Bride ALLEN BRADLEY"
                    }
                },
                "17": {
                    "Contact NO ALLEN BRADLEY ~ G2E17 ~ 001339": {
                        "id": "201904100005",
                        "barcode": "001339",
                        "place": "G2E17",
                        "designation": "Contact NO ALLEN BRADLEY"
                    }
                },
                "18": {
                    "Contact NC ALLEN BRADLEY ~ G2E18 ~ 001341": {
                        "id": "201904100007",
                        "barcode": "001341",
                        "place": "G2E18",
                        "designation": "Contact NC ALLEN BRADLEY"
                    }
                },
                "19": {
                    "Fixation ALLEN BRADLEY ~ G2E19 ~ 001340": {
                        "id": "201904100006",
                        "barcode": "001340",
                        "place": "G2E19",
                        "designation": "Fixation ALLEN BRADLEY"
                    }
                },
                "20": {
                    "Voyant led diamètre 16mm rouge Etagere de bippage ~ G2E20 ~ 002245": {
                        "id": "202208180001",
                        "barcode": "002245",
                        "place": "G2E20",
                        "designation": "Voyant led diamètre 16mm rouge Etagere de bippage"
                    }
                },
                "21": {
                    "MINUTERIE SIEMENS SIMIREL ~ G2E21 ~ 001345": {
                        "id": "201904100011",
                        "barcode": "001345",
                        "place": "G2E21",
                        "designation": "MINUTERIE SIEMENS SIMIREL"
                    },
                    "Temporisateur SCHNEIDER RE7CL ~ G2E21 ~ 002394": {
                        "id": "202306280004",
                        "barcode": "002394",
                        "place": "G2E21",
                        "designation": "Temporisateur SCHNEIDER RE7CL"
                    }
                },
                "22": {
                    "Compteur tachy tempo 48X48 DELTA 220v ~ G2E22 ~ 001344": {
                        "id": "201904100010",
                        "barcode": "001344",
                        "place": "G2E22",
                        "designation": "Compteur tachy tempo 48X48 DELTA 220v"
                    }
                },
                "23": {
                    "Relais MERLIN GERIN ~ G2E23 ~ 001347": {
                        "id": "201904100013",
                        "barcode": "001347",
                        "place": "G2E23",
                        "designation": "Relais MERLIN GERIN"
                    }
                },
                "24": {
                    "MINUTERIE HAGER ~ G2E24 ~ 001346": {
                        "id": "201904100012",
                        "barcode": "001346",
                        "place": "G2E24",
                        "designation": "MINUTERIE HAGER"
                    }
                },
                "25": {
                    "Temporisateur MERLIN GERIN ~ G2E25 ~ 001348": {
                        "id": "201904100014",
                        "barcode": "001348",
                        "place": "G2E25",
                        "designation": "Temporisateur MERLIN GERIN"
                    }
                },
                "26": {
                    "Temporisateur CROUZET MAR1 24V DC 24 240 VAC ~ G2E26 ~ 001350": {
                        "id": "201904100016",
                        "barcode": "001350",
                        "place": "G2E26",
                        "designation": "Temporisateur CROUZET MAR1 24V DC 24 240 VAC"
                    }
                },
                "27": {
                    "Temporisateur CROUZET TAR1 24V DC 24 240 VAC ~ G2E27 ~ 001349": {
                        "id": "201904100015",
                        "barcode": "001349",
                        "place": "G2E27",
                        "designation": "Temporisateur CROUZET TAR1 24V DC 24 240 VAC"
                    }
                },
                "28": {
                    "Temporisateur CROUZET MUR3 12V 240V DC/AC ~ G2E28 ~ 001853": {
                        "id": "202007300001",
                        "barcode": "001853",
                        "place": "G2E28",
                        "designation": "Temporisateur CROUZET MUR3 12V 240V DC/AC"
                    }
                },
                "29": {
                    "Minuterie CARLO CAMOZZI ~ G2E29 ~ 001343": {
                        "id": "201904100009",
                        "barcode": "001343",
                        "place": "G2E29",
                        "designation": "Minuterie CARLO CAMOZZI"
                    }
                },
                "01": {
                    "ARU à cle LEGRAND ~ G2E01 ~ 001323": {
                        "id": "201904090015",
                        "barcode": "001323",
                        "place": "G2E01",
                        "designation": "ARU à cle LEGRAND"
                    }
                },
                "02": {
                    "Voyant led 24V vert LEGRAND ~ G2E02 ~ 001324": {
                        "id": "201904090016",
                        "barcode": "001324",
                        "place": "G2E02",
                        "designation": "Voyant led 24V vert LEGRAND"
                    }
                },
                "03": {
                    "Contact NO LEGRAND ~ G2E03 ~ 001325": {
                        "id": "201904090017",
                        "barcode": "001325",
                        "place": "G2E03",
                        "designation": "Contact NO LEGRAND"
                    }
                },
                "04": {
                    "Contact NC LEGRAND ~ G2E04 ~ 001326": {
                        "id": "201904090018",
                        "barcode": "001326",
                        "place": "G2E04",
                        "designation": "Contact NC LEGRAND"
                    }
                },
                "05": {
                    "Bouton tournant 2 positions MOELLER ~ G2E05 ~ 001331": {
                        "id": "201904090023",
                        "barcode": "001331",
                        "place": "G2E05",
                        "designation": "Bouton tournant 2 positions MOELLER"
                    }
                },
                "06": {
                    "BP rouge MOELLER ~ G2E06 ~ 001328": {
                        "id": "201904090020",
                        "barcode": "001328",
                        "place": "G2E06",
                        "designation": "BP rouge MOELLER"
                    }
                },
                "07": {
                    "BP blanc MOELLER ~ G2E07 ~ 001329": {
                        "id": "201904090021",
                        "barcode": "001329",
                        "place": "G2E07",
                        "designation": "BP blanc MOELLER"
                    }
                },
                "08": {
                    "BP noir MOELLER ~ G2E08 ~ 001330": {
                        "id": "201904090022",
                        "barcode": "001330",
                        "place": "G2E08",
                        "designation": "BP noir MOELLER"
                    }
                },
                "09": {
                    "Contact NO MOELLER ~ G2E09 ~ 002098": {
                        "id": "202111080005",
                        "barcode": "002098",
                        "place": "G2E09",
                        "designation": "Contact NO MOELLER"
                    },
                    "Contact NC MOELLER ~ G2E09 ~ 002547": {
                        "id": "202402090001",
                        "barcode": "002547",
                        "place": "G2E09",
                        "designation": "Contact NC MOELLER"
                    }
                }
            }
        },
        "3 Colonne": {
            "A": {
                "Disjoncteur de tête ~ G3A ~ 001603": {
                    "id": "201904190023",
                    "barcode": "001603",
                    "place": "G3A",
                    "designation": "Disjoncteur de tête"
                },
                "Declencheur de disjoncteur ~ G3A ~ 001604": {
                    "id": "201904190024",
                    "barcode": "001604",
                    "place": "G3A",
                    "designation": "Declencheur de disjoncteur"
                },
                "01": {
                    "Bloc Autonome éclairage de sécurité ~ G3A01 ~ 001901": {
                        "id": "202101070003",
                        "barcode": "001901",
                        "place": "G3A01",
                        "designation": "Bloc Autonome éclairage de sécurité"
                    }
                },
                "02": {
                    "Bloc Autonome éclairage de sécurité ~ G3A02 ~ 001902": {
                        "id": "202101070004",
                        "barcode": "001902",
                        "place": "G3A02",
                        "designation": "Bloc Autonome éclairage de sécurité"
                    }
                }
            },
            "B": {
                "10": {
                    "Disjoncteur X plus S2/1 ~ G3B10 ~ 002225": {
                        "id": "202207010004",
                        "barcode": "002225",
                        "place": "G3B10",
                        "designation": "Disjoncteur X plus S2/1"
                    }
                },
                "11": {
                    "Disjoncteur X plus S4/1 ~ G3B11 ~ 002226": {
                        "id": "202207010005",
                        "barcode": "002226",
                        "place": "G3B11",
                        "designation": "Disjoncteur X plus S4/1"
                    }
                },
                "12": {
                    "Disjoncteur X plus S10/1 ~ G3B12 ~ 002228": {
                        "id": "202207010006",
                        "barcode": "002228",
                        "place": "G3B12",
                        "designation": "Disjoncteur X plus S10/1"
                    }
                },
                "13": {
                    "Disjoncteur X plusB16/1 ~ G3B13 ~ 002227": {
                        "id": "202207010007",
                        "barcode": "002227",
                        "place": "G3B13",
                        "designation": "Disjoncteur X plusB16/1"
                    }
                },
                "14": {
                    "Disjoncteur SCHNEIDER C10 ~ G3B14 ~ 002277": {
                        "id": "202210200001",
                        "barcode": "002277",
                        "place": "G3B14",
                        "designation": "Disjoncteur SCHNEIDER C10"
                    }
                },
                "15": {
                    "Prise double plexo gris 2P+T ~ G3B15 ~ 001928": {
                        "id": "202103220001",
                        "barcode": "001928",
                        "place": "G3B15",
                        "designation": "Prise double plexo gris 2P+T"
                    },
                    "Prise simple plexo gris 2P+T ~ G3B15 ~ 002223": {
                        "id": "202207010001",
                        "barcode": "002223",
                        "place": "G3B15",
                        "designation": "Prise simple plexo gris 2P+T"
                    }
                },
                "16": {
                    "Triplette électrique ~ G3B16 ~ 001673": {
                        "id": "201905130002",
                        "barcode": "001673",
                        "place": "G3B16",
                        "designation": "Triplette électrique"
                    }
                },
                "01": {
                    "Disjoncteur MERLIN GERIN c 16 ~ G3B01 ~ 001516": {
                        "id": "201904160024",
                        "barcode": "001516",
                        "place": "G3B01",
                        "designation": "Disjoncteur MERLIN GERIN c 16"
                    }
                },
                "02": {
                    "Disjoncteur MERLIN GERIN c 20 ~ G3B02 ~ 001514": {
                        "id": "201904160022",
                        "barcode": "001514",
                        "place": "G3B02",
                        "designation": "Disjoncteur MERLIN GERIN c 20"
                    }
                },
                "03": {
                    "Bloc differentiel vigi C60 MERLIN GERIN ~ G3B03 ~ 001517": {
                        "id": "201904160025",
                        "barcode": "001517",
                        "place": "G3B03",
                        "designation": "Bloc differentiel vigi C60 MERLIN GERIN"
                    }
                },
                "04": {
                    "Disjoncteur C4 ~ G3B04 ~ 001520": {
                        "id": "201904160028",
                        "barcode": "001520",
                        "place": "G3B04",
                        "designation": "Disjoncteur C4"
                    },
                    "Disjoncteur B4 ~ G3B04 ~ 002629": {
                        "id": "202412230001",
                        "barcode": "002629",
                        "place": "G3B04",
                        "designation": "Disjoncteur B4"
                    }
                },
                "05": {
                    "Disjoncteur HAGER D16 ~ G3B05 ~ 001518": {
                        "id": "201904160026",
                        "barcode": "001518",
                        "place": "G3B05",
                        "designation": "Disjoncteur HAGER D16"
                    }
                },
                "06": {
                    "Disjoncteur C1 dx3 1p+ng ~ G3B06 ~ 001519": {
                        "id": "201904160027",
                        "barcode": "001519",
                        "place": "G3B06",
                        "designation": "Disjoncteur C1 dx3 1p+ng"
                    },
                    "Disjoncteur C2 ~ G3B06 ~ 002532": {
                        "id": "202401040003",
                        "barcode": "002532",
                        "place": "G3B06",
                        "designation": "Disjoncteur C2"
                    }
                },
                "07": {
                    "Disjoncteur C6 ~ G3B07 ~ 002091": {
                        "id": "202111040004",
                        "barcode": "002091",
                        "place": "G3B07",
                        "designation": "Disjoncteur C6"
                    }
                },
                "08": {
                    "Disjoncteur C20 LEGRAND ~ G3B08 ~ 001521": {
                        "id": "201904160029",
                        "barcode": "001521",
                        "place": "G3B08",
                        "designation": "Disjoncteur C20 LEGRAND"
                    },
                    "Disjoncteur differentiel 300mA Acti9 Vigi iC60 ~ G3B08 ~ 002586": {
                        "id": "202406140001",
                        "barcode": "002586",
                        "place": "G3B08",
                        "designation": "Disjoncteur differentiel 300mA Acti9 Vigi iC60"
                    }
                },
                "09": {
                    "Disjoncteur SIEMENS sirius ~ G3B09 ~ 001522": {
                        "id": "201904160030",
                        "barcode": "001522",
                        "place": "G3B09",
                        "designation": "Disjoncteur SIEMENS sirius"
                    }
                }
            },
            "C": {
                "10": {
                    "Détecteur de mouvement Luxomat encastrable ~ G3C10 ~ 001681": {
                        "id": "201905130010",
                        "barcode": "001681",
                        "place": "G3C10",
                        "designation": "Détecteur de mouvement Luxomat encastrable"
                    },
                    "Détecteur de mouvement legrand ~ G3C10 ~ 001746": {
                        "id": "202002260001",
                        "barcode": "001746",
                        "place": "G3C10",
                        "designation": "Détecteur de mouvement legrand"
                    }
                },
                "11": {
                    "Horloge Hager éclairage / portail ~ G3C11 ~ 001860": {
                        "id": "202008240003",
                        "barcode": "001860",
                        "place": "G3C11",
                        "designation": "Horloge Hager éclairage / portail"
                    }
                },
                "12": {
                    "Détecteur de mouvement theben ~ G3C12 ~ 001680": {
                        "id": "201905130009",
                        "barcode": "001680",
                        "place": "G3C12",
                        "designation": "Détecteur de mouvement theben"
                    },
                    "Détecteur de mouvement luxomat ~ G3C12 ~ 001700": {
                        "id": "201908010001",
                        "barcode": "001700",
                        "place": "G3C12",
                        "designation": "Détecteur de mouvement luxomat"
                    }
                },
                "13": {
                    "Thermostat ambiance thera 6 radiateur ~ G3C13 ~ 002067": {
                        "id": "202110270004",
                        "barcode": "002067",
                        "place": "G3C13",
                        "designation": "Thermostat ambiance thera 6 radiateur"
                    }
                },
                "14": {
                    "Thermostat d'ambiance ~ G3C14 ~ 001665": {
                        "id": "201905070020",
                        "barcode": "001665",
                        "place": "G3C14",
                        "designation": "Thermostat d'ambiance"
                    }
                },
                "15": {
                    "Servo moteur thermique 230V ac pour climatiseur ~ G3C15 ~ 001862": {
                        "id": "202008250001",
                        "barcode": "001862",
                        "place": "G3C15",
                        "designation": "Servo moteur thermique 230V ac pour climatiseur"
                    }
                },
                "16": {
                    "Prise Hypra 3P+T ~ G3C16 ~ 002205": {
                        "id": "202203090002",
                        "barcode": "002205",
                        "place": "G3C16",
                        "designation": "Prise Hypra 3P+T"
                    }
                },
                "17": {
                    "Attache tube IRO + bouchon jaune ~ G3C17 ~ 002118": {
                        "id": "202111120008",
                        "barcode": "002118",
                        "place": "G3C17",
                        "designation": "Attache tube IRO + bouchon jaune"
                    }
                },
                "18": {
                    "Résistance chauffante 55W pour armoire electrique ~ G3C18 ~ 002396": {
                        "id": "202307110001",
                        "barcode": "002396",
                        "place": "G3C18",
                        "designation": "Résistance chauffante 55W pour armoire electrique"
                    }
                },
                "19": {
                    "Prise RJ45 ~ G3C19 ~ 001666": {
                        "id": "201905100001",
                        "barcode": "001666",
                        "place": "G3C19",
                        "designation": "Prise RJ45"
                    }
                },
                "20": {
                    "Prise RJ45 ~ G3C20 ~ 001667": {
                        "id": "201905100002",
                        "barcode": "001667",
                        "place": "G3C20",
                        "designation": "Prise RJ45"
                    },
                    "Manchon Prise RJ45 ~ G3C20 ~ 001669": {
                        "id": "201905110002",
                        "barcode": "001669",
                        "place": "G3C20",
                        "designation": "Manchon Prise RJ45"
                    },
                    "Prise RJ45 ~ G3C20 ~ 001670": {
                        "id": "201905110003",
                        "barcode": "001670",
                        "place": "G3C20",
                        "designation": "Prise RJ45"
                    }
                },
                "01": {
                    "Bouton poussoir ~ G3C01 ~ 001656": {
                        "id": "201905070011",
                        "barcode": "001656",
                        "place": "G3C01",
                        "designation": "Bouton poussoir"
                    },
                    "Batibox a sceller ~ G3C01 ~ 002481": {
                        "id": "202309280001",
                        "barcode": "002481",
                        "place": "G3C01",
                        "designation": "Batibox a sceller"
                    },
                    "Prise Mosaic complete a encastrer ~ G3C01 ~ 002482": {
                        "id": "202309280002",
                        "barcode": "002482",
                        "place": "G3C01",
                        "designation": "Prise Mosaic complete a encastrer"
                    }
                },
                "02": {
                    "Prise armoire electrique ~ G3C02 ~ 001662": {
                        "id": "201905070017",
                        "barcode": "001662",
                        "place": "G3C02",
                        "designation": "Prise armoire electrique"
                    }
                },
                "03": {
                    "Prise encastrable ~ G3C03 ~ 001664": {
                        "id": "201905070019",
                        "barcode": "001664",
                        "place": "G3C03",
                        "designation": "Prise encastrable"
                    }
                },
                "04": {
                    "Prise moulée femelle ~ G3C04 ~ 001672": {
                        "id": "201905130001",
                        "barcode": "001672",
                        "place": "G3C04",
                        "designation": "Prise moulée femelle"
                    }
                },
                "05": {
                    "Prise moulée male 2p+T ~ G3C05 ~ 001671": {
                        "id": "201905110004",
                        "barcode": "001671",
                        "place": "G3C05",
                        "designation": "Prise moulée male 2p+T"
                    }
                },
                "06": {
                    "Support a vis ~ G3C06 ~ 001661": {
                        "id": "201905070016",
                        "barcode": "001661",
                        "place": "G3C06",
                        "designation": "Support a vis"
                    },
                    "Sortie de cable ~ G3C06 ~ 002116": {
                        "id": "202111120006",
                        "barcode": "002116",
                        "place": "G3C06",
                        "designation": "Sortie de cable"
                    },
                    "Enjoliveur mozaïc ~ G3C06 ~ 002117": {
                        "id": "202111120007",
                        "barcode": "002117",
                        "place": "G3C06",
                        "designation": "Enjoliveur mozaïc"
                    }
                },
                "07": {
                    "Télévariateur ~ G3C07 ~ 001674": {
                        "id": "201905130003",
                        "barcode": "001674",
                        "place": "G3C07",
                        "designation": "Télévariateur"
                    },
                    "Alimentation stabilisée 230 Vac 24 Vdc pour dalle eclairage couloir ~ G3C07 ~ 002627": {
                        "id": "202412190001",
                        "barcode": "002627",
                        "place": "G3C07",
                        "designation": "Alimentation stabilisée 230 Vac 24 Vdc pour dalle eclairage couloir"
                    }
                },
                "08": {
                    "Télérupteur ~ G3C08 ~ 001677": {
                        "id": "201905130006",
                        "barcode": "001677",
                        "place": "G3C08",
                        "designation": "Télérupteur"
                    },
                    "Contacteur SCHNEIDER 230v 20A ~ G3C08 ~ 002698": {
                        "id": "202510010004",
                        "barcode": "002698",
                        "place": "G3C08",
                        "designation": "Contacteur SCHNEIDER 230v 20A"
                    }
                },
                "09": {
                    "Boitier electronic éclrairage ~ G3C09 ~ 001678": {
                        "id": "201905130007",
                        "barcode": "001678",
                        "place": "G3C09",
                        "designation": "Boitier electronic éclrairage"
                    }
                }
            },
            "D": {
                "10": {
                    "Pile bouton pour le pied a coulisse ~ G3D10 ~ 002456": {
                        "id": "202308160003",
                        "barcode": "002456",
                        "place": "G3D10",
                        "designation": "Pile bouton pour le pied a coulisse"
                    }
                },
                "11": {
                    "Pile 4.5v ~ G3D11 ~ 002689": {
                        "id": "202506120001",
                        "barcode": "002689",
                        "place": "G3D11",
                        "designation": "Pile 4.5v"
                    }
                },
                "12": {
                    "Pile CR2430 pupitre bruleur calandre ~ G3D12 ~ 001267": {
                        "id": "201904050018",
                        "barcode": "001267",
                        "place": "G3D12",
                        "designation": "Pile CR2430 pupitre bruleur calandre"
                    }
                },
                "13": {
                    "Pile Lithium 3 Volts CR2025 ~ G3D13 ~ 001268": {
                        "id": "201904050019",
                        "barcode": "001268",
                        "place": "G3D13",
                        "designation": "Pile Lithium 3 Volts CR2025"
                    }
                },
                "14": {
                    "Pile Lithium 3 Volts CR1632 ~ G3D14 ~ 001269": {
                        "id": "201904050020",
                        "barcode": "001269",
                        "place": "G3D14",
                        "designation": "Pile Lithium 3 Volts CR1632"
                    }
                },
                "15": {
                    "Pile Lithium 3 Volts CR1220 ~ G3D15 ~ 001270": {
                        "id": "201904050021",
                        "barcode": "001270",
                        "place": "G3D15",
                        "designation": "Pile Lithium 3 Volts CR1220"
                    }
                },
                "16": {
                    "Pile Lithium 3 Volts CR2032 ~ G3D16 ~ 001271": {
                        "id": "201904050022",
                        "barcode": "001271",
                        "place": "G3D16",
                        "designation": "Pile Lithium 3 Volts CR2032"
                    }
                },
                "17": {
                    "Pile avec collerette Lithium 3 Volts CR2477N ~ G3D17 ~ 001272": {
                        "id": "201904050023",
                        "barcode": "001272",
                        "place": "G3D17",
                        "designation": "Pile avec collerette Lithium 3 Volts CR2477N"
                    }
                },
                "19": {
                    "Pile a souder Lithium 3Volts CR2450 ~ G3D19 ~ 001274": {
                        "id": "201904050025",
                        "barcode": "001274",
                        "place": "G3D19",
                        "designation": "Pile a souder Lithium 3Volts CR2450"
                    }
                },
                "20": {
                    "Pile Lithium 3 Volts CR2450N ~ G3D20 ~ 001275": {
                        "id": "201904050026",
                        "barcode": "001275",
                        "place": "G3D20",
                        "designation": "Pile Lithium 3 Volts CR2450N"
                    }
                },
                "21": {
                    "Batterie rechargeable (bloc secours) ni-cd 2s1p 2.4v 1.6Ah 3.84Wh ~ G3D21 ~ 001276": {
                        "id": "201904050027",
                        "barcode": "001276",
                        "place": "G3D21",
                        "designation": "Batterie rechargeable (bloc secours) ni-cd 2s1p 2.4v 1.6Ah 3.84Wh"
                    }
                },
                "22": {
                    "Pile Alcalines1,5 Volts LR03 AAA industriel ~ G3D22 ~ 001277": {
                        "id": "201904050028",
                        "barcode": "001277",
                        "place": "G3D22",
                        "designation": "Pile Alcalines1,5 Volts LR03 AAA industriel"
                    }
                },
                "23": {
                    "Pile Alcalines1,5 Volts LR6 AA industriel ~ G3D23 ~ 001278": {
                        "id": "201904050029",
                        "barcode": "001278",
                        "place": "G3D23",
                        "designation": "Pile Alcalines1,5 Volts LR6 AA industriel"
                    },
                    "Pile lithium AA 3,6 V LS14500 pile automate ~ G3D23 ~ 002503": {
                        "id": "202311220001",
                        "barcode": "002503",
                        "place": "G3D23",
                        "designation": "Pile lithium AA 3,6 V LS14500 pile automate"
                    }
                },
                "24": {
                    "Pile Alcalines A23 ~ G3D24 ~ 001279": {
                        "id": "201904050030",
                        "barcode": "001279",
                        "place": "G3D24",
                        "designation": "Pile Alcalines A23"
                    }
                },
                "25": {
                    "Pile Lithium 3 Volts CR2325 ~ G3D25 ~ 001280": {
                        "id": "201904050031",
                        "barcode": "001280",
                        "place": "G3D25",
                        "designation": "Pile Lithium 3 Volts CR2325"
                    }
                },
                "26": {
                    "Pile Lithium 3 Volts CR1/2AA ~ G3D26 ~ 001281": {
                        "id": "201904050032",
                        "barcode": "001281",
                        "place": "G3D26",
                        "designation": "Pile Lithium 3 Volts CR1/2AA"
                    }
                },
                "27": {
                    "Pile Lithium 3 Volts CR2 ~ G3D27 ~ 001282": {
                        "id": "201904050033",
                        "barcode": "001282",
                        "place": "G3D27",
                        "designation": "Pile Lithium 3 Volts CR2"
                    }
                },
                "28": {
                    "Pile Lithium 3 Volts CR AA ~ G3D28 ~ 001734": {
                        "id": "201912230001",
                        "barcode": "001734",
                        "place": "G3D28",
                        "designation": "Pile Lithium 3 Volts CR AA"
                    }
                },
                "29": {
                    "Pile Lithium 3 Volts BR2325 ~ G3D29 ~ 001284": {
                        "id": "201904050035",
                        "barcode": "001284",
                        "place": "G3D29",
                        "designation": "Pile Lithium 3 Volts BR2325"
                    }
                },
                "30": {
                    "Pile Lithium 3 Volts BR2330 ~ G3D30 ~ 001285": {
                        "id": "201904050036",
                        "barcode": "001285",
                        "place": "G3D30",
                        "designation": "Pile Lithium 3 Volts BR2330"
                    }
                },
                "31": {
                    "Pile Lithium 3 Volts BR1225A/BN ~ G3D31 ~ 001283": {
                        "id": "201904050034",
                        "barcode": "001283",
                        "place": "G3D31",
                        "designation": "Pile Lithium 3 Volts BR1225A/BN"
                    }
                },
                "32": {
                    "Pile rechargeable AAA 800mah ~ G3D32 ~ 001834": {
                        "id": "202006080001",
                        "barcode": "001834",
                        "place": "G3D32",
                        "designation": "Pile rechargeable AAA 800mah"
                    }
                },
                "33": {
                    "Pile 6lr61( 9V) ~ G3D33 ~ 001906": {
                        "id": "202101250002",
                        "barcode": "001906",
                        "place": "G3D33",
                        "designation": "Pile 6lr61( 9V)"
                    },
                    "Batterie VRLA 12V 2.3AH ~ G3D33 ~ 002581": {
                        "id": "202405280003",
                        "barcode": "002581",
                        "place": "G3D33",
                        "designation": "Batterie VRLA 12V 2.3AH"
                    }
                },
                "01": {
                    "Starter 4/22W ~ G3D01 ~ 001242": {
                        "id": "201904040014",
                        "barcode": "001242",
                        "place": "G3D01",
                        "designation": "Starter 4/22W"
                    }
                },
                "02": {
                    "Starter 4/65W ~ G3D02 ~ 001243": {
                        "id": "201904040015",
                        "barcode": "001243",
                        "place": "G3D02",
                        "designation": "Starter 4/65W"
                    }
                },
                "03": {
                    "Ampoules led 10w 840ml 4000K E27 ~ G3D03 ~ 001244": {
                        "id": "201904040016",
                        "barcode": "001244",
                        "place": "G3D03",
                        "designation": "Ampoules led 10w 840ml 4000K E27"
                    }
                },
                "04": {
                    "Ampoules à led E14 (2.3w soit 25w) 250 lumen ~ G3D04 ~ 001245": {
                        "id": "201904040017",
                        "barcode": "001245",
                        "place": "G3D04",
                        "designation": "Ampoules à led E14 (2.3w soit 25w) 250 lumen"
                    },
                    "Ampoules DULUX INTELL 7W/825 E14 ~ G3D04 ~ 001264": {
                        "id": "201904050015",
                        "barcode": "001264",
                        "place": "G3D04",
                        "designation": "Ampoules DULUX INTELL 7W/825 E14"
                    }
                },
                "05": {
                    "Ampoules led 1055ml E27 ~ G3D05 ~ 001246": {
                        "id": "201904040018",
                        "barcode": "001246",
                        "place": "G3D05",
                        "designation": "Ampoules led 1055ml E27"
                    }
                },
                "06": {
                    "Ampoules ABI AURORA E14 12V 15W ~ G3D06 ~ 001247": {
                        "id": "201904040019",
                        "barcode": "001247",
                        "place": "G3D06",
                        "designation": "Ampoules ABI AURORA E14 12V 15W"
                    }
                },
                "07": {
                    "Ampoules SA LYNX-S 9W/840 ~ G3D07 ~ 002249": {
                        "id": "202209090002",
                        "barcode": "002249",
                        "place": "G3D07",
                        "designation": "Ampoules SA LYNX-S 9W/840"
                    }
                },
                "07 Bis": {
                    "Ampoules PL-T 26w/840/4P G24Q-3 (différent PL-C) ~ G3D07BIS ~ 001248": {
                        "id": "201904040020",
                        "barcode": "001248",
                        "place": "G3D07BIS",
                        "designation": "Ampoules PL-T 26w/840/4P G24Q-3 (différent PL-C)"
                    }
                },
                "08": {
                    "Ampoules PL-C 18w/840/4P G24Q-2 ~ G3D08 ~ 001249": {
                        "id": "201904040021",
                        "barcode": "001249",
                        "place": "G3D08",
                        "designation": "Ampoules PL-C 18w/840/4P G24Q-2"
                    }
                },
                "08 Bis": {
                    "Ampoules PL-C 26w/840/4P G24Q-3 ~ G3D08BIS ~ 002737": {
                        "id": "202512240001",
                        "barcode": "002737",
                        "place": "G3D08BIS",
                        "designation": "Ampoules PL-C 26w/840/4P G24Q-3"
                    }
                },
                "09": {
                    "Ampoules 4.8V/0.75A ~ G3D09 ~ 001265": {
                        "id": "201904050016",
                        "barcode": "001265",
                        "place": "G3D09",
                        "designation": "Ampoules 4.8V/0.75A"
                    }
                }
            }
        }
    },
    "Rangée H": {
        "1 Colonne": {
            "A": {
                "10": {
                    "Boite Dérivation LEGRAND ronde diametre 60 ~ H1A10 ~ 001762": {
                        "id": "202003170004",
                        "barcode": "001762",
                        "place": "H1A10",
                        "designation": "Boite Dérivation LEGRAND ronde diametre 60"
                    },
                    "Boite Dérivation LEGRAND carré 100X100 ~ H1A10 ~ 001914": {
                        "id": "202102040004",
                        "barcode": "001914",
                        "place": "H1A10",
                        "designation": "Boite Dérivation LEGRAND carré 100X100"
                    },
                    "Boite Dérivation BLM carré 80X80 ~ H1A10 ~ 002088": {
                        "id": "202111040001",
                        "barcode": "002088",
                        "place": "H1A10",
                        "designation": "Boite Dérivation BLM carré 80X80"
                    }
                },
                "01": {
                    "Colliers blancs 100mm COLRING ~ H1A01 ~ 001287": {
                        "id": "201904050038",
                        "barcode": "001287",
                        "place": "H1A01",
                        "designation": "Colliers blancs 100mm COLRING"
                    }
                },
                "02": {
                    "Colliers blancs 200mm COLRING ~ H1A02 ~ 001286": {
                        "id": "201904050037",
                        "barcode": "001286",
                        "place": "H1A02",
                        "designation": "Colliers blancs 200mm COLRING"
                    }
                },
                "03": {
                    "Colliers blancs 360mm COLRING ~ H1A03 ~ 001288": {
                        "id": "201904050039",
                        "barcode": "001288",
                        "place": "H1A03",
                        "designation": "Colliers blancs 360mm COLRING"
                    }
                },
                "04": {
                    "Embase a coller de collier blanc COLRING ~ H1A04 ~ 001290": {
                        "id": "201904050041",
                        "barcode": "001290",
                        "place": "H1A04",
                        "designation": "Embase a coller de collier blanc COLRING"
                    }
                },
                "05": {
                    "Embase a cheville pour collier noir ~ H1A05 ~ 001289": {
                        "id": "201904050040",
                        "barcode": "001289",
                        "place": "H1A05",
                        "designation": "Embase a cheville pour collier noir"
                    }
                },
                "06": {
                    "Colliers COLSON noir 180 mm ~ H1A06 ~ 002173": {
                        "id": "202112200001",
                        "barcode": "002173",
                        "place": "H1A06",
                        "designation": "Colliers COLSON noir 180 mm"
                    }
                },
                "07": {
                    "Colliers COLSON noir 265 mm ~ H1A07 ~ 001291": {
                        "id": "201904050042",
                        "barcode": "001291",
                        "place": "H1A07",
                        "designation": "Colliers COLSON noir 265 mm"
                    }
                },
                "08": {
                    "Colliers COLSON noir 357 mm ~ H1A08 ~ 001292": {
                        "id": "201904050043",
                        "barcode": "001292",
                        "place": "H1A08",
                        "designation": "Colliers COLSON noir 357 mm"
                    }
                },
                "09": {
                    "Colliers COLSON noir 498 mm ~ H1A09 ~ 001293": {
                        "id": "201904050044",
                        "barcode": "001293",
                        "place": "H1A09",
                        "designation": "Colliers COLSON noir 498 mm"
                    }
                }
            },
            "B": {
                "10": {
                    "Entretoise, rondelle graphite et acier ~ H1B10 ~ 000821": {
                        "id": "201903140046",
                        "barcode": "000821",
                        "place": "H1B10",
                        "designation": "Entretoise, rondelle graphite et acier"
                    },
                    "Commutateur de sécurité ~ H1B10 ~ 000822": {
                        "id": "201903140047",
                        "barcode": "000822",
                        "place": "H1B10",
                        "designation": "Commutateur de sécurité"
                    }
                },
                "11": {
                    "Joint elliptique de chaudière vapeur trou d'homme 320 graphités ~ H1B11 ~ 002511": {
                        "id": "202312050001",
                        "barcode": "002511",
                        "place": "H1B11",
                        "designation": "Joint elliptique de chaudière vapeur trou d'homme 320 graphités"
                    },
                    "Joint elliptique de chaudière vapeur trou d'homme 420 graphités ~ H1B11 ~ 002512": {
                        "id": "202312050002",
                        "barcode": "002512",
                        "place": "H1B11",
                        "designation": "Joint elliptique de chaudière vapeur trou d'homme 420 graphités"
                    }
                },
                "02": {
                    "Sonde de température ~ H1B02 ~ 000815": {
                        "id": "201903140040",
                        "barcode": "000815",
                        "place": "H1B02",
                        "designation": "Sonde de température"
                    }
                },
                "03": {
                    "Controleur de débit à palette ~ H1B03 ~ 000814": {
                        "id": "201903140039",
                        "barcode": "000814",
                        "place": "H1B03",
                        "designation": "Controleur de débit à palette"
                    }
                },
                "04": {
                    "Thermomètre 297 D=80 PL50 0-120 ~ H1B04 ~ 000816": {
                        "id": "201903140041",
                        "barcode": "000816",
                        "place": "H1B04",
                        "designation": "Thermomètre 297 D=80 PL50 0-120"
                    }
                },
                "05": {
                    "Pièce niveau chaudière vapeur ~ H1B05 ~ 000818": {
                        "id": "201903140043",
                        "barcode": "000818",
                        "place": "H1B05",
                        "designation": "Pièce niveau chaudière vapeur"
                    }
                },
                "06": {
                    "Manomètre 0-1 bar ~ H1B06 ~ 000817": {
                        "id": "201903140042",
                        "barcode": "000817",
                        "place": "H1B06",
                        "designation": "Manomètre 0-1 bar"
                    }
                },
                "07": {
                    "Vanne motorisée alimentation d'eau chaudiere ~ H1B07 ~ 000813": {
                        "id": "201903140038",
                        "barcode": "000813",
                        "place": "H1B07",
                        "designation": "Vanne motorisée alimentation d'eau chaudiere"
                    }
                },
                "08": {
                    "Relais niveau C-Mac 2/RT ~ H1B08 ~ 000820": {
                        "id": "201903140045",
                        "barcode": "000820",
                        "place": "H1B08",
                        "designation": "Relais niveau C-Mac 2/RT"
                    }
                },
                "09": {
                    "Bougie chaudieres ~ H1B09 ~ 001688": {
                        "id": "201906030001",
                        "barcode": "001688",
                        "place": "H1B09",
                        "designation": "Bougie chaudieres"
                    }
                }
            },
            "C": {
                "01": {
                    "Piece pompe acide ~ H1C01 ~ 001994": {
                        "id": "202107290001",
                        "barcode": "001994",
                        "place": "H1C01",
                        "designation": "Piece pompe acide"
                    }
                },
                "02": {
                    "Tuyau d'acide 4x6 PTFE ~ H1C02 ~ 000469": {
                        "id": "201903050028",
                        "barcode": "000469",
                        "place": "H1C02",
                        "designation": "Tuyau d'acide 4x6 PTFE"
                    },
                    "Tuyau d'acide 2x4 PTFE ~ H1C02 ~ 000470": {
                        "id": "201903050029",
                        "barcode": "000470",
                        "place": "H1C02",
                        "designation": "Tuyau d'acide 2x4 PTFE"
                    },
                    "Tuyau d'acide PTFE 4X6 (25m) ~ H1C02 ~ 002181": {
                        "id": "202201170001",
                        "barcode": "002181",
                        "place": "H1C02",
                        "designation": "Tuyau d'acide PTFE 4X6 (25m)"
                    }
                },
                "03": {
                    "Electrode PH (cote rejet ) bamo ~ H1C03 ~ 000961": {
                        "id": "201903190010",
                        "barcode": "000961",
                        "place": "H1C03",
                        "designation": "Electrode PH (cote rejet ) bamo"
                    }
                },
                "04": {
                    "Electrode de PH (tuyau acide) code: 9308RP ~ H1C04 ~ 001961": {
                        "id": "202105060001",
                        "barcode": "001961",
                        "place": "H1C04",
                        "designation": "Electrode de PH (tuyau acide) code: 9308RP"
                    }
                },
                "05": {
                    "Cordon avec connecteur coaxial 9054 BAMO côté rejet ~ H1C05 ~ 002641": {
                        "id": "202502050001",
                        "barcode": "002641",
                        "place": "H1C05",
                        "designation": "Cordon avec connecteur coaxial 9054 BAMO côté rejet"
                    },
                    "Connecteur coaxial 9054 côté rejet ~ H1C05 ~ 002642": {
                        "id": "202502050002",
                        "barcode": "002642",
                        "place": "H1C05",
                        "designation": "Connecteur coaxial 9054 côté rejet"
                    },
                    "Cordon 10m avec connecteur coaxial 9054 ~ H1C05 ~ 002666": {
                        "id": "202503240004",
                        "barcode": "002666",
                        "place": "H1C05",
                        "designation": "Cordon 10m avec connecteur coaxial 9054"
                    },
                    "Cordon avec connecteur coaxial BAMO côté acide code 9060/10/9054 ~ H1C05 ~ 002742": {
                        "id": "202601080001",
                        "barcode": "002742",
                        "place": "H1C05",
                        "designation": "Cordon avec connecteur coaxial BAMO côté acide code 9060/10/9054"
                    },
                    "Connecteur coaxial a visser de cable BRG côté acide ~ H1C05 ~ 002743": {
                        "id": "202601080002",
                        "barcode": "002743",
                        "place": "H1C05",
                        "designation": "Connecteur coaxial a visser de cable BRG côté acide"
                    }
                }
            },
            "D": {
                "10": {
                    "Vanne PP/EPDM D25 ~ H1D10 ~ 002211": {
                        "id": "202203140002",
                        "barcode": "002211",
                        "place": "H1D10",
                        "designation": "Vanne PP/EPDM D25"
                    }
                },
                "11": {
                    "Robinet à bille d32DN25 ~ H1D11 ~ 000384": {
                        "id": "201902110014",
                        "barcode": "000384",
                        "place": "H1D11",
                        "designation": "Robinet à bille d32DN25"
                    }
                },
                "12": {
                    "Debitmètre avec cellule ifm NO viton (Chrystens) ~ H1D12 ~ 002001": {
                        "id": "202108030004",
                        "barcode": "002001",
                        "place": "H1D12",
                        "designation": "Debitmètre avec cellule ifm NO viton (Chrystens)"
                    },
                    "Cellule ifm if5345 pour debitmetre ~ H1D12 ~ 002002": {
                        "id": "202108030005",
                        "barcode": "002002",
                        "place": "H1D12",
                        "designation": "Cellule ifm if5345 pour debitmetre"
                    }
                },
                "13": {
                    "Raccord cannelé PVC 1/2 D16 ~ H1D13 ~ 000389": {
                        "id": "201902110019",
                        "barcode": "000389",
                        "place": "H1D13",
                        "designation": "Raccord cannelé PVC 1/2 D16"
                    },
                    "Raccord cannelé PVC 1/2 D13 ~ H1D13 ~ 000390": {
                        "id": "201902110020",
                        "barcode": "000390",
                        "place": "H1D13",
                        "designation": "Raccord cannelé PVC 1/2 D13"
                    },
                    "Connecteur pour tuyau 10mm ~ H1D13 ~ 000461": {
                        "id": "201903050020",
                        "barcode": "000461",
                        "place": "H1D13",
                        "designation": "Connecteur pour tuyau 10mm"
                    },
                    "Connecteur pour tuyau 12mm ~ H1D13 ~ 002257": {
                        "id": "202209140006",
                        "barcode": "002257",
                        "place": "H1D13",
                        "designation": "Connecteur pour tuyau 12mm"
                    }
                },
                "14": {
                    "Raccord PP 1/2\" Pex 12/16 ~ H1D14 ~ 000394": {
                        "id": "201902120001",
                        "barcode": "000394",
                        "place": "H1D14",
                        "designation": "Raccord PP 1/2\" Pex 12/16"
                    },
                    "Raccord PP 1/2\" Pex 8/12 ~ H1D14 ~ 000458": {
                        "id": "201903050017",
                        "barcode": "000458",
                        "place": "H1D14",
                        "designation": "Raccord PP 1/2\" Pex 8/12"
                    }
                },
                "15": {
                    "Olives/joint pour raccord Pex ~ H1D15 ~ 002524": {
                        "id": "202312290003",
                        "barcode": "002524",
                        "place": "H1D15",
                        "designation": "Olives/joint pour raccord Pex"
                    }
                },
                "16": {
                    "Bloc de distributeur pneumatique (SMCbolck of LVA )Chrystens ~ H1D16 ~ 002598": {
                        "id": "202407110001",
                        "barcode": "002598",
                        "place": "H1D16",
                        "designation": "Bloc de distributeur pneumatique (SMCbolck of LVA )Chrystens"
                    },
                    "Membrane pour distributeur pneumatique (SMCbolck of LVA )Chrystens ~ H1D16 ~ 002599": {
                        "id": "202407110002",
                        "barcode": "002599",
                        "place": "H1D16",
                        "designation": "Membrane pour distributeur pneumatique (SMCbolck of LVA )Chrystens"
                    }
                },
                "17": {
                    "Tête pompe avec clapet dépannage javel ~ H1D17 ~ 002694": {
                        "id": "202509260001",
                        "barcode": "002694",
                        "place": "H1D17",
                        "designation": "Tête pompe avec clapet dépannage javel"
                    }
                },
                "18": {
                    "Pompe a membrane wilden (chrystens) occasion ~ H1D18 ~ 000481": {
                        "id": "201903050040",
                        "barcode": "000481",
                        "place": "H1D18",
                        "designation": "Pompe a membrane wilden (chrystens) occasion"
                    }
                },
                "19": {
                    "Vanne IBC Produit lessiviel ~ H1D19 ~ 002728": {
                        "id": "202511030001",
                        "barcode": "002728",
                        "place": "H1D19",
                        "designation": "Vanne IBC Produit lessiviel"
                    }
                },
                "20": {
                    "Coude de sortie cuve de produit lessiviel ~ H1D20 ~ 002738": {
                        "id": "202512260001",
                        "barcode": "002738",
                        "place": "H1D20",
                        "designation": "Coude de sortie cuve de produit lessiviel"
                    }
                },
                "01": {
                    "Joint acide javel aspiration Chrystens ~ H1D01 ~ 002260": {
                        "id": "202209140009",
                        "barcode": "002260",
                        "place": "H1D01",
                        "designation": "Joint acide javel aspiration Chrystens"
                    },
                    "Joint acide javel refoulement Chrystens ~ H1D01 ~ 002261": {
                        "id": "202209140010",
                        "barcode": "002261",
                        "place": "H1D01",
                        "designation": "Joint acide javel refoulement Chrystens"
                    },
                    "Joint refoulement Chrystens ~ H1D01 ~ 002262": {
                        "id": "202209140011",
                        "barcode": "002262",
                        "place": "H1D01",
                        "designation": "Joint refoulement Chrystens"
                    },
                    "Kit de joints ~ H1D01 ~ 002676": {
                        "id": "202503280006",
                        "barcode": "002676",
                        "place": "H1D01",
                        "designation": "Kit de joints"
                    }
                },
                "02": {
                    "Clapet anti retour aspiration Javel ~ H1D02 ~ 002259": {
                        "id": "202209140008",
                        "barcode": "002259",
                        "place": "H1D02",
                        "designation": "Clapet anti retour aspiration Javel"
                    },
                    "Clapet anti retour aspiration Javel ~ H1D02 ~ 002664": {
                        "id": "202503240002",
                        "barcode": "002664",
                        "place": "H1D02",
                        "designation": "Clapet anti retour aspiration Javel"
                    }
                },
                "03": {
                    "Clapet anti retour refoulement Javel ~ H1D03 ~ 002213": {
                        "id": "202203140004",
                        "barcode": "002213",
                        "place": "H1D03",
                        "designation": "Clapet anti retour refoulement Javel"
                    }
                },
                "04": {
                    "Clapet anti retour aspiration PP/EPDM ~ H1D04 ~ 002214": {
                        "id": "202203140005",
                        "barcode": "002214",
                        "place": "H1D04",
                        "designation": "Clapet anti retour aspiration PP/EPDM"
                    },
                    "Clapet anti retour aspiration PP/EPDM ~ H1D04 ~ 002279": {
                        "id": "202210210002",
                        "barcode": "002279",
                        "place": "H1D04",
                        "designation": "Clapet anti retour aspiration PP/EPDM"
                    }
                },
                "05": {
                    "Clapet anti retour refoulement PP/EPDM ~ H1D05 ~ 002258": {
                        "id": "202209140007",
                        "barcode": "002258",
                        "place": "H1D05",
                        "designation": "Clapet anti retour refoulement PP/EPDM"
                    },
                    "Clapet anti retour refoulement PP/EPDM ~ H1D05 ~ 002674": {
                        "id": "202503280004",
                        "barcode": "002674",
                        "place": "H1D05",
                        "designation": "Clapet anti retour refoulement PP/EPDM"
                    }
                },
                "06": {
                    "Membrane de pompe E100 ~ H1D06 ~ 002663": {
                        "id": "202503240001",
                        "barcode": "002663",
                        "place": "H1D06",
                        "designation": "Membrane de pompe E100"
                    }
                },
                "07": {
                    "Membrane de pompe E50/75 ~ H1D07 ~ 002687": {
                        "id": "202504290004",
                        "barcode": "002687",
                        "place": "H1D07",
                        "designation": "Membrane de pompe E50/75"
                    }
                },
                "08": {
                    "Divers raccord Chrystens ~ H1D08 ~ 002003": {
                        "id": "202108030006",
                        "barcode": "002003",
                        "place": "H1D08",
                        "designation": "Divers raccord Chrystens"
                    }
                },
                "09": {
                    "Vanne 3 voies Chrystens ~ H1D09 ~ 002278": {
                        "id": "202210210001",
                        "barcode": "002278",
                        "place": "H1D09",
                        "designation": "Vanne 3 voies Chrystens"
                    }
                }
            },
            "E": {
                "01": {
                    "Ruban décolleur pour Grand Plat ( moins cher par 12) ~ H1E01 ~ 000696": {
                        "id": "201903120027",
                        "barcode": "000696",
                        "place": "H1E01",
                        "designation": "Ruban décolleur pour Grand Plat ( moins cher par 12)"
                    }
                },
                "02": {
                    "Ruban décolleur pour Petit Plat ~ H1E02 ~ 000695": {
                        "id": "201903120026",
                        "barcode": "000695",
                        "place": "H1E02",
                        "designation": "Ruban décolleur pour Petit Plat"
                    }
                }
            }
        },
        "2 Colonne": {
            "A": {
                "Guide d'entrée filmeuse occasion ~ H2A ~ 000209": {
                    "id": "201901180002",
                    "barcode": "000209",
                    "place": "H2A",
                    "designation": "Guide d'entrée filmeuse occasion"
                },
                "Barre de soudure 540x40x12 ~ H2A ~ 000793": {
                    "id": "201903140018",
                    "barcode": "000793",
                    "place": "H2A",
                    "designation": "Barre de soudure 540x40x12"
                },
                "Traverse h-40 entraxe 77cm entre douille ~ H2A ~ 000795": {
                    "id": "201903140020",
                    "barcode": "000795",
                    "place": "H2A",
                    "designation": "Traverse h-40 entraxe 77cm entre douille"
                },
                "Résistance de soudure ~ H2A ~ 001955": {
                    "id": "202104210001",
                    "barcode": "001955",
                    "place": "H2A",
                    "designation": "Résistance de soudure"
                },
                "01": {
                    "Sac aspirateur maintenance (40 50 litre) ~ H2A01 ~ 001795": {
                        "id": "202004070005",
                        "barcode": "001795",
                        "place": "H2A01",
                        "designation": "Sac aspirateur maintenance (40 50 litre)"
                    }
                },
                "02": {
                    "Filtre aspirateur maintenance ~ H2A02 ~ 001793": {
                        "id": "202004070003",
                        "barcode": "001793",
                        "place": "H2A02",
                        "designation": "Filtre aspirateur maintenance"
                    }
                },
                "03": {
                    "Filtre aspirateur ménage ~ H2A03 ~ 001791": {
                        "id": "202004070001",
                        "barcode": "001791",
                        "place": "H2A03",
                        "designation": "Filtre aspirateur ménage"
                    },
                    "Filtre aspirateur linge sale ~ H2A03 ~ 001792": {
                        "id": "202004070002",
                        "barcode": "001792",
                        "place": "H2A03",
                        "designation": "Filtre aspirateur linge sale"
                    }
                },
                "04": {
                    "Cosse MR25-6+ ~ H2A04 ~ 000773": {
                        "id": "201903130028",
                        "barcode": "000773",
                        "place": "H2A04",
                        "designation": "Cosse MR25-6+"
                    },
                    "Embout 25mm2 ~ H2A04 ~ 000774": {
                        "id": "201903130029",
                        "barcode": "000774",
                        "place": "H2A04",
                        "designation": "Embout 25mm2"
                    },
                    "Cable H07RN-F 450/750V 1X25mm2 pour cosse ~ H2A04 ~ 000775": {
                        "id": "201903130030",
                        "barcode": "000775",
                        "place": "H2A04",
                        "designation": "Cable H07RN-F 450/750V 1X25mm2 pour cosse"
                    }
                },
                "05": {
                    "Disque isolant ~ H2A05 ~ 000782": {
                        "id": "201903140007",
                        "barcode": "000782",
                        "place": "H2A05",
                        "designation": "Disque isolant"
                    },
                    "Douille céramique ~ H2A05 ~ 000783": {
                        "id": "201903140008",
                        "barcode": "000783",
                        "place": "H2A05",
                        "designation": "Douille céramique"
                    }
                },
                "06": {
                    "Sonde de température PT100 filmeuse Beck ~ H2A06 ~ 000776": {
                        "id": "201903140001",
                        "barcode": "000776",
                        "place": "H2A06",
                        "designation": "Sonde de température PT100 filmeuse Beck"
                    }
                },
                "07": {
                    "Pupitre complet pour filmeuse Beck ~ H2A07 ~ 002236": {
                        "id": "202207120004",
                        "barcode": "002236",
                        "place": "H2A07",
                        "designation": "Pupitre complet pour filmeuse Beck"
                    }
                },
                "08": {
                    "Pieces de récupération ~ H2A08 ~ 002326": {
                        "id": "202301300001",
                        "barcode": "002326",
                        "place": "H2A08",
                        "designation": "Pieces de récupération"
                    }
                }
            },
            "B": {
                "Gaines flexibles ~ H2B ~ 002242": {
                    "id": "202208040001",
                    "barcode": "002242",
                    "place": "H2B",
                    "designation": "Gaines flexibles"
                },
                "Gaines en nylon ~ H2B ~ 002471": {
                    "id": "202308240011",
                    "barcode": "002471",
                    "place": "H2B",
                    "designation": "Gaines en nylon"
                }
            },
            "C": {
                "Cable souple 4G2.5 ~ H2C ~ 002338": {
                    "id": "202303070003",
                    "barcode": "002338",
                    "place": "H2C",
                    "designation": "Cable souple 4G2.5"
                }
            },
            "D": {
                "Cable robotique pour chemin de cable ~ H2D ~ 001927": {
                    "id": "202103190001",
                    "barcode": "001927",
                    "place": "H2D",
                    "designation": "Cable robotique pour chemin de cable"
                }
            },
            "E": {
                "Divers fils unifilaire ~ H2E ~ 002206": {
                    "id": "202203090003",
                    "barcode": "002206",
                    "place": "H2E",
                    "designation": "Divers fils unifilaire"
                },
                "07": {
                    "Connecteur Profibus ~ H2E07 ~ 001655": {
                        "id": "201905070010",
                        "barcode": "001655",
                        "place": "H2E07",
                        "designation": "Connecteur Profibus"
                    }
                },
                "09": {
                    "Divers cables blindés 0.34mm² (ethernet/téléphone...) ~ H2E09 ~ 002115": {
                        "id": "202111120005",
                        "barcode": "002115",
                        "place": "H2E09",
                        "designation": "Divers cables blindés 0.34mm² (ethernet/téléphone...)"
                    }
                }
            },
            "F": {
                "Isolant 2m recouvable adhesif 19-22 ~ H2F ~ 002308": {
                    "id": "202212210001",
                    "barcode": "002308",
                    "place": "H2F",
                    "designation": "Isolant 2m recouvable adhesif 19-22"
                },
                "Mousses de protection ~ H2F ~ 002468": {
                    "id": "202308240008",
                    "barcode": "002468",
                    "place": "H2F",
                    "designation": "Mousses de protection"
                },
                "01": {
                    "Accroche réglette occasion ~ H2F01 ~ 001616": {
                        "id": "201905030002",
                        "barcode": "001616",
                        "place": "H2F01",
                        "designation": "Accroche réglette occasion"
                    },
                    "Clips réglette ~ H2F01 ~ 001617": {
                        "id": "201905030003",
                        "barcode": "001617",
                        "place": "H2F01",
                        "designation": "Clips réglette"
                    }
                }
            }
        },
        "3 Colonne": {
            "A": {
                "Disjoncteur multi 9 C60N C63 A ~ H3A ~ 002347": {
                    "id": "202303270001",
                    "barcode": "002347",
                    "place": "H3A",
                    "designation": "Disjoncteur multi 9 C60N C63 A"
                },
                "01": {
                    "Rails et passages de câbles armoire éléctrique ~ H3A01 ~ 002461": {
                        "id": "202308240001",
                        "barcode": "002461",
                        "place": "H3A01",
                        "designation": "Rails et passages de câbles armoire éléctrique"
                    }
                }
            },
            "B": {
                "Cable rigide 3g2.5 ~ H3B ~ 002336": {
                    "id": "202303070001",
                    "barcode": "002336",
                    "place": "H3B",
                    "designation": "Cable rigide 3g2.5"
                },
                "Cable rigide 5g1.5 ~ H3B ~ 002337": {
                    "id": "202303070002",
                    "barcode": "002337",
                    "place": "H3B",
                    "designation": "Cable rigide 5g1.5"
                }
            },
            "C": {
                "04": {
                    "Chaine porte cables serie E2i LG: 1000mm ~ H3C04 ~ 002559": {
                        "id": "202404160001",
                        "barcode": "002559",
                        "place": "H3C04",
                        "designation": "Chaine porte cables serie E2i LG: 1000mm"
                    },
                    "Embout pour chaine porte cables serie E2i LG: 1000mm ~ H3C04 ~ 002560": {
                        "id": "202404160002",
                        "barcode": "002560",
                        "place": "H3C04",
                        "designation": "Embout pour chaine porte cables serie E2i LG: 1000mm"
                    }
                },
                "09": {
                    "Chariot porte câble plat navette Lavatec ~ H3C09 ~ 002460": {
                        "id": "202308230002",
                        "barcode": "002460",
                        "place": "H3C09",
                        "designation": "Chariot porte câble plat navette Lavatec"
                    }
                }
            },
            "D": {
                "Divers flexible vapeur ~ H3D ~ 002208": {
                    "id": "202203110001",
                    "barcode": "002208",
                    "place": "H3D",
                    "designation": "Divers flexible vapeur"
                }
            },
            "E": {
                "10": {
                    "Pièces de fixation armoire éléctrique ~ H3E10 ~ 002462": {
                        "id": "202308240002",
                        "barcode": "002462",
                        "place": "H3E10",
                        "designation": "Pièces de fixation armoire éléctrique"
                    }
                },
                "11": {
                    "Points d'accroche sur IPN ~ H3E11 ~ 002464": {
                        "id": "202308240004",
                        "barcode": "002464",
                        "place": "H3E11",
                        "designation": "Points d'accroche sur IPN"
                    }
                },
                "12": {
                    "Ecrous de goulotte ~ H3E12 ~ 002466": {
                        "id": "202308240006",
                        "barcode": "002466",
                        "place": "H3E12",
                        "designation": "Ecrous de goulotte"
                    }
                },
                "01": {
                    "Ressort pour bac a font montant l:430 ~ H3E01 ~ 001759": {
                        "id": "202003170001",
                        "barcode": "001759",
                        "place": "H3E01",
                        "designation": "Ressort pour bac a font montant l:430"
                    },
                    "Ressort pour bac a font montant l:340 ~ H3E01 ~ 002121": {
                        "id": "202111150002",
                        "barcode": "002121",
                        "place": "H3E01",
                        "designation": "Ressort pour bac a font montant l:340"
                    },
                    "Roulette pour bac a font montant ~ H3E01 ~ 002122": {
                        "id": "202111150003",
                        "barcode": "002122",
                        "place": "H3E01",
                        "designation": "Roulette pour bac a font montant"
                    },
                    "Cable pour bac a font montant ~ H3E01 ~ 002123": {
                        "id": "202111150004",
                        "barcode": "002123",
                        "place": "H3E01",
                        "designation": "Cable pour bac a font montant"
                    }
                },
                "02": {
                    "Ressort pour bac a font montant l:160 ~ H3E02 ~ 002120": {
                        "id": "202111150001",
                        "barcode": "002120",
                        "place": "H3E02",
                        "designation": "Ressort pour bac a font montant l:160"
                    }
                },
                "08": {
                    "Clips bord de tôle ~ H3E08 ~ 002465": {
                        "id": "202308240005",
                        "barcode": "002465",
                        "place": "H3E08",
                        "designation": "Clips bord de tôle"
                    }
                },
                "09": {
                    "Bouchons carrés ~ H3E09 ~ 002463": {
                        "id": "202308240003",
                        "barcode": "002463",
                        "place": "H3E09",
                        "designation": "Bouchons carrés"
                    }
                }
            },
            "F": {
                "01": {
                    "Tube eclairage 18w/865 ~ H3F01 ~ 001620": {
                        "id": "201905030006",
                        "barcode": "001620",
                        "place": "H3F01",
                        "designation": "Tube eclairage 18w/865"
                    }
                },
                "02": {
                    "Tube eclairage 8w/640 ~ H3F02 ~ 001622": {
                        "id": "201905030008",
                        "barcode": "001622",
                        "place": "H3F02",
                        "designation": "Tube eclairage 8w/640"
                    }
                },
                "03": {
                    "Tube eclairage 13w/640 ~ H3F03 ~ 001623": {
                        "id": "201905030009",
                        "barcode": "001623",
                        "place": "H3F03",
                        "designation": "Tube eclairage 13w/640"
                    }
                },
                "04": {
                    "Tube eclairage 14w/840 ~ H3F04 ~ 002056": {
                        "id": "202110060001",
                        "barcode": "002056",
                        "place": "H3F04",
                        "designation": "Tube eclairage 14w/840"
                    }
                },
                "05": {
                    "Tube eclairage type buro 36w/840 (bureau entree bih ) occasion ~ H3F05 ~ 002293": {
                        "id": "202211100001",
                        "barcode": "002293",
                        "place": "H3F05",
                        "designation": "Tube eclairage type buro 36w/840 (bureau entree bih ) occasion"
                    }
                },
                "06": {
                    "Prise canalis ~ H3F06 ~ 001663": {
                        "id": "201905070018",
                        "barcode": "001663",
                        "place": "H3F06",
                        "designation": "Prise canalis"
                    }
                }
            }
        },
        "4 Colonne": {
            "A": {
                "01": {
                    "Tube eclairage 58w/840 ~ H4A01 ~ 001627": {
                        "id": "201905030013",
                        "barcode": "001627",
                        "place": "H4A01",
                        "designation": "Tube eclairage 58w/840"
                    }
                },
                "02": {
                    "Tube eclairage 36w/865 ~ H4A02 ~ 001625": {
                        "id": "201905030011",
                        "barcode": "001625",
                        "place": "H4A02",
                        "designation": "Tube eclairage 36w/865"
                    },
                    "Tube eclairage 36w/840 ~ H4A02 ~ 001626": {
                        "id": "201905030012",
                        "barcode": "001626",
                        "place": "H4A02",
                        "designation": "Tube eclairage 36w/840"
                    }
                },
                "03": {
                    "Tube eclairage T5 49W 840 ~ H4A03 ~ 001738": {
                        "id": "202002050002",
                        "barcode": "001738",
                        "place": "H4A03",
                        "designation": "Tube eclairage T5 49W 840"
                    }
                }
            }
        }
    },
    "Rangée I": {
        "1 Colonne": {
            "Guide au mètre ~ I1 ~ 000603": {
                "id": "201903070058",
                "barcode": "000603",
                "place": "I1",
                "designation": "Guide au mètre"
            },
            "Jonc bleu pour rail ~ I1 ~ 000604": {
                "id": "201903070059",
                "barcode": "000604",
                "place": "I1",
                "designation": "Jonc bleu pour rail"
            }
        },
        "2 Colonne": {
            "A": {
                "Courbe U double R490 90° ~ I2A ~ 000431": {
                    "id": "201903040007",
                    "barcode": "000431",
                    "place": "I2A",
                    "designation": "Courbe U double R490 90°"
                },
                "Courbe horizontalbend SUADUB R600 75° ~ I2A ~ 000433": {
                    "id": "201903040009",
                    "barcode": "000433",
                    "place": "I2A",
                    "designation": "Courbe horizontalbend SUADUB R600 75°"
                },
                "Courbe horizontalbend SUADOU R600 105° ~ I2A ~ 000434": {
                    "id": "201903040010",
                    "barcode": "000434",
                    "place": "I2A",
                    "designation": "Courbe horizontalbend SUADOU R600 105°"
                },
                "Courbe double SUA extérieur R600 75° ~ I2A ~ 000436": {
                    "id": "201903040012",
                    "barcode": "000436",
                    "place": "I2A",
                    "designation": "Courbe double SUA extérieur R600 75°"
                }
            },
            "B": {
                "Divers rail sans référence constructeur ~ I2B ~ 002191": {
                    "id": "202202030002",
                    "barcode": "002191",
                    "place": "I2B",
                    "designation": "Divers rail sans référence constructeur"
                }
            },
            "C": {
                "Courbe Métric double SXA R600 90° ~ I2C ~ 000425": {
                    "id": "201903040001",
                    "barcode": "000425",
                    "place": "I2C",
                    "designation": "Courbe Métric double SXA R600 90°"
                },
                "Courbe double horizontale SXA R 90° ~ I2C ~ 000427": {
                    "id": "201903040003",
                    "barcode": "000427",
                    "place": "I2C",
                    "designation": "Courbe double horizontale SXA R 90°"
                },
                "Courbe U montante double 30° (M25?) ~ I2C ~ 002307": {
                    "id": "202212160001",
                    "barcode": "002307",
                    "place": "I2C",
                    "designation": "Courbe U montante double 30° (M25?)"
                }
            }
        },
        "3 Colonne": {
            "A": {
                "Courbe horizontalbenu double R350 180° ~ I3A ~ 000432": {
                    "id": "201903040008",
                    "barcode": "000432",
                    "place": "I3A",
                    "designation": "Courbe horizontalbenu double R350 180°"
                },
                "Courbe double SUA R710 180° ~ I3A ~ 000437": {
                    "id": "201903040013",
                    "barcode": "000437",
                    "place": "I3A",
                    "designation": "Courbe double SUA R710 180°"
                },
                "Courbe double horizontal SXA R600 INV 180° ~ I3A ~ 000438": {
                    "id": "201903040014",
                    "barcode": "000438",
                    "place": "I3A",
                    "designation": "Courbe double horizontal SXA R600 INV 180°"
                },
                "Courbe horizontalbend SUADOU R600 180° ~ I3A ~ 000439": {
                    "id": "201903040015",
                    "barcode": "000439",
                    "place": "I3A",
                    "designation": "Courbe horizontalbend SUADOU R600 180°"
                },
                "Courbe SXA double R600 180° ~ I3A ~ 000440": {
                    "id": "201903040016",
                    "barcode": "000440",
                    "place": "I3A",
                    "designation": "Courbe SXA double R600 180°"
                },
                "Courbe horizontalbend SUADOU R600 180° ~ I3A ~ 000441": {
                    "id": "201903040017",
                    "barcode": "000441",
                    "place": "I3A",
                    "designation": "Courbe horizontalbend SUADOU R600 180°"
                },
                "Courbe U R490 90° simple ~ I3A ~ 000444": {
                    "id": "201903050003",
                    "barcode": "000444",
                    "place": "I3A",
                    "designation": "Courbe U R490 90° simple"
                },
                "Courbe U R490 180° ~ I3A ~ 000447": {
                    "id": "201903050006",
                    "barcode": "000447",
                    "place": "I3A",
                    "designation": "Courbe U R490 180°"
                }
            },
            "B": {
                "Courbe Métric SUA R600 30° ~ I3B ~ 000426": {
                    "id": "201903040002",
                    "barcode": "000426",
                    "place": "I3B",
                    "designation": "Courbe Métric SUA R600 30°"
                },
                "Courbe double SUA R710 30° ~ I3B ~ 000428": {
                    "id": "201903040004",
                    "barcode": "000428",
                    "place": "I3B",
                    "designation": "Courbe double SUA R710 30°"
                },
                "Courbe horizontale double sortie R600 60° ~ I3B ~ 000429": {
                    "id": "201903040005",
                    "barcode": "000429",
                    "place": "I3B",
                    "designation": "Courbe horizontale double sortie R600 60°"
                },
                "Courbe horizontalbend SXADUB R600 30° ~ I3B ~ 000430": {
                    "id": "201903040006",
                    "barcode": "000430",
                    "place": "I3B",
                    "designation": "Courbe horizontalbend SXADUB R600 30°"
                },
                "Courbe horizontalben SUASIN R600 60° ~ I3B ~ 000435": {
                    "id": "201903040011",
                    "barcode": "000435",
                    "place": "I3B",
                    "designation": "Courbe horizontalben SUASIN R600 60°"
                },
                "Courbe 180° R350 type U ~ I3B ~ 000442": {
                    "id": "201903050001",
                    "barcode": "000442",
                    "place": "I3B",
                    "designation": "Courbe 180° R350 type U"
                },
                "Courbe horizontalbendusingle ~ I3B ~ 000443": {
                    "id": "201903050002",
                    "barcode": "000443",
                    "place": "I3B",
                    "designation": "Courbe horizontalbendusingle"
                },
                "Rail pour cintre vide au dessus des Maximat (départ des taquets) ~ I3B ~ 001886": {
                    "id": "202012010001",
                    "barcode": "001886",
                    "place": "I3B",
                    "designation": "Rail pour cintre vide au dessus des Maximat (départ des taquets)"
                },
                "Courbe SXA DOUBLE R600 INV 45° pour M4 ~ I3B ~ 002583": {
                    "id": "202406040001",
                    "barcode": "002583",
                    "place": "I3B",
                    "designation": "Courbe SXA DOUBLE R600 INV 45° pour M4"
                }
            }
        },
        "4 Colonne": {
            "Rail droit L=920mm \"Profile ALU \"\"U\" (voir référence : 401048-01) vendu au mètre ~ I4 ~ 000449": {
                "id": "201903050008",
                "barcode": "000449",
                "place": "I4",
                "designation": "Rail droit L=920mm \"Profile ALU \"\"U\" (voir référence : 401048-01) vendu au mètre"
            },
            "Plaque de mousse silicone adhesive noire (850X9.5X1050mm) ~ I4 ~ 000769": {
                "id": "201903130024",
                "barcode": "000769",
                "place": "I4",
                "designation": "Plaque de mousse silicone adhesive noire (850X9.5X1050mm)"
            },
            "Plaque tissu de verre PTFE teflon une face autocollante 1000X1000X0.35 ~ I4 ~ 001807": {
                "id": "202004090003",
                "barcode": "001807",
                "place": "I4",
                "designation": "Plaque tissu de verre PTFE teflon une face autocollante 1000X1000X0.35"
            },
            "Canne d'aspiration Christeyns ~ I4 ~ 001911": {
                "id": "202102040001",
                "barcode": "001911",
                "place": "I4",
                "designation": "Canne d'aspiration Christeyns"
            },
            "Rail droit \"Profile ALU \"\"U\"\" au mètre\" ~ I4 ~ 002140": {
                "id": "202111160013",
                "barcode": "002140",
                "place": "I4",
                "designation": "Rail droit \"Profile ALU \"\"U\"\" au mètre\""
            },
            "Teflon-ZK-1/2 teflon adhésif 100 x 50 cm ~ I4 ~ 002147": {
                "id": "202111160020",
                "barcode": "002147",
                "place": "I4",
                "designation": "Teflon-ZK-1/2 teflon adhésif 100 x 50 cm"
            },
            "Teflon non adhésif 100X100cm ~ I4 ~ 002148": {
                "id": "202111160021",
                "barcode": "002148",
                "place": "I4",
                "designation": "Teflon non adhésif 100X100cm"
            },
            "Feuille de joint graphite 1.25mm ~ I4 ~ 002151": {
                "id": "202111160024",
                "barcode": "002151",
                "place": "I4",
                "designation": "Feuille de joint graphite 1.25mm"
            },
            "Mousse protection adhesive noire /jaune ~ I4 ~ 002193": {
                "id": "202202030004",
                "barcode": "002193",
                "place": "I4",
                "designation": "Mousse protection adhesive noire /jaune"
            },
            "Feuille de joint papier ~ I4 ~ 002194": {
                "id": "202202030005",
                "barcode": "002194",
                "place": "I4",
                "designation": "Feuille de joint papier"
            },
            "Canne d'aspiration Christeyns ~ I4 ~ 002233": {
                "id": "202207120001",
                "barcode": "002233",
                "place": "I4",
                "designation": "Canne d'aspiration Christeyns"
            },
            "Rail droit \"profile ALU \"\"U LARGE \"\" AU METRE ~ I4 ~ 002480": {
                "id": "202309260001",
                "barcode": "002480",
                "place": "I4",
                "designation": "Rail droit \"profile ALU \"\"U LARGE \"\" AU METRE"
            },
            "Plaque tissu de verre PTFEA teflon NON autocollante 1000X1000X0.15 ~ I4 ~ 002557": {
                "id": "202403290001",
                "barcode": "002557",
                "place": "I4",
                "designation": "Plaque tissu de verre PTFEA teflon NON autocollante 1000X1000X0.15"
            },
            "Canne d'aspiration PP750 Christeyns avec anti retour ~ I4 ~ 002686": {
                "id": "202504290003",
                "barcode": "002686",
                "place": "I4",
                "designation": "Canne d'aspiration PP750 Christeyns avec anti retour"
            }
        }
    },
    "Support de cellule sick fabrication artisanale ~ Support-d ~ 002145": {
        "id": "202111160018",
        "barcode": "002145",
        "place": "Support-d",
        "designation": "Support de cellule sick fabrication artisanale"
    },
    "Filtre a eau pour arrivée eau de forage 25 micro ~ Filtre-a- ~ 002219": {
        "id": "202203230001",
        "barcode": "002219",
        "place": "Filtre-a-",
        "designation": "Filtre a eau pour arrivée eau de forage 25 micro"
    },
    "Palpeur de température infra rouge ~ Palpeur-d ~ 002595": {
        "id": "202206170001",
        "barcode": "002595",
        "place": "Palpeur-d",
        "designation": "Palpeur de température infra rouge"
    },
    "MO Main d'oeuvre ~ MO-Main-d ~ 002454": {
        "id": "202308160001",
        "barcode": "002454",
        "place": "MO-Main-d",
        "designation": "MO Main d'oeuvre"
    },
    "Serrure du local Chariot ~ Serrure-d ~ 002680": {
        "id": "202504140001",
        "barcode": "002680",
        "place": "Serrure-d",
        "designation": "Serrure du local Chariot"
    },
    "Filtre tamis 615x3794 tunel finition ~ Filtre-ta ~ 000001": {
        "id": "202505070001",
        "barcode": "000001",
        "place": "Filtre-ta",
        "designation": "Filtre tamis 615x3794 tunel finition"
    },
    "Filtre tamis 615x5294 tunel finition ~ Filtre-ta ~ 002727": {
        "id": "202510270001",
        "barcode": "002727",
        "place": "Filtre-ta",
        "designation": "Filtre tamis 615x5294 tunel finition"
    },
    "Derrière les tunnels Lavatec": {
        "Membrane pour presse 12 (avec anneau incorporé chez maxipress) Lavatec LP571/LP572 ~ Membrane- ~ 000761": {
            "id": "201903130016",
            "barcode": "000761",
            "place": "Membrane-",
            "designation": "Membrane pour presse 12 (avec anneau incorporé chez maxipress) Lavatec LP571/LP572"
        },
        "Membrane pour presse 10 marque Jensen ATTENTION sans joints 9905178411 ~ Membrane- ~ 000762": {
            "id": "201903130017",
            "barcode": "000762",
            "place": "Membrane-",
            "designation": "Membrane pour presse 10 marque Jensen ATTENTION sans joints 9905178411"
        },
        "Tuyau d'eau de transfert diamètre 102 x 111 (serrage dans armoire bleue) ~ Tuyau-de ~ 000796": {
            "id": "201903140021",
            "barcode": "000796",
            "place": "Tuyau-de",
            "designation": "Tuyau d'eau de transfert diamètre 102 x 111 (serrage dans armoire bleue)"
        },
        "Jeu de joints pour membrane blanche presse 10 marque Jensen ~ Jeu-de-jo ~ 002314": {
            "id": "202301040002",
            "barcode": "002314",
            "place": "Jeu-de-jo",
            "designation": "Jeu de joints pour membrane blanche presse 10 marque Jensen"
        },
        "Anneaux pour montage membrane Lavatec LP571/LP572 ~ Anneaux-p ~ 002455": {
            "id": "202308160002",
            "barcode": "002455",
            "place": "Anneaux-p",
            "designation": "Anneaux pour montage membrane Lavatec LP571/LP572"
        },
        "Membrane pour presse 12 (sans anneau incorporé chez Maxipress) Lavatec LP571/LP572 ~ Membrane- ~ 002479": {
            "id": "202309250001",
            "barcode": "002479",
            "place": "Membrane-",
            "designation": "Membrane pour presse 12 (sans anneau incorporé chez Maxipress) Lavatec LP571/LP572"
        },
        "Membrane pour presse 10 blanche RENFORCEE marque Jensen ATTENTION sans joints 9905178411 ~ Membrane- ~ 002579": {
            "id": "202405280001",
            "barcode": "002579",
            "place": "Membrane-",
            "designation": "Membrane pour presse 10 blanche RENFORCEE marque Jensen ATTENTION sans joints 9905178411"
        }
    },
    "Etagere derriere GP": {
        "Arbre rouleau diamètre 102mm L:3452mm remis en état pour engageuse GP ~ Arbre-rou ~ 001974": {
            "id": "202106140001",
            "barcode": "001974",
            "place": "Arbre-rou",
            "designation": "Arbre rouleau diamètre 102mm L:3452mm remis en état pour engageuse GP"
        },
        "Arbre rouleau avec anneau dia 102mm L:3460mm remis en état pour engageuse GP ~ Arbre-rou ~ 001975": {
            "id": "202106140002",
            "barcode": "001975",
            "place": "Arbre-rou",
            "designation": "Arbre rouleau avec anneau dia 102mm L:3460mm remis en état pour engageuse GP"
        },
        "Molleton renforcé spécial Kannegiesser 8100X3600 pour calandre 1300X1300 ~ Molleton- ~ 002171": {
            "id": "202112060001",
            "barcode": "002171",
            "place": "Molleton-",
            "designation": "Molleton renforcé spécial Kannegiesser 8100X3600 pour calandre 1300X1300"
        },
        "Glissiere pour pince engageuse GP occasion ~ Glissiere ~ 002296": {
            "id": "202211240002",
            "barcode": "002296",
            "place": "Glissiere",
            "designation": "Glissiere pour pince engageuse GP occasion"
        },
        "Cire high power plus ~ Cire-high ~ 002297": {
            "id": "202211240003",
            "barcode": "002297",
            "place": "Cire-high",
            "designation": "Cire high power plus"
        },
        "Molletons GP DUO Kannegiesser 1200 x 3300 (2 molletons) ~ Molletons ~ 002405": {
            "id": "202307260001",
            "barcode": "002405",
            "place": "Molletons",
            "designation": "Molletons GP DUO Kannegiesser 1200 x 3300 (2 molletons)"
        },
        "Molletons PP DUO Kannegiesser 1300 C 3300 (2 molletons) ~ Molletons ~ 002406": {
            "id": "202307260002",
            "barcode": "002406",
            "place": "Molletons",
            "designation": "Molletons PP DUO Kannegiesser 1300 C 3300 (2 molletons)"
        },
        "Arbre rouleau diamètre 102mm L:3252mm A FAIRE REPARER pour plieuse classic GP ~ Arbre-rou ~ 002551": {
            "id": "202402160002",
            "barcode": "002551",
            "place": "Arbre-rou",
            "designation": "Arbre rouleau diamètre 102mm L:3252mm A FAIRE REPARER pour plieuse classic GP"
        }
    },
    "Local chaufferie": {
        "Galet tunnel ~ Galet-tun ~ 001977": {
            "id": "202107190002",
            "barcode": "001977",
            "place": "Galet-tun",
            "designation": "Galet tunnel"
        },
        "Fluide caloporteur calandre GP/PP FC7 EN FUT de 215 LITRES ~ Fluide-ca ~ 002333": {
            "id": "202302230002",
            "barcode": "002333",
            "place": "Fluide-ca",
            "designation": "Fluide caloporteur calandre GP/PP FC7 EN FUT de 215 LITRES"
        },
        "Liqueur alcalimétrique N25 1000m ~ Liqueur-a ~ 002609": {
            "id": "202409050003",
            "barcode": "002609",
            "place": "Liqueur-a",
            "designation": "Liqueur alcalimétrique N25 1000m"
        },
        "Languette semi-quantitative test Sulfite 10-1000mg/l ~ Languette ~ 002622": {
            "id": "202411280001",
            "barcode": "002622",
            "place": "Languette",
            "designation": "Languette semi-quantitative test Sulfite 10-1000mg/l"
        },
        "Produit A177 fût de 250 KG ~ Produit-A ~ 002623": {
            "id": "202411280002",
            "barcode": "002623",
            "place": "Produit-A",
            "designation": "Produit A177 fût de 250 KG"
        },
        "Réactif bleu TH fiole de 60 mL ~ Réactif-b ~ 002631": {
            "id": "202412260002",
            "barcode": "002631",
            "place": "Réactif-b",
            "designation": "Réactif bleu TH fiole de 60 mL"
        }
    },
    "Local Compresseur": {
        "Filtre à poche SONIQ II cadre plastique 25mm 492X492X635 mm C25mm POUR LINGE SALE( quantité: 16 ) ~ Filtre-à- ~ 001848": {
            "id": "202007220003",
            "barcode": "001848",
            "place": "Filtre-à-",
            "designation": "Filtre à poche SONIQ II cadre plastique 25mm 492X492X635 mm C25mm POUR LINGE SALE( quantité: 16 )"
        },
        "Prefiltre a refaire avec les boites métalliques de type 80 de 490X490X47 ~ Prefiltre ~ 002166": {
            "id": "202111180001",
            "barcode": "002166",
            "place": "Prefiltre",
            "designation": "Prefiltre a refaire avec les boites métalliques de type 80 de 490X490X47"
        }
    },
    "Local CTA INDUS et RESID": {
        "Prefiltre à Poche NOVATEX Dim : 592 X 592 X 200mm (Préfiltre Indust Q=12 / Resident Q=8) ~ Prefiltre ~ 001773": {
            "id": "202003260001",
            "barcode": "001773",
            "place": "Prefiltre",
            "designation": "Prefiltre à Poche NOVATEX Dim : 592 X 592 X 200mm (Préfiltre Indust Q=12 / Resident Q=8)"
        },
        "Filtre à Poche SONIQ Dim : 592 X 592 X 360mm (Filtre Indust Q=12 / resident Q=8) ~ Filtre-à- ~ 001847": {
            "id": "202007220002",
            "barcode": "001847",
            "place": "Filtre-à-",
            "designation": "Filtre à Poche SONIQ Dim : 592 X 592 X 360mm (Filtre Indust Q=12 / resident Q=8)"
        }
    },
    "Local huile": {
        "Huile structovis EHD 5L pour chaine ~ Huile-str ~ 000161": {
            "id": "201801260001",
            "barcode": "000161",
            "place": "Huile-str",
            "designation": "Huile structovis EHD 5L pour chaine"
        },
        "Huile thermique (fluide caloporteur) F22S Lapauw ~ Huile-the ~ 000162": {
            "id": "201801260002",
            "barcode": "000162",
            "place": "Huile-the",
            "designation": "Huile thermique (fluide caloporteur) F22S Lapauw"
        },
        "Huile Unil Opal HVB46 presse 12 bibon de 25l ~ Huile-Uni ~ 000163": {
            "id": "201801260003",
            "barcode": "000163",
            "place": "Huile-Uni",
            "designation": "Huile Unil Opal HVB46 presse 12 bibon de 25l"
        },
        "Huile Lubsyn 220 réducteurs : tunnel de lavage kannegiesser identique Huile klubersynth GH6.220 besoin de 12.5l ~ Huile-Lub ~ 000164": {
            "id": "201801260004",
            "barcode": "000164",
            "place": "Huile-Lub",
            "designation": "Huile Lubsyn 220 réducteurs : tunnel de lavage kannegiesser identique Huile klubersynth GH6.220 besoin de 12.5l"
        },
        "Huile Mobil SHC 634 reducteur Lapauw ~ Huile-Mob ~ 000165": {
            "id": "201801260005",
            "barcode": "000165",
            "place": "Huile-Mob",
            "designation": "Huile Mobil SHC 634 reducteur Lapauw"
        },
        "Fluide caloporteur calandre GP/PP FC7 EN BIDON ~ Fluide-ca ~ 000231": {
            "id": "201901180024",
            "barcode": "000231",
            "place": "Fluide-ca",
            "designation": "Fluide caloporteur calandre GP/PP FC7 EN BIDON"
        },
        "Huile Mobil26 DTE ultra presse 10 (bidon de 20l) ~ Huile-Mob ~ 001936": {
            "id": "202103300002",
            "barcode": "001936",
            "place": "Huile-Mob",
            "designation": "Huile Mobil26 DTE ultra presse 10 (bidon de 20l)"
        },
        "Nettoyant calandre GP/PP FC clean ~ Nettoyant ~ 002152": {
            "id": "202111170001",
            "barcode": "002152",
            "place": "Nettoyant",
            "designation": "Nettoyant calandre GP/PP FC clean"
        },
        "Huile klubersynth GH6.460 ~ Huile-klu ~ 002153": {
            "id": "202111170002",
            "barcode": "002153",
            "place": "Huile-klu",
            "designation": "Huile klubersynth GH6.460"
        },
        "Huile Duragear BL Réducteurs tunnel de lavage Lavatec ~ Huile-Dur ~ 002154": {
            "id": "202111170003",
            "barcode": "002154",
            "place": "Huile-Dur",
            "designation": "Huile Duragear BL Réducteurs tunnel de lavage Lavatec"
        },
        "Fluide caloporteur Fragoltherm Q7 ~ Fluide-ca ~ 002155": {
            "id": "202111170004",
            "barcode": "002155",
            "place": "Fluide-ca",
            "designation": "Fluide caloporteur Fragoltherm Q7"
        },
        "Huile lubsyn 460 réducteurs secheuse Kannegiesser ~ Huile-lub ~ 002156": {
            "id": "202111170005",
            "barcode": "002156",
            "place": "Huile-lub",
            "designation": "Huile lubsyn 460 réducteurs secheuse Kannegiesser"
        },
        "Huile klubersynth GH6.220 identique Huile lubsyn 220 ~ Huile-klu ~ 002157": {
            "id": "202111170006",
            "barcode": "002157",
            "place": "Huile-klu",
            "designation": "Huile klubersynth GH6.220 identique Huile lubsyn 220"
        },
        "Cartouche de graisse kluberplex BE31.502 ~ Cartouche ~ 002158": {
            "id": "202111170007",
            "barcode": "002158",
            "place": "Cartouche",
            "designation": "Cartouche de graisse kluberplex BE31.502"
        },
        "Cartouche de graisse galaxie ~ Cartouche ~ 002313": {
            "id": "202301040001",
            "barcode": "002313",
            "place": "Cartouche",
            "designation": "Cartouche de graisse galaxie"
        },
        "Bombe de peinture RAL9005 400ml noir brillant ~ Bombe-de- ~ 002576": {
            "id": "202405160005",
            "barcode": "002576",
            "place": "Bombe-de-",
            "designation": "Bombe de peinture RAL9005 400ml noir brillant"
        },
        "Bombe de peinture RAL1021 400ml jaune ~ Bombe-de- ~ 002577": {
            "id": "202405160006",
            "barcode": "002577",
            "place": "Bombe-de-",
            "designation": "Bombe de peinture RAL1021 400ml jaune"
        },
        "Bombe de peinture RAL9010 400ml blanc ~ Bombe-de- ~ 002578": {
            "id": "202405160007",
            "barcode": "002578",
            "place": "Bombe-de-",
            "designation": "Bombe de peinture RAL9010 400ml blanc"
        },
        "Dose DS10000 déboucheur ~ Dose-DS10 ~ 002607": {
            "id": "202409050001",
            "barcode": "002607",
            "place": "Dose-DS10",
            "designation": "Dose DS10000 déboucheur"
        },
        "Savon d'atelier Proderm ~ Savon-da ~ 002608": {
            "id": "202409050002",
            "barcode": "002608",
            "place": "Savon-da",
            "designation": "Savon d'atelier Proderm"
        },
        "Bombe aérosol graisse Paste HT1200 tube 150ml ~ Bombe-aér ~ 002650": {
            "id": "202503120005",
            "barcode": "002650",
            "place": "Bombe-aér",
            "designation": "Bombe aérosol graisse Paste HT1200 tube 150ml"
        },
        "Bombe aérosol Huiles Lube TF tube 500ml ~ Bombe-aér ~ 002651": {
            "id": "202503120006",
            "barcode": "002651",
            "place": "Bombe-aér",
            "designation": "Bombe aérosol Huiles Lube TF tube 500ml"
        },
        "Bombe aérosol Nettoyante clean F 500ml ~ Bombe-aér ~ 002652": {
            "id": "202503120007",
            "barcode": "002652",
            "place": "Bombe-aér",
            "designation": "Bombe aérosol Nettoyante clean F 500ml"
        },
        "Interflon nettoyant dégraissant lubrifiant Eco Degreaser Flacons avec tête de pulvé +Flacons avec tête de pulvé ~ Interflon ~ 002653": {
            "id": "202503120008",
            "barcode": "002653",
            "place": "Interflon",
            "designation": "Interflon nettoyant dégraissant lubrifiant Eco Degreaser Flacons avec tête de pulvé +Flacons avec tête de pulvé"
        },
        "Absorbant vegetal ignifuge (sac de 40litres ) ~ Absorbant ~ 002655": {
            "id": "202503180001",
            "barcode": "002655",
            "place": "Absorbant",
            "designation": "Absorbant vegetal ignifuge (sac de 40litres )"
        },
        "Bombe de peinture RAL5015 400ml bleu ~ Bombe-de- ~ 002660": {
            "id": "202503190001",
            "barcode": "002660",
            "place": "Bombe-de-",
            "designation": "Bombe de peinture RAL5015 400ml bleu"
        },
        "Bombe de peinture RAL3001 400ml rouge ~ Bombe-de- ~ 002681": {
            "id": "202504150001",
            "barcode": "002681",
            "place": "Bombe-de-",
            "designation": "Bombe de peinture RAL3001 400ml rouge"
        },
        "Cartouche de graisse vulcain IT 2332 ~ Cartouche ~ 002691": {
            "id": "202508280001",
            "barcode": "002691",
            "place": "Cartouche",
            "designation": "Cartouche de graisse vulcain IT 2332"
        },
        "Microsec F ~ Microsec- ~ 002706": {
            "id": "202510200001",
            "barcode": "002706",
            "place": "Microsec-",
            "designation": "Microsec F"
        },
        "TANET neutral ~ TANET-neu ~ 002707": {
            "id": "202510200002",
            "barcode": "002707",
            "place": "TANET-neu",
            "designation": "TANET neutral"
        },
        "Lingettes de nettoyage ~ Lingettes ~ 002708": {
            "id": "202510200003",
            "barcode": "002708",
            "place": "Lingettes",
            "designation": "Lingettes de nettoyage"
        },
        "Détecteur de fuite ~ Détecteur ~ 002709": {
            "id": "202510200004",
            "barcode": "002709",
            "place": "Détecteur",
            "designation": "Détecteur de fuite"
        },
        "Barrière thermique pare feu 100 FLAM ~ Barrière- ~ 002710": {
            "id": "202510200005",
            "barcode": "002710",
            "place": "Barrière-",
            "designation": "Barrière thermique pare feu 100 FLAM"
        },
        "ProColle SILPOWER ~ ProColle- ~ 002711": {
            "id": "202510200006",
            "barcode": "002711",
            "place": "ProColle-",
            "designation": "ProColle SILPOWER"
        },
        "Liquide de frein DOT 4 BOSCH ~ Liquide-d ~ 002712": {
            "id": "202510200007",
            "barcode": "002712",
            "place": "Liquide-d",
            "designation": "Liquide de frein DOT 4 BOSCH"
        },
        "Lave glace antigel ~ Lave-glac ~ 002713": {
            "id": "202510200008",
            "barcode": "002713",
            "place": "Lave-glac",
            "designation": "Lave glace antigel"
        },
        "Lubrifiant moteur diesel Maxima rld eco 15w-30 ~ Lubrifian ~ 002714": {
            "id": "202510200009",
            "barcode": "002714",
            "place": "Lubrifian",
            "designation": "Lubrifiant moteur diesel Maxima rld eco 15w-30"
        },
        "HY-GARD Hydraulic & Transmission Oil ~ HY-GARD-H ~ 002715": {
            "id": "202510200010",
            "barcode": "002715",
            "place": "HY-GARD-H",
            "designation": "HY-GARD Hydraulic & Transmission Oil"
        },
        "Liquide de refroidissement ISO TECH ~ Liquide-d ~ 002716": {
            "id": "202510200011",
            "barcode": "002716",
            "place": "Liquide-d",
            "designation": "Liquide de refroidissement ISO TECH"
        },
        "Natac ~ Natac ~ 002717": {
            "id": "202510200012",
            "barcode": "002717",
            "place": "Natac",
            "designation": "Natac"
        },
        "Enrobé réactif à l'eau AQUASPHALT ~ Enrobé-ré ~ 002718": {
            "id": "202510200013",
            "barcode": "002718",
            "place": "Enrobé-ré",
            "designation": "Enrobé réactif à l'eau AQUASPHALT"
        },
        "Sel de déneigement ~ Sel-de-dé ~ 002719": {
            "id": "202510200014",
            "barcode": "002719",
            "place": "Sel-de-dé",
            "designation": "Sel de déneigement"
        },
        "ScrewGuard Rotair ~ ScrewGuar ~ 002720": {
            "id": "202510200015",
            "barcode": "002720",
            "place": "ScrewGuar",
            "designation": "ScrewGuard Rotair"
        },
        "Détartrant d'eau industrielle et décapant carrelages ~ Détartran ~ 002721": {
            "id": "202510200016",
            "barcode": "002721",
            "place": "Détartran",
            "designation": "Détartrant d'eau industrielle et décapant carrelages"
        },
        "Gas Oil ~ Gas-Oil ~ 002722": {
            "id": "202510200017",
            "barcode": "002722",
            "place": "Gas-Oil",
            "designation": "Gas Oil"
        },
        "Peinture de signalisation ECOLACK BLEU ~ Peinture- ~ 002723": {
            "id": "202510200018",
            "barcode": "002723",
            "place": "Peinture-",
            "designation": "Peinture de signalisation ECOLACK BLEU"
        },
        "Lubrifiant haute température ~ Lubrifian ~ 002724": {
            "id": "202510200019",
            "barcode": "002724",
            "place": "Lubrifian",
            "designation": "Lubrifiant haute température"
        },
        "Peinture ACRYLIC RAL3000 ~ Peinture- ~ 002725": {
            "id": "202510200020",
            "barcode": "002725",
            "place": "Peinture-",
            "designation": "Peinture ACRYLIC RAL3000"
        },
        "Peinture routière PILAXIAL ~ Peinture- ~ 002726": {
            "id": "202510200021",
            "barcode": "002726",
            "place": "Peinture-",
            "designation": "Peinture routière PILAXIAL"
        }
    },
    "Local informatique": {
        "Batterie MC55xx/67 li-ion 3600mAh pour sapette ZEBRA expédition ~ Batterie- ~ 002502": {
            "id": "202311160002",
            "barcode": "002502",
            "place": "Batterie-",
            "designation": "Batterie MC55xx/67 li-ion 3600mAh pour sapette ZEBRA expédition"
        },
        "Batterie de rechange pour combiné DECT 8232 BATTERIE ALCATEL DECT 82-32 (=RTR001F01) vendu par 5 ~ Batterie- ~ 002507": {
            "id": "202311270001",
            "barcode": "002507",
            "place": "Batterie-",
            "designation": "Batterie de rechange pour combiné DECT 8232 BATTERIE ALCATEL DECT 82-32 (=RTR001F01) vendu par 5"
        },
        "House pour pocket ZEBRA expédition ~ House-pou ~ 002611": {
            "id": "202409200001",
            "barcode": "002611",
            "place": "House-pou",
            "designation": "House pour pocket ZEBRA expédition"
        },
        "combiné de téléphone DECT 8232 ~ combiné-d ~ 002614": {
            "id": "202410150001",
            "barcode": "002614",
            "place": "combiné-d",
            "designation": "combiné de téléphone DECT 8232"
        },
        "Telecommande de portail marque Cardin référence : S449 QZ/2 ~ Telecomma ~ 002618": {
            "id": "202410240001",
            "barcode": "002618",
            "place": "Telecomma",
            "designation": "Telecommande de portail marque Cardin référence : S449 QZ/2"
        }
    },
    "Mezzanine maintenance": {
        "Tempo genou droit MM1/2'' levier l 350 ~ Tempo-gen ~ 001731": {
            "id": "201912200003",
            "barcode": "001731",
            "place": "Tempo-gen",
            "designation": "Tempo genou droit MM1/2'' levier l 350"
        },
        "Grille siphon sanitaire ~ Grille-si ~ 002066": {
            "id": "202110270003",
            "barcode": "002066",
            "place": "Grille-si",
            "designation": "Grille siphon sanitaire"
        },
        "Recharge de prefiltre type G4 (3543) pour type 80 ~ Recharge- ~ 002182": {
            "id": "202201200001",
            "barcode": "002182",
            "place": "Recharge-",
            "designation": "Recharge de prefiltre type G4 (3543) pour type 80"
        },
        "Projecteurs LED 150W IP65 standart Dimmable ~ Projecteu ~ 002612": {
            "id": "202410040001",
            "barcode": "002612",
            "place": "Projecteu",
            "designation": "Projecteurs LED 150W IP65 standart Dimmable"
        },
        "Dalles lumineuses (plafonnier a led pour couloir et bureau) ~ Dalles-lu ~ 002613": {
            "id": "202410040002",
            "barcode": "002613",
            "place": "Dalles-lu",
            "designation": "Dalles lumineuses (plafonnier a led pour couloir et bureau)"
        },
        "Flexible pour WC tuyau d'eau ~ Flexible- ~ 002683": {
            "id": "202504180002",
            "barcode": "002683",
            "place": "Flexible-",
            "designation": "Flexible pour WC tuyau d'eau"
        },
        "Tube IRO diametre 16 (IRL16T) ~ Tube-IRO- ~ 000001": {
            "id": "202505060001",
            "barcode": "000001",
            "place": "Tube-IRO-",
            "designation": "Tube IRO diametre 16 (IRL16T)"
        },
        "Tube IRO diametre 20 (IRL20T) ~ Tube-IRO- ~ 000001": {
            "id": "202505060001",
            "barcode": "000001",
            "place": "Tube-IRO-",
            "designation": "Tube IRO diametre 20 (IRL20T)"
        }
    },
    "Non géré": {
        "Relais de securite PHOENIX CONTACT ~ Relais-de ~ 001949": {
            "id": "202104190002",
            "barcode": "001949",
            "place": "Relais-de",
            "designation": "Relais de securite PHOENIX CONTACT"
        },
        "Manager de combustion w-fm25 ~ Manager-d ~ 002064": {
            "id": "202110270001",
            "barcode": "002064",
            "place": "Manager-d",
            "designation": "Manager de combustion w-fm25"
        },
        "Etrier de maintien Wg 10/20 ~ Etrier-de ~ 002065": {
            "id": "202110270002",
            "barcode": "002065",
            "place": "Etrier-de",
            "designation": "Etrier de maintien Wg 10/20"
        },
        "Lecteur de puce RFID HF DATAMARS ~ Lecteur-d ~ 002301": {
            "id": "202212060001",
            "barcode": "002301",
            "place": "Lecteur-d",
            "designation": "Lecteur de puce RFID HF DATAMARS"
        },
        "Antenne A-PO 1300 RAQUETTE DATAMARS ~ Antenne-A ~ 002302": {
            "id": "202212060002",
            "barcode": "002302",
            "place": "Antenne-A",
            "designation": "Antenne A-PO 1300 RAQUETTE DATAMARS"
        },
        "Fusible couteaux T00 63AGL ~ Fusible-c ~ 002342": {
            "id": "202303160001",
            "barcode": "002342",
            "place": "Fusible-c",
            "designation": "Fusible couteaux T00 63AGL"
        }
    },
    "NON STOCKER": {
        "Joint TSNU 09/ palier sng 509 vendu par pair ~ Joint-TSN ~ 001753": {
            "id": "202003110001",
            "barcode": "001753",
            "place": "Joint-TSN",
            "designation": "Joint TSNU 09/ palier sng 509 vendu par pair"
        },
        "Fermeture elecromagnetique ~ Fermeture ~ 001789": {
            "id": "202004060006",
            "barcode": "001789",
            "place": "Fermeture",
            "designation": "Fermeture elecromagnetique"
        },
        "Profil 38-1968-4 ~ Profil-38 ~ 001890": {
            "id": "202012180001",
            "barcode": "001890",
            "place": "Profil-38",
            "designation": "Profil 38-1968-4"
        },
        "Bague bronze a collerette maximat 10/13 .10 ~ Bague-bro ~ 001934": {
            "id": "202103260003",
            "barcode": "001934",
            "place": "Bague-bro",
            "designation": "Bague bronze a collerette maximat 10/13 .10"
        },
        "Vis hexagonale M10X40 pour ressort pneumatique FS200-10 ~ Vis-hexag ~ 002411": {
            "id": "202307260007",
            "barcode": "002411",
            "place": "Vis-hexag",
            "designation": "Vis hexagonale M10X40 pour ressort pneumatique FS200-10"
        },
        "Amortisseur de direction ~ Amortisse ~ 002412": {
            "id": "202307260008",
            "barcode": "002412",
            "place": "Amortisse",
            "designation": "Amortisseur de direction"
        },
        "Rondelle 10.5-A2 pour ressort pneumatique FS200-10 ~ Rondelle- ~ 002413": {
            "id": "202307260009",
            "barcode": "002413",
            "place": "Rondelle-",
            "designation": "Rondelle 10.5-A2 pour ressort pneumatique FS200-10"
        },
        "Rondelle de securite pour ressort pneumatique FS200-10 ~ Rondelle- ~ 002414": {
            "id": "202307260010",
            "barcode": "002414",
            "place": "Rondelle-",
            "designation": "Rondelle de securite pour ressort pneumatique FS200-10"
        },
        "Coussin d'air ( RESSORT PNEUMATIQUE FS 200-10 ) ~ Coussin-d ~ 002415": {
            "id": "202307270001",
            "barcode": "002415",
            "place": "Coussin-d",
            "designation": "Coussin d'air ( RESSORT PNEUMATIQUE FS 200-10 )"
        },
        "Harnais de câbles grande PS40-100NT ~ Harnais-d ~ 002446": {
            "id": "202308090026",
            "barcode": "002446",
            "place": "Harnais-d",
            "designation": "Harnais de câbles grande PS40-100NT"
        },
        "Raccords fileté pour câbles ~ Raccords- ~ 002447": {
            "id": "202308090027",
            "barcode": "002447",
            "place": "Raccords-",
            "designation": "Raccords fileté pour câbles"
        },
        "Raccords de tuyau ~ Raccords- ~ 002450": {
            "id": "202308140001",
            "barcode": "002450",
            "place": "Raccords-",
            "designation": "Raccords de tuyau"
        },
        "Bride de tuyau 8-16 ~ Bride-de- ~ 002451": {
            "id": "202308140002",
            "barcode": "002451",
            "place": "Bride-de-",
            "designation": "Bride de tuyau 8-16"
        },
        "Contre ecrou M25x1,5 ~ Contre-ec ~ 002452": {
            "id": "202308140003",
            "barcode": "002452",
            "place": "Contre-ec",
            "designation": "Contre ecrou M25x1,5"
        },
        "Tuyau PS40-100 ~ Tuyau-PS4 ~ 002453": {
            "id": "202308140004",
            "barcode": "002453",
            "place": "Tuyau-PS4",
            "designation": "Tuyau PS40-100"
        },
        "Arbre 12/10 l=615 de sortie roll on ~ Arbre-12 ~ 002517": {
            "id": "202312190001",
            "barcode": "002517",
            "place": "Arbre-12",
            "designation": "Arbre 12/10 l=615 de sortie roll on"
        },
        "Rouleau d:22mm L=61mm de sortie roll on ~ Rouleau-d ~ 002550": {
            "id": "202402160001",
            "barcode": "002550",
            "place": "Rouleau-d",
            "designation": "Rouleau d:22mm L=61mm de sortie roll on"
        }
    },
    "RDC maintenance": {
        "Puce LOGITAG pour Cintres ~ Puce-LOGI ~ 000219": {
            "id": "201901180012",
            "barcode": "000219",
            "place": "Puce-LOGI",
            "designation": "Puce LOGITAG pour Cintres"
        },
        "Pompe submersible forage ~ Pompe-sub ~ 000485": {
            "id": "201903050044",
            "barcode": "000485",
            "place": "Pompe-sub",
            "designation": "Pompe submersible forage"
        },
        "Roulette pour navette a platine pivotante roue 125 avec frein noir ~ Roulette- ~ 001728": {
            "id": "201912180001",
            "barcode": "001728",
            "place": "Roulette-",
            "designation": "Roulette pour navette a platine pivotante roue 125 avec frein noir"
        },
        "Plafonnier à led (réglette a led ) ~ Plafonnie ~ 001804": {
            "id": "202004080009",
            "barcode": "001804",
            "place": "Plafonnie",
            "designation": "Plafonnier à led (réglette a led )"
        },
        "Verin hydraulique de cuve presse 10 ~ Verin-hyd ~ 001823": {
            "id": "202004270001",
            "barcode": "001823",
            "place": "Verin-hyd",
            "designation": "Verin hydraulique de cuve presse 10"
        },
        "Bouteille argon 4.5 2.3m3 ~ Bouteille ~ 001839": {
            "id": "202006220002",
            "barcode": "001839",
            "place": "Bouteille",
            "designation": "Bouteille argon 4.5 2.3m3"
        },
        "Puce LOGITAG pour Navettes ~ Puce-LOGI ~ 001903": {
            "id": "202101140001",
            "barcode": "001903",
            "place": "Puce-LOGI",
            "designation": "Puce LOGITAG pour Navettes"
        },
        "Motoréducteur linge sale VC1 nord green 2.2kw ~ Motoréduc ~ 001956": {
            "id": "202105030001",
            "barcode": "001956",
            "place": "Motoréduc",
            "designation": "Motoréducteur linge sale VC1 nord green 2.2kw"
        },
        "Moteur B5 kuenie ou Vem 7.5Kw ~ Moteur-B5 ~ 001962": {
            "id": "202105140001",
            "barcode": "001962",
            "place": "Moteur-B5",
            "designation": "Moteur B5 kuenie ou Vem 7.5Kw"
        },
        "Palan DEMAG type DC PRO demag 500kg ~ Palan-DEM ~ 002159": {
            "id": "202111170008",
            "barcode": "002159",
            "place": "Palan-DEM",
            "designation": "Palan DEMAG type DC PRO demag 500kg"
        },
        "Moteur pompe centrifuge PP (bleu sans copot ventilo ) ~ Moteur-po ~ 002160": {
            "id": "202111170009",
            "barcode": "002160",
            "place": "Moteur-po",
            "designation": "Moteur pompe centrifuge PP (bleu sans copot ventilo )"
        },
        "Pompe centrifuge PP ~ Pompe-cen ~ 002161": {
            "id": "202111170010",
            "barcode": "002161",
            "place": "Pompe-cen",
            "designation": "Pompe centrifuge PP"
        },
        "Réducteur planétaire coude F HPM12 gaz (en pieces détachées) pour GP ~ Réducteur ~ 002162": {
            "id": "202111170011",
            "barcode": "002162",
            "place": "Réducteur",
            "designation": "Réducteur planétaire coude F HPM12 gaz (en pieces détachées) pour GP"
        },
        "Moteur 15 kw pour réducteur planétaire coude F HPM12 gaz (en pieces détachées) pour GP ~ Moteur-15 ~ 002163": {
            "id": "202111170012",
            "barcode": "002163",
            "place": "Moteur-15",
            "designation": "Moteur 15 kw pour réducteur planétaire coude F HPM12 gaz (en pieces détachées) pour GP"
        },
        "Tole perforée sechoir kannegiesser D40 ~ Tole-perf ~ 002164": {
            "id": "202111170013",
            "barcode": "002164",
            "place": "Tole-perf",
            "designation": "Tole perforée sechoir kannegiesser D40"
        },
        "Motoréducteur planétaire coude pour PP occasion ~ Motoréduc ~ 002272": {
            "id": "202209300001",
            "barcode": "002272",
            "place": "Motoréduc",
            "designation": "Motoréducteur planétaire coude pour PP occasion"
        },
        "Filtre à peluches séchoir kannegiesser ~ Filtre-à- ~ 002295": {
            "id": "202211240001",
            "barcode": "002295",
            "place": "Filtre-à-",
            "designation": "Filtre à peluches séchoir kannegiesser"
        },
        "Pompe a eau de circulation chaudière ~ Pompe-a-e ~ 002351": {
            "id": "202304110001",
            "barcode": "002351",
            "place": "Pompe-a-e",
            "designation": "Pompe a eau de circulation chaudière"
        },
        "Jeu de flexibles hydrauliques presse 10 ~ Jeu-de-fl ~ 002421": {
            "id": "202308090001",
            "barcode": "002421",
            "place": "Jeu-de-fl",
            "designation": "Jeu de flexibles hydrauliques presse 10"
        },
        "Feutre PE/aramide 4000/345 LE M coupe 3850X3450 (molleton) ~ Feutre-PE ~ 002504": {
            "id": "202311220002",
            "barcode": "002504",
            "place": "Feutre-PE",
            "designation": "Feutre PE/aramide 4000/345 LE M coupe 3850X3450 (molleton)"
        },
        "Roulette pour navette a platine pivotante roue 125 avec frein bleu ~ Roulette- ~ 002506": {
            "id": "202311240001",
            "barcode": "002506",
            "place": "Roulette-",
            "designation": "Roulette pour navette a platine pivotante roue 125 avec frein bleu"
        },
        "Vérin complet Kanne diamètre 250 course 160 pour calandre GP avec bride et chape avant ~ Vérin-com ~ 002561": {
            "id": "202404220001",
            "barcode": "002561",
            "place": "Vérin-com",
            "designation": "Vérin complet Kanne diamètre 250 course 160 pour calandre GP avec bride et chape avant"
        },
        "Vérin festo diamètre 250 course 160 pour calandre GP sans bride et chape avant ~ Vérin-fes ~ 002562": {
            "id": "202404220002",
            "barcode": "002562",
            "place": "Vérin-fes",
            "designation": "Vérin festo diamètre 250 course 160 pour calandre GP sans bride et chape avant"
        },
        "Bride d'orientation pour vérin festo diamètre 250 course 160 pour calandre GP ~ Bride-do ~ 002563": {
            "id": "202404220003",
            "barcode": "002563",
            "place": "Bride-do",
            "designation": "Bride d'orientation pour vérin festo diamètre 250 course 160 pour calandre GP"
        },
        "Chape avant (tete articulée) pour vérin festo diamètre 250 course 160 pour calandre GP ~ Chape-ava ~ 002564": {
            "id": "202404220004",
            "barcode": "002564",
            "place": "Chape-ava",
            "designation": "Chape avant (tete articulée) pour vérin festo diamètre 250 course 160 pour calandre GP"
        },
        "Cable plat pour navette industrielle bobine de 50m ~ Cable-pla ~ 002600": {
            "id": "202407190001",
            "barcode": "002600",
            "place": "Cable-pla",
            "designation": "Cable plat pour navette industrielle bobine de 50m"
        },
        "Ressort de rouleau de calandre ~ Ressort-d ~ 002601": {
            "id": "202407190002",
            "barcode": "002601",
            "place": "Ressort-d",
            "designation": "Ressort de rouleau de calandre"
        },
        "Moteur 2.2KW et turbine 230/400 turbine air extraction de L'AIR A L'EXTÉRIEUR ~ Moteur-2 ~ 002638": {
            "id": "202501170001",
            "barcode": "002638",
            "place": "Moteur-2",
            "designation": "Moteur 2.2KW et turbine 230/400 turbine air extraction de L'AIR A L'EXTÉRIEUR"
        },
        "Fusible 2A pour poste a souder taille 6*32 ~ Fusible-2 ~ 002640": {
            "id": "202501310001",
            "barcode": "002640",
            "place": "Fusible-2",
            "designation": "Fusible 2A pour poste a souder taille 6*32"
        },
        "Turbine air extraction Gauche ~ Turbine-a ~ 000001": {
            "id": "202505090001",
            "barcode": "000001",
            "place": "Turbine-a",
            "designation": "Turbine air extraction Gauche"
        },
        "Fixation Moteur/Turbine air extraction ~ Fixation- ~ 000001": {
            "id": "202505090001",
            "barcode": "000001",
            "place": "Fixation-",
            "designation": "Fixation Moteur/Turbine air extraction"
        },
        "Ruban signalisation Rubaplast rouge/blanc 100mx50mm 54 03 44 ~ Ruban-sig ~ 002688": {
            "id": "202505230001",
            "barcode": "002688",
            "place": "Ruban-sig",
            "designation": "Ruban signalisation Rubaplast rouge/blanc 100mx50mm 54 03 44"
        },
        "Moteur Ventilateur pour aérotherme ~ Moteur-Ve ~ 002739": {
            "id": "202512300001",
            "barcode": "002739",
            "place": "Moteur-Ve",
            "designation": "Moteur Ventilateur pour aérotherme"
        },
        "Armoire en commun": {
            "Flexible sanitaire L500 FF 3/8 ~ R ~ 002682": {
                "id": "202504180001",
                "barcode": "002682",
                "place": "R",
                "designation": "Flexible sanitaire L500 FF 3/8"
            }
        }
    },
    "réparation extétieur automatisme électrique": {
        "Ecran tactile engageuse PP ~ Ecran-tac ~ 002644": {
            "id": "202502210001",
            "barcode": "002644",
            "place": "Ecran-tac",
            "designation": "Ecran tactile engageuse PP"
        }
    }
};