


// Appeler cette fonction au chargement de la page


function getInterventions() {
    const urlParams = new URLSearchParams(window.location.search);
    const username = urlParams.get('user');

    // Ajoutez un timestamp à l'URL pour éviter la mise en cache
    const url = `../data/user/${username}_${CléType}.csv?timestamp=${new Date().getTime()}`;

    fetch(url)
        .then(response => {
            if (!response.ok) {
                alert("Aucune donnée à afficher");
                throw new Error('Erreur lors du chargement du fichier CSV');
            }
            return response.text();
        })
        .then(data => {
            if (!data.trim()) {
                // Vérifie si le fichier est vide
                alert("Aucune donnée à afficher");
                return;
            }
            openNewTabWithTable(data);
        })
        .catch(error => {
            console.error('Erreur :', error);
        });
}

function openNewTabWithTable(data) {
    const urlParams = new URLSearchParams(window.location.search);
    const username = urlParams.get('user') || "Utilisateur";

    // Construction du tableau
    const rows = data.split('\n');
    let tableHtml = `<div class="responsive-table-container"><table>`;
    
    rows.forEach((row, index) => {
        if (!row.trim()) return;
        const cols = row.split(';');
        tableHtml += '<tr>';
        cols.forEach(col => {
            tableHtml += index === 0 ? `<th>${col}</th>` : `<td>${col}</td>`;
        });
        tableHtml += '</tr>';
    });
    tableHtml += '</table></div>';

    const modalContent = document.getElementById('modalContent');
    if (!modalContent) return;

    // Injection de la structure unifiée
    modalContent.innerHTML = `
        <div class="modal-header-fixed">
            <span class="close">&times;</span>
            <h2 style="margin:0; font-size:1.1rem;">Interventions de ${username}</h2>
        </div>
        <div class="modal-body-scroll">
            ${tableHtml}
        </div>
    `;

    // Affichage
    const modal = document.getElementById('dataModal');
    if (modal) modal.style.display = 'block';

    // Gestion de la fermeture
    const closeBtn = modalContent.querySelector('.close');
    if (closeBtn) closeBtn.onclick = () => modal.style.display = 'none';
    
    window.onclick = (event) => { 
        if (event.target == modal) modal.style.display = 'none'; 
    };
}

function ajouterInformationsSupplementaires(data) {
    // Récupérer le paramètre "user" depuis l'URL
    const urlParams = new URLSearchParams(window.location.search);
    const user = urlParams.get('user') || 'Utilisateur inconnu'; // Valeur par défaut si "user" n'est pas présent

    const parties = data.split('_').map(partie => partie.trim());
    const id = generateUniqueId();

    // Obtenir l'heure actuelle au format HH:mm:ss
    const maintenant = new Date();
    const heureEnregistrement = `${maintenant.getHours().toString().padStart(2, '0')}:${maintenant.getMinutes().toString().padStart(2, '0')}:${maintenant.getSeconds().toString().padStart(2, '0')}`;

    // Retourner l'objet avec toutes les informations, y compris "Tech" pour l'utilisateur et l'heure d'enregistrement
    return {
        id,
        date: parties[0],
        temps: parties[1],
        zoneTexte1: parties[2],
        zoneTexte2: parties[3],
        zoneTexte3: parties[4],
        zoneTexte4: parties[5],
        zoneTexte5: parties[6],
        zoneTexte6: parties[7],
        Tech: user, // Ajouter l'utilisateur comme technicien
        heureEnregistrement // Ajouter l'heure d'enregistrement
    };
}



let searchActive = false; // Variable pour suivre l'état de la recherche

// Importez la bibliothèque "unorm" si elle n'est pas déjà incluse dans votre projet
// Exemple : <script src="https://unpkg.com/unorm@1.4.1"></script>

function normalizeString(str) {
    return (str || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}


let isChronosActif = true; // Variable pour suivre l'état actuel



// Appeler cette fonction pour exporter vers le serveur
function exportServ() {
    exportInterventions('server');
}

// Appeler cette fonction pour télécharger localement
function exportToTxt() {
    exportInterventions('local');
}

// Fonction pour convertir les dates au format YYYYMMDD
function formatDate(dateStr) {
    if (!dateStr) return "0";
    const [day, month, year] = dateStr.split('/').map(part => part.padStart(2, '0'));
    return `${year}${month}${day}`;
}


function convertToHours(timeStr) {
    if (!timeStr) return 0;

    // Regex pour capturer les heures et minutes
    const regex = /(\d{1,2}):(\d{2})/;
    const matches = timeStr.match(regex);

    if (matches) {
        const hh = parseInt(matches[1], 10); // Extraction des heures
        const mm = parseInt(matches[2], 10); // Extraction des minutes

        // Conversion : heures + (minutes converties en fraction d'heure)
        return hh + mm / 60;
    }

    return 0; // Si le format est invalide, on retourne 0
}


function convertToHourssnd(timeString) {
    // Variables pour stocker les valeurs extraites
    let days = 0,
        hours = 0,
        minutes = 0,
        seconds = 0;

    // Regex pour capturer les jours, heures, minutes et secondes (meilleure gestion des espaces)
    const regex = /(?:(\d+)j)?\s*(?:(\d+)h)?\s*(?:(\d+)m)?\s*(?:(\d+)s)?/;
    const match = timeString.match(regex);

    if (match) {
        // Si les valeurs existent, les convertir en nombres, sinon 0
        days = match[1] ? parseInt(match[1]) : 0;
        hours = match[2] ? parseInt(match[2]) : 0;
        minutes = match[3] ? parseInt(match[3]) : 0;
        seconds = match[4] ? parseInt(match[4]) : 0;
    }

    // Conversion en heures
    let totalHours = (days * 24) + hours + (minutes / 60) + (seconds / 3600);

    // Si le total est inférieur à 1 minute, on considère que c'est au moins 1 minute
    if (totalHours < 1 / 60) {
        totalHours = 1 / 60; // correspond à 1 minute, soit environ 0.0167 heures
    }

    return totalHours.toFixed(3); // Limite à 3 décimales pour l'affichage
}



exportInterventions = async function(exportType) {
    let urlParams = new URLSearchParams(window.location.search);
    let utilisateurExclu = urlParams.get('user'); 
    let clé = utilisateurExclu + '_uver';
    
    // Récupération du mode
    const CléType = localStorage.getItem(clé) || 'Work'; 

    const enregistrementsString = await getPrefixedItem('enregistrements');
    if (!enregistrementsString) return;

    let enregistrements = JSON.parse(enregistrementsString);
    const user = decodeURIComponent(urlParams.get('user')) || "Utilisateur inconnu";

    let csvContent = "";
    // --- TES NOUVEAUX ENTÊTES ---
    if (CléType === 'Priv') {
        csvContent = "ID;Date intervention;Numéro de fiche;Compteur machine;Nom Fiche(not use);Remarque;Pièces;Durée arrêt (h);Personnel;Nombre d'heures\n";
    } else {
        csvContent = "ID;Date intervention;Désignation machine;Type de panne;Cause;Résumé intervention;Pièces;Durée arrêt (h);Personnel;Temps\n";
    }

    enregistrements.forEach((record) => {
        if (record) {
            const id = record.id || "0";
            const dateIntervention = record.date ? formatDate(record.date) : "0";
            const col2 = record.zoneTexte1 || "0"; 
            const col3 = record.zoneTexte4 || "0"; 
            
            let col4;
            const modeActuel = (CléType || "").trim();
            
            console.log("--- Debug Ligne ---");
            console.log("Mode détecté (CléType):", modeActuel);
            console.log("zoneTexte1 (N° Fiche):", record.zoneTexte1);

            if (modeActuel === 'Priv') {
                console.log("Passage en mode PRIV détecté");
                
                if (typeof findCodeByFicheNumber === "function") {
                    const result = findCodeByFicheNumber(record.zoneTexte1);
                    console.log("Résultat de findCodeByFicheNumber:", result);
                    
                    col4 = result || "Code non trouvé pour " + record.zoneTexte1;
                } else {
                    console.error("ERREUR : La fonction findCodeByFicheNumber n'existe pas ou n'est pas chargée.");
                    col4 = "Fonction findCode manquante";
                }
            } else {
                console.log("Passage en mode WORK (Correctif)");
                col4 = record.zoneTexte5 || "0";
            }
            
            console.log("Valeur finale affectée à col4:", col4);
            const resumeIntervention = record.zoneTexte2 || "0";
            const piecesEnregistre = record.zoneTexte3 || "";
            const dureeArret = record.zoneTexte6 ? convertToHours(record.zoneTexte6) : "0";
            const personnel = record.Tech ? record.Tech : user;
            const nombreHeures = record.temps ? convertToHourssnd(record.temps) : "0";

            // Construction de la ligne CSV
            csvContent += `${id};${dateIntervention};${col2};${col3};${col4};${resumeIntervention};${piecesEnregistre};${dureeArret};${personnel};${nombreHeures}\n`;
        }
    });

    const bom = "\uFEFF";
    const finalContent = bom + csvContent;

    if (exportType === 'server') {
        const formData = new FormData();
        formData.append("user", user);
        formData.append("csvContent", finalContent);
        formData.append("cleType", CléType);

        try {
            const response = await fetch("PHP/save_interventions.php", { method: "POST", body: formData });
            const result = await response.json();
            if (result.success) {
                alert("Les interventions ont été enregistrées.");
                await removePrefixedItem('enregistrements');
                setTimeout(afficherEnregistrements, 500);
            } else {
                alert("Erreur serveur : " + result.error);
            }
        } catch (error) {
            console.error("Erreur export:", error);
        }
    }
};


async function exportBRUTTxt() {
    // Récupérer l'enregistrement
    const enregistrements = await getPrefixedItem('enregistrements');

    if (!enregistrements) {
        console.error('Aucun enregistrement trouvé');
        return;
    }

    // Conversion en JSON si ce n'est pas déjà fait
    const parsedEnregistrements = JSON.parse(enregistrements);

    // Transformer chaque enregistrement en une chaîne formatée brute
    const contenuFormate = parsedEnregistrements.map(enregistrement => {
        return JSON.stringify(enregistrement, null, 2); // Formater chaque enregistrement comme une chaîne JSON brute
    }).join("\n"); // Joindre tous les enregistrements avec une nouvelle ligne entre eux

    // Créer un Blob avec le contenu brut
    const blob = new Blob([contenuFormate], {
        type: 'text/plain'
    });

    // Créer un lien temporaire pour télécharger le fichier
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'enregistrements_brut.txt'; // Nom du fichier
    document.body.appendChild(a);
    a.click();

    // Nettoyer le lien temporaire
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}