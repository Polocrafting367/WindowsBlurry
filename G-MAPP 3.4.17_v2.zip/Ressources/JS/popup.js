document.getElementById('resetNotifButton').addEventListener('click', async () => {
  if (confirm("Voulez-vous vraiment réinitialiser toutes les notifications ?")) {
    await removePrefixedItem('popup_aide_global');

    await removePrefixedItem('Notification');
    await removePrefixedItem('NotificationEtModal');

    alert("✅ Notifications réinitialisées.");
  }
});



// Liste temporaire des popups affichées (mémoire vive uniquement)
const popupsActives = new Set();



async function afficherPopupAideCustom(target, texte, cleStorage, maxAffichages = 7) {
  let state = await getPopupState();

  if (state[cleStorage] === 'fermé') return;

  let compteur = parseInt(state[cleStorage] || '0', 10);
  if (compteur >= maxAffichages) {
    state[cleStorage] = 'fermé';
    await setPopupState(state);
    return;
  }
  state[cleStorage] = String(compteur + 1);
  await setPopupState(state);

  let elementCible = null;
  if (typeof target === 'string') {
    if (target.startsWith('#')) {
      elementCible = document.getElementById(target.substring(1));
    } else if (target.startsWith('.')) {
      const collection = document.getElementsByClassName(target.substring(1));
      elementCible = collection.length > 0 ? collection[0] : null;
    } else {
      elementCible = document.querySelector(target);
    }
  } else if (target instanceof HTMLElement) {
    elementCible = target;
  }

  if (!elementCible) {
    console.warn("Cible introuvable :", target);
    return;
  }

  if (popupsActives.has(elementCible)) {
    console.log("Popup déjà affichée pour cette cible");
    return;
  }

  popupsActives.add(elementCible);

  const popup = document.createElement('div');
  popup.className = 'popup-aide';
  popup.innerHTML = `
    <span class="popup-aide-close" title="Ne plus afficher">&times;</span>
    <div class="popup-aide-body">${texte}</div>
  `;

  elementCible.appendChild(popup);

  const dureeAffichage = 7000;
setTimeout(() => {
    // 1. Mesure la hauteur actuelle
    const currentHeight = popup.offsetHeight + "px";

    // 2. Applique cette hauteur fixe avant transition
    popup.style.height = currentHeight;

    // 3. Oblige le navigateur à prendre en compte cette hauteur (reflow forcé)
    popup.offsetHeight;  // forcer un reflow

    // 4. Applique la transition et réduit à 0
    popup.style.transition = "height 500ms ease, opacity 500ms ease";
    popup.style.height = "0px";
    popup.style.opacity = "0";

    // 5. Supprime après la transition
    setTimeout(() => {
        popup.remove();
        popupsActives.delete(elementCible);
    }, 500);
}, dureeAffichage);


  popup.querySelector('.popup-aide-close').addEventListener('click', async () => {
    popup.remove();
    popupsActives.delete(elementCible);
    state = await getPopupState();
    state[cleStorage] = 'fermé';
    await setPopupState(state);
  });
}


async function getPopupState() {
  const data = await getPrefixedItem('popup_aide_global');
  if (!data) return {};

  if (typeof data === 'string') {
    try {
      return JSON.parse(data);
    } catch (e) {
      console.error("❌ Erreur de parsing JSON:", e);
      return {};
    }
  }

  // Si déjà objet
  return data;
}


async function setPopupState(state) {
  await setPrefixedItem('popup_aide_global', JSON.stringify(state));
}


//afficherPopupAideCustom(
//      ".scrollable-tabs",
 //     `Il est maintenant possible de réorganiser les notes via le <>`,
 //     'pop_note_tab',
 //     7
 //   ); 

const DUREE_NOTIFICATION = 7500;
const KEY_DESACTIVATION_GLOBAL = 'Notification_Date_Disabled';
const DELAI_INITIAL_MS = 500; // Délai d'attente initial (0.5 seconde)

/**
 * Lit le contenu d'un fichier et retourne la première ligne.
 */
async function lirePremiereDate(url) {
    try {
        const response = await fetch(url);
        if (!response.ok) {
            // Pas de log d'erreur ici pour rester discret, sauf si critique
            return null;
        }
        const text = await response.text();
        const lignes = text.trim().split('\n');
        return lignes.length > 0 && lignes[0].trim() !== '' ? lignes[0].trim() : null;
    } catch (error) {
        return null;
    }
}

/**
 * Calcule la différence en jours entre deux dates.
 */
function diffJours(d1, d2) {
    const ONE_DAY = 1000 * 60 * 60 * 24;
    const date1 = new Date(d1.getFullYear(), d1.getMonth(), d1.getDate());
    const date2 = new Date(d2.getFullYear(), d2.getMonth(), d2.getDate());
    const diffTime = Math.abs(date2.getTime() - date1.getTime());
    return Math.floor(diffTime / ONE_DAY);
}


/**
 * Calcule la différence en mois entre deux dates.
 */
function diffMois(d1, d2) {
    let mois = (d2.getFullYear() - d1.getFullYear()) * 12;
    mois -= d1.getMonth();
    mois += d2.getMonth();
    return Math.max(0, mois); 
}

function formaterDateJourMois(dateString) {
    // La date doit être traitée comme UTC pour éviter les décalages horaires
    const dateParts = dateString.split('-');
    // Date.UTC(année, mois-1, jour)
    const date = new Date(Date.UTC(dateParts[0], dateParts[1] - 1, dateParts[2]));
    
    // Si la date est invalide
    if (isNaN(date.getTime())) {
        return dateString; 
    }

    // Changement ici : 'short' pour le mois pour obtenir 'jan', 'fév', 'mar', etc.
    const options = { day: '2-digit', month: 'short' };
    
    // Ajout d'une manipulation pour retirer le point final qui apparaît souvent avec 'short' (ex: déc.)
    let dateFormatee = date.toLocaleDateString('fr-FR', options);

    // Suppression du point final si présent pour un affichage plus propre (ex: 12 déc.)
    dateFormatee = dateFormatee.replace('.', ''); 

    return dateFormatee;
}


/**
 * Gère l'affichage séquentiel des notifications liées aux dates de sauvegarde.
 */
async function gererNotificationsDates() {
    
    // 1. Vérification de la désactivation
    const notificationsDesactivees = await getPrefixedItem(KEY_DESACTIVATION_GLOBAL);
    if (notificationsDesactivees === 'disabled') {
        return;
    }
    
    const aujourdHui = new Date();
    const notificationsAEnvoyer = [];

    // --- 1. VÉRIFICATION DE ../date_LM.txt (Sauvegarde) ---
    const dateSauvegardeStr = await lirePremiereDate('../date_LM.txt');
    
    if (dateSauvegardeStr) {
        const dateSauvegarde = new Date(dateSauvegardeStr + 'T00:00:00');
        if (!isNaN(dateSauvegarde.getTime())) {
            const joursEcoules = diffJours(dateSauvegarde, aujourdHui);
    
            if (joursEcoules > 12) {
                const dateFormatee = formaterDateJourMois(dateSauvegardeStr);
                
                // MESSAGE COURT N°1 :
                notificationsAEnvoyer.push({
                    message: `⚠️ Dernier export : ${dateFormatee} (>${joursEcoules}j)`, // Ex: Exportation: 12 déc. (>1827j)
                    couleurTxt: 'white',
                    couleurBg: '#E74C3C',
                });
            }
        }
    }

    // --- 2. VÉRIFICATION DE ../date_LM_JS.txt (Lieux et Pièces) ---
    try {
        const response = await fetch('../date_LM_JS.txt');
        if (response.ok) {
            const text = await response.text();
            const lignes = text.trim().split('\n').map(l => l.trim()).filter(l => l.length > 0);
            

            if (lignes.length >= 2) {
                const datePiecesStr = lignes[1];
                const datePieces = new Date(datePiecesStr + 'T00:00:00');
                if (!isNaN(datePieces.getTime())) {
                    const moisEcoules = diffMois(datePieces, aujourdHui);
                    if (moisEcoules > 6) {
                        // MESSAGE COURT N°3 :
                        notificationsAEnvoyer.push({
                            message: `Pièces : MAJ > 6 mois (${moisEcoules}mois)`, // Ex: Pièces: Mise à jour > 6 mois (8m)
                            couleurTxt: 'white',
                            couleurBg: '#d636ac',
                        });
                    }
                }
            }
            
            // 2a. 1ère ligne : Lieux (> 12 mois)
            if (lignes.length >= 1) {
                const dateLieuxStr = lignes[0];
                const dateLieux = new Date(dateLieuxStr + 'T00:00:00');
                if (!isNaN(dateLieux.getTime())) {
                    const moisEcoules = diffMois(dateLieux, aujourdHui);
                    if (moisEcoules > 12) {
                        // MESSAGE COURT N°2 :
                        notificationsAEnvoyer.push({
                            message: `Lieux : MAJ > 1 ans (${moisEcoules}mois)`, // Ex: Lieux: Mise à jour > 1 an (15m)
                            couleurTxt: 'white',
                            couleurBg: '#36a2d6',
                        });
                    }
                }
            }

            // 2b. 2ème ligne : Pièces (> 6 mois)

        }
    } catch (error) {
        // Ignorer les erreurs de fetch/réseau en mode production
    }

    // --- 3. Envoi séquentiel des notifications ---
    if (notificationsAEnvoyer.length > 0) {
        // Délai initial pour stabiliser le DOM
        await new Promise(resolve => setTimeout(resolve, DELAI_INITIAL_MS));
    }
    
    for (const notif of notificationsAEnvoyer) {
        showTemporaryBannerNotification(
            notif.message,
            notif.couleurTxt,
            notif.couleurBg
        );
        
        // Attendre 7.5 secondes entre les notifications
        await new Promise(resolve => setTimeout(resolve, DUREE_NOTIFICATION));
    }
}