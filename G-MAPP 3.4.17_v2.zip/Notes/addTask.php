<?php
$data = json_decode(file_get_contents('php://input'), true);
$folderId = $data['folderId'] ?? 'notes';
$parts = explode('_key_', $folderId);
$user = $parts[0];
$notesDir = "../data/{$user}_/{$folderId}/";

$id = uniqid('note_', true);

// Calcul de la position de secours (fin de liste)
$existingFiles = glob($notesDir . '*.json');
$lastPos = count($existingFiles) + 1;

// Si le JS envoie une position, on l'utilise, sinon on met à la fin
$position = (isset($data['position']) && $data['position'] !== null) ? floatval($data['position']) : $lastPos;

$newTask = [
    'id' => $id,
    'note' => $data['note'] ?? '',
    'folderId' => $folderId,
    'importance' => $data['importance'] ?? '1',
    'createdBy' => $data['createdBy'] ?? '',
    'dateCreated' => date('Y-m-d'),
    'position' => $position,
    'completed' => false
];

file_put_contents($notesDir . $id . '.json', json_encode($newTask));

header('Content-Type: application/json');
echo json_encode($newTask);