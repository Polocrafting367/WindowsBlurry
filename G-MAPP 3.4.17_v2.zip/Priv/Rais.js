const lieuData = {
    types: [
],
    causes: [
] 
};

