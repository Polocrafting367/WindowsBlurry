const jours = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"];
let currentJourIndex = (new Date().getDay() + 6) % 7;
let exportEndHourOrigine = null;
let valeurInitialeExport = null;
let defautstart = 0;
let scaleFactor = 4;

async function loadPlanningData() {
  try {
    const select = document.getElementById("technicienSelect");
    if (select && planningData.utilisateurs) {
      select.innerHTML = "";

      const optAll = document.createElement("option");
      optAll.value = "TOUT";
      optAll.textContent = "Tout les Tech";
      select.appendChild(optAll);

      for (const nom in planningData.utilisateurs) {
        if (nom.toUpperCase() === "PAUSE") continue;
        const option = document.createElement("option");
        option.value = nom;
        option.textContent = `Tech ${nom}`;
        select.appendChild(option);
      }
    }

    buildJourSelectOptions();
    bindJourSelectChangeOnce();
    bindTechSelectChangeOnce();

    await applySavedSelectionForCurrentDay();

    // applique le verrouillage jours selon l’utilisateur courant
    syncJourSelectModeWithTech();

    const jourNom = jours[currentJourIndex];
    document.getElementById("jourAffichage").textContent = jourNom;
    document.getElementById("jourAffichageModal").textContent = jourNom;

    afficherJour(currentJourIndex);
    afficherPlanning();
  } catch (error) {
    console.error("❌ Erreur lecture Planning dans IndexedDB :", error);
    planningData = {};
  }
}


// --- utilitaires codes/dates ---
// === Utils stricts ===
function _normCode(v){ return String(v ?? "").trim().replace(/\s+/g,""); }
function _pickCode(entry){
  if (!entry || typeof entry !== "object") return "";
  return _normCode(
    entry.code ??
    entry.codeFiche ??
    entry["Numéro de fiche"] ??
    entry.numero ??
    entry.id ??
    entry.Id ??
    ""
  );
}
function _daysBetween(d1, d2){
  const MS = 24*60*60*1000;
  const a = new Date(d1); a.setHours(0,0,0,0);
  const b = new Date(d2); b.setHours(0,0,0,0);
  return Math.floor((b - a)/MS);
}
function _extractMensuelCodesFromArbo(arbo){
  const out = new Set();
  const mensuel = arbo?.Mensuel || {};
  for (const classeur of Object.values(mensuel)){
    for (const fiche of Object.values(classeur)){
      const code = _normCode(fiche?.["Numéro de fiche"]);
      if (code) out.add(code);
    }
  }
  return out;
}
function _ensureLancerButton(carteEl, codeFiche){
  const box = carteEl.querySelector(".boutons-container");
  if (!box) return;
  const hasBtn = Array.from(box.querySelectorAll("button"))
    .some(b => /lancer/i.test(b.textContent));
  if (hasBtn) return;
  const btn = document.createElement("button");
  btn.textContent = "Lancer";
  btn.addEventListener("click", ()=> ouvrirIframe(codeFiche));
  box.prepend(btn);
}
function _removeLancerButton(carteEl){
  const box = carteEl.querySelector(".boutons-container");
  if (!box) return;
  Array.from(box.querySelectorAll("button")).forEach(b=>{
    if (/lancer/i.test(b.textContent)) b.remove();
  });
}

// === Post-traitement FINI/Lancer pour Mensuels vus en lieuxHebdo ===
async function applyMensuelFiniFromHebdo() {
  const mensuelSet = _extractMensuelCodesFromArbo(arborescence);

  // Charge lieuxHebdo
  let lieuxHebdo = [];
  try {
    const data = await getPrefixedItem("lieuxHebdo");
    lieuxHebdo = JSON.parse(data || "[]");
  } catch {}

  // Map: dernier passage daté par code + set des codes vus
  const lastDateByCode = new Map();
  const seenCodes = new Set();
  for (const entry of lieuxHebdo){
    const c = _pickCode(entry);
    if (!c) continue;
    seenCodes.add(c);
    if (entry?.date){
      const d = new Date(entry.date);
      if (!Number.isNaN(d.getTime())){
        d.setHours(0,0,0,0);
        const prev = lastDateByCode.get(c);
        if (!prev || d > prev) lastDateByCode.set(c, d);
      }
    }
  }

  const today = new Date(); today.setHours(0,0,0,0);

  // Parcourt toutes les cartes affichées
  const cards = document.querySelectorAll("#cartesContainer .carte-intervention");
  cards.forEach(carte=>{
    const code = _normCode(carte.dataset.code);
    if (!code) return;

    // On n’agit que sur les mensuels effectivement vus en lieuxHebdo
    if (!seenCodes.has(code)) return;
    if (!mensuelSet.has(code)) return;

    // Imposer l’état FINI
    carte.classList.add("fini");

    // Bouton Lancer: seulement si dernière date > 25 jours
    const last = lastDateByCode.get(code) || null;
    if (last){
      const diff = _daysBetween(last, today);
      if (diff > 15) {
        _ensureLancerButton(carte, code);
      } else {
        _removeLancerButton(carte);
      }
    } else {
      // Pas de date → FINI sans Lancer
      _removeLancerButton(carte);
    }
  });
}

async function afficherPlanning() {
  const selectEl = document.getElementById("technicienSelect");
  const selected = selectEl ? selectEl.value : "TOUT";

  // filtre jour depuis le select
  const jourSel = (document.getElementById("jourSelect")?.value || "SEMAINE").toUpperCase();
  const mapJour = {LUNDI:0, MARDI:1, MERCREDI:2, JEUDI:3, VENDREDI:4, SAMEDI:5, DIMANCHE:6};
  let filtreJourIndex = null; // null = semaine complète
  if (jourSel in mapJour) filtreJourIndex = mapJour[jourSel];
  else if (jourSel === "AUJOURDHUI") filtreJourIndex = getTodayJourIndex();

  const container = document.getElementById("cartesContainer");
  if (!container) return;
  container.innerHTML = "";

  // bornes semaine courante [lundi..dimanche]
  const aujourdHui = new Date(); aujourdHui.setHours(0,0,0,0);
  const lundi = new Date(aujourdHui);
  const corr = (lundi.getDay() === 0 ? -6 : 1 - lundi.getDay());
  lundi.setDate(lundi.getDate() + corr);
  lundi.setHours(0,0,0,0);

  const dimanche = new Date(lundi);
  dimanche.setDate(lundi.getDate() + 6);
  dimanche.setHours(23,59,59,999);

  const selectedDate = new Date(lundi);
  selectedDate.setDate(lundi.getDate() + currentJourIndex);
  selectedDate.setHours(0,0,0,0);

  // ===== Chargement validations depuis IndexedDB =====
  let lieuxHebdo = [];
  try {
    const data = await getPrefixedItem("lieuxHebdo");
    lieuxHebdo = JSON.parse(data || "[]");
  } catch {}

  // Set des codes vus et map code -> [dates normalisées]
  const validatedSet = new Set();
  const validations = new Map();
  const norm = (v) => String(v ?? "").trim().replace(/\s+/g, "");
  const pickCode = (entry) => {
    if (!entry || typeof entry !== "object") return "";
    return norm(
      entry.code ??
      entry.codeFiche ??
      entry["Numéro de fiche"] ??
      entry.numero ??
      entry.id ??
      entry.Id ??
      ""
    );
  };

  lieuxHebdo.forEach(entry => {
    const codeN = pickCode(entry);
    if (!codeN) return;
    validatedSet.add(codeN);
    if (entry.date) {
      const d = new Date(entry.date);
      if (!Number.isNaN(d.getTime())) {
        d.setHours(0,0,0,0);
        if (!validations.has(codeN)) validations.set(codeN, []);
        validations.get(codeN).push(d);
      }
    }
  });

  // ===== Helpers validations =====
  const getValidations = (code) => validations.get(norm(code)) || [];
  const aUneValidationQuelconque = (code) => validatedSet.has(norm(code));
  const estValideDansMois = (code, y, m) =>
    getValidations(code).some(d => d.getFullYear() === y && d.getMonth() === m);

  function mondayOf(d) {
    const x = new Date(d); x.setHours(0,0,0,0);
    const c = (x.getDay() === 0 ? -6 : 1 - x.getDay());
    x.setDate(x.getDate() + c);
    return x;
  }
  const estFiniExact = (code, dateJour) =>
    getValidations(code).some(d => d.getTime() === dateJour.getTime());

  const estFiniSemaine = (code) =>
    getValidations(code).some(d => d >= lundi && d <= dimanche);

  // ===== Logique Mensuelle =====
  function estFiniMensuel(code, dateJour) {
    const y = dateJour.getFullYear();
    const m = dateJour.getMonth();
    if (estValideDansMois(code, y, m)) return true;

    const lastPrev = new Date(y, m, 0); // dernier jour du mois précédent
    const prevY = lastPrev.getFullYear();
    const prevM = lastPrev.getMonth();
    if (!estValideDansMois(code, prevY, prevM)) return false;

    const ws = mondayOf(lastPrev); ws.setHours(0,0,0,0);
    const we = new Date(ws); we.setDate(ws.getDate() + 6); we.setHours(23,59,59,999);
    return (dateJour >= ws && dateJour <= we);
  }

  function afficherBoutonLancerMensuel(code, dateRef) {
    const y = dateRef.getFullYear();
    const m = dateRef.getMonth();
    const lastPrev = new Date(y, m, 0);
    const ws = mondayOf(lastPrev); ws.setHours(0,0,0,0);
    const we = new Date(ws); we.setDate(ws.getDate() + 6); we.setHours(23,59,59,999);

    const inOverlapWeek = (dateRef >= ws && dateRef <= we);
    const validPrev = estValideDansMois(code, lastPrev.getFullYear(), lastPrev.getMonth());
    const validCurr = estValideDansMois(code, y, m);
    return inOverlapWeek && validPrev && !validCurr;
  }

  // Règles FINI/Lancer
  const estFiniPour = (bloc, dateJour) => {
    if (!isMensuelBloc(bloc)) {
      if (selected.toUpperCase() === "MATIN") return estFiniExact(bloc.codeFiche, dateJour);
      return estFiniSemaine(bloc.codeFiche);
    }
    if (aUneValidationQuelconque(bloc.codeFiche)) return true;
    return estFiniMensuel(bloc.codeFiche, dateJour);
  };

  const forceLancerPour = (bloc, dateJour) => {
    if (!isMensuelBloc(bloc)) return false;
    if (aUneValidationQuelconque(bloc.codeFiche) && dateJour.getDate() > 25) return true;
    return afficherBoutonLancerMensuel(bloc.codeFiche, dateJour);
  };

  // ===== Collecte des éléments en appliquant les filtres =====
  const elements = [];
  for (let i = 0; i < 7; i++) {
    if (filtreJourIndex !== null && i !== filtreJourIndex) continue;

    const jour = jours[i];
    const blocs = (planningData.blocs && planningData.blocs[jour]) || [];
    const dateJour = new Date(lundi);
    dateJour.setDate(lundi.getDate() + i);
    dateJour.setHours(0, 0, 0, 0);

    for (const b of blocs) {
      if (!b?.texte || b.texte.trim() === ".") continue;
      if (!b?.codeFiche) continue;
      b.codeFiche = norm(b.codeFiche);

      if (selected !== "TOUT") {
        if (selected.toUpperCase() === "MATIN") {
          if ((b.user || "").toUpperCase() !== "MATIN") continue;
          if (dateJour.getTime() !== selectedDate.getTime()) continue;
        } else {
          if (b.user !== selected) continue;
        }
      } else if ((b.user || "").toUpperCase() === "MATIN") continue;

      const fini = estFiniPour(b, dateJour);
      const badgeM = isMensuelBloc(b) && estValideDansMois(b.codeFiche, dateJour.getFullYear(), dateJour.getMonth());
      const fl = forceLancerPour(b, dateJour);

      elements.push({ b, dateJour, isFini: fini, badgeM, forceLancer: fl });
    }
  }

  elements.sort((x, y) => compareTitres(x.b, y.b));

  const wrapper = document.createElement("div");
  wrapper.innerHTML = `
    <h3>${
      filtreJourIndex === null
        ? (selected === "TOUT"
            ? "Toutes les fiches (hors MATIN)"
            : selected.toUpperCase() === "MATIN"
              ? "Fiches MATIN (jour sélectionné)"
              : "Fiches de " + selected + " (semaine)")
        : ("Fiches du " + jours[filtreJourIndex] + (selected==="TOUT" ? "" : " • " + selected))
    }</h3>
    <div id="listeUnique" class="section-content"></div>`;
  container.appendChild(wrapper);

  const content = wrapper.querySelector("#listeUnique");
  elements.forEach(({ b, isFini, badgeM, forceLancer }) =>
    content.appendChild(createCarte(b, isFini, badgeM, forceLancer))
  );

  changerCouleur?.();
  afterRenderCartes?.();
  await applyMensuelFiniFromHebdo();

applyContrastEffects();
}


async function changerJour(delta) {
  currentJourIndex = (currentJourIndex + delta + 7) % 7;
  const jourNom = jours[currentJourIndex];
  document.getElementById("jourAffichage").textContent = jourNom;
  document.getElementById("jourAffichageModal").textContent = jourNom;

  // met à jour le select si un jour précis est affiché
  const sel = document.getElementById("jourSelect");
  if (sel) {
    const rev = ["LUNDI","MARDI","MERCREDI","JEUDI","VENDREDI","SAMEDI","DIMANCHE"];
    if (sel.value !== "SEMAINE" && sel.value !== "AUJOURDHUI") {
      sel.value = rev[currentJourIndex];
    }
  }

  await applySavedSelectionForCurrentDay();
  afficherJour(currentJourIndex);
  afficherPlanning();
}


function afficherJour(index) {
  const jourNom = jours[index];
  document.getElementById("jourAffichage").textContent = jourNom;

  const param = planningData.parametres[jourNom];
  const blocs = planningData.blocs[jourNom] || [];
  const machines = planningData.machines || [];

  const startHour = param?.startHour ?? 8;
  const totalHours = param?.totalHours ?? 8;
  const pauseStart = param?.pauseStart ?? 12;
  const pauseEnd = param?.pauseEnd ?? 13;
  const divisions = 4;
  const pas = 1 / divisions;
  const nbCol = Math.ceil(totalHours * divisions);

  const thead = document.getElementById("planningHead");
  const tbody = document.getElementById("planningBody");
  thead.innerHTML = "";
  tbody.innerHTML = "";

  const head1 = document.createElement("tr");
  const head2 = document.createElement("tr");
  head1.innerHTML = '<th rowspan="2">Machine</th>';
  for (let h = 0; h < Math.ceil(totalHours); h++) {
    const th = document.createElement("th");
    th.colSpan = divisions;
    th.textContent = `${(Math.floor(startHour + h)) % 24}h`;
    head1.appendChild(th);
    for (let d = 0; d < divisions; d++) {
      const td = document.createElement("th");
      td.textContent = "";
      head2.appendChild(td);
    }
  }
  thead.append(head1, head2);

  machines.forEach((nom, rowIndex) => {
    const tr = document.createElement("tr");
    const tdLabel = document.createElement("td");
    tdLabel.textContent = nom;
    tr.appendChild(tdLabel);

    let cursor = 0;
    while (cursor < nbCol) {
      const bloc = blocs.find(b => b.ligne === rowIndex && b.start === cursor);
      const td = document.createElement("td");
      const currentHour = startHour + Math.floor(cursor / divisions) + (cursor % divisions) * pas;

      if (bloc) {
        td.colSpan = bloc.end - bloc.start + 1;
        td.textContent = bloc.texte;
 if (bloc.user) {
  td.classList.add(bloc.user);
  td.style.backgroundColor = colorFromUser(bloc.user, "HQ");
 }
        td.classList.add("merged");
        if (bloc.codeFiche) {
          td.style.cursor = "pointer";
          td.addEventListener("click", () => ouvrirIframe(bloc.codeFiche));
        }
        cursor = bloc.end + 1;
      } else {
  // Détermine les types
  const isExtra = cursor >= nbCol;
  const isBeforeStart = cursor < ((startHour % 1) * divisions);

  if (isExtra || isBeforeStart) {
    td.classList.add("hors-duree");
  } else {
    td.classList.add("editable");
  }

  cursor++;
}

      tr.appendChild(td);
    }

    tbody.appendChild(tr);
  });
}


const createCarte = (b, isFini = false, badgeM = false, forceLancer = false) => {
  const carte = document.createElement("div");
  carte.dataset.code = b.codeFiche || "";
  carte.dataset.titre = b.texte || "";
  carte.dataset.machine = ((planningData.machines || [])[b.ligne] || "");

  const resume = getResumeFiche(b.codeFiche) || "";
  carte.dataset.resume = resume;

  // Durée: infoprev d'abord, sinon largeur du bloc
  const info = (typeof infoprev === "object" && infoprev) ? infoprev[String(b.codeFiche || "").trim()] : null;
  const dureeTheoMin = info ? parseHeureTheoToMinutes(info["Heure de travail théorique"]) : null;
  const dureeBlocMin = (b.end - b.start + 1) * 15;
  const dureeMinutes = Number.isFinite(dureeTheoMin) ? dureeTheoMin : dureeBlocMin;

  const userTheorique = (b.user || "Non défini");

  const joursLoc = ["Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche"];
  const jourPref = joursLoc.find(jour => (planningData.blocs[jour] || []).includes(b)) || "N/A";

  carte.className = "carte-intervention" + (isFini ? " fini" : "");

  const userCouleur = colorFromUser(b.user || (document.getElementById("technicienSelect")?.value || "A"));
  carte.style.backgroundColor = isFini ? lightenColor(userCouleur, 40) : userCouleur;

  const titreAff = `${b.texte}`;
  const truncated = resume.length > 60 ? resume.slice(0, 57) + "..." : resume;

  const badgeHtml = badgeM ? `<span class="badge-mensuel" title="Mensuel validé ce mois">M</span>` : "";

  carte.innerHTML = `
    <div class="carte-header">
      ${badgeHtml}
      <strong>${titreAff}</strong> • ${(planningData.machines || [])[b.ligne] || ""}
    </div>
    <br>
    <em class="resume-ligne">${truncated}</em><br>
    <small> Tech ${userTheorique} - ${jourPref} </small><br>
    <small><strong>Durée estimée :</strong> ${formatMinutes(dureeMinutes)}</small>
    <div class="boutons-container">
      ${(!isFini || forceLancer) ? `<button onclick="ouvrirIframe('${b.codeFiche}')">Lancer</button>` : ""}
      <button onclick="afficherResumeModal('${b.codeFiche}', \`${resume}\`, ${dureeMinutes}, \`${titreAff}\`)">Résumé</button>
    </div>
  `;
  return carte;
};

// Supprime les balises HTML d'un titre
function stripTags(s){ return String(s || '').replace(/<[^>]*>/g, '').trim(); }

// Détecte une fiche mensuelle : code commence par "M" OU texte commence par "M"
function isMensuelBloc(bloc){
  const code = String(bloc?.codeFiche || '').trim();
  if (/^M\b/i.test(code)) return true;
  const txt = stripTags(bloc?.texte);
  return /^\s*M\b/i.test(txt);
}
function bindTechSelectChangeOnce(){
  const el = document.getElementById("technicienSelect");
  if (!el) return;
  if (el._boundChangeOnce) return;       // garde anti-doublon
  el._boundChangeOnce = true;

  el.addEventListener("change", async function(){
    const val = this.value;

    // verrouillage jours si MATIN, sinon rétablit la semaine
    if (String(val).toUpperCase() === "MATIN"){
      forceJourSelectTodayMode();
    } else {
      restoreJourSelectFullWeek();
    }

    // IMPORTANT: ne PAS rappeler applySavedSelectionForCurrentDay() ici
    // on respecte le choix utilisateur
    saveWeekTechPrefLS(val, currentJourIndex);

    // rafraîchis les vues
    afficherJour(currentJourIndex);
    afficherPlanning();
  });
}



document.getElementById("exportStartHour")?.addEventListener("keydown", function(e) {
  if (e.key === "," || e.key === "." || e.key === "e") e.preventDefault();
});
document.getElementById("exportEndHour")?.addEventListener("keydown", function(e) {
  if (e.key === "," || e.key === "." || e.key === "e") e.preventDefault();
});





function toggleSection(activeId) {
  const sections = ["aujourdhuiContent", "retardContent", "termineContent"];
  const icons = {
    "aujourdhuiContent": "toggle-icon-aujourdhui",
    "retardContent": "toggle-icon-retard", 
    "termineContent": "toggle-icon-termine"
  };

  sections.forEach(sectionId => {
    const content = document.getElementById(sectionId);
    const icon = document.getElementById(icons[sectionId]);
    const wrapper = content.closest(".section-wrapper");
    const placeholder = document.getElementById(`placeholder-${sectionId}`);

    if (sectionId === activeId) {
      const isVisible = content.style.display !== "none";
      content.style.display = isVisible ? "none" : "block";
      icon.textContent = isVisible ? "▲" : "▼";

      if (wrapper) wrapper.classList.toggle("fermee", isVisible);
      if (placeholder) {
        placeholder.innerHTML = '';
        if (isVisible) ajouterCarteVide(sectionId);
      }
    } else {
      content.style.display = "none";
      icon.textContent = "▲";
      if (wrapper) wrapper.classList.add("fermee");
      if (placeholder) ajouterCarteVide(sectionId);
    }
  });
}


function openSection(sectionId) {
  const section = document.getElementById(sectionId);
  const wrapper = section.closest(".section-wrapper");
  const placeholder = document.getElementById(`placeholder-${sectionId}`);
  const icon = document.getElementById(`toggle-icon-${sectionId.split('Content')[0]}`);

  section.style.display = "block";
  if (wrapper) wrapper.classList.remove("fermee");
  if (placeholder) placeholder.innerHTML = '';
  if (icon) icon.textContent = "▼";
}




function closeSection(sectionId) {
  const section = document.getElementById(sectionId);
  if (!section) return;

  section.style.display = "none";

  const icon = document.getElementById(`toggle-icon-${sectionId.split('Content')[0]}`);
  if (icon) icon.textContent = "▲";

  const wrapper = section.closest(".section-wrapper");
  const placeholder = document.getElementById(`placeholder-${sectionId}`);

  // Vérifie si la section a des cartes
  const hasCartes = section.querySelector(".carte-intervention");
  if (hasCartes && wrapper && placeholder) {
    wrapper.classList.add("fermee");
    ajouterCarteVide(sectionId);
  } else {
    if (wrapper) wrapper.classList.remove("fermee");
    if (placeholder) placeholder.innerHTML = '';
  }
}



function getResumeFiche(codeFiche) {
  for (const niveau1 of Object.values(arborescence)) {
    for (const niveau2 of Object.values(niveau1)) {
      for (const [key, value] of Object.entries(niveau2)) {
        if (value["Numéro de fiche"] === codeFiche) {
          return value["Résumé intervention"] || "";
        }
      }
    }
  }
  return "Résumé non trouvé.";
}
function afficherResumeModal(codeFiche, resume, duree, afficheTexte) {
  let modal = document.getElementById("modalResume");
  
  if (!modal) {
    modal = document.createElement("div");
    modal.id = "modalResume";
    modal.className = "modal"; 
    document.body.appendChild(modal);
  }

  modal.innerHTML = `
    <div class="modal-content">
      <span class="close" onclick="document.getElementById('modalResume').style.display='none'">&times;</span>
      <h3>Fiche n° ${codeFiche}</h3>
      <p>${afficheTexte}</p>
      <p>${resume}</p>
      <p><strong>Durée estimée :</strong> ${formatMinutes(Number(duree)||0)}</p>
      
      <button onclick="document.getElementById('modalResume').style.display='none'; ouvrirIframe('${codeFiche}')" style="background: green; color: white;">
        Lancer chrono
      </button>
      
      <button onclick="document.getElementById('modalResume').style.display='none'" style="background: #888; color: white;">
        Fermer
      </button>
    </div>
  `;

  modal.style.display = "block";
}


function convertTime(index, startHour = 0) {
  const heure = startHour + Math.floor(index / 4);
  const minutes = (index % 4) * 15;
  return `${Math.floor(heure % 24)}h${minutes.toString().padStart(2, "0")}`;
}

function ouvrirModalplann() {
  document.getElementById("modalPlanning").style.display = "block";
}

function fermerModalplann() {
  document.getElementById("modalPlanning").style.display = "none";
}


function ajouterCarteVide(sectionId) {
  const content = document.getElementById(sectionId);
  const placeholder = document.getElementById(`placeholder-${sectionId}`);
  const wrapper = content?.closest(".section-wrapper");
  if (!content || !placeholder || !wrapper) return;

  // Ne rien faire si la section ne contient aucune carte
  const aDesCartes = content.querySelector(".carte-intervention");
  if (!aDesCartes) {
    wrapper.classList.remove("fermee");
    placeholder.innerHTML = '';
    return;
  }

  // Couleur selon la section et le technicien
  const user = document.getElementById("technicienSelect")?.value || "A";
  let couleurFond = "#ffd6d6"; // Retard par défaut
 if (sectionId === "termineContent") {
   couleurFond = lightenColor(colorFromUser(user), 40);
 } else if (sectionId === "aujourdhuiContent") {
   couleurFond = colorFromUser(user);
 }

  // Création de la carte vide
  const carte = document.createElement("div");
  carte.className = "carte-intervention carte-vide";
  carte.style.backgroundColor = couleurFond;

  const overlay = document.createElement("div");
  overlay.className = "carte-vide-overlay";

  carte.appendChild(overlay);
  placeholder.innerHTML = '';
  placeholder.appendChild(carte);

  wrapper.classList.add("fermee");
}

function lightenColor(input, percent) {
  const hex = normalizeColor(input);
  const num = parseInt(hex.slice(1), 16);
  const r = Math.min(255, (num >> 16) + percent);
  const g = Math.min(255, ((num >> 8) & 0x00FF) + percent);
  const b = Math.min(255, (num & 0x0000FF) + percent);
  return `rgb(${r}, ${g}, ${b})`;
}



function ouvrirModalExportpng() {
  const jourNom = jours[currentJourIndex];
  const param = (planningData.parametres && planningData.parametres[jourNom]) || {};
  const startHour = parseFloat(param.startHour ?? 8) - 0.5;
  const totalHours = parseFloat(param.totalHours ?? 8);
  const endBase = startHour + totalHours - 0.5;

  const start = startHour;
  const end = startHour + totalHours;

  const startEl = document.getElementById("exportStartHour");
  const endEl = document.getElementById("exportEndHour");
  if (!startEl || !endEl) return;

  startEl.value = start;
  endEl.value = end;

  exportEndHourOrigine = endBase;
  valeurInitialeExport = endBase - startHour - 0.5;
  defautstart = startHour;

  genererPreviewExport();
  const modal = document.getElementById("modalExportpng");
  if (modal) modal.style.display = "block";
}




function genererPreviewExport() {
  const start = parseFloat(document.getElementById("exportStartHour")?.value);
  const end   = parseFloat(document.getElementById("exportEndHour")?.value);
  if (Number.isNaN(start) || Number.isNaN(end) || start >= end) { alert("Plage horaire invalide."); return; }

  const preview = document.getElementById("previewExport");
  if (!preview) return;
  preview.innerHTML = "";

  const sourceTable = document.getElementById("planningTable");
  if (!sourceTable) return;

  const tableClone = sourceTable.cloneNode(true);
  tableClone.id = "planningTableExport";
  tableClone.style.marginBottom = "10px";
  tableClone.querySelectorAll("button").forEach(btn => btn.remove());

  // Conversion heure -> index quart d’heure par rapport à defautstart
  const startIndex = Math.round((start - defautstart) * 4);
  const endIndex   = Math.round((end   - defautstart) * 4);

  const allRows = Array.from(tableClone.querySelectorAll("tr"));
  allRows.forEach((row) => {
    let colIndex = 0;
    const cells = Array.from(row.querySelectorAll("td, th"));
    cells.forEach(cell => {
      const span = cell.colSpan || 1;

      // Ne coupe jamais la première colonne "Machine"
      if (cell.cellIndex === 0) { colIndex += span; return; }

      const outLeft  = (colIndex + span) <= startIndex;
      const outRight = colIndex >= endIndex;

      if (outLeft || outRight) {
        cell.remove();
      }
      colIndex += span;
    });
  });

  // Conteneur centré
  const exportWrapper = document.createElement("div");
  exportWrapper.style.display = "flex";
  exportWrapper.style.flexDirection = "column";
  exportWrapper.style.alignItems = "center";
  exportWrapper.style.width = "fit-content";
  exportWrapper.style.margin = "0 auto";

  exportWrapper.appendChild(tableClone);

  // Barre de pied
  const footerBar = document.createElement("div");
  footerBar.style.display = "flex";
  footerBar.style.justifyContent = "space-between";
  footerBar.style.alignItems = "center";
  footerBar.style.width = tableClone.offsetWidth + "px";
  footerBar.style.fontSize = "14px";
  footerBar.style.gap = "10px";
  setTimeout(() => { footerBar.style.width = tableClone.offsetWidth + "px"; }, 0);

  // Légende techniciens
  const legend = document.createElement("div");
  legend.style.display = "flex";
  legend.style.flexWrap = "wrap";
  legend.style.alignItems = "center";
  legend.style.gap = "12px";

  const users = planningData.utilisateurs || {};
  for (const [nom, couleur] of Object.entries(users)) {
    if (nom.toUpperCase() === "PAUSE") continue;
    const item = document.createElement("div");
    item.style.display = "flex"; item.style.alignItems = "center"; item.style.gap = "5px";
    const colorBox = document.createElement("div");
    colorBox.style.width = "16px"; colorBox.style.height = "16px";
    colorBox.style.backgroundColor = normalizeColor(couleur);
    colorBox.style.border = "1px solid #000";
    const label = document.createElement("span"); label.textContent = nom;
    item.appendChild(colorBox); item.appendChild(label);
    legend.appendChild(item);
  }

  const titre = document.createElement("div");
  const jourNom = jours[currentJourIndex];
  titre.textContent = `Planning préventif - ${jourNom.toUpperCase()}`;
  titre.style.flex = "1"; titre.style.textAlign = "center";

  const dateExport = document.createElement("div");
  dateExport.textContent = new Date().toLocaleDateString("fr-FR");
  dateExport.style.whiteSpace = "nowrap";

  footerBar.appendChild(legend);
  footerBar.appendChild(titre);
  footerBar.appendChild(dateExport);

  exportWrapper.appendChild(footerBar);
  preview.appendChild(exportWrapper);
}



async function imprimerpng() {
  const sourceElement = document.querySelector("#previewExport > div");

  if (!sourceElement) {
    alert("Aucun contenu à exporter.");
    return;
  }

  const jourAffichageSpan = document.getElementById("jourAffichageModal");
  const jourNom = jourAffichageSpan ? jourAffichageSpan.textContent.toUpperCase() : "JOUR";
  const date = new Date();
  const jour = String(date.getDate()).padStart(2, "0");
  const mois = String(date.getMonth() + 1).padStart(2, "0");
  const annee = String(date.getFullYear()).slice(2);
  const nomFichier = `Planning-Prev-${jourNom}-${jour}-${mois}-${annee}.png`;

// 🎯 Scale dynamique entre 3 (large écran) et 8 (petit tableau)
const baseWidth = sourceElement.scrollWidth;
const minScale = 4;
const maxScale = 8;

// Seuils de largeur entre lesquels on ajuste le scale
const minWidth = 600;  // petite div → gros zoom
const maxWidth = 1800; // très large div → petit zoom

if (baseWidth <= minWidth) {
  scaleFactor = maxScale;
} else if (baseWidth >= maxWidth) {
  scaleFactor = minScale;
} else {
  const ratio = (baseWidth - minWidth) / (maxWidth - minWidth);
  scaleFactor = maxScale - ratio * (maxScale - minScale);
}

  const width = sourceElement.scrollWidth;
  const height = sourceElement.offsetHeight;

  // ✅ Clone sans gonfler sa taille logique
  const clone = sourceElement.cloneNode(true);
  clone.style.position = "absolute";
 clone.style.left = "-99999px";
  clone.style.top = "0";
  clone.style.background = "white";
  clone.style.transform = `scale(${scaleFactor})`;
  clone.style.transformOrigin = "top";
  clone.style.width = width + "px";
  clone.style.height = height + "px";
  clone.style.overflow = "visible";

  document.body.appendChild(clone);

  try {
    const blob = await domtoimage.toBlob(clone, {
      bgcolor: "white",
      width: width * scaleFactor,
      height: height * scaleFactor,
 
    });

    const blobUrl = URL.createObjectURL(blob);
    document.body.removeChild(clone);

    // 🔍 Affichage modal
    const container = document.createElement("div");
    container.style.position = "fixed";
    container.style.top = "0";
    container.style.left = "0";
    container.style.width = "100vw";
    container.style.height = "100vh";
    container.style.background = "rgba(0,0,0,0.95)";
    container.style.zIndex = "9999";
    container.style.display = "flex";
    container.style.flexDirection = "column";
    container.style.alignItems = "center";
    container.style.justifyContent = "center";
    container.style.padding = "20px";
    container.style.boxSizing = "border-box";

    const title = document.createElement("p");
    title.textContent = `Prévisualisation : ${nomFichier}`;
    const scaleInfo = document.createElement("p");
scaleInfo.textContent = `Facteur de zoom : ${scaleFactor.toFixed(2)}x`;
scaleInfo.style.color = "#ccc";
scaleInfo.style.fontSize = "0.9em";
scaleInfo.style.marginBottom = "15px";
scaleInfo.style.textAlign = "center";

    title.style.color = "white";
    title.style.fontWeight = "bold";
    title.style.marginBottom = "10px";
    title.style.textAlign = "center";

    const img = document.createElement("img");
    img.src = blobUrl;
    img.alt = nomFichier;
    img.style.maxWidth = "90vw";
    img.style.maxHeight = "70vh";
    img.style.border = "2px solid white";
    img.style.marginBottom = "15px";

    const buttonContainer = document.createElement("div");
    buttonContainer.style.display = "flex";
    buttonContainer.style.gap = "10px";

    const downloadBtn = document.createElement("button");
    downloadBtn.textContent = "📥 Télécharger";
    downloadBtn.style.padding = "10px 20px";
    downloadBtn.onclick = () => {
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = nomFichier;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };

    const closeBtn = document.createElement("button");
    closeBtn.textContent = "Fermer";
    closeBtn.style.padding = "10px 20px";
    closeBtn.onclick = () => {
      URL.revokeObjectURL(blobUrl);
      document.body.removeChild(container);
    };

    buttonContainer.appendChild(downloadBtn);
    buttonContainer.appendChild(closeBtn);

    container.appendChild(title);
    container.appendChild(scaleInfo); 
    container.appendChild(img);
    container.appendChild(buttonContainer);
    document.body.appendChild(container);

  } catch (err) {
    console.error("Erreur lors de la capture :", err);
    alert("Erreur lors de la capture de l'image.");
    if (document.body.contains(clone)) document.body.removeChild(clone);
  }
}


document.getElementById("exportStartHour").addEventListener("keydown", function(e) {
  if (e.key === "," || e.key === "." || e.key === "e") {
    e.preventDefault();
  }
});

document.getElementById("exportEndHour").addEventListener("keydown", function(e) {
  if (e.key === "," || e.key === "." || e.key === "e") {
    e.preventDefault();
  }
});

function normalizeColor(input) {
  let c = input;
  if (c && typeof c === "object") c = c.HQ || c.base || "#cccccc";
  if (typeof c !== "string") c = String(c || "#cccccc");
  c = c.trim();

  // rgb(r,g,b) -> hex
  if (c.toLowerCase().startsWith("rgb(")) {
    const m = /rgb\((\d+),\s*(\d+),\s*(\d+)\)/i.exec(c);
    if (m) {
      const toHex = v => Math.max(0, Math.min(255, +v)).toString(16).padStart(2, "0");
      return `#${toHex(m[1])}${toHex(m[2])}${toHex(m[3])}`;
    }
    return "#cccccc";
  }

  // "aabbcc" -> "#aabbcc", "#abc" -> "#aabbcc"
  if (!c.startsWith("#")) c = "#" + c;
  let hex = c.slice(1);
  if (hex.length === 3) hex = hex.split("").map(ch => ch + ch).join("");
  if (hex.length !== 6) return "#cccccc";
  return ("#" + hex).toLowerCase();
}
function colorFromUser(user, freq = "HQ") {
  const u = (planningData && planningData.utilisateurs) ? planningData.utilisateurs[user] : null;
  if (!u) return "#cccccc";
  if (typeof u === "string") return normalizeColor(u);
  return normalizeColor(u[freq] || u.HQ || u.base || "#cccccc");
}
function parseTitreOrdre(t) {
  const res = { J: [Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY],
                H: [Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY],
                M: [Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY] };
  if (!t) return res;
  const titre = String(t).replace(/^[A-Za-zÀ-ÿ]+ *:\s*/,'').trim();
  const rx = /([JHM])\s*(\d)\s*-\s*(\d)/gi;
  let m;
  while ((m = rx.exec(titre))) {
    const L = m[1].toUpperCase();
    const a = parseInt(m[2], 10), b = parseInt(m[3], 10);
    if (Number.isInteger(a) && Number.isInteger(b)) res[L] = [a, b];
  }
  return res;
}

function compareTitres(a, b) {
  const ta = parseTitreOrdre(a?.texte);
  const tb = parseTitreOrdre(b?.texte);
  const order = ['J','H','M'];
  for (const L of order) {
    if (ta[L][0] !== tb[L][0]) return ta[L][0] - tb[L][0];
    if (ta[L][1] !== tb[L][1]) return ta[L][1] - tb[L][1];
  }
  const sa = (a?.texte || '').localeCompare(b?.texte || '', 'fr', {numeric:true});
  if (sa !== 0) return sa;
  return (a?.codeFiche || '').localeCompare(b?.codeFiche || '', 'fr', {numeric:true});
}
// Comparateur: J(a,b) puis H(a,b) puis M(a,b), puis fallback sur texte
function compareTitres(a, b) {
  const ta = parseTitreOrdre(a?.texte);
  const tb = parseTitreOrdre(b?.texte);
  const order = ['J','H','M'];
  for (const L of order) {
    if (ta[L][0] !== tb[L][0]) return ta[L][0] - tb[L][0];
    if (ta[L][1] !== tb[L][1]) return ta[L][1] - tb[L][1];
  }
  // fallback stable
  const sa = (a?.texte || '').localeCompare(b?.texte || '', 'fr', {numeric:true});
  if (sa !== 0) return sa;
  return (a?.codeFiche || '').localeCompare(b?.codeFiche || '', 'fr', {numeric:true});
}

/* ==== RECHERCHE CARTES — BLOC COMPLET AUTONOME ==== */

// État interne
let _rechResults = [];
let _rechIndex = -1;
let _rechDebounce = null;
const RECH_DEBOUNCE_MS = 150;

// --- Utils ---
function _rechNormalize(str){
  return (str || "")
    .toString()
    .normalize("NFD").replace(/[\u0300-\u036f]/g,"")
    .toLowerCase()
    .trim();
}
function _rechClearHighlights(){
  document.querySelectorAll(".carte-intervention.highlight-rech, .carte-intervention.pulse-focus")
    .forEach(el => el.classList.remove("highlight-rech","pulse-focus"));
}
function _rechCollect(){
  // toutes les cartes actuellement rendues
  return Array.from(document.querySelectorAll("#cartesContainer .carte-intervention"));
}
function _rechFilter(query){
  const q = _rechNormalize(query);
  if (!q) return [];
  const cards = _rechCollect();
  return cards.filter(card=>{
    const hay =
      _rechNormalize(card.dataset.machine) + " " +
      _rechNormalize(card.dataset.titre)   + " " +
      _rechNormalize(card.dataset.code)    + " " +
      _rechNormalize(card.dataset.resume)  + " " +
      _rechNormalize(card.innerText);
    return hay.includes(q);
  });
}
function _rechUpdateCounter(){
  const cnt = document.getElementById("rechCount");
  if (!cnt) return;
  if (_rechResults.length === 0){ cnt.textContent = "0/0"; return; }
  cnt.textContent = `${_rechIndex+1}/${_rechResults.length}`;
}
function _rechFocus(idx){
  if (_rechResults.length === 0) return;
  _rechIndex = (idx + _rechResults.length) % _rechResults.length;
  const el = _rechResults[_rechIndex];
  _rechClearHighlights();
  el.classList.add("highlight-rech","pulse-focus");
  el.scrollIntoView({ behavior: "smooth", block: "center" });
  _rechUpdateCounter();
}
function _rechRun(query){
  _rechResults = _rechFilter(query);
  _rechIndex = -1;
  if (_rechResults.length > 0){ _rechFocus(0); } else { _rechClearHighlights(); }
  _rechUpdateCounter();
}

// --- Création / montage de la barre s'il le faut ---
function _rechEnsureBar(){
  if (document.getElementById("rechCartesWrap")) return; // déjà présent

  const select = document.getElementById("technicienSelect");
  const anchor = select?.parentElement || document.querySelector("#plannTab .container") || document.body;

  // wrapper
  const wrap = document.createElement("div");
  wrap.id = "rechCartesWrap";
  wrap.className = "rech-cartes";
  wrap.innerHTML = `
    <input id="rechCartesInput" type="text" placeholder="Rechercher une carte (machine, titre, résumé, code)…" />
    <div class="rech-actions">
      <button id="rechPrev" title="Carte précédente (Shift+Entrée)">⬅️</button>
      <span id="rechCount">0/0</span>
      <button id="rechNext" title="Carte suivante (Entrée)">➡️</button>
      <button id="rechClear" title="Effacer">❌</button>
    </div>
  `;

  // Insère juste avant le select si possible, sinon tout en haut du container
  if (select && anchor) {
    anchor.insertBefore(wrap, select);
  } else {
    anchor.prepend(wrap);
  }
}

function _rechBindEvents(){
  const input   = document.getElementById("rechCartesInput");
  const btnPrev = document.getElementById("rechPrev");
  const btnNext = document.getElementById("rechNext");
  const btnClear= document.getElementById("rechClear");

  if (!input) return;

  // Evite le double-binding sur l'input
  if (!input._rechBound) {
    input._rechBound = true;

    input.addEventListener("input", ()=>{
      const val = input.value;
      clearTimeout(_rechDebounce);
      _rechDebounce = setTimeout(()=>_rechRun(val), RECH_DEBOUNCE_MS);
    });

    input.addEventListener("keydown",(e)=>{
      if (e.key === "Enter"){
        if (_rechResults.length){
          if (e.shiftKey) _rechFocus(_rechIndex - 1);
          else            _rechFocus(_rechIndex + 1);
        }
        e.preventDefault();
      } else if (e.key === "Escape"){
        input.value = "";
        _rechResults = []; _rechIndex = -1;
        _rechClearHighlights(); _rechUpdateCounter();
      }
    });
  }

  if (btnPrev && !btnPrev._rechBound){
    btnPrev._rechBound = true;
    btnPrev.addEventListener("click", ()=>{ if (_rechResults.length) _rechFocus(_rechIndex - 1); });
  }
  if (btnNext && !btnNext._rechBound){
    btnNext._rechBound = true;
    btnNext.addEventListener("click", ()=>{ if (_rechResults.length) _rechFocus(_rechIndex + 1); });
  }
  if (btnClear && !btnClear._rechBound){
    btnClear._rechBound = true;
    btnClear.addEventListener("click", ()=>{
      const input = document.getElementById("rechCartesInput");
      if (!input) return;
      input.value = "";
      _rechResults = []; _rechIndex = -1;
      _rechClearHighlights(); _rechUpdateCounter();
      input.focus();
    });
  }

  // Recalcule quand on change de technicien — bindé une seule fois
  const sel = document.getElementById("technicienSelect");
  if (sel && !sel._rechChangeBound){
    sel._rechChangeBound = true;
    sel.addEventListener("change", ()=>{
      setTimeout(()=>{
        const v = document.getElementById("rechCartesInput")?.value || "";
        _rechRun(v);
      }, 0);
    });
  }
}


// --- API publique à appeler ---
// 1) À appeler UNE FOIS après le DOM prêt (ou à la fin de ton fichier)
function initRechercheCartes(){
  _rechEnsureBar();
  _rechBindEvents();
  // lancement à vide
  const v = document.getElementById("rechCartesInput")?.value || "";
  _rechRun(v);
}

// 2) À appeler APRÈS CHAQUE RENDU de cartes (à la fin d'afficherPlanning)
function afterRenderCartes(){
  _rechEnsureBar();
  _rechBindEvents();
  const v = document.getElementById("rechCartesInput")?.value || "";
  _rechRun(v);
}

// Auto-init si le DOM est déjà prêt, sinon sur event
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initRechercheCartes, { once:true });
} else {
  initRechercheCartes();
}


// ====== PERSISTENCE EN LOCALSTORAGE (par semaine) ======

// Lundi 00:00 de la semaine de d
function getMonday(d = new Date()) {
  const x = new Date(d);
  x.setHours(0,0,0,0);
  const day = x.getDay(); // dim=0..sam=6
  const corr = (day === 0 ? -6 : 1 - day);
  x.setDate(x.getDate() + corr);
  return x;
}
function ymd(date){
  const y = date.getFullYear();
  const m = String(date.getMonth()+1).padStart(2,'0');
  const d = String(date.getDate()).padStart(2,'0');
  return `${y}-${m}-${d}`;
}
function weekKeyFor(d = new Date()){
  return `techSelect:${ymd(getMonday(d))}`; // ex: techSelect:2025-11-03
}

// Charge/Enregistre dans localStorage
function loadWeekTechPrefLS() {
  try {
    const raw = localStorage.getItem(weekKeyFor());
    return raw ? JSON.parse(raw) : null; // { last, lastDayIndex, ts }
  } catch { return null; }
}
function saveWeekTechPrefLS(value, dayIndex) {
  const payload = { last: String(value || ""), lastDayIndex: Number(dayIndex)||0, ts: Date.now() };
  try { localStorage.setItem(weekKeyFor(), JSON.stringify(payload)); } catch {}
}

// Règles: Lundi reset, si MATIN choisi >= vendredi → sam/dim = MATIN
function computeDefaultTechForDay(weekPref, dayIndex) {
  if (dayIndex === 0) return "TOUT"; // Lundi → reset

  if (weekPref && (weekPref.last || weekPref.last === "")) {
    const last = String(weekPref.last);
    const lastIdx = Number(weekPref.lastDayIndex)||0;

    if (last.toUpperCase() === "MATIN" && lastIdx >= 4) { // 4 = vendredi
      if (dayIndex === 5 || dayIndex === 6) return "MATIN"; // sam/dim
    }
    return last || "TOUT";
  }
  return "TOUT";
}

async function applySavedSelectionForCurrentDay(setUI = true) {
  const sel = document.getElementById("technicienSelect");
  if (!sel) return;

  const weekPref = loadWeekTechPrefLS();
  const defVal = computeDefaultTechForDay(weekPref, currentJourIndex);

  if (setUI) {
    const exists = Array.from(sel.options).some(o => o.value === defVal);
    sel.value = exists ? defVal : "TOUT";
  }

  saveWeekTechPrefLS(sel.value, currentJourIndex);
}


// Parse "Heure de travail théorique" -> minutes
function parseHeureTheoToMinutes(v) {
  if (v == null) return null;
  if (typeof v === "number" && Number.isFinite(v)) return Math.round(v); // minutes

  const s = String(v).trim().toLowerCase().replace(/,/g, "."); // "2:00", "2h30", "2.5h", "150", "10 min"
  if (!s) return null;

  // HH:MM
  let m = /^(\d+):(\d{1,2})$/.exec(s);
  if (m) {
    const h = parseInt(m[1], 10), mi = parseInt(m[2], 10);
    if (Number.isInteger(h) && Number.isInteger(mi)) return h * 60 + mi;
  }

  // XhY, Xh, X h YY, etc.
  m = /^(\d+(?:\.\d+)?)\s*h(?:\s*(\d{1,2}))?$/.exec(s);
  if (m) {
    const h = parseFloat(m[1]);
    const mi = m[2] ? parseInt(m[2], 10) : 0;
    return Math.round(h * 60) + (Number.isInteger(mi) ? mi : 0);
  }

  // minutes explicites
  m = /^(\d+(?:\.\d+)?)\s*(?:min|m)$/.exec(s);
  if (m) return Math.round(parseFloat(m[1]));

  // nombre nu: par défaut minutes. Si décimal, heures.
  if (/^\d+(?:\.\d+)?$/.test(s)) {
    const n = parseFloat(s);
    if (!Number.isFinite(n)) return null;
    if (s.includes(".")) return Math.round(n * 60); // décimal → heures
    return Math.round(n); // entier → minutes
  }

  return null;
}

function formatMinutes(mm) {
  const h = Math.floor(mm / 60);
  const m = mm % 60;
  return `${h}h${m.toString().padStart(2, "0")}min`;
}


function buildJourSelectOptions(){
  const sel = document.getElementById("jourSelect");
  if (!sel) return;
  if (sel._filled) return;
  sel._filled = true;

  sel.innerHTML = "";

  const todayIdx = getTodayJourIndex(); // 0=lundi..6=dimanche
  const keys = ["LUNDI","MARDI","MERCREDI","JEUDI","VENDREDI","SAMEDI","DIMANCHE"];
  const labels = ["Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche"];

  // 1) Toute la semaine
  let op = document.createElement("option");
  op.value = "SEMAINE"; op.textContent = "Toute la semaine";
  sel.appendChild(op);

  // 2) Aujourd'hui
  op = document.createElement("option");
  op.value = "AUJOURDHUI"; op.textContent = "Aujourd'hui";
  sel.appendChild(op);

  // 3) Tous les jours sauf aujourd'hui
  for (let i=0;i<7;i++){
    if (i === todayIdx) continue;
    const o = document.createElement("option");
    o.value = keys[i]; o.textContent = labels[i];
    sel.appendChild(o);
  }

  // par défaut: semaine entière
  sel.value = "SEMAINE";
}

function bindJourSelectChangeOnce(){
  const sel = document.getElementById("jourSelect");
  if (!sel || sel._bound) return;
  sel._bound = true;

  sel.addEventListener("change", async function(){
    const map = {LUNDI:0, MARDI:1, MERCREDI:2, JEUDI:3, VENDREDI:4, SAMEDI:5, DIMANCHE:6};

    if (this.value in map){
      currentJourIndex = map[this.value];
      const jourNom = jours[currentJourIndex];
      document.getElementById("jourAffichage").textContent = jourNom;
      document.getElementById("jourAffichageModal").textContent = jourNom;
      await applySavedSelectionForCurrentDay();
      afficherJour(currentJourIndex);
    } else if (this.value === "AUJOURDHUI"){
      currentJourIndex = getTodayJourIndex();
      const jourNom = jours[currentJourIndex];
      document.getElementById("jourAffichage").textContent = jourNom;
      document.getElementById("jourAffichageModal").textContent = jourNom;
      await applySavedSelectionForCurrentDay();
      afficherJour(currentJourIndex);
    } else if (this.value === "SEMAINE"){
      // vue semaine → ne pas modifier currentJourIndex, juste rafraîchir la liste
    }

    afficherPlanning();
  });
}


// 0=lundi..6=dimanche comme currentJourIndex
function getTodayJourIndex(){
  return (new Date().getDay() + 6) % 7;
}

function forceJourSelectTodayMode(){
  const sel = document.getElementById("jourSelect");
  if (!sel) return;

  // verrouillage sur "AUJOURD'HUI" sans autre choix
  sel.innerHTML = "";
  const op = document.createElement("option");
  op.value = "AUJOURDHUI";
  op.textContent = "Aujourd'hui";
  sel.appendChild(op);
  sel.value = "AUJOURDHUI";
  sel.disabled = true;

  // synchronise l’affichage de jour
  currentJourIndex = getTodayJourIndex();
  const jourNom = jours[currentJourIndex];
  const a = document.getElementById("jourAffichage");
  const b = document.getElementById("jourAffichageModal");
  if (a) a.textContent = jourNom;
  if (b) b.textContent = jourNom;
}

function restoreJourSelectFullWeek(){
  const sel = document.getElementById("jourSelect");
  if (!sel) return;

  // réactive et rebâtit toutes les options
  sel.disabled = false;
  sel._filled = false;           // important pour autoriser le rebuild
  buildJourSelectOptions();      // remet SEMAINE, AUJOURD'HUI, jours
  sel.value = "SEMAINE";
}

function syncJourSelectModeWithTech(){
  const techSel = document.getElementById("technicienSelect");
  if (!techSel) return;
  const val = String(techSel.value || "");
  if (val.toUpperCase() === "MATIN"){
    forceJourSelectTodayMode();
  } else {
    restoreJourSelectFullWeek();
  }
}
