



function deepClone(obj) { return JSON.parse(JSON.stringify(obj)); }

async function afficherModalEditionDate(enregistrement, enregistrements) {
    const modalDiv = document.createElement('div');
    modalDiv.className = 'modal';
    modalDiv.style.display = 'block';

    // Convertir la date au format YYYY-MM-DD pour l'input date
    const dateParts = enregistrement.date.split('/');
    const dateFormatted = `${dateParts[2]}-${dateParts[1].padStart(2, '0')}-${dateParts[0].padStart(2, '0')}`;

    // Date maximale et minimale
    const text = date_LM;  // Assume `date_LM` is defined and holds the max allowable date as string
    const maxDate = text.trim(); 
    const maxDateObj = new Date(maxDate);
    const maxDateMs = maxDateObj.getTime();
    const oneDayMs = 3 * 24 * 60 * 60 * 1000;
    const add = maxDateMs - oneDayMs;
    const minDateObj = new Date(add);
    const minDate = minDateObj.toISOString().split('T')[0];
    const todayFormatted = new Date().toISOString().split('T')[0];

    
    modalDiv.innerHTML = `
        <div class="modal-content">
            <span class="close-button" onclick="fermerModal(this)">&times;</span>
            <h2>Modifier les détails</h2>
            <div>
                <label for="dateInput">Date : (Merci de ne pas revenir avant le ${minDate})</label>
                <input type="date" id="dateInput" value="${dateFormatted}" min="${minDate}" max="${todayFormatted}">
            </div>
            <div>
                <label for="resumeInput">Résumé :</label>
                <input type="text" id="resumeInput" value="${enregistrement.zoneTexte2}">
            </div>
            <div>
                <label for="typePanneSelect">Compteur :</label>
                <input type="text" id="typePanneSelect" value="${enregistrement.zoneTexte4}"></input>
            </div>
            <div>
                <label for="causePanneSelect" style="display: none;">Cause de la panne :</label>
                <input id="causePanneSelect" style="display: none;"></input>
            </div>
            <div>
                <label for="tempsArretInput">Temps d'arrêt (hh:mm) :</label>
                <input type="time" id="tempsArretInput" value="${enregistrement.zoneTexte6}">
            </div>
            <br>
            <button id="modifierDateButton">Modifier</button>
        </div>
    `;

    document.body.appendChild(modalDiv);

    // Ajout de l'événement pour modifier les valeurs
modalDiv.querySelector('#modifierDateButton').addEventListener('click', async () => {
    const newDate = modalDiv.querySelector('#dateInput').value;
    if (new Date(newDate) < new Date(minDate) || new Date(newDate) > new Date(todayFormatted)) {
        alert("La date sélectionnée est hors des limites autorisées.");
        return;
    }
    // On applique le remplacement au moment de lire les inputs :
    const newResume = remplacerPlusUnicode(modalDiv.querySelector('#resumeInput').value);
    const newType = remplacerPlusUnicode(modalDiv.querySelector('#typePanneSelect').value);
    const newCause = remplacerPlusUnicode(modalDiv.querySelector('#causePanneSelect').value);
    const newTempsArret = modalDiv.querySelector('#tempsArretInput').value;

    const [year, month, day] = newDate.split('-');
    const formattedDate = `${day}/${month}/${year}`;

    const groupeEnregistrements = enregistrements.filter(e => e.id === enregistrement.id);
    groupeEnregistrements.forEach(enreg => {
        enreg.date = formattedDate;
        enreg.zoneTexte2 = newResume;
        enreg.zoneTexte4 = newType;
        enreg.zoneTexte5 = newCause;
        enreg.zoneTexte6 = newTempsArret;
    });

    await setPrefixedItem('enregistrements', JSON.stringify(enregistrements));
    afficherEnregistrements();
    fermerModal(modalDiv);
});

    changerCouleur();
}





