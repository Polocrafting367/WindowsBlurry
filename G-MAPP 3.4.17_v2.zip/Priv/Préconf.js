const preConfigurations = {
  
};