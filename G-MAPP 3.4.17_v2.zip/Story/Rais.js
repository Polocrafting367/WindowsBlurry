const lieuData = {
    types: [
],
    causes: [
] 
};

