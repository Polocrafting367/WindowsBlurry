# WindowsBlurry

Page HTML créée en partie avec des IA, le code n'est pas vraiment optimisé, mais je fais de mon mieux :)

À visualiser en ligne à cette adresse : [Blurry Windows](https://sites.google.com/view/polocrafting/blurry-windows)

![image](https://github.com/Polocrafting367/WindowsBlurry-1/blob/main/Images/Capture%20d'%C3%A9cran%202024-03-04%20212100.png?raw=true)


Chaîne YouTube : [Ma chaine Youtube](https://www.youtube.com/channel/UCTL3fXI8aZnYweRvys6m2bA)

J'ai perdu l'accès à mon ancien compte "polocrafting", mais je reste le créateur du projet. Je vais continuer son développement ici. Merci à [@Zerbaib](https://github.com/Zerbaib) pour sa petite contribution sur l'ancien projet et l'idée de séparer les fichiers pour une meilleure organisation.

## Changelog


[Changelog](changelog.txt)






