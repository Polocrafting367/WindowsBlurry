async function fetchUsers() {
    try {
        const response = await fetch('users.json');
        const data = await response.json();
        const users = Object.keys(data).map(key => ({
            username: key,
            password: data[key]
        }));
        displayUsers(users);
        populateUserSelect(users);
    } catch (error) {
        console.error('Erreur lors de la récupération des utilisateurs:', error);
    }
}

function displayUsers(users) {
    const userSection = document.getElementById('userSection');
    userSection.innerHTML = '';
    users.forEach(user => {
        if (user.username !== "Gestion") {
            const userDiv = document.createElement('div');
            userDiv.className = 'user-window';
            userDiv.innerHTML = `<h2>${user.username}</h2><p>Hash du mot de passe</p>`;
            userSection.appendChild(userDiv);
        }
    });
}

function populateUserSelect(users) {
    const userSelect = document.getElementById('userSelect');
    userSelect.innerHTML = '';
    users.forEach(user => {
        if (user.username !== "Gestion") {
            const option = document.createElement('option');
            option.value = user.username;
            option.textContent = user.username;
            userSelect.appendChild(option);
        }
    });
}

async function modifierMotDePasse() {
    const username = document.getElementById('userSelect').value;
    const newPassword = document.getElementById('newPassword').value;
    const feedback = document.getElementById('feedback');

    try {
        const response = await fetch('users.json');
        const users = await response.json();
        users[username] = newPassword; // Hash de mot de passe, ajout ou modification

        await fetch('updateUsers.json', { 
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(users)
        });

        feedback.textContent = 'Mot de passe modifié avec succès!';
        fetchUsers();
    } catch (error) {
        console.error('Erreur:', error);
        feedback.textContent = 'Erreur lors de la modification du mot de passe.';
    }
}

async function creerUtilisateur() {
    const username = document.getElementById('newUsername').value;
    const password = document.getElementById('createPassword').value;
    const feedback = document.getElementById('feedback');

    try {
        const response = await fetch('users.json');
        const users = await response.json();
        if (users.hasOwnProperty(username)) {
            feedback.textContent = 'Erreur: Utilisateur déjà existant.';
            return;
        }
        users[username] = password; // Hash de mot de passe

        await fetch('updateUsers.json', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(users)
        });

        feedback.textContent = 'Nouvel utilisateur créé avec succès!';
        fetchUsers();
    } catch (error) {
        console.error('Erreur:', error);
        feedback.textContent = 'Erreur lors de la création de l’utilisateur.';
    }
}

// Initialisation
fetchUsers();
