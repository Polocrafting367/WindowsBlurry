const lieuData = {
    types: ["Type 1", "Type 2", "Type 3"], // Remplacez les éléments par les types réels que vous souhaitez afficher
    causes: ["Cause 1", "Cause 2", "Cause 3"] // Remplacez les éléments par les causes réelles que vous souhaitez afficher
};