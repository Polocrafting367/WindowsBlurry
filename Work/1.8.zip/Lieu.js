const arborescence = {

        "linge sale": {
            "non triés": {
                "convoyeur inclinné": {                
                    "tapis": {},
                    "INC ..": {},
                },
                "Poste d'accrochage": {},
                "station déchargement (DU...)": {},
                "tampon stockage": {},
                "voie de stockage": {},
                "Tunnel de désinfection": {}
            },
            
            "triés": {
                "nappe industriel": {                
                    "alvéoles .. industriel": {},
                    "futurail industriel": {},
                    "aiguillage industriel": {},
                    "tapis industriel": {},
                    "Basculeur sling vide": {},
                    "Chargeur de sac (sling)": {},
                    "Redresseur sling vide": {},
                    "dechargeur tunnel ..": {},

                },

                "nappe résident": {                
                    "alvéoles .. résident": {},
                    "futurail résident": {},
                    "tapis résident": {},
                }


            }
        },
        "lavages": {
            "Lavage laveuses ": {},
            "Séchoirs manuels": {},
            "Lavage": {
                "tapis lavage industriel": {},
                "tapis lavage résident": {},
                "Ampicker": {},
                "Essoreuse kannegiesser": {},
                "Navette industriel (avant séchoir)": {},
                "Navette kannegiesser (avant séchoir)": {},
                "Presse jensen tunnel 10": {},
                "Presse lavatec tunnel 12": {},
                "Tunnel 10x35 kannegiesser": {},
                "Tunnel 10x50 LAVATEC industriel": {},
                "Tunnel 12x50 LAVATEC industriel": {}
              },
            "Séchage": {
                "Séchoirs industriels": {                
                    "Séchoir industriel n°1": {},
                    "Séchoir industriel n°2": {},
                    "Séchoir industriel n°3": {},
                    "Séchoir industriel n°4": {},
                    "Séchoir industriel n°5": {}
            },
                "Séchoirs résidents": {                    
                    "Séchoir résidents n°1": {},
                    "Séchoir résidents n°2": {},
                    "Séchoir résidents n°3": {},
                    "Séchoir résidents n°4": {},
                    "Séchoir résidents n°5": {}}
            },
            "Sodilec":{}
        },


        "Finition": {
            "Ligne grand plat GP": {                        
                "Cercleuse automatique grand plat GP": {},
                "Engageuse grand plat GP": {},
                "Plieuse classic grand plat GP": {},
                "Sécheuse repasseuse grand plat GP": {},
                "Empileur grand plat GP": {},
                "Tapis grand plat GP": {}
            },
            "Ligne petit plat PP": {                
                "Cercleuse automatique petit plat PP": {},
                "Engageuse petit plat PP": {},
                "Plieuse classic petit plat PP": {},
                "Plieuse napkin petit plat PP": {},
                "Sécheuse repasseuse petit plat PP": {},
                "Empileur petit plat PP": {}
            },
            "Ligne VT et non pucé": {
                "Convoyeurs et tapis": {},
                "Ligne de tri système Métricon": {
                    "Convoyeur à chaine Métricon M..": {                    
                        "Tri A": {},
                        "Tri B": {},
                        "Buffer": {}
                    },
                    "Mise sur cintre ": {                        
                        "Mise sur cintre 1": {},
                        "Mise sur cintre 2": {},
                        "Mise sur cintre 3": {},
                        "Mise sur cintre 4": {}
                    },
                    "Étiqueteuse VT": {},
                    "Filmeuse PP VT": {},
                    "Tunnel de finition": {},
                    "Tunnel de lecture ": {},
                    "Système informatique": {}

                },
                "Plieuses VT": {                        
                    "Plieuses VT Maximat 1": {},
                    "Plieuses VT Maximat 2": {}
                }
            },


        "Linge séché": {
            "Cercleuse indépendante": {                        
                "Cercleuse Lapaw": {},
                "Cercleuse Couverture": {}},
            "Plieuses couverture": {},
            " Ligne plieuses eponges": {
                "Maitre": {},
                "Esclave": {},
                "Cercleuse automatique éponges": {},
            },
            "Petit plat résident LAPAW": {                
                "Engageuse petit plat LAPAW": {},
                "Plieuse classic petit plat LAPAW": {},
                "Plieuse napkin petit plat LAPAW": {},
                "Sécheuse repasseuse petit plat LAPAW": {},
                "Empileur petit plat LAPAW": {}},
            "Pliage manuel": {},
            "Poste bipage 1": {},
            "Poste bipage 2": {},
            "Poste marquage": {},
            "Tapis": {}
            }



        },
         "Expedition": {
            "Étiqueteuse navette": {},            
            "Étiqueteuse QR code navette": {},
            "Poste de lecture (RAMSES)": {}

        },
         "Administratif": {},
         "Autres": {},
         "Batiment": {            
            "Sanitaires": {},            
            "Self": {},
            "Système d'alarme incendie": {}
        },
        "Magasin": {            
            "Imprimante étiquette CAB": {},            
            "Thermocolleuse Thermopatch": {},
            "Machine a coudre 1": {},
            "Imprimante étiquette CAB": {},            
            "Poste marquage 5 (vers caillebotis)": {}
        },
        "Technique": {            
            "local chaufferie": {},            
            " local eau": {            
                "Adoucisseur": {},
                "Dégrilleur": {},             
                "Surpresseur": {}
            },
            "Local electrique": {},
            "Local engin (expédition)": {},            
            " local lessiviel": {               
                "Armoire Flux-Multi (pompe laveuses)": {},
                "Armoire électrique Laundry X-Pert": {}            
            },
            "local Pneumatique": {               
                "Compresseur (droite côté CTA)": {},
                "Compresseur (gauche côté nappe résident)": {},
                "Sécheur d'air": {}
        },
            "local TGBT": {},
            "local ventilation": {},
        }
    
    
};