document.addEventListener("DOMContentLoaded", function () {
    chargerLieux();
    afficherEnregistrements();
    setDefaultTab();
});


if (!localStorage.getItem('lieuxEnregistres')) {
    localStorage.setItem('lieuxEnregistres', JSON.stringify([]));
}


let timers = {};
let lieuxState = {};

let globalPauseState = false;

        function formatTime(time) {
    return time < 10 ? '0' + time : time;
}



function chargerLieux() {
    const lieuxList = document.getElementById('lieux-list');
    const lieuxDropdown = document.getElementById('lieuxDropdown');

    // Charger les lieux enregistrés dans le localStorage
    const lieuxEnregistres = localStorage.getItem('lieuxEnregistres') || '';
    const lieuxEnregistresArray = lieuxEnregistres.split(',');

    lieuxList.innerHTML = '';

    // Traitement des lieux enregistrés dans le localStorage
    lieuxEnregistresArray.forEach(nomLieu => {
        if (nomLieu.trim() !== '' && nomLieu !== '[]') {
            const lieuItem = document.createElement('li');
            lieuItem.innerHTML = `<div class="place-card" onclick="ouvrirIframe('${nomLieu}')">
                                    <span class="pastille" id="pastille-${nomLieu}">${nomLieu}</span>
                                    <div class="iframe-container" id="iframe-container-${nomLieu}"></div>
                                </div>`;

            lieuxList.appendChild(lieuItem);

            const option = document.createElement('option');
            option.value = nomLieu;
            option.textContent = nomLieu;
            lieuxDropdown.appendChild(option);
        }
    });

    // Traitement des lieux définis dans le tableau
     const lieuxPredefinisArray = [
  "Accrochage",
  "Laveuses",
  "séchoir élécrtolux",
  "séchoir résident",
  "Linge Sale",
  "Alvéoles Linge Sale",
  "Slings",
  "Alvéoles résident",
  "Sings résident",
  "Linge Sale résident",
  "Futurail",
  "DU.",
  "CI.",
  "Redresseur Linge Sale",
  "Chargeur Linge Sale",
  "Tunnel 10",
  "Tunnel 12",
  "Tunnel Kanne",
  "séchoir Industriel lavatec",
  "Filmeuse",
  "Tunnel de lecture",
  "étiqueuteuse Filmeuse",
  "Expedition",
  "étiqueuteuse Expedition",
  "Navettes",
  "Grand Plat GP",
  "Cercleuse Petit plat GP",
  "Petit Plat PP",
  "Cercleuse Petit plat PP",
  "Maximat",
  "Metric",
  "TriA",
  "TriB",
  "Cintre Bloqué/Bourrage",
  "Tunnel de finition",
  "Tunnel de Désinfection",
  "Plieuse couverture",
  "Cercleuse couverture",
  "Plieuse eponge",
  "Cercleuse eponge",
  "Lapaw",
  "Cercleuse Lapaw",
  "Poste bipage",
  "étiqueuteuse bipage",
  "Direction",
  "Batiment",
  "Menage",
  "Informatique",
  "responsable",
  "Autre"
];


    lieuxPredefinisArray.forEach(nomLieu => {
        if (!lieuxEnregistresArray.includes(nomLieu) && nomLieu.trim() !== '' && nomLieu !== '[]') {
            const lieuItem = document.createElement('li');
            lieuItem.innerHTML = `<div class="place-card" onclick="ouvrirIframe('${nomLieu}')">
                                    <span class="pastille" id="pastille-${nomLieu}">${nomLieu}</span>
                                    <div class="iframe-container" id="iframe-container-${nomLieu}"></div>
                                </div>`;

            lieuxList.appendChild(lieuItem);
        }
    });
}


function supprimerLieu() {
    const lieuxDropdown = document.getElementById('lieuxDropdown');
    const selectedLieu = lieuxDropdown.value;

    if (selectedLieu) {
        // Ajoutez une confirmation avant de supprimer
        const confirmation = window.confirm("Êtes-vous sûr de vouloir supprimer ce lieu ?");
        
        if (confirmation) {
            // Supprimez l'élément sélectionné des cookies
            const lieuxEnregistres = localStorage.getItem('lieuxEnregistres') || '';
            
            // Convertir la chaîne en tableau en supprimant les espaces vides
            const lieuxEnregistresArray = lieuxEnregistres.split(',').filter(lieu => lieu.trim() !== '');

            const indexToRemove = lieuxEnregistresArray.indexOf(selectedLieu);

            if (indexToRemove !== -1) {
                lieuxEnregistresArray.splice(indexToRemove, 1);
                localStorage.setItem('lieuxEnregistres', lieuxEnregistresArray.join(','));

                // Rechargez la liste des lieux
                chargerLieux();

                // Mettez à jour la liste déroulante
                mettreAJourListeDeroulante(localStorage.getItem('lieuxEnregistres') || '');
            }
        }
    }
}






function afficherEnregistrements() {
    const enregistrementsDiv = document.getElementById('enregistrements');
    const enregistrements = localStorage.getItem('enregistrements');

    if (enregistrements) {
        enregistrementsDiv.innerHTML = enregistrements;
    }
}
function setDefaultTab() {
    // Ouvrir l'onglet "Créer" par défaut
    openTab('creer');
}

function openTab(tabName) {
    var i, tabcontent, tabbuttons;

    // Cacher tous les onglets
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Retirer la classe "active" de tous les boutons
    tabbuttons = document.getElementsByClassName("tab-button");
    for (i = 0; i < tabbuttons.length; i++) {
        tabbuttons[i].classList.remove("active");
    }

    // Afficher l'onglet sélectionné
    document.getElementById(tabName + "Tab").style.display = "block";

    // Ajouter la classe "active" au bouton correspondant
    document.getElementById(tabName + "Button").classList.add("active");
}


function ajouterLieu() {
    const nouveauLieuInput = document.getElementById('nouveauLieu');
    const nouveauLieu = nouveauLieuInput.value.trim();

    if (nouveauLieu !== '') {
        // Ajouter le nouveau lieu à localStorage
        const lieuxEnregistres = localStorage.getItem('lieuxEnregistres') || '';
        const nouveauxLieux = lieuxEnregistres + ',' + nouveauLieu;
        localStorage.setItem('lieuxEnregistres', nouveauxLieux);

        // Ajouter le nouveau lieu en haut de la liste lieux-list
        ajouterLieuEnHaut(nouveauLieu);

        // Mettre à jour la liste déroulante
        mettreAJourListeDeroulante(nouveauxLieux);

    }

    // Effacer le champ de saisie
    nouveauLieuInput.value = '';
}

function ajouterLieuEnHaut(nouveauLieu) {
    const lieuxList = document.getElementById('lieux-list');

    // Créer un nouvel élément li
    const lieuItem = document.createElement('li');
            lieuItem.innerHTML = `<div class="place-card" onclick="ouvrirIframe('${nouveauLieu}')">
                                    <span class="pastille" id="pastille-${nouveauLieu}">${nouveauLieu}</span>
                                    <div class="iframe-container" id="iframe-container-${nouveauLieu}"></div>
                                </div>`;

    // Insérer l'élément en haut de la liste lieux-list
    lieuxList.prepend(lieuItem);
}


function mettreAJourListeDeroulante(lieuxEnregistres) {
    const lieuxDropdown = document.getElementById('lieuxDropdown');

    // Effacer la liste déroulante actuelle
    lieuxDropdown.innerHTML = '';

    // Convertir la chaîne en tableau en supprimant les espaces vides
    const lieuxEnregistresArray = lieuxEnregistres.split(',').filter(lieu => lieu.trim() !== '');

    lieuxEnregistresArray.forEach(nomLieu => {
        // Ajouter seulement si le lieu n'est pas "[ ]"
        if (nomLieu !== "[]") {
            const option = document.createElement('option');
            option.value = nomLieu;
            option.textContent = nomLieu;
            lieuxDropdown.appendChild(option);
        }
    });
}




function supprimerTousLesCookies() {
    // Demandez une confirmation avant de supprimer tous les cookies
   const confirmation = window.confirm(
  "Êtes-vous sûr de vouloir supprimer tous les cookies ?\nLes interventions et lieux personnalisés seront supprimés"
);

    if (confirmation) {
        // Supprimez le cookie 'lieuxEnregistres'
        localStorage.removeItem('lieuxEnregistres');

        // Supprimez le cookie 'enregistrements'
        localStorage.removeItem('enregistrements');

        // Rafraîchissez la page ou mettez à jour l'affichage des enregistrements
        location.reload();

        // Affichez un message après la suppression des cookies
        alert("Tous les cookies ont été supprimés");
    }
}




function exportToTxt() {
    const enregistrementsDiv = document.getElementById('enregistrements');
    const enregistrementsData = enregistrementsDiv.innerText;

    // Créer un objet Date pour obtenir la date d'aujourd'hui
    const currentDate = new Date();
    const formattedDate = `${currentDate.getDate()}-${currentDate.getMonth() + 1}-${currentDate.getFullYear()}`;

    // Générer le contenu du fichier texte avec la date et les enregistrements
    const fileContent = `Export du ${formattedDate}\n\n${enregistrementsData}`;

    // Créer un objet Blob pour le contenu du fichier
    const blob = new Blob([fileContent], { type: 'text/plain' });

    // Créer un objet URL pour le Blob
    const url = URL.createObjectURL(blob);

    // Créer un élément de lien pour déclencher le téléchargement
    const link = document.createElement('a');
    link.href = url;
    link.download = `export_${formattedDate}.txt`;

    // Ajouter le lien à la page et déclencher le téléchargement
    document.body.appendChild(link);
    link.click();

    // Retirer le lien de la page une fois le téléchargement terminé
    document.body.removeChild(link);
}



function deleteCookies() {
    // Demander une confirmation avant de supprimer tous les enregistrements
    const confirmation = window.confirm("Êtes-vous sûr de vouloir supprimer tous les enregistrements ?");

    if (confirmation) {
        // Supprimer tous les enregistrements dans localStorage
        localStorage.removeItem('enregistrements');

        // Rafraîchir ou mettre à jour l'affichage des enregistrements
        location.reload();

        alert("Tous les enregistrements ont été supprimés");
    }
}

function toggleChronosState() {
    const lieuxList = document.getElementById('lieux-list');
    const lieuxItems = lieuxList.getElementsByTagName('li');
    const searchInput = document.getElementById('searchInput');

    if (isChronosActif) {
        // Mettre à jour la valeur de la zone de recherche avec "Actif"
        searchInput.value = 'actif';

        // Parcourir la liste des lieux
        for (let i = 0; i < lieuxItems.length; i++) {
            const lieuName = lieuxItems[i].innerText.toLowerCase();

            // Vérifier si le lieu contient "Actif" dans son nom
            if (lieuName.includes('actif')) {
                // Afficher l'élément
                lieuxItems[i].style.display = 'block';
                lieuxItems[i].classList.add('active');
            } else {
                // Cacher les éléments qui ne contiennent pas "Actif"
                lieuxItems[i].style.display = 'none';
                lieuxItems[i].classList.remove('active');
            }
        }

        // Mettre à jour le texte du bouton
        document.getElementById('toggleButton').innerText = 'Retour';

    } else {
        // Réinitialiser la recherche
        searchInput.value = '';

        // Afficher tous les éléments
        for (let i = 0; i < lieuxItems.length; i++) {
            lieuxItems[i].style.display = 'block';
            lieuxItems[i].classList.remove('active');
        }

        // Mettre à jour le texte du bouton
        document.getElementById('toggleButton').innerText = 'Chronos Actif';
    }

    // Inverser l'état
    isChronosActif = !isChronosActif;
}

